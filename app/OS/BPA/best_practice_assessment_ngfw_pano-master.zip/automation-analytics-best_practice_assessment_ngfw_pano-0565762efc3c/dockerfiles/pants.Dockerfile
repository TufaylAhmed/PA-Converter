FROM python:3.7.3
RUN apt-get update && apt-get install -y build-essential && apt-get clean
RUN pip install pipenv
WORKDIR /app
COPY ./Pipfile Pipfile
COPY ./Pipfile.lock Pipfile.lock
RUN pipenv install --dev --system
COPY . ./
RUN pip install .
ENV BPA_PANTS_MODE jenkins
CMD python -m pants.run
