import os


# Typical values are (local, jenkins)
PANTS_MODE = os.getenv("BPA_PANTS_MODE", "local").lower()

# Establish path variables
base_path = os.path.dirname(os.path.realpath(__file__))
failed_path = os.path.join(base_path, "failed_configs")
