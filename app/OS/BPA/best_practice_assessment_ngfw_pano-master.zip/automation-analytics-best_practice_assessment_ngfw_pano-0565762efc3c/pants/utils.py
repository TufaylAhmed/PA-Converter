import logging
import os
import sys
from collections import namedtuple
from concurrent import futures
from io import BytesIO
from tarfile import ReadError
from timeit import default_timer as timer
from typing import Optional

import pandas as pd
import requests
from lxml.etree import XMLSyntaxError
from pymysql.err import MySQLError
from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError

from bpa.controller import Controller
from bpa.models.tsf import TSFError
from . import failed_path, PANTS_MODE


LOG = logging.getLogger(__name__)


def get_pants_file(file_path) -> Optional[BytesIO]:
    """Query PANTS for the XML config or TGZ of a given ID.

    Args:
        file_path: File path of desired file.

    Returns:
        XML content if it was downloaded and parsed else None.
    """
    try:
        xml = requests.get(
            f"https://pants.paloaltonetworks.local/{file_path}",
            verify=False,
            timeout=15.0,
        )
        xml.raise_for_status()
        return BytesIO(xml.content)
    except (requests.exceptions.HTTPError, TimeoutError):
        LOG.warning("Network error while downloading file")
    except (TypeError, IOError):
        LOG.warning("Bytes error while parsing file")
    except BaseException:
        LOG.warning("Unknown error while querying file")
    return None


def get_metrics(row, start, exc_info):
    """Get metrics for a given row.

    Args:
        row: RecordRow instance.
        start: Starting time.
        exc_info: Exception information.

    Returns:
        Metrics dictionary from running BPA tool.
    """
    return {
        "err_class": exc_info[0].__name__ if exc_info else None,
        "pants_id": row.pants_id,
        "model": row.model,
        "serial_number": row.serial_number,
        "sw_version": row.sw_version,
        "time": round(timer() - start, 4),
    }


def run_bpat_from_tsf(record):
    """Run BPA report on given row.

    Creates a controller instance, generates BPA report
    and logs whether or not an error was encountered.

    Args:
        row: DataFrame entry.
        collector: Traceback collector.

    Returns:
        Execution metrics from running BPA report.
    """
    start = timer()

    RecordRow = namedtuple("RecordRow", record)
    row = RecordRow(**record)

    try:
        raw = get_pants_file(row.tsf_path)
        if raw is None:
            return get_metrics(row, start, None)
        controller = Controller.from_tsf(fileobj=raw)
        # NOTE: Switch between testing on local machine and CI server
        if PANTS_MODE == "local":
            controller.publisher_manager.get("executive_summary")
        else:
            controller.publisher_manager.get("report")
            controller.publisher_manager.get("executive_summary")
            controller.publisher_manager.get("failed_checks", documentation=[])
        return get_metrics(row, start, None)
    # Ignore race conditions or corrupt data
    except (ReadError, XMLSyntaxError, TSFError):
        return get_metrics(row, start, None)
    # Ignore intermittent SQL errors
    except (MySQLError, SQLAlchemyError):
        return get_metrics(row, start, None)
    # Ignore additional errors
    except (EOFError, TypeError, TimeoutError):
        return get_metrics(row, start, None)
    # Catch remaining errors as they are relevant to developers
    except BaseException:
        LOG.exception(
            f"{row.pants_id} | {row.model} | {row.serial_number} | {row.sw_version}\n\n"
        )
        # NOTE: Save failed input for local troubleshooting
        if PANTS_MODE == "local":
            with open(os.path.join(failed_path, f"{row.pants_id}.tgz"), "wb") as f:
                f.write(raw.read())
        return get_metrics(row, start, sys.exc_info())


def get_pants_ids():
    """Get PANTS identifiers.

    Expects environment variables for PANTS database. All of the config
    has a prefix of PANTS_* and should be straightforward to populate
    from a CI job.

    Returns:
        Pandas dataframe of all eligible PANTS IDs to test.
    """
    engine_meta = {
        "user": os.getenv("PANTS_USER"),
        "password": os.getenv("PANTS_PASS"),
        "host": os.getenv("PANTS_HOST"),
        "database": os.getenv("PANTS_DB"),
    }

    engine = create_engine(
        "mysql+pymysql://{user}:{password}@{host}:3306/{database}".format(**engine_meta)
    )

    # Only select un-archived files with a valid serial number and official sw version of 7+
    query = """
    select tsf.pants_id, tsf.filename as tsf_path, meta.model, meta.serial_number, meta.sw_version, min(f.filename) as file_path
    from pants_techsupportfile tsf
    inner join pants_techsupportfilemeta meta on tsf.id=meta.ts_file_id
    inner join pants_savedfile f on tsf.id = f.ts_file_id
    where meta.archived = 0
    and meta.sw_version REGEXP '^[7,8].[0-9]{1,2}.[0-9]{1,2}$'
    and meta.serial_number REGEXP '^[0-9A-Z]*$'
    and f.filename like '%%running-config.xml'
    and tsf.filename like '%%.tgz'
    group by tsf.pants_id, meta.model, meta.serial_number, meta.sw_version
    """
    return pd.read_sql_query(query, con=engine)


def get_percent(a, b):
    """Get percentage of two values.

    Args:
        a: First integer.
        b: Second integer.

    Returns:
        Percentage rounded to two decimals.
    """
    return round(a / b * 100, 2)


def run_workers(work, data, workers=4):
    """Run multiple threads for work function.

    Args:
        work: Function used for generating results.
        data: Iterable / collection to apply work on.
        workers: How many processes to use.

    Yields:
        Deferred result given as a generator output.
    """
    num_ran = 0
    num_total = len(data)
    with futures.ProcessPoolExecutor(max_workers=workers) as executor:
        future_to_result = {executor.submit(work, arg): arg for arg in data}
        for future in futures.as_completed(future_to_result):
            num_ran += 1
            # NOTE: Print every line if PANTS_MODE is local, otherwise every 25 lines
            factor = 1 if PANTS_MODE == "local" else 25
            if num_ran % factor == 0:
                logging.info(
                    "Completed {processed} of {total} tasks ({percent}%)".format(
                        processed=num_ran,
                        total=num_total,
                        percent=get_percent(num_ran, num_total),
                    )
                )
            yield future.result()
