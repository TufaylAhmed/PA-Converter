import logging

import urllib3
import pandas as pd

from . import PANTS_MODE
from .utils import run_bpat_from_tsf, run_workers, get_pants_ids, get_percent


# Ignore security hazard since certs SHOULD be trusted (https)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Set logging configuration
logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
LOG = logging.getLogger(__name__)


class TestPants:
    @staticmethod
    def get_message(lstr, rstr):
        return f'\n\n{lstr}\n{"=" * len(lstr)}\n\n{rstr}\n'

    @staticmethod
    def filter_entries(df):
        ignored_ids = {221_633}
        filtered_df = df[~df["pants_id"].isin(ignored_ids)]
        if PANTS_MODE == "local":
            filtered_df = filtered_df.groupby("sw_version").first().reset_index()
        return filtered_df.to_dict("records")

    def __call__(self):
        """Runs BPA against PANTS test suite."""
        records = self.filter_entries(get_pants_ids())
        results = run_workers(run_bpat_from_tsf, records)

        # Aggregate results
        coll_df = pd.DataFrame([result for result in results])
        bad_df = coll_df[coll_df["err_class"].notna()]

        # Timing metrics
        timing = coll_df["time"].describe()
        LOG.info(self.get_message("Timing metrics", timing))

        # Longest top_n
        top_n = 5
        top_df = coll_df.nlargest(top_n, "time")[["pants_id", "time"]]
        LOG.info(self.get_message(f"Top {top_n} running", top_df))

        if len(bad_df) == 0:
            return

        bad_pants_ids = bad_df["pants_id"]
        LOG.error(self.get_message("Error PANTS identifiers", bad_pants_ids))

        raise Exception(
            "{failed} of {total} tests failed ({percent}%)".format(
                failed=len(bad_df),
                total=len(coll_df),
                percent=get_percent(len(bad_df), len(coll_df)),
            )
        )


if __name__ == "__main__":
    pants = TestPants()
    pants()
