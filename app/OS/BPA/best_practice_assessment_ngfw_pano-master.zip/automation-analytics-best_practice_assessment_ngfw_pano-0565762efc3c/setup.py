from setuptools import setup, find_packages
from os import path
from io import open


here = path.abspath(path.dirname(__file__))

from bpa import __version__ as bpa_version

with open(path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

install_required = [
    "dataclasses",
    "iptools",
    "Jinja2",
    "lxml",
    "pandas>=0.22.0",
    "Pillow<=5.4.1",
    "PyMySQL",
    "reportlab<=3.5.18",
    "requests",
    "seaborn",
    "six",
    "SQLAlchemy",
    "xlrd",
    "XlsxWriter",
    "pendulum",
    "svglib<=0.9.0",
]

setup_required = ["pytest-runner"]

test_required = ["pytest", "pytest-cov"]

extra_required = {
    "mysql": ["mysqlclient", "PyMySQL"],
    "postgresql": ["psycopg2"],
    "postgresql_binary": ["psycopg2-binary"],
    "sql": ["SQLAlchemy"],
    "test": test_required,
}

setup(
    name="BPA",
    version=bpa_version,
    description="Generates data from analyzing PAN-OS device configuration",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Customer Success Tools",
    author_email="customersuccesstools@paloaltonetworks.com",
    packages=find_packages(exclude=("tests", "scripts", "legacy")),
    entry_points={
        "console_scripts": [
            "bpa-cli=bpa.cli:main",
            "bpa-legacy-cli=bpa.legacy.cli:main",
        ]
    },
    python_requires=">=3.6",
    install_requires=install_required,
    setup_requires=setup_required,
    tests_require=test_required,
    extras_require=extra_required,
    include_package_data=True,
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Environment :: Console",
        "Environment :: Web Environment",
        "Intended Audience :: Developers",
        "Topic :: Utilities",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
    ],
)
