"""
from unittest import mock
import pytest

from bpa.handlers.best_practice_assessment.bp_checks.device.dynamic_updates import DynamicUpdates


@pytest.mark.parametrize('test_input, expected', [
    ('every-30-mins', 'pass'),
    ('weekly', 'fail'),
])
def test_apps_threats_warn_recurrence(test_input, expected):
    with mock.patch.object(DynamicUpdates, "__init__", lambda a, b, c, d, e, f: None):
        with mock.patch.object(DynamicUpdates, 'apps_threats', new_callable=mock.PropertyMock) as mock_apps_threats:
            mock_apps_threats.return_value = mock.MagicMock(recurrence=test_input, action='download-and-install', threshold=0)
            apps_threats = DynamicUpdates(None, None, None, None, None)
            apps_threats.device_deployment_app_and_threat = None
            assert apps_threats.apps_threats_warn.result == expected


@pytest.mark.parametrize('test_input, expected', [
    (0, 'fail'),
    (1, 'pass'),
])
def test_apps_and_threats_app_id_threshold_warn(test_input, expected):
    with mock.patch.object(DynamicUpdates, "__init__", lambda a, b, c, d, e, f: None):
        with mock.patch.object(DynamicUpdates, 'apps_threats', new_callable=mock.PropertyMock) as mock_apps_threats:
            mock_apps_threats.return_value = mock.MagicMock(new_app_threshold=test_input, recurrence='every-30-mins', action='download-and-install', threshold=0)
            apps_threats = DynamicUpdates(None, None, None, None, None)
            apps_threats.device_deployment_app_and_threat = None
            apps_threats.apps_threats.version = 8.1  # If PAN-OS version is below 8.1, this BPA check does not run
            assert apps_threats.apps_and_threats_app_id_threshold_warn.result == expected
"""
