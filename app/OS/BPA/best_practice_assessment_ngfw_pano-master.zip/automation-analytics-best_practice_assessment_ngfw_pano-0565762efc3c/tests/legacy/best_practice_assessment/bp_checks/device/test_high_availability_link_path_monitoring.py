"""
from bpa.handlers.best_practice_assessment.bp_checks.device.high_availability import HighAvailabilityLinkPathMonitoring

from unittest.mock import patch


def test_path_monitoring_groups_warn_panorama_pass():
    with patch.object(HighAvailabilityLinkPathMonitoring, "__init__", lambda x, y, z: None):
        ha = HighAvailabilityLinkPathMonitoring(None, None)
        ha.ha_enabled = True
        ha.path_monitoring_enabled = True
        ha.panorama = True
        ha.ip_destination_set = True
        ha.one_group_enabled = True
        assert ha.path_monitoring_groups_warn.result == 'pass'


def test_path_monitoring_groups_warn_panorama_fail():
    with patch.object(HighAvailabilityLinkPathMonitoring, "__init__", lambda x, y, z: None):
        ha = HighAvailabilityLinkPathMonitoring(None, None)
        ha.ha_enabled = True
        ha.path_monitoring_enabled = True
        ha.panorama = True
        ha.ip_destination_set = True
        ha.one_group_enabled = False
        assert ha.path_monitoring_groups_warn.result == 'fail'


def test_path_monitoring_groups_warn_template_pass():
    with patch.object(HighAvailabilityLinkPathMonitoring, "__init__", lambda x, y, z: None):
        ha = HighAvailabilityLinkPathMonitoring(None, None)
        ha.ha_enabled = True
        ha.path_monitoring_enabled = True
        ha.panorama = False
        ha.ip_destination_set = True
        ha.one_group_enabled = True
        ha.ip_source_set = True
        ha.template_name = 'Template-Test'
        ha.path_monitoring_groups_vlan = 'Vlan-10'
        ha.path_monitoring_groups_vwire = 'Vwire1'
        ha.path_monitoring_groups_vrouter = []
        assert ha.path_monitoring_groups_warn.result == 'pass'


def test_path_monitoring_groups_warn_template_fail():
    with patch.object(HighAvailabilityLinkPathMonitoring, "__init__", lambda x, y, z: None):
        ha = HighAvailabilityLinkPathMonitoring(None, None)
        ha.ha_enabled = True
        ha.path_monitoring_enabled = True
        ha.panorama = False
        ha.ip_destination_set = True
        ha.one_group_enabled = False
        ha.ip_source_set = True
        ha.template_name = 'Template-Test'
        ha.path_monitoring_groups_vlan = 'Vlan-10'
        ha.path_monitoring_groups_vwire = 'Vwire1'
        ha.path_monitoring_groups_vrouter = []
        assert ha.path_monitoring_groups_warn.result == 'fail'
"""
