"""
from unittest.mock import patch
import pytest

from bpa.handlers.best_practice_assessment.bp_checks.device.device_setup import ContentIDSettings


@pytest.mark.parametrize("test_input,expected", [
    (False, 'pass'),
    (True, 'fail'),
])
def test_exceed_appID_queue_warn(test_input, expected):
    with patch.object(ContentIDSettings, "__init__", lambda w, x, y: None):
        cID = ContentIDSettings(None, None)
        cID.exceed_appID_queue_enabled = test_input
        assert cID.exceed_appID_queue_disabled_warn.result == expected
"""
