"""
import pytest

from ...best_practice_assessment import common


class TestCommon(object):

    def test_validate_text_xpath(self):
        with pytest.raises(AttributeError):
            common.validate_text_xpath(None)

    def test_bool_attr(self):
        with pytest.raises(AttributeError):
            common.bool_attr(None, None)

    def test_num_attr(self):
        with pytest.raises(TypeError):
            common.num_attr(None, None)

    def test_str_attr(self):
        result = common.str_attr(None, None)
        assert result == ''

    def test_tag_val(self):
        result = common.tag_val(None, None, 'blah')
        assert result == 'blah'
"""
