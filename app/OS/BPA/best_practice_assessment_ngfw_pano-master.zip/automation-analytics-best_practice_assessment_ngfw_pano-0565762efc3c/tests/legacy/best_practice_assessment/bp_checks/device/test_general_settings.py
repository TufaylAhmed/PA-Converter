"""
# -*- coding: utf-8 -*-
from unittest.mock import patch
from unittest.mock import MagicMock

import pytest

from bpa.models.constants import NONE
from bpa.handlers.best_practice_assessment.bp_checks.device.device_setup import GeneralSettings


@pytest.mark.skip('Not refactored')
def test_login_banner_enabled_warn():
    with patch.object(GeneralSettings, "__init__", lambda w, x, y, z: None):
        gs = GeneralSettings(None, None, None)
        gs.login_banner_enabled = False
        assert gs.login_banner_enabled_warn.result == 'fail'


@pytest.mark.skip('Not refactored')
def test_auto_acquire_commit_lock_enabled_warn():
    with patch.object(GeneralSettings, "__init__", lambda w, x, y, z: None):
        gs = GeneralSettings(None, None, None)
        gs.auto_acquire_commit_lock_enabled = False
        assert gs.auto_acquire_commit_lock_enabled_warn.result == 'fail'


@pytest.mark.skip('Not refactored')
def test_cert_expiration_check_enabled_warn_1():
    with patch.object(GeneralSettings, "__init__", lambda w, x, y, z: None):
        gs = GeneralSettings(None, None, None)
        gs.ssl_tls_service_profile = NONE
        assert gs.cert_expiration_check_enabled_warn.result == 'fail'


@pytest.mark.skip('Not refactored')
def test_cert_expiration_check_enabled_warn_2():
    with patch.object(GeneralSettings, "__init__", lambda w, x, y, z: None):
        gs = GeneralSettings(None, None, None)
        gs.ssl_tls_service_profile = 'Test'
        gs.cert_expiration_check_enabled = False
        assert gs.cert_expiration_check_enabled_warn.result == 'fail'


@pytest.mark.skip('Not refactored')
def test_cert_expiration_check_enabled_warn_3():
    with patch.object(GeneralSettings, "__init__", lambda w, x, y, z: None):
        gs = GeneralSettings(None, None, None)
        gs.ssl_tls_service_profile = 'SSL Profile'
        gs.cert_expiration_check_enabled = True
        gs._xml_config = MagicMock()
        test1 = MagicMock()
        test1.name = 'SSL Profile'
        test1.certificate = 'SSL Profile'

        test2 = MagicMock()
        test2.name = 'SSL Profile'
        test2.certificate = 'SSL Profile'

        test3 = MagicMock()
        test3.name = 'SSL Profile'
        test3.certificate = 'SSL Profile'

        test4 = MagicMock()
        test4.name = 'SSL Profile'
        test4.certificate = 'SSL Profile'
        dummy_results = [[test1], [test2], [test3], [test4]]
        gs._xml_config().features.get.side_effect = dummy_results
        assert gs.cert_expiration_check_enabled_warn.result == 'pass'
"""
