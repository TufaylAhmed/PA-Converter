"""
from unittest.mock import patch
import pytest

from bpa.handlers.best_practice_assessment.bp_checks.device.device_setup import SessionSettings


@pytest.mark.parametrize("test_input, expected", [
    (False, 'pass'),
    (True, 'fail'),
])
def test_exceed_oo_queue_warn(test_input, expected):
    with patch.object(SessionSettings, "__init__", lambda w, x, y, z: None):
        ss = SessionSettings(None, None, None)
        ss.exceed_tcp_out_of_order_queue_enabled = False
        assert ss.exceed_oo_queue_disabled_warn.result == 'pass'
"""
