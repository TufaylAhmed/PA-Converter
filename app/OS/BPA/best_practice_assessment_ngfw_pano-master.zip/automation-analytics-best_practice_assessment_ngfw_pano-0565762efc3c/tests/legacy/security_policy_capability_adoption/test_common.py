"""
import json

import pytest

from ...handlers.security_policy_capability_adoption import common


class TestCommon(object):

    def test_get_connection(self):
        with pytest.raises(IOError):
            common.get_connection('mysql')

    def test_join_text_nodes(self):
        with pytest.raises(TypeError):
            common.join_text_nodes(None, None)

    def test_get_text_node(self):
        text = common.get_text_node(None, None, default='hello')
        assert text == 'hello'

    def test_encoder(self):
        x = json.dumps(set([1, 2, 3, 4, 5]), cls=common.SetEncoder)
        assert type(x) is str
        assert x == '[1, 2, 3, 4, 5]'
"""
