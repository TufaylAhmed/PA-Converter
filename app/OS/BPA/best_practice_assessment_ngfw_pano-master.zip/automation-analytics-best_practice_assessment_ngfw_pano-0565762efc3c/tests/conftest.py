import pytest

from bpa.analyzers.adoption.manager import AdoptionAnalyzerManager
from bpa.analyzers.best_practices.manager import BestPracticesAnalyzerManager
from bpa.models.manager import ModelManager
from bpa.publishers.manager import PublisherManager


@pytest.fixture
def check_info():
    """Get check_info as a fixture.

    This is particularly handy for BestPracticeAnalyzer instances.
    But can be useful for other cases to validate that check_info
    is as expected.

    Returns:
        Dictionary of check-related metadata.
    """
    return BestPracticesAnalyzerManager.get_check_info()


@pytest.fixture
def model_manager_factory():
    def _model_manager_factory(
        populate_models=None, populate_tree=None, populate_other=None
    ):
        """Generate ModelManager for testing purposes.

        Args:
            populate_models: Function for populating ModelSet instances.
            populate_tree: Function for populating Tree attribute.
            populate_other: Function for populating system_info, license_info, etc.

        Returns:
            ModelManager instance.
        """
        model_manager = ModelManager()

        # NOTE: Create artifical model sets to prevent many tests from failing
        for key, kls in model_manager.model_lookup.items():
            model_manager.model_set_lookup[key] = kls.model_set()

        # Create tree and add metadata
        if populate_tree:
            populate_tree(model_manager)

        # Create model sets and populate them with models
        if populate_models:
            populate_models(model_manager)

        # Create system + license info as well as other things
        if populate_other:
            populate_other(model_manager)

        return model_manager

    return _model_manager_factory


@pytest.fixture
def bp_manager_factory():
    def _bp_manager_factory(model_manager):
        return BestPracticesAnalyzerManager(model_manager)

    return _bp_manager_factory


@pytest.fixture
def adoption_manager_factory():
    def _adoption_manager_factory(bp_manager):
        return AdoptionAnalyzerManager(bp_manager)

    return _adoption_manager_factory


@pytest.fixture
def publisher_manager_factory():
    def _publisher_manager_factory(adoption_manager):
        return PublisherManager(adoption_manager)

    return _publisher_manager_factory
