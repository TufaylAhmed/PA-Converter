import os

# Skip flags
SKIP_E2E = os.getenv("BPA_E2E") is None

# Typical values are (local, jenkins)
PANTS_MODE = os.getenv("BPA_PANTS_MODE", "local").lower()

# Test paths
base_path = os.path.dirname(os.path.realpath(__file__))
fixt_path = os.path.join(base_path, "fixtures")

# Config paths
lab_path = os.path.join(fixt_path, "lab_configs")
failed_path = os.path.join(fixt_path, "failed_configs")
pulled_path = os.path.join(fixt_path, "pulled_configs")

# Docs path
docs_path = os.path.join(fixt_path, "documentation")
