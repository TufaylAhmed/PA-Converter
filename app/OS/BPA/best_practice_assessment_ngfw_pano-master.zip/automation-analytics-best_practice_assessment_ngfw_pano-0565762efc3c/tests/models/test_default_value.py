from typing import Union

import pytest
from dataclasses import dataclass

from bpa.models.default_value import DefaultValue
from bpa.models.base_model import BaseModel
from bpa.models.sub_model import SubModel


@dataclass
class Car(SubModel):
    """Represents sub-model in BPA"""

    brand: Union[str, DefaultValue] = DefaultValue("Toyota")
    wheels: Union[int, DefaultValue] = DefaultValue(4)

    def __bool__(self):
        return self.wheels > 2


@dataclass
class Person(BaseModel):
    """Represents top-model in BPA"""

    xpath = ""
    age: Union[int, DefaultValue] = DefaultValue(45)
    name: Union[str, DefaultValue] = DefaultValue("Peter")
    car: Union[Car, DefaultValue] = DefaultValue(Car(brand="Chevy", wheels=8))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def person(model_manager):
    return Person(age=35, model_manager=model_manager)


@pytest.mark.core
class TestDefaultValue:
    def test_simple_literals(self, person):
        assert person.age == getattr(person, "age") == 35
        assert person.name == getattr(person, "name") == "Peter"

    def test_composite_objects(self, person):
        assert person.car.brand == "Chevy"
        assert person.car.wheels == 8

    def test_boolean_attrs(self, person):
        assert bool(person.age) is True
        assert bool(person.name) is True
        assert bool(person.car) is True

    def test_dict_base(self, person):
        assert type(person.__dict__) is dict
        assert type(person.__dataclass_fields__) is dict

    def test_dict_sub(self, person):
        assert type(person.car.__dict__) is dict
        assert type(person.car.__dataclass_fields__) is dict

    def test_to_dict(self, person):
        for res in [person.to_dict(), person.car.to_dict()]:
            assert type(res) is dict
            for k, v in res.items():
                assert not isinstance(v, DefaultValue)
