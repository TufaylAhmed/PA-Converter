from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.policies.policy_based_forwarding_rule import (
    PolicyBasedForwardingRuleModel,
)
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.panorama = False

    return model_manager_factory(populate_tree=populate_tree)


def test_policy_based_forwarding(model_manager):
    obj = PolicyBasedForwardingRuleModel.from_el(entry, model_manager)
    assert obj.name == "PBF_TEST"
    assert obj.action == "discard"
    assert obj.rulebase is None
    assert obj.monitor_enabled is False
