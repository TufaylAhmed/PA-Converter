import pytest
from lxml import etree

from bpa.models.policies.app_override import AppOverrideModel
from tests.utils.config import get_snippet_from_path


config = etree.fromstring(get_snippet_from_path(__name__))
entry = config.xpath(AppOverrideModel.xpath)[0]


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_app_override(model_manager):
    obj = AppOverrideModel.from_el(entry, model_manager)
    assert obj.name == "PostOverrideTest"
    assert obj.rulebase == "post-rulebase"
