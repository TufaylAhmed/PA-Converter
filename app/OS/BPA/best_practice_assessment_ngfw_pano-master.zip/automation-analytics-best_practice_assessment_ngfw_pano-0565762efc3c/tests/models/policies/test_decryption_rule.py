from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.policies.decryption_rule import DecryptionRuleModel
from tests.utils.config import get_snippet_from_path


config = etree.fromstring(get_snippet_from_path(__name__))
entry = config.xpath(DecryptionRuleModel.xpath)[0]


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.panorama = True

    return model_manager_factory(populate_tree=populate_tree)


def test_decryption_rule(model_manager):
    obj = DecryptionRuleModel.from_el(entry, model_manager)
    assert obj.name == "DecryptTest"
    assert obj.action == "decrypt"
    assert obj.rule_type == "ssl-forward-proxy"
    assert obj.decryption_profile == "default"
    assert obj.categories == ["auctions"]
    assert obj.rulebase == "post-rulebase"
