from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.policies.captive_portal_rule import CaptivePortalRuleModel
from tests.utils.config import get_snippet_from_path


config_8x = etree.fromstring(get_snippet_from_path(__name__ + "_8x"))
entry_8x = config_8x.xpath(CaptivePortalRuleModel.xpath)[0]

entry_7x = etree.fromstring(get_snippet_from_path(__name__ + "_7x"))


@pytest.fixture
def model_manager_7x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 7
        model_manager.tree.panorama = False

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_manager_8x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8

    return model_manager_factory(populate_tree=populate_tree)


def test_captive_portal_rule_8x(model_manager_8x):
    obj = CaptivePortalRuleModel.from_el(entry_8x, model_manager_8x)
    assert obj.name == "CaptiveTest"
    assert obj.action == "default-browser-challenge"
    assert obj.timeout == 60
    assert obj.source_zones == ["Trust"]
    assert obj.destination_zones == ["Trust"]
    assert obj.source_addresses == ["panw-highrisk-ip-list"]
    assert obj.destination_addresses == ["panw-highrisk-ip-list"]
    assert obj.services == ["service-http"]
    assert obj.vsys == "shared"
    assert obj.rulebase == "pre-rulebase"
    assert obj.source_users == ["User1", "User2"]


def test_captive_portal_rule_7x(model_manager_7x):
    obj = CaptivePortalRuleModel.from_el(entry_7x, model_manager_7x)
    assert obj.name == "CP_TEST"
    assert obj.action == "browser-challenge"
