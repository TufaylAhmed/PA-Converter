from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.policies.security_rule import SecurityRuleModel
from bpa.models.model_sets.security_rule import SecurityRuleModelSet
from tests.utils.config import get_snippet_from_path


config = etree.fromstring(get_snippet_from_path(__name__))
entry = config.xpath(SecurityRuleModel.xpath)[0]


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.system_info = {"serial": "123"}

    return model_manager_factory(populate_tree=populate_tree)


def test_security_rule_model(model_manager, monkeypatch):
    monkeypatch.setattr(
        SecurityRuleModel, "get_targets", lambda x, y, z: ["123:no-vsys"]
    )
    obj = SecurityRuleModel.from_el(entry, model_manager)
    assert obj is not None
    assert isinstance(obj.model_set(), SecurityRuleModelSet)
    assert obj.rule_enabled is True
    assert obj.rule_name == "block-to-outside"
    assert obj.rule_type == "universal"
    assert obj.url_categories == ["alcohol-and-tobacco"]

    assert obj.source_users == ["any"]
    assert obj.source_zones == ["any"]

    assert obj.log_start_enabled is False
    assert obj.log_end_enabled is True

    assert obj.dest_addresses == [
        "hcp-block-list",
        "outside-ip-block",
        "panw-highrisk-ip-list",
        "panw-known-ip-list",
    ]

    assert obj.tags == ["block"]
