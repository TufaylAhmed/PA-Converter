from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.policies.tunnel_inspection import TunnelInspectionModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.panorama = True

    return model_manager_factory(populate_tree=populate_tree)


def test_tunnel_inspection(model_manager):
    obj = TunnelInspectionModel.from_el(entry, model_manager)
    assert obj.name == "tun-inspect-simple"
    assert obj.tunnel_protocols == ["gre", "gtp", "vxlan"]
    assert obj.tunnel_source_zone == "ZonSrc-Tun"
    assert obj.tunnel_dest_zone == "ZonDst-Tun"
