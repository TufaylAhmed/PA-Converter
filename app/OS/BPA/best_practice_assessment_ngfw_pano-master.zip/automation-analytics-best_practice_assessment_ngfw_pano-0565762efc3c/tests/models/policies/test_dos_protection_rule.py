import pytest
from lxml import etree

from bpa.models.policies.dos_protection_rule import DosProtectionRuleModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_dos_protection_rule(model_manager):
    obj = DosProtectionRuleModel.from_el(entry, model_manager)
    assert obj is not None
    assert obj.name == "Dos Policy"
    assert obj.action == "protect"
    assert obj.dos_protection_profile == "DoS protection"
