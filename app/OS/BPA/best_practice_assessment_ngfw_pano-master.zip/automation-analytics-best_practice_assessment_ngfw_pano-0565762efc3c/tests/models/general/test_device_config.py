from unittest.mock import MagicMock

from lxml import etree

from bpa.models.general.device_config import DeviceConfigModel
from tests.utils.config import get_snippet_from_path


config = etree.fromstring(get_snippet_from_path(__name__))


def test_device_config():
    model_manager = MagicMock()
    device_config = DeviceConfigModel.from_el(config, model_manager)
    assert device_config.template_name is None
    assert device_config.build_index() == ["template_name"]
