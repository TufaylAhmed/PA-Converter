import pytest
from lxml import etree

from bpa.models.network.zone_protection_profile import (
    ZoneProtectionProfileModel,
    PacketBasedAttackProtection,
    FloodProtection,
    FloodProtectionFeature,
    ReconnaissanceProtection,
    TcpDrop,
)
from tests.utils.config import get_snippet_from_path
from tests.utils.compare import compare_dataclass_objects


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_zone_protection_profile(model_manager):
    zpp = ZoneProtectionProfileModel.from_el(entry, model_manager)
    assert zpp.name == "Test-ZPP"
    assert zpp.packet_based_attack_protection == PacketBasedAttackProtection(
        False, TcpDrop(True, True, True, True)
    )
    assert zpp.flood_protection == FloodProtection(
        FloodProtectionFeature(True, 10000, 10000, 40000),
        FloodProtectionFeature(True, 10000, 10000, 40000),
        FloodProtectionFeature(True, 10000, 10000, 40000),
        FloodProtectionFeature(True, 10000, 10000, 40000),
        FloodProtectionFeature(True, 10000, 10000, 40000),
    )
    compare_dataclass_objects(
        zpp.reconnaissance_protection,
        ReconnaissanceProtection(True, True, True, [], []),
    )
