import pytest
from lxml import etree

from bpa.models.network.global_protect import GlobalProtectSiteToSiteTunnelSettingsModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_global_protect_portal(model_manager):
    gp_tunnel_settings = GlobalProtectSiteToSiteTunnelSettingsModel.from_el(
        entry, model_manager
    )
    assert gp_tunnel_settings.name == "GP-Gw1-S"
    assert gp_tunnel_settings.tunnel_monitoring_enabled
    assert gp_tunnel_settings.replay_attack_detection_enabled is False
    assert gp_tunnel_settings.ipsec_crypto_profile == "Sat-Prfo"
