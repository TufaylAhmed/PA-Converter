import pytest
from lxml import etree

from bpa.models.network.dns_proxy import DnsProxyModel, DnsProxyRule
from tests.utils.compare import compare_lists
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_dns_proxy(model_manager):
    dns_proxy = DnsProxyModel.from_el(entry, model_manager)
    assert dns_proxy.name == "dns_proxy_test"
    assert dns_proxy.enabled
    assert dns_proxy.cache
    assert dns_proxy.interfaces
    rule_list = [DnsProxyRule(name="test_dns_proxy_rule", cacheable=True)]
    assert len(dns_proxy.rules) > 0
    compare_lists(dns_proxy.rules, rule_list)
