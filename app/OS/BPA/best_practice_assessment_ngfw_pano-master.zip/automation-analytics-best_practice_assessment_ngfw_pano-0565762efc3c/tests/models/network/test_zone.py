from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.network.zone import ZoneModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.0

    return model_manager_factory(populate_tree=populate_tree)


def test_zone(model_manager):
    zone = ZoneModel.from_el(entry, model_manager)
    assert zone.name == "test-zone"
    assert zone.user_id_enabled
    assert zone.using_acl_include_list
    assert zone.zone_protection_profile == "Test-ZPP"
    assert zone.packet_buffer_protection_enabled
