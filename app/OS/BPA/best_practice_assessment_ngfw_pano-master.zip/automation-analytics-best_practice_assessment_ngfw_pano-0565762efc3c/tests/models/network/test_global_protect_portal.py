from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.network.global_protect import (
    GlobalProtectPortalModel,
    AuthClient,
    GlobalProtectPortalAgentConfig,
)
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1

    return model_manager_factory(populate_tree=populate_tree)


def test_global_protect_portal(model_manager):
    model_manager.tree.version = 8.1
    gp_portal = GlobalProtectPortalModel.from_el(entry, model_manager)
    auth_clients = [AuthClient(name="Client-Atuth", auth_profile="Ldap-Auth")]
    agent_configs = [
        GlobalProtectPortalAgentConfig(
            name="Cfg-1",
            save_user_credentials="Yes",
            two_factor_authentication=[],
            internal_host_detection_enabled=False,
            continue_with_invalid_portal_server_cert=True,
            enforce_gp_connection_for_network_access=False,
            collect_hip_data_enabled=True,
            external_gateway_ips=["2.2.2.2"],
            disable_timeout=0,
        )
    ]
    assert gp_portal.name == "GP-Portal"
    assert gp_portal.satellite_trusted_root_ca == ["fw-root-ca"]
    assert gp_portal.agent_trusted_root_ca == ["fw-root-ca"]
    assert gp_portal.ssl_tls_service_profile == "SSL-Prof"
    assert gp_portal.certificate_profile == "Cert-Profile"
    assert not gp_portal.satellites_configured
    assert gp_portal.satellite_ocsp_responder == "OCSP"

    assert len(gp_portal.auth_clients) > 0
    for i, j in zip(gp_portal.auth_clients, auth_clients):
        assert i.name == j.name
        assert i.auth_profile == j.auth_profile

    assert len(gp_portal.agent_configs) > 0
    for i, j in zip(gp_portal.agent_configs, agent_configs):
        for key in i.__dict__.keys():
            assert i.__dict__.get(key) == j.__dict__.get(key)
