import pytest
from lxml import etree

from bpa.models.network.global_protect import (
    GlobalProtectGatewayModel,
    AuthClient,
    GlobalProtectGatewayAgentConfig,
)
from tests.utils.compare import compare_lists
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_global_protect_portal(model_manager):
    gp_gateway = GlobalProtectGatewayModel.from_el(entry, model_manager)
    auth_clients = [AuthClient(name="Cln-Auth", auth_profile="test-auth-profile")]
    agent_configs = [
        GlobalProtectGatewayAgentConfig(
            name="Clnt-cfg",
            access_routes=["3.3.3.3"],
            no_direct_access_to_local_network=True,
        )
    ]
    assert gp_gateway.name == "GP-Gw1"
    assert gp_gateway.tunnel_mode_enabled
    assert gp_gateway.certificate_profile == "test-certificate-profile"
    assert gp_gateway.ssl_tls_service_profile == "test-ssl-tls-service-profile"

    assert len(gp_gateway.auth_clients) > 0
    compare_lists(gp_gateway.auth_clients, auth_clients)
    compare_lists(gp_gateway.agent_configs, agent_configs)
