import pytest
from lxml import etree

from bpa.models.network.gre_tunnel import GreTunnelModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_gre_tunnel(model_manager):
    tunnel = GreTunnelModel.from_el(entry, model_manager)
    assert tunnel.name == "gre-simple"
    assert tunnel.peer_ip == "2.3.4.5"
    assert tunnel.keep_alive_interval == 15
    assert tunnel.keep_alive_retry == 5
    assert tunnel.keep_alive_hold_timer == 10
    assert tunnel.keep_alive_enable is True
