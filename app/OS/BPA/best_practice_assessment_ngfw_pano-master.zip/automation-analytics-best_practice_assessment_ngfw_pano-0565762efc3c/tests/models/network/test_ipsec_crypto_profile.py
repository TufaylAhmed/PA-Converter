import pytest
from lxml import etree

from bpa.models.network.ipsec_crypto_profile import IpSecCryptoProfileModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_ipsec_crypto_profile(model_manager):
    ipsec = IpSecCryptoProfileModel.from_el(entry, model_manager)
    assert ipsec.name == "pan-default"
    assert ipsec.protocol == "esp"
    assert ipsec.encryption_algorithms == ["aes-128-cbc", "3des"]
    assert ipsec.authentication_algorithms == ["sha1"]
