import pytest
from lxml import etree

from bpa.models.network.interface_management_profile import (
    InterfaceManagementProfileModel,
)
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_interface_management_profile(model_manager):
    profile = InterfaceManagementProfileModel.from_el(entry, model_manager)
    assert profile is not None
    assert profile.name == "If-Mgmt-Prof-1"
    assert profile.protocols == {"http", "telnet", "https", "ssh"}
