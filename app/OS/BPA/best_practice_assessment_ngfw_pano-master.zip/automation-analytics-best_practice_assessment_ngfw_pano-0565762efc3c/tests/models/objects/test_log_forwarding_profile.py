from collections import defaultdict
from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.objects.log_forwarding_profile import (
    LogForwardingProfileModel,
    MatchList,
    Setting,
)
from tests.utils.compare import compare_lists
from tests.utils.config import get_snippet_from_path


# two versions of XML
entry_7x = etree.fromstring(get_snippet_from_path(__name__ + "_7x"))  # PAN-OS 7.x
entry_8x = etree.fromstring(get_snippet_from_path(__name__ + "_8x"))  # PAN-OS 8.x


@pytest.fixture
def model_manager_7x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 7

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_manager_8x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8

    return model_manager_factory(populate_tree=populate_tree)


def test_log_forwarding_profile_8x(model_manager_8x):
    profile = LogForwardingProfileModel.from_el(entry_8x, model_manager_8x)
    assert profile is not None

    assert profile.name == "LF-1"
    assert len(profile.settings) > 0

    type_frequency = defaultdict(int)
    for setting in profile.settings:
        assert type(setting) is MatchList
        type_frequency[setting.log_type] += 1

    assert type_frequency["threat"] > 0
    assert type_frequency["traffic"] > 0
    assert type_frequency["wildfire"] > 0
    assert profile.settings[0].log_type == "threat"
    assert profile.settings[0].snmp == ["SNMPT TRAP SEVER"]
    assert profile.settings[0].filter == "(severity eq critical)"
    assert profile.settings[1].filter == "(severity eq high)"


def test_log_forwarding_profile_7x(model_manager_7x):
    actual_profile = LogForwardingProfileModel.from_el(entry_7x, model_manager_7x)
    assert actual_profile is not None
    assert actual_profile.name == "LOG_FORWARDING_PROFILE_TEST"

    assert len(actual_profile.settings) > 0
    expected_profile = MagicMock()
    expected_profile.settings = [
        Setting(
            log_type="traffic",
            log_levels={
                "any": {
                    "panorama": True,
                    "snmp": False,
                    "email": False,
                    "syslog": False,
                }
            },
        ),
        Setting(
            log_type="threat",
            log_levels={
                "informational": {
                    "panorama": True,
                    "snmp": False,
                    "email": False,
                    "syslog": False,
                },
                "low": {
                    "panorama": True,
                    "snmp": False,
                    "email": False,
                    "syslog": False,
                },
                "medium": {
                    "panorama": True,
                    "snmp": False,
                    "email": False,
                    "syslog": True,
                },
                "high": {
                    "panorama": True,
                    "snmp": True,
                    "email": False,
                    "syslog": False,
                },
                "critical": {
                    "panorama": False,
                    "snmp": False,
                    "email": False,
                    "syslog": False,
                },
            },
        ),
        Setting(
            log_type="wildfire",
            log_levels={
                "benign": {
                    "panorama": False,
                    "snmp": False,
                    "email": False,
                    "syslog": False,
                },
                "grayware": {
                    "panorama": True,
                    "snmp": False,
                    "email": False,
                    "syslog": False,
                },
                "malicious": {
                    "panorama": True,
                    "snmp": False,
                    "email": False,
                    "syslog": False,
                },
            },
        ),
    ]
    compare_lists(actual_profile.settings, expected_profile.settings)
