from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.objects.application import ApplicationModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = float(7.1)

    return model_manager_factory(populate_tree=populate_tree)


def test_application(model_manager):
    app = ApplicationModel.from_el(entry, model_manager)
    assert app.name == "Bogus-App"
    assert app.timeout == 10
    assert app.tcp_timeout == 10
    assert app.tcp_half_closed_timeout == 10
    assert app.tcp_time_wait_timeout == 10
    assert app.defaults_configured is True
    assert app.timeouts_configured is True
    assert len(app.signatures) == 2
