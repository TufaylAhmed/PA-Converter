import pytest
from lxml import etree

from bpa.models.objects.security_profile.data_filtering_profile import (
    DataFilteringProfileModel,
)
from bpa.models.objects.security_profile.data_filtering_profile import DataFilteringRule
from tests.utils.compare import compare_lists
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_data_filtering_profile(model_manager):
    obj = DataFilteringProfileModel.from_el(entry, model_manager)

    rule_list = [
        DataFilteringRule(data_pattern="testpattern1"),
        DataFilteringRule(data_pattern="testpattern2"),
    ]
    compare_lists(obj.rules, rule_list)
