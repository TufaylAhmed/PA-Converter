import pytest
from lxml import etree

from bpa.models.objects.security_profile.wildfire_analysis_profile import (
    WildfireAnalysisProfileModel,
    WildfireAnalysisProfileRule,
)
from tests.utils.compare import compare_lists
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_wildfire_analysis_profile(model_manager):
    obj = WildfireAnalysisProfileModel.from_el(entry, model_manager)
    assert obj.name == "Wf-prof"
    expected_rules = [
        WildfireAnalysisProfileRule(
            applications=["accelo", "access-grid"],
            file_types=["apk", "flash"],
            direction="upload",
            analysis="public-cloud",
        ),
        WildfireAnalysisProfileRule(
            applications=["4shared", "adobe-cloud"],
            file_types=["MacOSX", "pdf"],
            direction="download",
            analysis="private-cloud",
        ),
    ]
    assert len(obj.rules) > 0
    compare_lists(obj.rules, expected_rules)
