import pytest
from lxml import etree

from bpa.models.objects.security_profile.file_blocking_profile import (
    FileBlockingProfileModel,
)
from bpa.models.objects.security_profile.file_blocking_profile import FileBlockingRule
from tests.utils.compare import compare_lists
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_file_blocking_profile(model_manager):
    obj = FileBlockingProfileModel.from_el(entry, model_manager)
    rule_list = [
        FileBlockingRule(
            applications=["any"],
            file_types=[
                "7z",
                "bat",
                "chm",
                "class",
                "cpl",
                "dll",
                "exe",
                "hlp",
                "hta",
                "jar",
                "ocx",
                "PE",
                "pif",
                "rar",
                "scr",
                "torrent",
                "vbe",
                "wsf",
            ],
            direction="both",
            action="block",
        ),
        FileBlockingRule(
            applications=["any"],
            file_types=["encrypted-rar", "encrypted-zip"],
            direction="both",
            action="continue",
        ),
    ]
    compare_lists(obj.rules, rule_list)
