import os
import json
import weakref
from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.objects.security_profile.url_filtering_profile import (
    UrlFilteringProfileModel,
    CredentialEnforcement,
)
from bpa import data_path
from tests.utils.compare import compare_dictionaries, compare_dataclass_objects
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8

    return model_manager_factory(populate_tree=populate_tree)


def test_url_filtering_profile(model_manager):
    url_categories = json.load(open(os.path.join(data_path, "url_categories.json")))
    model_manager.tree.url_categories = set(
        url_categories["paloaltonetworks"]
    )  # assumes in config: urldb = 'paloaltonetworks'
    obj = UrlFilteringProfileModel.from_el(entry, model_manager)
    expected_url_model = UrlFilteringProfileModel(
        location=None,
        model_manager=weakref.ref(model_manager),
        name="TestURL",
        log_container_page_only_enabled=True,
        site_access_categories={
            "alert": ["unknown"],
            "block": ["web-advertisements"],
            "continue": ["translation"],
            "override": ["training-and-tools"],
            "allow": [
                "dating",
                "internet-portals",
                "financial-services",
                "computer-and-internet-info",
                "web-based-email",
                "news",
                "philosophy-and-political-advocacy",
                "government",
                "copyright-infringement",
                "alcohol-and-tobacco",
                "religion",
                "military",
                "real-estate",
                "games",
                "extremism",
                "business-and-economy",
                "sex-education",
                "music",
                "shopping",
                "swimsuits-and-intimate-apparel",
                "shareware-and-freeware",
                "command-and-control",
                "questionable",
                "social-networking",
                "adult",
                "recreation-and-hobbies",
                "reference-and-research",
                "entertainment-and-arts",
                "auctions",
                "job-search",
                "content-delivery-networks",
                "proxy-avoidance-and-anonymizers",
                "educational-institutions",
                "travel",
                "web-hosting",
                "nudity",
                "dynamic-dns",
                "hacking",
                "home-and-garden",
                "motor-vehicles",
                "insufficient-content",
                "gambling",
                "search-engines",
                "abused-drugs",
                "personal-sites-and-blogs",
                "phishing",
                "legal",
                "online-storage-and-backup",
                "streaming-media",
                "not-resolved",
                "stock-advice-and-tools",
                "weapons",
                "hunting-and-fishing",
                "abortion",
                "internet-communications-and-telephony",
                "peer-to-peer",
                "private-ip-addresses",
                "health-and-medicine",
                "parked",
                "society",
                "malware",
                "sports",
                "grayware",
                "cryptocurrency",
            ],
        },
        credential_enforcement=CredentialEnforcement(
            mode="domain-credentials",
            log_severity="medium",
            categories={
                "alert": ["unknown"],
                "block": ["web-advertisements", "web-hosting"],
                "continue": ["translation"],
                "allow": [
                    "dating",
                    "internet-portals",
                    "financial-services",
                    "computer-and-internet-info",
                    "web-based-email",
                    "news",
                    "philosophy-and-political-advocacy",
                    "government",
                    "copyright-infringement",
                    "alcohol-and-tobacco",
                    "religion",
                    "military",
                    "real-estate",
                    "games",
                    "extremism",
                    "business-and-economy",
                    "sex-education",
                    "music",
                    "shopping",
                    "swimsuits-and-intimate-apparel",
                    "shareware-and-freeware",
                    "command-and-control",
                    "questionable",
                    "social-networking",
                    "adult",
                    "training-and-tools",
                    "recreation-and-hobbies",
                    "reference-and-research",
                    "entertainment-and-arts",
                    "auctions",
                    "job-search",
                    "content-delivery-networks",
                    "proxy-avoidance-and-anonymizers",
                    "educational-institutions",
                    "travel",
                    "nudity",
                    "dynamic-dns",
                    "hacking",
                    "home-and-garden",
                    "motor-vehicles",
                    "insufficient-content",
                    "gambling",
                    "search-engines",
                    "abused-drugs",
                    "personal-sites-and-blogs",
                    "phishing",
                    "legal",
                    "online-storage-and-backup",
                    "streaming-media",
                    "not-resolved",
                    "stock-advice-and-tools",
                    "weapons",
                    "hunting-and-fishing",
                    "abortion",
                    "internet-communications-and-telephony",
                    "peer-to-peer",
                    "private-ip-addresses",
                    "health-and-medicine",
                    "parked",
                    "society",
                    "malware",
                    "sports",
                    "grayware",
                    "cryptocurrency",
                ],
            },
        ),
    )

    assert obj.log_container_page_only_enabled is True

    compare_dictionaries(
        obj.site_access_categories, expected_url_model.site_access_categories
    )

    compare_dataclass_objects(
        obj.credential_enforcement, expected_url_model.credential_enforcement
    )
