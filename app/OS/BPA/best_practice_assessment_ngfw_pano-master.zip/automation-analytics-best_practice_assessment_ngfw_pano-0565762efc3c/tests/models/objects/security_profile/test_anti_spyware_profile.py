import pytest
from lxml import etree

from bpa.models.objects.security_profile.anti_spyware_profile import (
    AntiSpywareProfileModel,
    AntiSpywareRule,
    EDLDomain,
)
from bpa.models.objects.security_profile.common import ThreatException
from tests.utils.compare import compare_lists
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_anti_spyware_profile(model_manager):
    obj = AntiSpywareProfileModel.from_el(entry, model_manager)
    assert obj.botnet_threat_exceptions == ["123"]
    assert obj.dns_signature_packet_capture == "extended-capture"
    assert obj.passive_dns_monitoring_enabled is True
    assert obj.dns_sinkhole is True
    assert obj.sinkhole_ipv4 == "pan-sinkhole-default-ip"
    threat_list = [
        ThreatException(name="10313", packet_capture="single-packet"),
        ThreatException(name="10522", packet_capture="extended-capture"),
        ThreatException(name="10286", packet_capture="disable"),
    ]

    assert len(obj.spyware_threat_exceptions) > 0
    compare_lists(obj.spyware_threat_exceptions, threat_list)

    assert len(obj.edl_domains) > 0
    compare_lists(
        obj.edl_domains, [EDLDomain(name="default-paloalto-dns", action="sinkhole")]
    )

    assert len(obj.rules) > 0
    compare_lists(
        obj.rules,
        [
            AntiSpywareRule(
                name="test",
                severity=["any"],
                action="default",
                category="any",
                packet_capture="disable",
            )
        ],
    )
