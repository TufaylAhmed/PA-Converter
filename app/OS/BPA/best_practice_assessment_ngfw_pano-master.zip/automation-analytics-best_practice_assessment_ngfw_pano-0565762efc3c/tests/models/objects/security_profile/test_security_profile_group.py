import pytest
from lxml import etree

from bpa.models.objects.security_profile.common import SecurityProfileGroupModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))
config = entry.get("entry")


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_security_profile_group(model_manager):
    profile_group = SecurityProfileGroupModel.from_el(entry, model_manager)
    assert profile_group is not None
    assert profile_group.name == "Sec-Prof-Med"
    assert profile_group.antivirus == "default"
    assert profile_group.anti_spyware == "AS-Profile-1"
    assert profile_group.is_ips_profile_group is True
