import pytest
from lxml import etree

from bpa.models.objects.authentication_object import AuthenticationObjectModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_auth_object(model_manager):
    auth_obj = AuthenticationObjectModel.from_el(entry, model_manager)
    assert auth_obj is not None

    assert auth_obj.name == "Auth-SAP-Servers"
    assert auth_obj.authentication_method == "web-form"
    assert auth_obj.authentication_profile == "Auth SAP Srvrs"
