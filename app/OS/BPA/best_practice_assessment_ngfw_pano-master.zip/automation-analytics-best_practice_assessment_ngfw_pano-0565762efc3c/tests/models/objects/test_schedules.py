from datetime import datetime
from unittest.mock import MagicMock

from lxml import etree

from bpa.models.objects.schedules import SchedulesModel, SchedulesRange
from tests.utils.compare import compare_lists
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


def test_schedules_model():
    model_manager = MagicMock()
    profile = SchedulesModel.from_el(entry, model_manager)
    assert profile is not None
    assert profile.name == "Sched1"
    assert profile.recurring is False
    expected_schedules = [
        SchedulesRange(
            start_time=datetime(2018, 10, 9, 1, 0),
            end_time=datetime(2018, 10, 18, 1, 0),
        )
    ]
    assert len(profile.schedule_ranges) > 0
    compare_lists(profile.schedule_ranges, expected_schedules)
