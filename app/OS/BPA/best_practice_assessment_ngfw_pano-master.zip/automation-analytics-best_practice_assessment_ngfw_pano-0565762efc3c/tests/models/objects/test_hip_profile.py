import pytest
from lxml import etree

from bpa.models.objects.hip_profile import HipProfileModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_hip_profile_model(model_manager):
    profile = HipProfileModel.from_el(entry, model_manager)
    assert profile is not None
    assert profile.name == "HIP-P"
    assert profile.matches == ["HIP-0"]
