from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.objects.service import ServiceModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = float(7.1)

    return model_manager_factory(populate_tree=populate_tree)


def test_service(model_manager):
    svc = ServiceModel.from_el(entry, model_manager)
    assert svc.name == "Bogus-Service"
    assert svc.timeouts_configured is True
