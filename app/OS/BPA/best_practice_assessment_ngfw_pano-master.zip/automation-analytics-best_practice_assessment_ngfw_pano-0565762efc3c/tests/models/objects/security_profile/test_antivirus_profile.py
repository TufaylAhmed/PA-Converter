from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.objects.security_profile.antivirus_profile import AntivirusProfileModel
from bpa.models.objects.security_profile.antivirus_profile import AntivirusDecoder
from tests.utils.compare import compare_lists
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_antivirus_profile(model_manager):
    model_manager = MagicMock()
    model_manager.tree.version = 9.0
    obj = AntivirusProfileModel.from_el(entry, model_manager)
    assert obj.name == "AV-Cust"
    assert obj.packet_capture_enabled is False
    assert obj.threat_exceptions == ["2079847"]
    assert obj.application_exceptions == ["51.com-mail"]
    decoder_list = [
        AntivirusDecoder(name="ftp", action="reset-both", wildfire_action="reset-both"),
        AntivirusDecoder(
            name="http", action="reset-both", wildfire_action="reset-both"
        ),
        AntivirusDecoder(name="imap", action="alert", wildfire_action="alert"),
        AntivirusDecoder(name="pop3", action="alert", wildfire_action="alert"),
        AntivirusDecoder(name="smb", action="reset-both", wildfire_action="reset-both"),
        AntivirusDecoder(name="smtp", action="alert", wildfire_action="alert"),
        AntivirusDecoder(
            name="http2", action="reset-both", wildfire_action="reset-both"
        ),
    ]

    assert len(obj.decoders) > 0
    compare_lists(obj.decoders, decoder_list)
