import pytest
from lxml import etree

from bpa.models.objects.security_profile.dos_protection_profile import (
    DosProtectionProfileModel,
)
from bpa.models.objects.security_profile.dos_protection_profile import FloodProtection
from tests.utils.compare import compare_lists
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_dos_protection_profile(model_manager):
    obj = DosProtectionProfileModel.from_el(entry, model_manager)

    assert obj.coverage_type == "aggregate"
    flood_list = [
        FloodProtection(
            flood_type="SYN",
            alarm=100,
            activate=230,
            maximal=1200,
            block_duration=331,
            enabled=True,
        ),
        FloodProtection(
            flood_type="UDP",
            alarm=10001,
            activate=10002,
            maximal=40003,
            block_duration=304,
            enabled=True,
        ),
        FloodProtection(
            flood_type="ICMP",
            alarm=10005,
            activate=10006,
            maximal=40007,
            block_duration=308,
            enabled=True,
        ),
        FloodProtection(
            flood_type="ICMPv6",
            alarm=10000,
            activate=10000,
            maximal=40000,
            block_duration=300,
            enabled=True,
        ),
        FloodProtection(
            flood_type="Other IP",
            alarm=10000,
            activate=10000,
            maximal=40000,
            block_duration=300,
            enabled=True,
        ),
    ]
    compare_lists(obj.flood_protections, flood_list)
