from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.objects.application_filter import ApplicationFilterModel
from tests.utils.config import get_snippet_from_path


config = etree.fromstring(get_snippet_from_path(__name__))
entry = config.xpath(ApplicationFilterModel.xpath)[0]


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = float(8.1)

    return model_manager_factory(populate_tree=populate_tree)


def test_application_filter(model_manager):
    filt = ApplicationFilterModel.from_el(entry, model_manager)
    assert filt.name == "simple-filter-1"
    assert filt.categories == ["business-systems", "collaboration"]
    assert filt.new_app_id_enabled is True
    assert filt.location == "vsys1"
