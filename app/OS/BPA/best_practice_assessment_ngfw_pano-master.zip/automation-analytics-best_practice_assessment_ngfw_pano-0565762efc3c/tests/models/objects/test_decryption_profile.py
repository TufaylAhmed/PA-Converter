import pytest
from lxml import etree

from bpa.models.objects.decryption_profile import DecryptionProfileModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_decryption_profile(model_manager):
    profile = DecryptionProfileModel.from_el(entry, model_manager)
    assert profile is not None

    assert profile.ssl_forward_proxy is not None
    assert profile.ssl_forward_proxy.block_expired_certificate is True
    assert profile.ssl_forward_proxy.block_untrusted_issuer is True
    assert profile.ssl_forward_proxy.block_unsupported_cipher is False

    assert profile.ssl_inbound_inspection is not None
    assert profile.ssl_inbound_inspection.block_unsupported_version is True
    assert profile.ssl_inbound_inspection.block_unsupported_cipher is True

    assert profile.ssl_protocol_settings is not None
    assert profile.ssl_protocol_settings.min_version == "tls1-1"
    assert profile.ssl_protocol_settings.max_version == "tls1-2"
    assert profile.ssl_protocol_settings.enc_algo_3des is True
    assert profile.ssl_protocol_settings.auth_algo_sha1 is True

    assert profile.no_decryption is not None
    assert profile.no_decryption.block_expired_certificate is True
    assert profile.no_decryption.block_untrusted_issuer is False

    assert profile.ssh_proxy is not None
    assert profile.ssh_proxy.block_unsupported_alg is True
    assert profile.ssh_proxy.block_unsupported_version is False
