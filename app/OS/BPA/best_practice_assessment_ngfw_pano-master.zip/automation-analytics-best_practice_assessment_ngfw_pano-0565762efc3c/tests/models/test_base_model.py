import pytest

from bpa.models.device.administrator import AdministratorModel


@pytest.mark.core
class TestBaseModel:
    def test_build_model_key(self):
        assert AdministratorModel.build_model_key() == "administrator"

    def test_build_index(self):
        assert AdministratorModel.build_index() == ["template_name", "name"]
