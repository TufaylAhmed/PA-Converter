import pytest
from unittest.mock import MagicMock
from lxml import etree

from bpa.models.device.certificate import CertificateModel
from tests.utils.config import get_snippet_from_path
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_path(__name__))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_certificate(model_manager):
    model_manager.tree = MagicMock()
    obj = CertificateModel.from_el(entry, model_manager)
    assert obj.name == "SAP Server Cert"
    assert obj.issuer_hash == "test1"
    assert obj.subject_hash == "test2"


def test_certificate_empty_xml(model_manager):
    model_manager.tree = MagicMock()
    obj = CertificateModel.from_el(empty_config, model_manager)
    assert obj.name is None
    assert obj.issuer_hash is None
    assert obj.subject_hash is None
