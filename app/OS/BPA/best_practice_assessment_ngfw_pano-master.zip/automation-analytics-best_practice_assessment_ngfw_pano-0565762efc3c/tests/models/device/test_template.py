import pytest
from lxml import etree

from bpa.models.device.template import TemplateModel
from tests.utils.config import get_snippet_from_path
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_path(__name__))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


class TestTemplate:
    def test_template_pass(self, model_manager):
        template = TemplateModel.from_el(entry, model_manager)
        assert template is not None
        assert template.name == "Temple-FW"
        assert template.vsys == ["vsys1", "vsys2", "vsys3"]

    def test_template_empty_xml(self, model_manager):
        template = TemplateModel.from_el(empty_config, model_manager)
        assert template.name is None
