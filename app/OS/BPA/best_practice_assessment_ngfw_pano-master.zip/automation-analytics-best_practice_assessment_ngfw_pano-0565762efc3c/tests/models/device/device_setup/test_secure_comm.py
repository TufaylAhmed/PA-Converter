import os
from unittest.mock import MagicMock

from lxml import etree

from tests import fixt_path
from bpa.models.device.device_setup.secure_comm import (
    SecureCommSettings,
    DeviceCustomizeCommunication,
    PanoramaCustomizeCommunication,
)


el = etree.parse(os.path.join(fixt_path, "device_setup", "device_setup.xml")).getroot()


class Test_secure_comm_client:
    def test_ngfw(self):
        model_manager = MagicMock()
        model_manager.tree.panorama = False
        model_manager.tree.ngfw = True
        secure_comm = SecureCommSettings.parse_entry(el, model_manager)
        assert secure_comm.client is not None

    def test_panorama_running_pan_os_lt_81(self):
        model_manager = MagicMock()
        model_manager.tree.panorama = True
        model_manager.tree.ngfw = False
        model_manager.tree.version = 8.0
        secure_comm = SecureCommSettings.parse_entry(el, model_manager)
        assert secure_comm.client is None

    def test_panorama_running_pan_os_gte_81(self):
        model_manager = MagicMock()
        model_manager.tree.panorama = True
        model_manager.tree.ngfw = False
        model_manager.tree.version = 8.1
        secure_comm = SecureCommSettings.parse_entry(el, model_manager)
        assert secure_comm.client is not None


class Test_secure_comm_server:
    def test_ngfw(self):
        model_manager = MagicMock()
        model_manager.tree.panorama = False
        model_manager.tree.ngfw = True
        model_manager.tree.version = 0
        secure_comm = SecureCommSettings.parse_entry(el, model_manager)
        assert secure_comm.server is None

    def test_panorama(self):
        model_manager = MagicMock()
        model_manager.tree.panorama = True
        model_manager.tree.ngfw = False
        model_manager.tree.version = 0
        secure_comm = SecureCommSettings.parse_entry(el, model_manager)
        assert secure_comm.server is not None


def test_secure_comm_device():
    model_manager = MagicMock()
    model_manager.tree.panorama = False
    model_manager.tree.ngfw = True
    model_manager.tree.version = 8.1
    secure_comm = SecureCommSettings.parse_entry(el, model_manager)

    assert secure_comm.client.certificate_type == "scep"
    assert secure_comm.client.certificate_profile == "Cert-Profile"
    assert secure_comm.client.certificate is None
    assert secure_comm.client.scep_profile == "scep"

    assert isinstance(
        secure_comm.client.customize_communication, DeviceCustomizeCommunication
    )
    assert secure_comm.client.customize_communication.panorama is True
    assert secure_comm.client.customize_communication.pan_db is True
    assert secure_comm.client.customize_communication.wildfire is False
    assert secure_comm.client.customize_communication.log_collector is True

    assert secure_comm.server is None


def test_secure_comm_pano():
    model_manager = MagicMock()
    model_manager.tree.panorama = True
    model_manager.tree.ngfw = False
    model_manager.tree.version = 8.1
    secure_comm = SecureCommSettings.parse_entry(el, model_manager)

    assert isinstance(
        secure_comm.client.customize_communication, PanoramaCustomizeCommunication
    )
    assert secure_comm.client.customize_communication.high_availability is False
    assert secure_comm.client.customize_communication.wildfire is False

    assert secure_comm.server.ssl_tls_service_profile == "pano-ssl-tls"
    assert secure_comm.server.certificate_profile == "pano-cert-prof"
    assert secure_comm.server.allow_custom_certificate_only is True
