import pytest
from lxml import etree

from bpa.models.device.template_stack import TemplateStackModel
from tests.utils.config import get_snippet_from_path
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_path(__name__))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


class TestTemplateStack:
    def test_template_stack_pass(self, model_manager):
        stack = TemplateStackModel.from_el(entry, model_manager)
        assert stack is not None
        assert stack.name == "Template-Stk-1"
        assert stack.templates == ["Template-A", "Template-Global"]
        assert stack.devices == ["007251000047598"]

    def test_template_stack_empty_xml(self, model_manager):
        stack = TemplateStackModel.from_el(empty_config, model_manager)
        assert stack.name is None
