import pytest
from lxml import etree

from bpa.models.device.server_profiles import RadiusServerProfileModel
from tests.utils.config import get_snippet_from_model
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_model("server_profiles", "radius", "8x"))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_server_profiles_radius(model_manager):
    server = RadiusServerProfileModel.from_el(entry, model_manager)
    assert server.name == "TestRad"
    assert server.server_ip_configured is True
    assert server.protocol == "CHAP"


def test_server_profiles_radius_empty_xml(model_manager):
    server = RadiusServerProfileModel.from_el(empty_config, model_manager)
    assert server.name is None
    assert server.server_ip_configured is False
    assert server.protocol == "PEAP-MSCHAPv2"
