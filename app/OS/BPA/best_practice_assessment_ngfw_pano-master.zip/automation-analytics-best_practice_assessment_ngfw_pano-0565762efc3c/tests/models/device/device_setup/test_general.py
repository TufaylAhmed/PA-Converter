import os

from lxml import etree

from tests import fixt_path
from bpa.models.device.device_setup.device_setup import GeneralSettings
from tests.utils.config import get_empty_config


config = etree.parse(os.path.join(fixt_path, "device_setup", "device_setup.xml"))
empty_config = get_empty_config()


def test_general_settings():
    general = GeneralSettings.parse_entry(config, panorama=True)
    assert general.login_banner_enabled is True
    assert general.auto_acquire_commit_lock_enabled is True
    assert general.ssl_tls_service_profile == "Panorama-HTTPS"
    assert general.hostname == "panw"
    assert general.cert_expiration_check_enabled is None


def test_general_setting_empty_xml():
    general = GeneralSettings.parse_entry(empty_config, panorama=False)
    assert general.login_banner_enabled is False
    assert general.auto_acquire_commit_lock_enabled is False
    assert general.ssl_tls_service_profile is None
    assert general.hostname is None
    assert general.cert_expiration_check_enabled is None
    general = GeneralSettings.parse_entry(empty_config, panorama=True)
    assert general.login_banner_enabled is False
    assert general.auto_acquire_commit_lock_enabled is False
    assert general.ssl_tls_service_profile is None
    assert general.hostname is None
    assert general.cert_expiration_check_enabled is None
