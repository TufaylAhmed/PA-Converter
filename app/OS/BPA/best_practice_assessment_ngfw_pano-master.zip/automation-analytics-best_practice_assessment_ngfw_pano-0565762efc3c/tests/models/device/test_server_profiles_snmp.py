import pytest
from lxml import etree

from bpa.models.device.server_profiles import SnmpTrapServerProfileModel
from tests.utils.config import get_snippet_from_model
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_model("server_profiles", "snmp", "8x"))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_server_profiles_snmp(model_manager):
    server = SnmpTrapServerProfileModel.from_el(entry, model_manager)
    assert server.name == "SNMP_Test"
    assert server.version == "v2c"
    assert server.community == "COMM1"


# TODO: Add empty config test when we stop assuming tags exist
"""
def test_server_profiles_snmp_empty_xml(model_manager):
    server = SnmpTrapServerProfileModel.from_el(empty_config, model_manager)
    assert server.name is None
    assert server.version is None
    assert server.community == 'None'
"""
