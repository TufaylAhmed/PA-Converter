import pytest
from lxml import etree

from bpa.models.device.user_id_hub import UserIdHubModel
from tests.utils.config import get_snippet_from_path


config = etree.fromstring(get_snippet_from_path(__name__))
entry = config.xpath(UserIdHubModel.xpath)[0]


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_user_id_hub(model_manager):
    user_id_hub = UserIdHubModel.from_el(entry, model_manager)
    assert user_id_hub.name == "vsys1"
    assert user_id_hub.template_name == "Template-Simple"
