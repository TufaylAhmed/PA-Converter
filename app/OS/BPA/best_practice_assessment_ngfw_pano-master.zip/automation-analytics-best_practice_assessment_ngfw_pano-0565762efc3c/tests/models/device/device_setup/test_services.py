import os

from lxml import etree

from tests import fixt_path
from bpa.models.device.device_setup.services import ServicesSettings
from tests.utils.config import get_empty_config


config = etree.parse(os.path.join(fixt_path, "device_setup", "device_setup.xml"))
empty_config = get_empty_config()


def test_services():
    services = ServicesSettings.parse_entry(config)
    assert services.verify_update_server_identity_enabled is True
    assert services.primary_ntp_server_address == "1.2.3.4"
    assert services.secondary_ntp_server_address == "5.6.7.8"
    assert services.primary_ntp_server_auth_type == "autokey"
    assert services.secondary_ntp_server_auth_type is None


def test_services_empty_xml():
    services = ServicesSettings.parse_entry(empty_config)
    assert services.verify_update_server_identity_enabled is True
    assert services.primary_ntp_server_address is None
    assert services.secondary_ntp_server_address is None
    assert services.primary_ntp_server_auth_type is None
    assert services.secondary_ntp_server_auth_type is None
