import os

from lxml import etree

from tests import fixt_path
from bpa.models.default_value import DefaultValue
from bpa.models.device.device_setup.content_id import ContentIdSettings
from tests.utils.config import get_empty_config


config = etree.parse(os.path.join(fixt_path, "device_setup", "device_setup.xml"))
empty_config = get_empty_config()


def test_content_id():
    content_id = ContentIdSettings.parse_entry(config, panorama=False, version=8.1)
    assert content_id.use_x_forwarded_for_enabled is True
    assert content_id.strip_x_forwarded_for_enabled is False
    assert content_id.exceed_tcp_queue_enabled is False
    assert content_id.exceed_udp_queue_enabled is False
    assert content_id.exceed_appID_queue_enabled is True
    assert not content_id.vsys_not_forwarding_decrypted_content
    assert content_id.allow_http_range is True
    assert content_id.skip_block_http_range is None
    assert content_id.http_partial_enabled is True


def test_content_id_empty_xml():
    content_id = ContentIdSettings.parse_entry(
        empty_config, panorama=False, version=8.1
    )
    assert content_id.use_x_forwarded_for_enabled is False
    assert content_id.strip_x_forwarded_for_enabled is False
    assert content_id.exceed_tcp_queue_enabled is True
    assert content_id.exceed_udp_queue_enabled is True
    assert content_id.exceed_appID_queue_enabled is False
    assert not content_id.vsys_not_forwarding_decrypted_content
    assert content_id.allow_http_range is True
    assert content_id.skip_block_http_range is None
    assert content_id.http_partial_enabled is True


def test_content_id_to_dict():
    content_id = ContentIdSettings()
    assert content_id is not None
    config = content_id.to_dict()
    assert type(config) is dict
    assert all([not isinstance(v, DefaultValue) for v in config.values()])
