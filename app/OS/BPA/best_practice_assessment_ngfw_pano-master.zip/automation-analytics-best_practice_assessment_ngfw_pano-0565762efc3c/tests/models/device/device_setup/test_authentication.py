import os

from lxml import etree

from tests import fixt_path
from bpa.models.device.device_setup.authentication import AuthenticationSettings
from tests.utils.config import get_empty_config


config = etree.parse(os.path.join(fixt_path, "device_setup", "device_setup.xml"))
empty_config = get_empty_config()


def test_authentication_settings():
    auth_settings = AuthenticationSettings.parse_entry(config)
    assert auth_settings.authentication_profile == "Rad-Prof-Auth"
    assert auth_settings.certificate_profile == "Cert-PRof1"
    assert auth_settings.idle_timeout == 60
    assert auth_settings.failed_attempts == 2
    assert auth_settings.lockout_time == 46


def test_authentication_empty_xml():
    auth_settings = AuthenticationSettings.parse_entry(empty_config)
    assert auth_settings.authentication_profile is None
    assert auth_settings.certificate_profile is None
    assert auth_settings.idle_timeout == 60
    assert auth_settings.failed_attempts == 0
    assert auth_settings.lockout_time == 0
