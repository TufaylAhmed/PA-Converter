from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.device.dynamic_updates import DynamicUpdatesModel, UpdateType
from tests.utils.config import get_snippet_from_path
from tests.utils.config import get_empty_config
from tests.utils.compare import compare_dictionaries


entry = etree.fromstring(get_snippet_from_path(__name__))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1

    return model_manager_factory(populate_tree=populate_tree)


def test_certificate_profile(model_manager):
    obj = DynamicUpdatesModel.from_el(entry, model_manager)
    antivirus = UpdateType(
        recurrence="hourly",
        action="download-and-install",
        sync_to_peer=True,
        threshold=12,
    )
    threats = UpdateType(
        recurrence="every-30-mins",
        action="download-and-install",
        sync_to_peer=True,
        threshold=8,
        new_app_threshold=8,
    )
    wildfire = UpdateType(
        recurrence="every-min", action="download-and-install", sync_to_peer=True
    )
    compare_dictionaries(
        obj.update_types,
        {
            "anti-virus": antivirus,
            "threats": threats,
            "wildfire": wildfire,
            "global-protect-datafile": None,
            "global-protect-clientless-vpn": None,
        },
    )


def test_certificate_profile_empty_xml(model_manager):
    obj = DynamicUpdatesModel.from_el(empty_config, model_manager)
    compare_dictionaries(
        obj.update_types,
        {
            "anti-virus": None,
            "threats": None,
            "wildfire": None,
            "global-protect-datafile": None,
            "global-protect-clientless-vpn": None,
        },
    )
