import os

from lxml import etree

from tests import fixt_path
from bpa.models.device.device_setup.panorama import PanoramaSettings
from tests.utils.config import get_empty_config


config = etree.parse(os.path.join(fixt_path, "device_setup", "device_setup.xml"))
empty_config = get_empty_config()


def test_panorama():
    pano = PanoramaSettings.parse_entry(config)
    assert "1.2.3.4" in pano.panorama_servers
    assert "5.6.7.8" in pano.panorama_servers


def test_panorama_empty_xml():
    pano = PanoramaSettings.parse_entry(empty_config)
    assert len(pano.panorama_servers) == 0
