import os

from lxml import etree

from tests import fixt_path
from bpa.models.device.device_setup.management_interface import (
    ManagementInterfaceSettings,
)
from tests.utils.config import get_empty_config


config = etree.parse(os.path.join(fixt_path, "device_setup", "device_setup.xml"))
empty_config = get_empty_config()


def test_management_interface_settings():
    management_interface = ManagementInterfaceSettings.parse_entry(config)
    assert management_interface.management_ip_address == "127.0.0.1"

    assert len(management_interface.permitted_ip_addresses) == 2
    assert all(
        ip in management_interface.permitted_ip_addresses
        for ip in ["10.0.0.1", "10.0.0.2"]
    )

    assert management_interface.speed == "10Mbps-half-duplex"
    assert management_interface.telnet_disabled is True
    assert management_interface.http_disabled is False


def test_management_interface_settings_empty_xml():
    management_interface = ManagementInterfaceSettings.parse_entry(empty_config)
    assert management_interface.management_ip_address is None
    assert len(management_interface.permitted_ip_addresses) == 0
    assert management_interface.speed == "auto-negotiate"
    assert management_interface.telnet_disabled is True
    assert management_interface.http_disabled is True
