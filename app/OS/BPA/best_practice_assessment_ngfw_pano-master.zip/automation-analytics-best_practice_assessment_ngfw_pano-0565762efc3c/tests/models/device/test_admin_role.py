import pytest
from lxml import etree

from bpa.models.device.admin_role import AdminRoleModel
from tests.utils.config import get_snippet_from_path
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_path(__name__))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_admin_role(model_manager):
    admin_role = AdminRoleModel.from_el(entry, model_manager)
    assert admin_role.name == "temp-a-role"


def test_admin_role_empty_xml(model_manager):
    admin_role = AdminRoleModel.from_el(empty_config, model_manager)
    assert admin_role.name is None
