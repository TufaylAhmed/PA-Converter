import os

from lxml import etree

from tests import fixt_path
from bpa.models.device.device_setup.telemetry import (
    StatsServicesSettings,
    TelemetrySettings,
)
from tests.utils.config import get_empty_config


config = etree.parse(os.path.join(fixt_path, "device_setup", "device_setup.xml"))
empty_config = get_empty_config()


def test_stats_services():
    stats_services = StatsServicesSettings.parse_entry(config)
    assert stats_services.application_usage is True
    assert stats_services.attackers is True
    assert stats_services.attacking_countries is False
    assert stats_services.unknown_applications_by_destination_ports is True
    assert stats_services.unknown_applications_by_destination_addresses is True
    assert stats_services.unknown_categories_by_url is False
    assert stats_services.malware_categories_by_url is True
    assert stats_services.dataplane_cache_url is True
    assert stats_services.software_crash_info is True


def test_telemetry():
    telemetry = TelemetrySettings.parse_entry(config)
    assert telemetry.application_reports is True
    assert telemetry.threat_prevention_reports is True
    assert telemetry.threat_prevention_pcap is True
    assert telemetry.threat_prevention_information is False
    assert telemetry.passive_dns_monitoring is True
    assert telemetry.url_reports is True
    assert telemetry.health_performance_reports is True
    assert telemetry.file_identification_reports is False


def test_stats_services_empty_xml():
    stats_services = StatsServicesSettings.parse_entry(empty_config)
    assert stats_services.application_usage is False
    assert stats_services.attackers is False
    assert stats_services.attacking_countries is False
    assert stats_services.unknown_applications_by_destination_ports is False
    assert stats_services.unknown_applications_by_destination_addresses is False
    assert stats_services.unknown_categories_by_url is False
    assert stats_services.malware_categories_by_url is False
    assert stats_services.dataplane_cache_url is False
    assert stats_services.software_crash_info is False


def test_telemetry_empty_xml():
    telemetry = TelemetrySettings.parse_entry(empty_config)
    assert telemetry.application_reports is False
    assert telemetry.threat_prevention_reports is False
    assert telemetry.threat_prevention_pcap is False
    assert telemetry.threat_prevention_information is False
    assert telemetry.passive_dns_monitoring is False
    assert telemetry.url_reports is False
    assert telemetry.health_performance_reports is False
    assert telemetry.file_identification_reports is False
