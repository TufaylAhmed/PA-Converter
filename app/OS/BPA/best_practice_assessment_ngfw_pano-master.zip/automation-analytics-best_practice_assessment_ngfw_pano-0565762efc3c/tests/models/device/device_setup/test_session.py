import os

from lxml import etree

from tests import fixt_path
from bpa.models.device.device_setup.session import SessionSettings
from tests.utils.config import get_empty_config


config = etree.parse(os.path.join(fixt_path, "device_setup", "device_setup.xml"))
empty_config = get_empty_config()


def test_session_8():
    session = SessionSettings.parse_entry(config, version=8.0)
    assert session.rematch_sessions_enabled is True
    assert session.exceed_tcp_out_of_order_queue_enabled is False
    assert session.accelerated_aging_enabled is False

    assert session.timeout_settings.default == 30
    assert session.timeout_settings.discard_default == 69
    assert session.timeout_settings.discard_tcp == 90
    assert session.timeout_settings.discard_udp == 68
    assert session.timeout_settings.icmp == 6
    assert session.timeout_settings.scan == 10
    assert session.timeout_settings.tcp == 3600
    assert session.timeout_settings.tcp_handshake == 11
    assert session.timeout_settings.tcp_init == 5
    assert session.timeout_settings.tcp_half_closed == 120
    assert session.timeout_settings.tcp_time_wait == 15
    assert session.timeout_settings.unverified_rst == 30
    assert session.timeout_settings.udp == 30
    assert session.timeout_settings.captive_portal == 30

    assert session.packet_buffer_protection.enabled is True
    assert session.packet_buffer_protection.alert == 0
    assert session.packet_buffer_protection.activate == 1
    assert session.packet_buffer_protection.block_hold_time == 0
    assert session.packet_buffer_protection.block_duration == 3600


def test_session_pre_8():
    session = SessionSettings.parse_entry(config, version=7.1)
    assert session.packet_buffer_protection is None


def test_session_empty_xml():
    session = SessionSettings.parse_entry(empty_config, version=8.0)
    assert session.rematch_sessions_enabled is True
    assert session.exceed_tcp_out_of_order_queue_enabled is False
    assert session.accelerated_aging_enabled is True

    assert session.timeout_settings.default == 30
    assert session.timeout_settings.discard_default == 60
    assert session.timeout_settings.discard_tcp == 90
    assert session.timeout_settings.discard_udp == 60
    assert session.timeout_settings.icmp == 6
    assert session.timeout_settings.scan == 10
    assert session.timeout_settings.tcp == 3600
    assert session.timeout_settings.tcp_handshake == 10
    assert session.timeout_settings.tcp_init == 5
    assert session.timeout_settings.tcp_half_closed == 120
    assert session.timeout_settings.tcp_time_wait == 15
    assert session.timeout_settings.unverified_rst == 30
    assert session.timeout_settings.udp == 30
    assert session.timeout_settings.captive_portal == 30
    assert session.packet_buffer_protection is None

    session = SessionSettings.parse_entry(empty_config, version=7.0)
    assert session.packet_buffer_protection is None
