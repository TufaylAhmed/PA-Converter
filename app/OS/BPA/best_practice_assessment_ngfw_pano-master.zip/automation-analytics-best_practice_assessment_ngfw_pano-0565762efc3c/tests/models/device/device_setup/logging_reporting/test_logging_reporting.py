import os

from lxml import etree

from tests import fixt_path
from bpa.models.device.device_setup.logging_reporting_settings.logging_reporting import (
    LoggingReportingSettings,
)
from tests.utils.config import get_empty_config


config = etree.parse(os.path.join(fixt_path, "device_setup", "device_setup.xml"))
empty_config = get_empty_config()


def test_logging_reporting():
    logging_reporting = LoggingReportingSettings.parse_entry(config, panorama=True)
    assert logging_reporting.log_forwarding_from_device_enabled is False
    assert logging_reporting.log_on_high_dp_load_enabled is None


def test_logging_reporting_empty_xml():
    logging_reporting = LoggingReportingSettings.parse_entry(
        empty_config, panorama=False
    )
    assert logging_reporting.log_forwarding_from_device_enabled is None
    assert logging_reporting.log_on_high_dp_load_enabled is False
    logging_reporting = LoggingReportingSettings.parse_entry(
        empty_config, panorama=True
    )
    assert logging_reporting.log_forwarding_from_device_enabled is True
    assert logging_reporting.log_on_high_dp_load_enabled is None
