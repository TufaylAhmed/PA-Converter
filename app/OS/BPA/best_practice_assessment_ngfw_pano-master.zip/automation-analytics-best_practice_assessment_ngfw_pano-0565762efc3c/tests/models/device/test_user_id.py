import pytest
from lxml import etree

from bpa.models.device.user_id import UserIdModel, CaptivePortalSetting
from tests.utils.config import get_empty_config, get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_user_id(model_manager):
    obj = UserIdModel.from_el(entry, model_manager)
    assert obj is not None
    assert obj.include_networks == ["TestInclude1", "TestInclude2"]
    assert obj.server_log_monitor_frequency == 5
    assert obj.probing_enabled is True
    assert obj.user_id_timeout_enabled is True
    assert obj.user_id_timeout == 55
    assert [mon.name for mon in obj.server_monitors] == ["ServeMonTest", "ServerTest2"]

    assert len(obj.group_mappings) == 1
    mapping = obj.group_mappings[0]
    assert mapping.name == "User Grp Mapping"
    assert len(mapping.custom_groups) == 2
    assert all(g.name.startswith("Hello") for g in mapping.custom_groups)

    assert obj.captive_portal_setting == CaptivePortalSetting(
        enabled=True,
        mode="transparent",
        session_cookie_enabled=True,
        session_cookie_timeout=1440,
        ssl_tls_service_profile="SSL-Prof",
        ssl_tls_service_profile_min_version="tls1-0",
        auth_profile="Auth SAP Srvrs",
        cert_profile="Cert-Profile",
    )


def test_user_id_empty_xml(model_manager):
    obj = UserIdModel.from_el(empty_config, model_manager)
    assert obj is not None
    assert not obj.include_networks
    assert obj.server_log_monitor_frequency == 2
    assert obj.probing_enabled is False
    assert obj.user_id_timeout_enabled is True
    assert obj.user_id_timeout == 45
    assert not obj.server_monitors
    assert not obj.group_mappings
    assert obj.captive_portal_setting is None
