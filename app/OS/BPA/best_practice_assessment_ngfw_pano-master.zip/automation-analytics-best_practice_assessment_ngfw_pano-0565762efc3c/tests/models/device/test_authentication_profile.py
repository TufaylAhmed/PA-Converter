import pytest
from lxml import etree

from bpa.models.device.authentication_profile import AuthenticationProfileModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


# TODO: Add empty config test when we stop assuming tags exist
@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_authentication_profile(model_manager):
    authentication_profile = AuthenticationProfileModel.from_el(entry, model_manager)
    assert authentication_profile is not None
    assert authentication_profile.name == "Auth SAP Srvrs"
    assert authentication_profile.method == "local-database"
