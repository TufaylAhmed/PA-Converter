from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.device.log_settings import (
    LogSettingsConfigModel,
    LogSettingsSystemModel,
)
from tests.utils.config import get_empty_config, get_snippet_from_model

entry_system_7x = etree.fromstring(
    get_snippet_from_model("log_settings", "system", "7x")
)
entry_system_8_1 = etree.fromstring(
    get_snippet_from_model("log_settings", "system", "8_1")
)

entry_config_7x = etree.fromstring(
    get_snippet_from_model("log_settings", "config", "7x")
)
entry_config_8_1 = etree.fromstring(
    get_snippet_from_model("log_settings", "config", "8_1")
)
empty_config = get_empty_config()


@pytest.fixture
def model_manager_7x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 7

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_manager_8_1(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1

    return model_manager_factory(populate_tree=populate_tree)


def test_log_settings_system_7x(model_manager_7x):
    obj = LogSettingsSystemModel.from_el(entry_system_7x, model_manager_7x)
    assert obj is not None
    assert obj.log_send_to_info == {"send-syslog", "send-snmptrap"}
    assert obj.log_send_to_low == {"send-to-panorama", "send-email"}
    assert obj.log_send_to_medium == {
        "send-syslog",
        "send-to-panorama",
        "send-snmptrap",
    }
    assert obj.log_send_to_high == {"send-syslog", "send-to-panorama", "send-snmptrap"}
    assert obj.log_send_to_critical == {
        "send-syslog",
        "send-to-panorama",
        "send-snmptrap",
        "send-email",
    }


def test_log_settings_system_8_1(model_manager_8_1):
    obj = LogSettingsSystemModel.from_el(entry_system_8_1, model_manager_8_1)
    assert obj is not None
    assert obj.log_send_to_critical == {"send-to-panorama", "send-email"}
    assert obj.critical_content_logs == {"send-to-panorama", "send-email"}


def test_log_settings_config_7x(model_manager_7x):
    obj = LogSettingsConfigModel.from_el(entry_config_7x, model_manager_7x)
    assert obj is not None
    assert obj.config_logs_all == {
        "send-syslog",
        "send-snmptrap",
        "send-email",
        "send-to-panorama",
    }


def test_log_settings_config_8_1(model_manager_8_1):
    obj = LogSettingsConfigModel.from_el(entry_config_8_1, model_manager_8_1)
    assert obj.config_logs_all == {
        "send-syslog",
        "send-email",
        "send-snmptrap",
        "send-http",
    }


def test_log_settings_empty_config_7x(model_manager_7x):
    obj = LogSettingsSystemModel.from_el(empty_config, model_manager_7x)
    assert obj is not None
    assert not obj.log_send_to_info
    assert not obj.log_send_to_low
    assert not obj.log_send_to_medium
    assert not obj.log_send_to_high
    assert not obj.log_send_to_critical
    obj = LogSettingsConfigModel.from_el(empty_config, model_manager_7x)
    assert not obj.config_logs_all


def test_log_settings_empty_config_8_1(model_manager_8_1):
    obj = LogSettingsSystemModel.from_el(empty_config, model_manager_8_1)
    assert obj is not None
    assert not obj.log_send_to_info
    assert not obj.log_send_to_low
    assert not obj.log_send_to_medium
    assert not obj.log_send_to_high
    assert not obj.log_send_to_critical
    obj = LogSettingsConfigModel.from_el(empty_config, model_manager_8_1)
    assert not obj.config_logs_all
