import pytest

from bpa.models.device.template_stack import TemplateStackModel
from bpa.models.device.authentication_profile import AuthenticationProfileModel
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager_profile(model_manager_factory):
    def populate_models(model_manager):
        ms = model_manager.model_set_lookup["authentication_profile"] = ModelSet()

        ms.add(
            build_model(
                AuthenticationProfileModel,
                model_manager,
                template_name="Template-Stk-1",
                name="Other_profile",
                lockout_time=1,
            )
        )

        ms.add(
            build_model(
                AuthenticationProfileModel,
                model_manager,
                template_name="Template-FW",
                name="Test1",
                server_profile=None,
                lockout_time=0,
            )
        )

        ms.add(
            build_model(
                AuthenticationProfileModel,
                model_manager,
                template_name="Template-FW2",
                name="Test1",
                server_profile="ServerProf",
                lockout_time=12,
                allow_list=["all"],
            )
        )

    return model_manager_factory(populate_models=populate_models)


@pytest.mark.integration
class TestAuthenticationProfile:
    def test_auth_template_stack(self, model_manager_profile):
        stack = build_model(
            TemplateStackModel,
            model_manager=model_manager_profile,
            name="Template-Stk-1",
            templates=["Template-FW", "Template-FW2"],
            devices=["007251000032430"],
        )

        assert stack is not None
        assert stack.name == "Template-Stk-1"
        assert stack.templates == ["Template-FW", "Template-FW2"]

        auth_ms = stack.get("authentication_profile")
        templates = list(auth_ms)
        assert len(templates) == 2

        resolved_model1 = auth_ms.find(
            template_name="Template-Stk-1", location="", name="Other_profile"
        )

        resolved_model2 = auth_ms.find(
            template_name="Template-Stk-1", location="", name="Test1"
        )

        assert resolved_model1.template_name == "Template-Stk-1"
        assert resolved_model1.name == "Other_profile"

        assert resolved_model2.template_name == "Template-Stk-1"
        assert resolved_model2.name == "Test1"
        assert resolved_model2.server_profile is None
        assert resolved_model2.lockout_time == 0
        assert resolved_model2.allow_list == []
