import pytest
from lxml import etree

from bpa.models.device.ssl_tls_service_profile import SslTlsServiceProfileModel
from tests.utils.config import get_snippet_from_path
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_path(__name__))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_ssl(model_manager):
    ssl = SslTlsServiceProfileModel.from_el(entry, model_manager)
    assert ssl.name == "STPro"
    assert ssl.certificate == "Fwd-decryption"
    assert ssl.min_version == "tls1-2"


def test_ssl_empty_xml(model_manager):
    ssl = SslTlsServiceProfileModel.from_el(empty_config, model_manager)
    assert ssl.name is None
    assert ssl.certificate is None
    assert ssl.min_version == "tls1-0"
