import pytest
from lxml import etree

from bpa.models.device.certificate_profile import CertificateProfileModel
from tests.utils.config import get_snippet_from_path
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_path(__name__))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_certificate_profile(model_manager):
    obj = CertificateProfileModel.from_el(entry, model_manager)
    assert obj.name == "CertProf"
    assert obj.use_crl is True
    assert obj.use_ocsp is True


def test_certificate_profile_empty_xml(model_manager):
    obj = CertificateProfileModel.from_el(empty_config, model_manager)
    assert obj.name is None
    assert obj.use_crl is False
    assert obj.use_ocsp is False
