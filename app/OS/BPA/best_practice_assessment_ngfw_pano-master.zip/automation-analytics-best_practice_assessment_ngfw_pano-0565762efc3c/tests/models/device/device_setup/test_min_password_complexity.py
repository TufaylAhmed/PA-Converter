import os

from lxml import etree

from tests import fixt_path
from bpa.models.device.device_setup.min_password_complexity import (
    MinimumPasswordComplexitySettings,
)
from tests.utils.config import get_empty_config


config = etree.parse(os.path.join(fixt_path, "device_setup", "device_setup.xml")).find(
    "mgt-config/password-complexity"
)
empty_config = get_empty_config()


def test_min_password_complexity():
    min_password_complexity = MinimumPasswordComplexitySettings.parse_entry(config)
    assert min_password_complexity.enabled is False
    assert min_password_complexity.block_username_inclusion is True
    assert min_password_complexity.minimum_length == 9
    assert min_password_complexity.minimum_uppercase_letters == 2
    assert min_password_complexity.minimum_lowercase_letters == 2


def test_min_password_complexity_empty_xml():
    min_password_complexity = MinimumPasswordComplexitySettings.parse_entry(
        empty_config
    )
    assert min_password_complexity.enabled is False
    assert min_password_complexity.block_username_inclusion is False
    assert min_password_complexity.minimum_length == 0
    assert min_password_complexity.minimum_uppercase_letters == 0
    assert min_password_complexity.minimum_lowercase_letters == 0
