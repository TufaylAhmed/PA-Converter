import pytest
from lxml import etree

from bpa.models.device.server_profiles import SyslogServerProfileModel
from tests.utils.config import get_snippet_from_model
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_model("server_profiles", "syslog", "8x"))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_server_profiles_syslog(model_manager):
    server = SyslogServerProfileModel.from_el(entry, model_manager)
    assert server.name == "Syslog-Profile"
    assert server.transport == "UDP"


def test_server_profiles_syslog_empty_xml(model_manager):
    server = SyslogServerProfileModel.from_el(empty_config, model_manager)
    assert server.name is None
    assert server.transport == "None"
