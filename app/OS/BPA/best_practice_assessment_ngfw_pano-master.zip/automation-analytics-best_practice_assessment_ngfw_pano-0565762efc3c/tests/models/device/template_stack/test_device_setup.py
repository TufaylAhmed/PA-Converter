import pytest

from bpa.models.device.template_stack import TemplateStackModel
from bpa.models.device.device_setup.device_setup import DeviceSetupModel
from bpa.models.device.device_setup.general import GeneralSettings
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model, build_skeleton


@pytest.fixture
def model_manager_settings(model_manager_factory):
    def populate_models(model_manager):
        ms = model_manager.model_set_lookup["device_setup"] = ModelSet()

        # Template Stack 1 default settings
        ms.add(
            build_model(
                DeviceSetupModel,
                model_manager,
                template_name="Template-Stk-1",
                general=build_skeleton(
                    GeneralSettings, login_banner="None", hostname=None
                ),
            )
        )

        # Template 1 settings
        ms.add(
            build_model(
                DeviceSetupModel,
                model_manager,
                template_name="Template-FW",
                general=build_skeleton(
                    GeneralSettings, login_banner="None", hostname="winning-hostname"
                ),
            )
        )

        # Template 2 settings
        ms.add(
            build_model(
                DeviceSetupModel,
                model_manager,
                template_name="Template-FW2",
                general=build_skeleton(
                    GeneralSettings, login_banner="Descriptive banner...", hostname=None
                ),
            )
        )

    return model_manager_factory(populate_models=populate_models)


@pytest.mark.integration
class TestDeviceSetup:
    def test_device_template_stack(self, model_manager_settings):
        stack = build_model(
            TemplateStackModel,
            model_manager=model_manager_settings,
            name="Template-Stk-1",
            templates=["Template-FW", "Template-FW2"],
            devices=["007251000032430"],
        )

        assert stack is not None
        assert stack.name == "Template-Stk-1"
        assert stack.templates == ["Template-FW", "Template-FW2"]

        device_ms = stack.get("device_setup")
        model_list = list(device_ms)
        assert len(model_list) == 1

        resolved_model = model_list[0]
        assert resolved_model.template_name == "Template-Stk-1"
        assert resolved_model.general.login_banner == "Descriptive banner..."
        assert resolved_model.general.hostname == "winning-hostname"
