import pytest
from lxml import etree

from bpa.models.device.server_profiles import TacPlusServerProfileModel
from tests.utils.config import get_snippet_from_model
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_model("server_profiles", "tacplus", "8x"))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_server_profiles_tacplus(model_manager):
    server = TacPlusServerProfileModel.from_el(entry, model_manager)
    assert server.name == "Tacplus-Profile"
    assert len(server.server_list) > 0
    assert server.protocol == "CHAP"


def test_server_profiles_tacplus_empty_xml(model_manager):
    server = TacPlusServerProfileModel.from_el(empty_config, model_manager)
    assert server.name is None
    assert len(server.server_list) == 0
    assert server.protocol == "PEAP-MSCHAPv2"
