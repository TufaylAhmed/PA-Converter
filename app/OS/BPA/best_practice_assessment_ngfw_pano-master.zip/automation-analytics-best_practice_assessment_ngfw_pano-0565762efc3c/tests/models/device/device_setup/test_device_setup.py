import os
from unittest.mock import MagicMock

import pytest
from lxml import etree

from tests import fixt_path
from bpa.models.device.device_setup.device_setup import (
    DeviceSetupModel,
    PanoramaSettings,
    SessionSettings,
    StatsServicesSettings,
    TelemetrySettings,
)


config = etree.parse(
    os.path.join(fixt_path, "device_setup", "device_setup.xml")
).getroot()


@pytest.fixture
def model_manager_7x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 7.1
        model_manager.tree.panorama = False

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_manager_8x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.0
        model_manager.tree.panorama = True

    return model_manager_factory(populate_tree=populate_tree)


def test_device_setup_pano_8(model_manager_8x):
    device_setup = DeviceSetupModel.from_el(config, model_manager_8x)
    assert device_setup.panorama is None
    assert device_setup.session is None
    assert isinstance(device_setup.telemetry, TelemetrySettings)


def test_device_setup_ngfw_7(model_manager_7x):
    device_setup = DeviceSetupModel.from_el(config, model_manager_7x)
    assert isinstance(device_setup.panorama, PanoramaSettings)
    assert isinstance(device_setup.session, SessionSettings)
    assert isinstance(device_setup.telemetry, StatsServicesSettings)
