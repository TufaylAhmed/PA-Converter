import os

from lxml import etree

from tests import fixt_path
from bpa.models.device.device_setup.logging_reporting_settings.predefined_reports import (
    PredefinedReports,
)
from tests.utils.config import get_empty_config


config = etree.parse(os.path.join(fixt_path, "device_setup", "device_setup.xml"))
empty_config = get_empty_config()


def test_predefined_reports():
    predefined_reports_pano = PredefinedReports.parse_entry(config, panorama=True)
    predefined_reports_ngfw = PredefinedReports.parse_entry(config, panorama=False)
    assert set(predefined_reports_pano.enabled_predefined_reports) == set(
        ["top-rules", "top-sources"]
    )
    assert set(predefined_reports_ngfw.enabled_predefined_reports) == set(
        ["top-rules", "top-sources"]
    )


def test_predefined_reports_empty_xml():
    predefined_reports_pano = PredefinedReports.parse_entry(empty_config, panorama=True)
    all_reports_length = len(PredefinedReports.all_predefined_reports)
    assert len(predefined_reports_pano.enabled_predefined_reports) == all_reports_length
