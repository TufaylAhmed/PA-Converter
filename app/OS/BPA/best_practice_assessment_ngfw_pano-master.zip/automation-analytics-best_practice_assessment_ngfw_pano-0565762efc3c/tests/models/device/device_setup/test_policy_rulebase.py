import os

from lxml import etree

from bpa.models.device.device_setup.policy_rulebase import PolicyRulebase
from tests import fixt_path
from tests.utils.config import get_empty_config


policy_path = os.path.join(fixt_path, "device_setup", "policy_rulebase")
default_path = os.path.join(policy_path, "all_default.xml")
enabled_path = os.path.join(policy_path, "all_on.xml")
disabled_path = os.path.join(policy_path, "all_off.xml")

default_config = etree.parse(default_path)
enabled_config = etree.parse(enabled_path)
disabled_config = etree.parse(disabled_path)
empty_config = get_empty_config()


def test_policy_rulebase_default():
    policy_rulebase = PolicyRulebase.parse_entry(default_config)
    assert policy_rulebase.rule_require_audit_comment is False
    assert policy_rulebase.rule_fail_commit is False
    assert policy_rulebase.rule_hit_count is True
    assert policy_rulebase.appusage_policy is True


def test_policy_rulebase_empty_xml():
    policy_rulebase = PolicyRulebase.parse_entry(empty_config)
    assert policy_rulebase.rule_require_audit_comment is False
    assert policy_rulebase.rule_fail_commit is False
    assert policy_rulebase.rule_hit_count is True
    assert policy_rulebase.appusage_policy is True


def test_policy_rulebase_enabled():
    policy_rulebase = PolicyRulebase.parse_entry(enabled_config)
    assert policy_rulebase.rule_require_audit_comment is True
    assert policy_rulebase.rule_fail_commit is True
    assert policy_rulebase.rule_hit_count is True
    assert policy_rulebase.appusage_policy is True


def test_policy_rulebase_disabled():
    policy_rulebase = PolicyRulebase.parse_entry(disabled_config)
    assert policy_rulebase.rule_require_audit_comment is False
    assert policy_rulebase.rule_fail_commit is False
    assert policy_rulebase.rule_hit_count is False
    assert policy_rulebase.appusage_policy is False
