import pytest
from lxml import etree

from bpa.models.device.administrator import AdministratorModel
from tests.utils.config import get_snippet_from_path
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_path(__name__))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_admin(model_manager):
    admin = AdministratorModel.from_el(entry, model_manager)
    assert admin.name == "admin"
    assert admin.password_profile is None
    assert admin.authentication_profile == "dummy"
    assert admin.role == "superuser"


def test_admin_empty_xml(model_manager):
    admin = AdministratorModel.from_el(empty_config, model_manager)
    assert admin.name is None
    assert admin.password_profile is None
    assert admin.authentication_profile is None
    assert admin.role == "None"
