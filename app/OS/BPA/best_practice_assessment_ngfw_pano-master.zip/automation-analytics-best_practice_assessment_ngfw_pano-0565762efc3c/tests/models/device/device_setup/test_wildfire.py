import os

from lxml import etree

from tests import fixt_path
from bpa.models.device.device_setup.wildfire import WildFireSettings, SessionInfo
from tests.utils.config import get_empty_config


config = etree.parse(os.path.join(fixt_path, "device_setup", "device_setup.xml"))
empty_config = get_empty_config()


def test_wildfire_8():
    wildfire = WildFireSettings.parse_entry(config, version=8.0)
    assert wildfire is not None
    assert wildfire.wildfire_public_cloud == "wildfire.backup.paloaltonetworks.com"
    assert wildfire.timezone == "Japan"
    assert wildfire.report_grayware_files_enabled is True
    assert wildfire.size_limits == {
        "pe": 9,
        "apk": 12,
        "pdf": 503,
        "ms-office": 504,
        "jar": 2,
        "flash": 7,
        "MacOSX": 2,
        "archive": 13,
        "linux": 4,
        "email-link": 0,
    }
    assert wildfire.session_info == SessionInfo(
        source_ip_enabled=True,
        source_port_enabled=True,
        destination_ip_enabled=True,
        destination_port_enabled=True,
        virtual_system_enabled=True,
        application_enabled=True,
        user_enabled=True,
        url_enabled=True,
        file_name_enabled=True,
        email_sender_enabled=True,
        email_recipient_enabled=True,
        email_subject_enabled=True,
    )


def test_wildfire_default_limits_7_1():
    wildfire = WildFireSettings.parse_entry(config, version=7.1)
    assert wildfire.size_limits == {
        "pe": 9,
        "apk": 12,
        "pdf": 503,
        "ms-office": 504,
        "jar": 2,
        "flash": 7,
        "MacOSX": 2,
        "archive": 13,
        "linux": 4,
        "email-link": 0,
    }


def test_wildfire_empty_xml():
    wildfire = WildFireSettings.parse_entry(empty_config, version=8.0)
    assert wildfire.wildfire_public_cloud == "wildfire.paloaltonetworks.com"
    assert wildfire.timezone is None
    assert wildfire.report_grayware_files_enabled is False
    assert wildfire.size_limits == {
        "pe": 10,
        "apk": 10,
        "pdf": 500,
        "ms-office": 500,
        "jar": 1,
        "flash": 5,
        "MacOSX": 1,
        "archive": 10,
        "linux": 2,
        "email-link": 0,
    }
    assert wildfire.session_info == SessionInfo(
        source_ip_enabled=True,
        source_port_enabled=True,
        destination_ip_enabled=True,
        destination_port_enabled=True,
        virtual_system_enabled=True,
        application_enabled=True,
        user_enabled=True,
        url_enabled=True,
        file_name_enabled=True,
        email_sender_enabled=True,
        email_recipient_enabled=True,
        email_subject_enabled=True,
    )

    wildfire = WildFireSettings.parse_entry(empty_config, version=7.1)
    assert wildfire.size_limits == {
        "pe": 10,
        "apk": 10,
        "pdf": 500,
        "ms-office": 500,
        "jar": 1,
        "flash": 5,
        "MacOSX": 1,
        "archive": 10,
        "email-link": 0,
    }
