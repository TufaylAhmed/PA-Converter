from unittest.mock import MagicMock

import pytest
from lxml import etree

from bpa.models.constants import NONE
from bpa.models.device.high_availability import HighAvailabilityModel
from tests.utils.config import get_empty_config, get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.panorama = True
        model_manager.tree.version = 8.1

    return model_manager_factory(populate_tree=populate_tree)


def test_high_availability_panorama_true(model_manager):
    # Setup for test data
    obj = HighAvailabilityModel.from_el(entry, model_manager)
    assert obj.ha_enabled is True

    assert obj.general_config is not None
    assert obj.general_config.timers == "aggressive"
    assert obj.general_config.preemptive_enabled is True
    assert obj.general_config.ha1_config is None
    assert obj.general_config.ha2_config is None
    assert obj.general_config.ha3_config is None

    assert obj.link_path_monitoring_config is not None
    assert obj.link_path_monitoring_config.path_monitoring_enabled is True
    assert obj.link_path_monitoring_config.destination_ip_set is False
    assert obj.link_path_monitoring_config.one_group_enabled is False


def test_high_availability_panorama_true_template_fw(model_manager):
    # Setup for test data
    model_manager.tree.panorama = True
    HighAvailabilityModel._get_template_name = MagicMock(return_value="Template-FW")

    obj = HighAvailabilityModel.from_el(entry, model_manager)
    assert obj.ha_enabled is True

    assert obj.general_config is not None
    assert obj.general_config.timers == "aggressive"
    assert obj.general_config.preemptive_enabled is True
    assert obj.general_config.ha1_config is not None
    assert obj.general_config.ha2_config is not None
    assert obj.general_config.ha3_config is not None

    assert obj.link_path_monitoring_config is not None
    assert obj.link_path_monitoring_config.path_monitoring_enabled is True
    assert obj.link_path_monitoring_config.destination_ip_set is True
    assert obj.link_path_monitoring_config.one_group_enabled is True


def test_high_availability_panorama_false(model_manager):
    # Setup for test data
    model_manager.tree.panorama = False

    obj = HighAvailabilityModel.from_el(entry, model_manager)
    assert obj.ha_enabled is True

    assert obj.general_config is not None
    assert obj.general_config.timers == "aggressive"
    assert obj.general_config.preemptive_enabled is True

    assert obj.general_config.ha1_config.ip_address == "10.11.12.133"
    assert obj.general_config.ha1_config.port == "aux-1"
    assert obj.general_config.ha1_config.gateway == "12.12.12.133"
    assert obj.general_config.ha1_config.encryption_enabled is True
    assert obj.general_config.ha1_config.backup_ip_address == "13.13.12.133"
    assert obj.general_config.ha1_config.backup_port == "aux-1"
    assert obj.general_config.ha1_config.backup_netmask == NONE
    assert obj.general_config.ha1_config.backup_gateway == NONE

    assert obj.link_path_monitoring_config is not None
    assert obj.link_path_monitoring_config.path_monitoring_enabled is True
    assert obj.link_path_monitoring_config.destination_ip_set is True
    assert obj.link_path_monitoring_config.one_group_enabled is True


def test_high_availability_panorama_false_template_fw(model_manager):
    # Setup for test data
    model_manager.tree.panorama = False
    HighAvailabilityModel._get_template_name = MagicMock(return_value="Template-FW")

    obj = HighAvailabilityModel.from_el(entry, model_manager)
    assert obj.ha_enabled is True

    assert obj.general_config is not None
    assert obj.general_config.timers == "aggressive"
    assert obj.general_config.preemptive_enabled is True

    assert obj.general_config.ha1_config.ip_address == "10.11.12.133"
    assert obj.general_config.ha1_config.port == "aux-1"
    assert obj.general_config.ha1_config.gateway == "12.12.12.133"
    assert obj.general_config.ha1_config.encryption_enabled is True
    assert obj.general_config.ha1_config.backup_ip_address == "13.13.12.133"
    assert obj.general_config.ha1_config.backup_port == "aux-1"
    assert obj.general_config.ha1_config.backup_netmask == NONE
    assert obj.general_config.ha1_config.backup_gateway == NONE

    assert obj.link_path_monitoring_config is not None
    assert obj.link_path_monitoring_config.path_monitoring_enabled is True
    assert obj.link_path_monitoring_config.destination_ip_set is True
    assert obj.link_path_monitoring_config.one_group_enabled is True


def test_high_availability_empty_xml(model_manager):
    # Setup for test data
    obj = HighAvailabilityModel.from_el(empty_config, model_manager)
    assert obj.ha_enabled is False

    assert obj.general_config is not None
    assert obj.general_config.timers == "recommended"
    assert obj.general_config.preemptive_enabled is False
    assert obj.general_config.ha1_config is not None
    assert obj.general_config.ha2_config is not None
    assert obj.general_config.ha3_config is not None

    assert obj.link_path_monitoring_config is not None
    assert obj.link_path_monitoring_config.path_monitoring_enabled is True
    assert obj.link_path_monitoring_config.destination_ip_set is False
    assert obj.link_path_monitoring_config.one_group_enabled is False
