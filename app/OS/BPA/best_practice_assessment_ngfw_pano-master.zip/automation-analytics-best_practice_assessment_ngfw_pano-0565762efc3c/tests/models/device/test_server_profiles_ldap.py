import pytest
from lxml import etree

from bpa.models.device.server_profiles import LdapServerProfileModel
from tests.utils.config import get_snippet_from_model
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_model("server_profiles", "ldap", "8x"))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_server_profiles_ldap(model_manager):
    server = LdapServerProfileModel.from_el(entry, model_manager)
    assert server.name == "Lda prof"
    assert server.server_list == ["Sv1", "sv2"]
    assert server.require_ssl_tls_secured_connection is True
    assert server.verify_server_certificate_for_ssl_sessions is True


def test_server_profiles_ldap_empty_xml(model_manager):
    server = LdapServerProfileModel.from_el(empty_config, model_manager)
    assert server.name is None
    assert not server.server_list
    assert server.require_ssl_tls_secured_connection is True
    assert server.verify_server_certificate_for_ssl_sessions is False
