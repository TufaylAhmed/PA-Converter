import pytest
from lxml import etree

from bpa.models.device.password_profile import PasswordProfileModel
from tests.utils.config import get_snippet_from_path
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_path(__name__))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_pass_profile(model_manager):
    obj = PasswordProfileModel.from_el(entry, model_manager)
    assert obj.name == "PassProf"
    assert obj.password_change_period == "4"


def test_pass_profile_empty_xml(model_manager):
    obj = PasswordProfileModel.from_el(empty_config, model_manager)
    assert obj.name is None
    assert obj.password_change_period is None
