import pytest
from lxml import etree

from bpa.models.device.virtual_system import VirtualSystemModel
from tests.utils.config import get_snippet_from_path


config = etree.fromstring(get_snippet_from_path(__name__))
entry = config.xpath(VirtualSystemModel.xpath)[0]


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_virtual_system(model_manager):
    virtual_system = VirtualSystemModel.from_el(entry, model_manager)
    assert virtual_system.name == "vsys1"
    assert virtual_system.template_name == "Template-Simple"
