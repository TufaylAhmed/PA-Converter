import pytest
from lxml import etree

from bpa.models.device.authentication_sequence import AuthenticationSequenceModel
from tests.utils.config import get_snippet_from_path
from tests.utils.config import get_empty_config


entry = etree.fromstring(get_snippet_from_path(__name__))
empty_config = get_empty_config()


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_authentication_sequence(model_manager):
    obj = AuthenticationSequenceModel.from_el(entry, model_manager)
    assert obj is not None
    assert obj.name == "TestAuthSeq"
    assert obj.auth_profiles == ["Auth SAP Srvrs", "Auth Servers"]


def test_authentication_sequence_empty_xml(model_manager):
    obj = AuthenticationSequenceModel.from_el(empty_config, model_manager)
    assert obj is not None
    assert obj.name is None
    assert not obj.auth_profiles
