import pytest
from lxml import etree

from bpa.models.monitor.pdf_reports.pdf_report_group import PdfReportGroupModel
from tests.utils.config import get_snippet_from_path

from tests.utils.config import get_empty_config

empty_config = get_empty_config()


entry = etree.fromstring(get_snippet_from_path(__name__))
config = entry.xpath(PdfReportGroupModel.xpath)[0]


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_pdf_report_group(model_manager):
    report = PdfReportGroupModel.from_el(config, model_manager)
    assert report.name == "Bob"
    assert set(report.reports) == set(["risky-users", "risk-trend"])


def test_pdf_report_group_empty_xml():
    report = PdfReportGroupModel.from_el(empty_config, model_manager)
    assert report.name is None
    assert len(report.reports) == 0
