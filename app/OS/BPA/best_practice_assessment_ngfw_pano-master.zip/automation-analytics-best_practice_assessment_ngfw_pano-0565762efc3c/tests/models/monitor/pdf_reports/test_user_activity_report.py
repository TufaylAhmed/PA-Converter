import pytest
from lxml import etree

from bpa.models.monitor.pdf_reports.user_activity_report import UserActivityReportModel
from tests.utils.config import get_snippet_from_path


entry = etree.fromstring(get_snippet_from_path(__name__))


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_user_activity_report(model_manager):
    report = UserActivityReportModel.from_el(entry, model_manager)
    assert report is not None
    assert report.name == "SaaS-Activity-Rep"
    assert report.report_type == "saas-application-usage-report"
