import pytest
from lxml import etree

from bpa.models.monitor.pdf_reports.pdf_summary_report import PdfSummaryReportModel
from tests.utils.config import get_snippet_from_path

from tests.utils.config import get_empty_config

empty_config = get_empty_config()


entry = etree.fromstring(get_snippet_from_path(__name__))
config = entry.xpath(PdfSummaryReportModel.xpath)[0]


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


def test_pdf_summary_report(model_manager):
    report = PdfSummaryReportModel.from_el(config, model_manager)
    assert report.name == "Test-PDF"
    assert set(report.reports) == set(
        ["top-attacker-sources", "top-attacker-destinations"]
    )


def test_pdf_summary_report_empty_xml():
    report = PdfSummaryReportModel.from_el(empty_config, model_manager)
    assert report.name is None
    assert len(report.reports) == 0
