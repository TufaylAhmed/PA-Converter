import pytest
from unittest.mock import MagicMock

from bpa.models.model_sets.security_rule import SecurityRuleModelSet
from bpa.models.policies.security_rule import SecurityRuleModel
from bpa.models.utils.immutable import ImmutableCache

from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        sr_ms = model_manager.model_set_lookup["security_rule"] = SecurityRuleModelSet()
        sr_ms.add(
            build_model(
                SecurityRuleModel,
                model_manager,
                location="DG-Cali",
                rule_name="SR-1",
                rulebase="pre-rulebase",
            )
        )
        sr_ms.add(
            build_model(
                SecurityRuleModel,
                model_manager,
                location="DG-Cali",
                rule_name="SR-2",
                rulebase="pre-rulebase",
            )
        )
        sr_ms.add(
            build_model(
                SecurityRuleModel,
                model_manager,
                location="DG-Texas",
                rule_name="SR-3",
                rulebase="pre-rulebase",
            )
        )

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 9.0
        model_manager.tree.ancestors = {
            "DG-Cali": ["DG-Cali", "DG-USA", "shared"],
            "DG-Texas": ["DG-Texas", "DG-USA", "shared"],
            "DG-USA": ["DG-USA", "shared"],
            "shared": ["shared"],
        }

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.mark.core
class TestImmutableCache:
    def test_cache_magic(self):
        cache = ImmutableCache()
        assert bool(cache) is False
        assert len(cache) == 0
        with pytest.raises(KeyError):
            cache["bogus"]
        assert [k for k in cache] == []

    def test_fill(self):
        cache = ImmutableCache()
        cache.fill({"a": 1, "b": 2})
        assert len(cache) == 2
        assert "a" in cache
        assert "b" in cache
        cache.fill({"c": 3, "d": 4})
        assert len(cache) == 2
        assert "c" not in cache
        assert "d" not in cache

    def test_fill_name(self, model_manager):
        cache = ImmutableCache()
        cache.fill_name(model_manager, "security_rule")
        assert len(cache) == 2
        assert ("DG-Cali",) in cache
        assert ("DG-Texas",) in cache
        assert ("DG-USA",) not in cache
