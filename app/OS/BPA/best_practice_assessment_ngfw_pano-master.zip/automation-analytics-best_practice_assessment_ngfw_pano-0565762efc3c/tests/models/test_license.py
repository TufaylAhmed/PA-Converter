import pytest

from bpa.models.license import License


class Test_License:

    tsf_test_passing_data = [
        pytest.param(
            {
                "Feature": "Test Prevention",
                "Description": "dummy description",
                "Expires": "December 31, 9999",
                "Serial": "aB12c3",
                "Issued": "January 01, 2018",
            },
            marks=pytest.mark.passing,
        ),
        pytest.param(
            {
                "Feature": "Test Prevention",
                "Description": "dummy description",
                "Expires": "December 31, 9999",
            },
            marks=pytest.mark.passing,
        ),
    ]

    @pytest.mark.parametrize("lic_attrs", tsf_test_passing_data)
    def test_from_tsf_passing(self, lic_attrs):
        result = License.from_tsf(attrs=lic_attrs)
        assert isinstance(result, License)

    tsf_test_data_without_mandatory = [
        pytest.param({}, KeyError, marks=pytest.mark.passing),
        pytest.param(
            {"Feature": "Test Prevention"}, KeyError, marks=pytest.mark.passing
        ),
        pytest.param(
            {"Feature": "Test Prevention", "Description": "dummy description"},
            KeyError,
            marks=pytest.mark.passing,
        ),
        pytest.param(
            {
                "Feature": "Test Prevention",
                "Description": "dummy description",
                "Expires": "N/A",
            },
            None,
            marks=pytest.mark.passing,
        ),
    ]

    @pytest.mark.parametrize(
        "lic_attrs,expected_output", tsf_test_data_without_mandatory
    )
    def test_from_tsf_without_mandatory(self, lic_attrs, expected_output):
        if expected_output is None:
            lic = License.from_tsf(attrs=lic_attrs)
            assert lic is expected_output
        else:
            with pytest.raises(expected_output):
                License.from_tsf(attrs=lic_attrs)
