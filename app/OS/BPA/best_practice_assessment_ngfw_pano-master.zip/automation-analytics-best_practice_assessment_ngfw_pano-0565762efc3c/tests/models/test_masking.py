import pytest
from dataclasses import dataclass

from bpa.models.base_model import BaseModel
from bpa.models.constants import MASK
from bpa.models.utils.masking import mask_general, mask_ipv4


@dataclass
class Router(BaseModel):
    """Represents top-model in BPA"""

    xpath = ""

    name: str = "Peter"
    ip1: str = "45.46.47.48"
    ip2: str = "unknown"
    model: str = "Netgear"

    mask_attrs = {"name": ["name"], "ip1": ["ipv4"], "ip2": ["ipv4"]}


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def router(model_manager):
    return Router(model_manager=model_manager)


@pytest.mark.utils
class TestMaskUtilities:
    def test_mask_ipv4_none(self):
        assert mask_ipv4(None) is None

    def test_mask_ipv4_str(self):
        assert mask_ipv4("10.43.128.314") == "***.43.128.***"

    def test_mask_ipv4_list(self):
        expected = ["***.43.128.***", "***.43.128.***"]
        assert mask_ipv4(["10.43.128.314", "10.43.128.315"]) == expected

    def test_mask_ipv4_set(self):
        expected = {"***.43.128.***", "***.43.128.***"}
        assert mask_ipv4({"10.43.128.314", "10.43.128.315"}) == expected

    def test_mask_ipv4_dict(self):
        expected = {"home_ip": "***.43.128.***"}
        assert mask_ipv4({"home_ip": "10.43.128.314"}) == expected

    def test_mask_ipv4_unknown(self):
        expected = "unknown"
        assert mask_ipv4("unknown") == expected

    def test_mask_general_any(self):
        expected = "any"
        assert mask_general("any") == expected

    def test_mask_ipv4_invalid(self):
        with pytest.raises(ValueError):
            mask_ipv4(1)

    def test_mask_general_none(self):
        assert mask_general(None) is None

    def test_mask_general_str(self):
        assert mask_general("johndoe").startswith(MASK)

    def test_mask_general_str_empty(self):
        assert mask_general("") == ""

    def test_mask_general_str_one(self):
        assert mask_general("a") == "a"

    def test_mask_general_list(self):
        for val in mask_general(["hello", "world"]):
            assert val.startswith(MASK)


@pytest.mark.core
class TestMaskMixin:
    def test_mask_to_dict_general(self, router):
        router_dict = router.to_dict()
        assert router_dict["name"].startswith(MASK)

    def test_mask_to_dict_ipv4(self, router):
        router_dict = router.to_dict()
        assert router_dict["ip1"].startswith(MASK)
        assert router_dict["ip1"].endswith(MASK)
        assert router_dict["ip1"] == "***.46.47.***"

    def test_mask_to_dict_none(self, router):
        router_dict = router.to_dict()
        assert router_dict["model"] == "Netgear"

    def test_mask_to_dict_unknown(self, router):
        router_dict = router.to_dict()
        assert not router_dict["ip2"].startswith(MASK)
        assert router_dict["ip2"] == "unknown"
