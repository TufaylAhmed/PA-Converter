from unittest.mock import MagicMock

import pytest

from bpa.models.objects.security_profile.antivirus_profile import AntivirusProfileModel
from bpa.models.objects.security_profile.common import SecurityProfileGroupModel
from bpa.models.objects.security_profile.vulnerability_protection_profile import (
    VulnerabilityProtectionProfileModel,
)
from bpa.models.policies.security_rule import SecurityRuleModel
from bpa.models.model_sets.security_rule import SecurityRuleModelSet
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager_profile(model_manager_factory):
    def populate_models(model_manager):
        security_model1 = build_model(
            SecurityRuleModel,
            model_manager,
            location="DG-USA",
            action="allow",
            rule_name="security_rule_USA",
            profile_antivirus="AV-Prof-DG-USA",
        )

        security_model2 = build_model(
            SecurityRuleModel,
            model_manager,
            location="DG-Texas",
            action="allow",
            rule_name="security_rule_Texas",
            profile_antivirus="AV-Prof-DG-Texas",
        )

        avp_ms = model_manager.model_set_lookup["antivirus_profile"] = ModelSet()
        avp_ms.add(
            build_model(
                AntivirusProfileModel,
                model_manager,
                name="AV-Prof-DG-USA",
                location="DG-USA",
            )
        )
        avp_ms.add(
            build_model(
                AntivirusProfileModel,
                model_manager,
                name="AV-Prof-DG-Texas",
                location="DG-Texas",
            )
        )

        vpp_ms = model_manager.model_set_lookup[
            "vulnerability_protection_profile"
        ] = ModelSet()
        vpp_ms.add(
            build_model(
                VulnerabilityProtectionProfileModel,
                model_manager,
                name="VP-Prof-DG-USA",
                location="DG-USA",
            )
        )
        vpp_ms.add(
            build_model(
                VulnerabilityProtectionProfileModel,
                model_manager,
                name="VP-Prof-DG-Texas",
                location="DG-Texas",
            )
        )

        # NOTE: Added after profiles intentionally
        sr_ms = model_manager.model_set_lookup["security_rule"] = SecurityRuleModelSet()
        sr_ms.add(security_model1)
        sr_ms.add(security_model2)

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.ancestors = {
            "shared": ["shared"],
            "DG-USA": ["DG-USA", "shared"],
            "DG-Texas": ["DG-Texas", "DG-USA", "shared"],
            "DG-Plano": ["DG-Plano", "Texas-DG", "DG-USA", "shared"],
        }
        model_manager.tree.version = 8
        model_manager.tree.panorama = True

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def model_manager_profile_group(model_manager_factory):
    def populate_models(model_manager):
        security_model1 = build_model(
            SecurityRuleModel,
            model_manager,
            location="DG-USA",
            action="allow",
            rule_name="security_rule_USA",
            profile_group="Sec-Prof-Med",
        )

        prof_grp_ms = model_manager.model_set_lookup[
            "security_profile_group"
        ] = ModelSet()
        prof_grp_ms.add(
            build_model(
                SecurityProfileGroupModel,
                model_manager,
                location="DG-USA",
                name="Sec-Prof-Med",
            )
        )

        # NOTE: Added after profile groups intentionally
        sr_ms = model_manager.model_set_lookup["security_rule"] = SecurityRuleModelSet()
        sr_ms.add(security_model1)

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.ancestors = {
            "shared": ["shared"],
            "DG-USA": ["DG-USA", "shared"],
            "DG-Texas": ["DG-Texas", "DG-USA", "shared"],
            "DG-Plano": ["DG-Plano", "Texas-DG", "DG-USA", "shared"],
        }
        model_manager.tree.version = 8
        model_manager.tree.panorama = True

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.mark.core
class TestSecurityRuleModelSet:
    def test_sec_profiles_with_allow_rules(self, model_manager_profile):
        rule_ms = model_manager_profile.get("security_rule")
        key = ("DG-USA", "AV-Prof-DG-USA", "antivirus_profile")
        assert len(rule_ms.sec_profiles_with_allow_rules[key]) == 1

    def test_sec_profiles_with_allow_rules_empty(self, model_manager_profile):
        rule_ms = model_manager_profile.get("security_rule")
        key = ("DG-USA", "AV-Prof-DG-USA", "vulnerability_protection_profile")
        assert len(rule_ms.sec_profiles_with_allow_rules[key]) == 0
