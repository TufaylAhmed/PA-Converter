import pytest

from bpa.components.helper import panos_major_version

panos_major_version_data = [
    pytest.param("9.0.x", 9, marks=pytest.mark.passing),
    pytest.param(9, 9, marks=pytest.mark.passing),
    pytest.param(9.0, 9, marks=pytest.mark.passing),
    pytest.param("", 0, marks=pytest.mark.failing),
    pytest.param("Win", 0, marks=pytest.mark.failing),
]


@pytest.mark.parametrize("panos_version, expected_result", panos_major_version_data)
def test_panos_major_version(panos_version, expected_result):

    result = panos_major_version(panos_version)

    assert result == expected_result
