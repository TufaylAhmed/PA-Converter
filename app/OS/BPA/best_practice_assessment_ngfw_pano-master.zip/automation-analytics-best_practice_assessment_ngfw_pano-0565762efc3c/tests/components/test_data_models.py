import pytest
from unittest.mock import MagicMock
from collections import OrderedDict

from bpa.components.data_models import HeatMapHistory, BPAHistory


class TestHeatMapHistory:
    def test__reorder_history(self):
        heatmap_history = HeatMapHistory(historical_data=OrderedDict())

        heatmap_history._reorder_history()

        assert len(heatmap_history.historical_data.items()) == 0

        heatmap_history.historical_data = OrderedDict()

        heatmap_history.historical_data["2019-08-21 16:03:22"] = "obj 1"
        heatmap_history.historical_data["2019-08-21 16:03:00"] = "obj 2"
        heatmap_history.historical_data["2019-08-20 16:03:22"] = "obj 3"
        heatmap_history.historical_data["2019-08-20 17:00:22"] = "obj 4"

        assert len(heatmap_history.historical_data.items()) == 4

        heatmap_history._reorder_history()

        reordered_items = list(heatmap_history.historical_data.items())

        assert len(reordered_items) == 4
        assert reordered_items[0][0] == "2019-08-20 16:03:22"
        assert reordered_items[0][1] == "obj 3"
        assert reordered_items[1][0] == "2019-08-20 17:00:22"
        assert reordered_items[1][1] == "obj 4"
        assert reordered_items[2][0] == "2019-08-21 16:03:00"
        assert reordered_items[2][1] == "obj 2"
        assert reordered_items[3][0] == "2019-08-21 16:03:22"
        assert reordered_items[3][1] == "obj 1"

    @staticmethod
    @pytest.fixture
    def heatmap_history():

        _heatmap_history = HeatMapHistory(
            historical_data=OrderedDict(
                [
                    ("2019-08-20 16:03:22", "obj 3"),
                    ("2019-08-20 17:00:22", "obj 4"),
                    ("2019-08-21 16:03:00", "obj 2"),
                    ("2019-08-21 16:03:22", "obj 1"),
                ]
            )
        )
        return _heatmap_history

    def test_add_heatmap(self, heatmap_history):

        heatmap_history.add_heatmap(
            tsf_generation_date="2019-08-20 20:00:00",
            pan_os_version="9.0.x",
            heatmap_data={"some_key": "some_value"},
            serial_number="123456",
        )

        history_items = list(heatmap_history.historical_data.items())

        assert len(history_items) == 5
        assert history_items[2][0] == "2019-08-20 20:00:00"
        assert history_items[2][1] == {
            "data": {"some_key": "some_value"},
            "panos_version": "9.0.x",
            "serial_number": "123456",
        }

    def test_get_previous_heatmap(self, heatmap_history):

        result = heatmap_history.get_previous_heatmap(
            tsf_generation_date="2019-08-20 16:03:22"
        )
        assert result is None

        result = heatmap_history.get_previous_heatmap(
            tsf_generation_date="2019-08-21 16:03:00"
        )
        assert result == "obj 4"

        result = heatmap_history.get_previous_heatmap(
            tsf_generation_date="2019-08-21 16:03:22"
        )
        assert result == "obj 2"


class TestBPAHistory:
    def test_post_init(self):

        bpa_history = BPAHistory(
            sorted_historical_data=OrderedDict(
                [
                    (
                        "2019-08-21 16:03:22",
                        {"obj1-1": 11, "obj1-2": {"child_obj1-2": 12}},
                    ),
                    ("2019-08-21 16:03:00", {"obj2": 2}),
                ]
            )
        )
        flattened_items = list(bpa_history.sorted_historical_data.items())

        assert len(flattened_items) == 2
        assert flattened_items[0][0] == "2019-08-21 16:03:22"
        assert flattened_items[0][1] == {"obj1-1": 11, "obj1-2.child_obj1-2": 12}
        assert flattened_items[1][0] == "2019-08-21 16:03:00"
        assert flattened_items[1][1] == {"obj2": 2}

    def test__reorder_history(self):
        bpa_history = BPAHistory(sorted_historical_data=OrderedDict())

        bpa_history._reorder_history()

        assert len(bpa_history.sorted_historical_data.items()) == 0

        bpa_history.sorted_historical_data = OrderedDict()

        bpa_history.sorted_historical_data["2019-08-21 16:03:22"] = {"obj": 1}
        bpa_history.sorted_historical_data["2019-08-21 16:03:00"] = {"obj": 2}
        bpa_history.sorted_historical_data["2019-08-20 16:03:22"] = {"obj": 3}
        bpa_history.sorted_historical_data["2019-08-20 17:00:22"] = {"obj": 4}

        assert len(bpa_history.sorted_historical_data.items()) == 4

        bpa_history._reorder_history()

        reordered_items = list(bpa_history.sorted_historical_data.items())

        assert len(reordered_items) == 4
        assert reordered_items[0][0] == "2019-08-20 16:03:22"
        assert reordered_items[0][1] == {"obj": 3}
        assert reordered_items[1][0] == "2019-08-20 17:00:22"
        assert reordered_items[1][1] == {"obj": 4}
        assert reordered_items[2][0] == "2019-08-21 16:03:00"
        assert reordered_items[2][1] == {"obj": 2}
        assert reordered_items[3][0] == "2019-08-21 16:03:22"
        assert reordered_items[3][1] == {"obj": 1}

    @staticmethod
    @pytest.fixture
    def bpa_history():
        _bpa_history = BPAHistory(
            sorted_historical_data=OrderedDict(
                [
                    ("2019-08-20 16:03:22", {"obj": 3}),
                    ("2019-08-20 17:00:22", {"obj": 4}),
                    ("2019-08-21 16:03:00", {"obj": 2}),
                    ("2019-08-21 16:03:22", {"obj": 1}),
                ]
            )
        )
        return _bpa_history

    def test_add_assessment(self, bpa_history):

        latest_bpa_mock = MagicMock()
        latest_bpa_mock.json = MagicMock(
            return_value={"obj5-1": 51, "obj5-2": {"child_obj5-2": 52}}
        )

        result = bpa_history.add_assessment(
            tsf_generation_date="2019-08-20 20:00:00", latest_bpa=latest_bpa_mock
        )

        assert len(result) == 2
        assert type(result[0]) == dict
        assert result[0] == {"obj5-1": 51, "obj5-2.child_obj5-2": 52}
        assert result[1] is bpa_history.sorted_historical_data

        history_items = list(bpa_history.sorted_historical_data.items())

        assert len(history_items) == 5
        assert history_items[2][0] == "2019-08-20 20:00:00"
        assert history_items[2][1] == {"obj5-1": 51, "obj5-2.child_obj5-2": 52}

    def test_get_previous_heatmap(self, bpa_history):

        result = bpa_history.get_previous_assessment(
            current_tsf_generation_date="2019-08-20 16:03:22"
        )
        assert result is None

        result = bpa_history.get_previous_assessment(
            current_tsf_generation_date="2019-08-21 16:03:00"
        )
        assert result == {"obj": 4}

        result = bpa_history.get_previous_assessment(
            current_tsf_generation_date="2019-08-21 16:03:22"
        )
        assert result == {"obj": 2}
