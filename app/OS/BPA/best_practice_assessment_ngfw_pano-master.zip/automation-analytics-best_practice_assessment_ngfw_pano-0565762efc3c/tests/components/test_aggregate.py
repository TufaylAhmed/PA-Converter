from collections import defaultdict
import datetime
import pytest
import pandas as pd
from unittest.mock import Mock, patch

from bpa.components.constant import AdoptionMetrics
from bpa.components.aggregate import (
    AdoptionAnalysis,
    BPAChecksPassFail,
    HeatMapTrend,
    BPAChecksDocsMapping,
    BPASummary,
    BPChecksDescription,
    BPAChange,
    BPATrend,
)
from bpa.publishers.schemas.documentation import Documentation


class TestAdoptionAnalysis:
    @staticmethod
    @pytest.fixture
    def analysis_data():
        _data = [
            {
                AdoptionMetrics.TOTAL_RULE_COUNT_SLUG: 5,
                AdoptionMetrics.ALLOW_RULE_COUNT_SLUG: 3,
                AdoptionMetrics.DENY_RULE_COUNT_SLUG: 2,
                AdoptionMetrics.WILD_FIRE_SLUG: 2,
                AdoptionMetrics.LOG_FORWARDING_SLUG: 2,
                AdoptionMetrics.LOGGING_SLUG: 1,
            },
            {
                AdoptionMetrics.TOTAL_RULE_COUNT_SLUG: 1,
                AdoptionMetrics.ALLOW_RULE_COUNT_SLUG: 0,
                AdoptionMetrics.DENY_RULE_COUNT_SLUG: 1,
                AdoptionMetrics.WILD_FIRE_SLUG: 1,
            },
        ]

        return _data

    @pytest.mark.passing
    def test_aggregate_analysis_data(self, analysis_data):
        _analysis_data = analysis_data
        adoption_analysis = AdoptionAnalysis(analysis_data=_analysis_data)

        _aggregate_data = adoption_analysis.aggregate_analysis_data

        assert type(_aggregate_data) == dict
        assert _aggregate_data[AdoptionMetrics.TOTAL_RULE_COUNT_SLUG] == 6
        assert _aggregate_data[AdoptionMetrics.WILD_FIRE_SLUG] == 3
        assert _aggregate_data[AdoptionMetrics.LOGGING_SLUG] == 1

    @pytest.mark.passing
    def test_calculate_adoption_percentage(self, analysis_data):
        _analysis_data = analysis_data
        adoption_analysis = AdoptionAnalysis(analysis_data=_analysis_data)

        result = adoption_analysis.calculate_adoption_percentage()
        assert type(result) == dict
        assert result[AdoptionMetrics.WILD_FIRE_ADOPTION] == 100.0
        assert result[AdoptionMetrics.LOGGING_ADOPTION] == 16.7
        assert result[AdoptionMetrics.LOG_FORWARDING_ADOPTION] == 33.3

        # Testing a metrics missing scenario
        assert result[AdoptionMetrics.ANTI_SPYWARE_ADOPTION] == 0
        assert result[AdoptionMetrics.CREDENTIAL_THEFT_ADOPTION] == 0

        # Testing excluded metrics
        result = adoption_analysis.calculate_adoption_percentage(version="7.1.x")
        assert type(result) == dict
        assert AdoptionMetrics.CREDENTIAL_THEFT_ADOPTION not in result.keys()

        # Testing string value allowed in pct scenario
        result = adoption_analysis.calculate_adoption_percentage(
            version="7.1.x", pct_non_numeric_values_allowed=True
        )
        assert type(result) == dict
        assert result[AdoptionMetrics.CREDENTIAL_THEFT_ADOPTION] == "PAN-OS < 8.0"

    @pytest.mark.passing
    def test_calculate_count_total(self, analysis_data):
        adoption_analysis = AdoptionAnalysis(analysis_data=analysis_data)

        result = adoption_analysis.calculate_count_total()
        assert type(result) == dict
        assert result[AdoptionMetrics.TOTAL_RULE_COUNT] == 6
        assert result[AdoptionMetrics.ALLOW_RULE_COUNT] == 3
        assert result[AdoptionMetrics.DENY_RULE_COUNT] == 3

    @pytest.mark.passing
    def test_calculate_adoption_change(self):
        adoption_analysis = Mock()
        adoption_analysis.calculated_change_metrics = dict()
        adoption_analysis.calculated_metrics = {
            AdoptionMetrics.TOTAL_RULE_COUNT: 3,
            AdoptionMetrics.ALLOW_RULE_COUNT: 2,
            AdoptionMetrics.DENY_RULE_COUNT: 1,
            AdoptionMetrics.WILD_FIRE_ADOPTION: 2,
            AdoptionMetrics.URL_FILTERING_ADOPTION: 1,
        }

        # Testing scenario with No Prior Data
        result = AdoptionAnalysis.calculate_adoption_change(
            current_data_analysis=adoption_analysis, prior_data_analysis=None
        )
        assert type(result) == dict
        assert len(set(result.values())) == 1
        assert list(result.values())[0] == "No change"

        # Testing scenario with Prior Data
        prior_analysis = Mock()
        prior_analysis.calculated_metrics = {
            AdoptionMetrics.TOTAL_RULE_COUNT: 3,
            AdoptionMetrics.ALLOW_RULE_COUNT: 1,
            AdoptionMetrics.DENY_RULE_COUNT: 2,
            AdoptionMetrics.WILD_FIRE_ADOPTION: 0,
            AdoptionMetrics.ANTI_SPYWARE_ADOPTION: 3,
        }
        result = AdoptionAnalysis.calculate_adoption_change(
            current_data_analysis=adoption_analysis, prior_data_analysis=prior_analysis
        )

        assert result[AdoptionMetrics.TOTAL_RULE_COUNT] == "No change"
        assert result[AdoptionMetrics.ALLOW_RULE_COUNT] == "+1 pt"
        assert result[AdoptionMetrics.DENY_RULE_COUNT] == "-1 pt"
        assert result[AdoptionMetrics.WILD_FIRE_ADOPTION] == "+2 pts"
        assert result[AdoptionMetrics.URL_FILTERING_ADOPTION] == "No change"


class TestBPAChecksPassFail:
    @staticmethod
    @pytest.fixture
    def bpat_flattened_json():
        _data = {
            "device.left_nav": [
                {"bp_check": [{"id": 1, "result": ""}]},
                {"bp_check": [{"id": 1, "result": "pass"}]},
                {"bp_check": [{"id": 1, "result": "pass"}]},
                {"bp_check": [{"id": 1, "result": "fail"}]},
            ],
            "object.left_nav": [
                {"bp_check": [{"id": 1, "result": "fail"}]},
                {"bp_check": [{"id": 2, "result": ""}]},
                {"bp_check": [{"id": 3, "result": "pass"}]},
            ],
        }
        return _data

    @pytest.mark.passing
    def test_get_counts(self, bpat_flattened_json):
        result_obj = BPAChecksPassFail.get_counts(
            bpat_flattened_json=bpat_flattened_json
        )

        assert isinstance(result_obj, BPAChecksPassFail)
        result = result_obj.result

        assert list(result.keys()) == [1, 3]
        assert result[1]["pass"] == 2
        assert result[1]["fail"] == 2
        assert result[3]["pass"] == 1


class TestHeatMapTrend:
    @staticmethod
    @pytest.fixture
    def heatmap_history():
        _heatmap_history = Mock()
        _heatmap_history.historical_data = {
            "date1": {
                "panos_version": "9.0",
                "serial_number": "123456",
                "data": [
                    {
                        AdoptionMetrics.ALLOW_RULE_COUNT_SLUG: 3,
                        AdoptionMetrics.WILD_FIRE_SLUG: 1,
                    }
                ],
            },
            "date2": {
                "panos_version": "7.1.x",
                "serial_number": "123456",
                "data": [
                    {AdoptionMetrics.ALLOW_RULE_COUNT_SLUG: 3},
                    {AdoptionMetrics.ALLOW_RULE_COUNT_SLUG: 2},
                ],
            },
        }
        return _heatmap_history

    @pytest.mark.passing
    def test_generate(self, heatmap_history):
        result = HeatMapTrend.generate(heatmap_history=heatmap_history)

        assert type(result) == list

        result_date1 = result[0]
        assert result_date1["tsf_generated_date"] == "date1"
        assert result_date1[AdoptionMetrics.ALLOW_RULE_COUNT] == 3
        assert result_date1[f"{AdoptionMetrics.WILD_FIRE_ADOPTION} %"] == 33.3

        result_date2 = result[1]
        assert result_date2["tsf_generated_date"] == "date2"
        assert result_date2[AdoptionMetrics.ALLOW_RULE_COUNT] == 5


class TestBPAChecksDocsMapping:
    @staticmethod
    @pytest.fixture
    def pass_fail_checks_mock():
        _bpa_pass_fail_checks = Mock()
        _bpa_pass_fail_checks.result = {4: {"pass": 10, "fail": 1}}

        return _bpa_pass_fail_checks

    @staticmethod
    @pytest.fixture
    def previous_pass_fail_checks_mock():
        previous_bpa_pass_fail_checks = Mock()
        previous_bpa_pass_fail_checks.result = {4: {"pass": 10, "fail": 1}}

        return previous_bpa_pass_fail_checks

    @staticmethod
    @pytest.fixture
    def bpa_docs():
        _bpa_docs = Mock()
        first_doc = {
            "doc_id": 2,
            "title": "Title2",
            "capability_label": ["Cap Label 2.1", "Cap Label 2.2"],
            "class_label": ["Class Label 2.1", "Class Label 2.2"],
            "control_category": ["Control Cat 2.1", "Control Cat 2.2"],
            "cscv6_control": ["26.1", "26.2"],
            "cscv7_control": ["27.1", "27.2"],
            "top_nav": "Policy",
            "left_nav": "security",
            "doc_type": "warning",
            "description": "dummy 1",
            "rationale": "rationale",
            "references": ["references 1"],
            "last_updated_date": datetime.date.today(),
            "effort": "10 minutes",
            "complexity": "medium",
            "active": True,
        }
        second_doc = {
            "doc_id": 4,
            "title": "Title4",
            "capability_label": ["Cap Label 4"],
            "class_label": ["Class Label 4"],
            "control_category": ["Control Cat 4"],
            "cscv6_control": [],
            "cscv7_control": ["14.2"],
            "top_nav": "panorama",
            "left_nav": "security",
            "doc_type": "warning",
            "description": "dummy 2",
            "rationale": "rationale",
            "references": ["references 1"],
            "last_updated_date": datetime.date.today(),
            "effort": "20 minutes",
            "complexity": "hard",
            "active": True,
        }
        third_doc = {
            "doc_id": 245,
            "title": "Title245",
            "capability_label": ["Cap Label 245"],
            "class_label": [""],
            "control_category": [""],
            "cscv6_control": [""],
            "cscv7_control": [],
            "top_nav": "objects",
            "left_nav": "security",
            "doc_type": "warning",
            "description": "dummy 3",
            "rationale": "rationale",
            "references": ["references 1"],
            "last_updated_date": datetime.date.today(),
            "effort": "15 minutes",
            "complexity": "medium",
            "active": False,
        }
        _bpa_docs = [
            Documentation(**first_doc),
            Documentation(**second_doc),
            Documentation(**third_doc),
        ]

        return _bpa_docs

    @pytest.mark.passing
    def test_map_checks_to_docs(
        self, pass_fail_checks_mock, previous_pass_fail_checks_mock, bpa_docs
    ):
        result = BPAChecksDocsMapping.map_checks_to_docs(
            current_pass_fail_checks=pass_fail_checks_mock,
            previous_pass_fail_checks=previous_pass_fail_checks_mock,
            bpa_docs=bpa_docs,
        )
        assert isinstance(result, BPAChecksDocsMapping)

        _records = result.records
        assert type(_records) == pd.DataFrame

    @pytest.mark.passing
    def test_format_data_util(
        self, pass_fail_checks_mock, previous_pass_fail_checks_mock, bpa_docs
    ):
        mapping = BPAChecksDocsMapping.map_checks_to_docs(
            current_pass_fail_checks=pass_fail_checks_mock,
            previous_pass_fail_checks=previous_pass_fail_checks_mock,
            bpa_docs=bpa_docs,
        )
        assert isinstance(mapping, BPAChecksDocsMapping)
        result = mapping.format_data_util()

        # Asserting correct output format
        assert type(result) == list
        assert type(result[0]) == dict
        assert "ID" in result[0].keys()


class TestBPASummary:
    @staticmethod
    @pytest.fixture
    def pass_fail_checks_mock():
        _pass_fail_checks = Mock()
        _pass_fail_checks.result = {
            1: {BPAChecksPassFail.PASS: 10, BPAChecksPassFail.FAIL: 10},
            2: {BPAChecksPassFail.PASS: 0, BPAChecksPassFail.FAIL: 10},
            3: {BPAChecksPassFail.PASS: 10, BPAChecksPassFail.FAIL: 0},
        }
        return _pass_fail_checks

    @staticmethod
    @pytest.fixture
    def summarization_data_mock():
        _data = {
            "Functionality Capability": {
                1: ["Func Capa 1"],
                2: ["Func Capa 1", "Func Capa 2"],
                3: ["Func Capa 2"],
            },
            "Control Category": {
                1: ["Control Category 1"],
                2: ["Control Category 1", "Control Category 2"],
                3: ["Control Category 3"],
            },
        }
        return _data

    @pytest.mark.passing
    def test_from_mappings(self, pass_fail_checks_mock, summarization_data_mock):
        _summarization_data_mock = summarization_data_mock
        result = BPASummary.from_mappings(
            pass_fail_checks_mock, _summarization_data_mock
        )

        assert isinstance(result, BPASummary)

        result = result.data
        assert type(result) == defaultdict

        assert set(result.keys()) == set(_summarization_data_mock.keys())

        # Now validate all calculations
        assert result["Control Category"]["Control Category 1"]["passing"] == 10
        assert result["Control Category"]["Control Category 1"]["percent"] == 33
        assert result["Control Category"]["Control Category 1"]["total"] == 30
        assert result["Control Category"]["Control Category 2"]["passing"] == 0
        assert result["Control Category"]["Control Category 2"]["percent"] == 0
        assert result["Control Category"]["Control Category 2"]["total"] == 10
        assert result["Control Category"]["Control Category 3"]["passing"] == 10
        assert result["Control Category"]["Control Category 3"]["percent"] == 100
        assert result["Control Category"]["Control Category 3"]["total"] == 10
        assert result["Functionality Capability"]["Func Capa 1"]["passing"] == 10
        assert result["Functionality Capability"]["Func Capa 1"]["percent"] == 33
        assert result["Functionality Capability"]["Func Capa 1"]["total"] == 30
        assert result["Functionality Capability"]["Func Capa 2"]["passing"] == 10
        assert result["Functionality Capability"]["Func Capa 2"]["percent"] == 50
        assert result["Functionality Capability"]["Func Capa 2"]["total"] == 20


class TestBPChecksDescription:
    @staticmethod
    @pytest.fixture
    def bpa_docs():
        _bpa_docs = Mock()
        first_doc = {
            "doc_id": 2,
            "title": "Title2",
            "capability_label": ["Cap Label 2.1", "Cap Label 2.2"],
            "class_label": ["Class Label 2.1", "Class Label 2.2"],
            "control_category": ["Control Cat 2.1", "Control Cat 2.2"],
            "cscv6_control": ["26.1", "26.2"],
            "cscv7_control": ["27.1", "27.2"],
            "top_nav": "Policy",
            "left_nav": "security",
            "doc_type": "warning",
            "description": "dummy 1",
            "rationale": "rationale",
            "references": ["references 1"],
            "last_updated_date": datetime.date.today(),
            "effort": "10",
            "complexity": "medium",
            "active": True,
        }
        second_doc = {
            "doc_id": 1,
            "title": "Title4",
            "capability_label": ["Cap Label 4"],
            "class_label": ["Class Label 4"],
            "control_category": ["Control Cat 4"],
            "cscv6_control": [],
            "cscv7_control": ["14.2"],
            "top_nav": "panorama",
            "left_nav": "security",
            "doc_type": "warning",
            "description": "dummy 2",
            "rationale": "rationale",
            "references": ["references 1"],
            "last_updated_date": datetime.date.today(),
            "effort": "20",
            "complexity": "hard",
            "active": True,
        }

        _bpa_docs = [
            Documentation(**first_doc),
            Documentation(**second_doc),
        ]

        return _bpa_docs

    def test_get(self, bpa_docs):

        bpat = Mock()
        bpat.bp_manager().model_manager().documentation = bpa_docs
        bpat.result_attrs = ["attrb_A", "attrb_B", "attrb_C"]
        check_ids = [("attrb_A", {1}), ("attrb_B", {1, 2}), ("attrb_C", {1, 2})]

        with patch.object(BPChecksDescription, "_get_check_ids", side_effect=check_ids):
            result = BPChecksDescription().get(bpat=bpat)

        assert type(result) == dict

        # Validate values
        assert result["attrb_A"] == [bpa_docs[1].as_dict]
        assert result["attrb_B"] == [bpa_docs[0].as_dict, bpa_docs[1].as_dict]
        assert result["attrb_C"] == [bpa_docs[0].as_dict, bpa_docs[1].as_dict]


class TestBPADescription:
    @staticmethod
    @pytest.fixture
    def bpa_summary_mock():

        bpa_summary = Mock()
        bpa_summary.data = {
            "Functionality Capability": {
                "Func Capa 1": {"passing": 10, "total": 30, "percent": 33},
                "Func Capa 2": {"passing": 10, "total": 20, "percent": 50},
            },
            "Control Category": {
                "Control Category 1": {"passing": 10, "total": 30, "percent": 33},
                "Control Category 2": {"passing": 0, "total": 10, "percent": 0},
                "Control Category 3": {"passing": 10, "total": 10, "percent": 100},
            },
        }
        return bpa_summary

    def test_compare_change_no_prior_summary(self, bpa_summary_mock):

        result_summary = BPAChange(bpa_summary=bpa_summary_mock).compare_change(
            compare_against=None
        )

        result = result_summary.data

        for category, mappings in result.items():
            for key in mappings.keys():
                assert result[category][key]["change"] == "No change"

    def test_compare_change(self, bpa_summary_mock):

        prior_bpa_summary_mock = Mock()
        prior_bpa_summary_mock.data = {
            "Functionality Capability": {"Func Capa 1": {"percent": 33}},
            "Control Category": {
                "Control Category 1": {"percent": 35},
                "Control Category 2": {"percent": 1},
                "Control Category 3": {"percent": 98},
            },
        }
        result_summary = BPAChange(bpa_summary=bpa_summary_mock).compare_change(
            compare_against=prior_bpa_summary_mock
        )

        result = result_summary.data

        assert (
            result["Functionality Capability"]["Func Capa 1"]["change"] == "No change"
        )
        assert (
            result["Functionality Capability"]["Func Capa 2"]["change"] == "No change"
        )
        assert result["Control Category"]["Control Category 1"]["change"] == "-2 pts"
        assert result["Control Category"]["Control Category 2"]["change"] == "-1 pt"
        assert result["Control Category"]["Control Category 3"]["change"] == "+2 pts"


class TestBPATrend:
    def test_calculate_passing(self):
        records_mock = {
            "device_pass": 0,
            "device_total": 10,
            "network_pass": 10,
            "network_total": 10,
            "objects_pass": 5,
            "objects_total": 10,
            "panorama_pass": 6,
            "panorama_total": 9,
            "tsf_generated_date": "2017-11-29 23:59:59",
        }

        result = BPATrend()._calculate_passing(
            record=records_mock, include_keys=["tsf_generated_date"]
        )

        assert type(result) == dict
        assert result["device"] == 0.0
        assert result["network"] == 100.0
        assert result["objects"] == 50.0
        assert result["panorama"] == 66.67

        assert "tsf_generated_date" in result.keys()
        assert result["tsf_generated_date"] == "2017-11-29 23:59:59"

    def test_aggregate_measures(self):

        records_mock = {
            "device.left_nav_item.sub_item": [
                {"bp_check": [{"id": 1, "result": ""}]},
                {"bp_check": [{"id": 1, "result": "pass"}]},
                {"bp_check": [{"id": 1, "result": "pass"}]},
                {"bp_check": [{"id": 1, "result": "fail"}]},
            ],
            "object.left_nav_item": [
                {"bp_check": [{"id": 1, "result": "fail"}]},
                {"bp_check": [{"id": 2, "result": ""}]},
                {"bp_check": [{"id": 3, "result": "pass"}]},
            ],
        }

        result = BPATrend()._aggregate_measures(records=records_mock)

        assert type(result) == defaultdict
        assert len(result.keys()) == 4
        assert result["device_total"] == 3
        assert result["device_pass"] == 2
        assert result["object_total"] == 2
        assert result["object_pass"] == 1

        # Test include_dict
        mocked_dict = {"some_key": "some_value"}
        result = BPATrend()._aggregate_measures(
            records=dict(), include_dict=mocked_dict
        )
        assert result == mocked_dict

    def test_create_trend(self):
        bpa_history_mock = Mock()
        bpa_history_mock.sorted_historical_data = {"date_1": {}, "date_2": {}}

        mock_measure = defaultdict(int)
        mock_values = {
            "device_pass": 0,
            "device_total": 10,
            "network_pass": 10,
            "network_total": 10,
            "objects_pass": 5,
            "objects_total": 10,
            "panorama_pass": 6,
            "panorama_total": 9,
            "tsf_generated_date": "date_1",
        }
        for key, val in mock_values.items():
            mock_measure[key] = val

        _aggregate_measures_mocked = list()
        _aggregate_measures_mocked.append(mock_measure)
        _aggregate_measures_mocked.append(defaultdict(int))

        with patch.object(
            BPATrend, "_aggregate_measures", side_effect=_aggregate_measures_mocked
        ):

            result = BPATrend().create_trend(
                bpa_history=bpa_history_mock, panorama=True
            )

        assert len(result) == 2

        result_0 = result[0]
        assert type(result_0) == dict
        assert set(result_0.keys()) == {
            "policies",
            "objects",
            "device",
            "network",
            "panorama",
            "tsf_generated_date",
        }

        assert result_0["objects"] == 50.0
        assert result_0["panorama"] == 66.67
        assert result_0["policies"] == "Not Configured"
        assert result_0["device"] == 0.0
        assert result_0["network"] == 100.0
        assert result_0["tsf_generated_date"] == "date_1"

        result_1 = result[1]
        assert type(result_1) == dict
        assert set(result_1.keys()) == {
            "policies",
            "objects",
            "device",
            "network",
            "panorama",
            "tsf_generated_date",
        }

        for nav_item, passing_pct in result_1.items():
            assert passing_pct in ["Not Configured", 0]
