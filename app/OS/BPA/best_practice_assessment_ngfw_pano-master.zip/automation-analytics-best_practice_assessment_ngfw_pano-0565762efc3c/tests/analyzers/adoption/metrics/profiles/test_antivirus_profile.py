import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.adoption.metrics.profiles.antivirus import AntivirusProfileMetric
from bpa.models.objects.security_profile.antivirus_profile import (
    AntivirusProfileModel,
    AntivirusDecoder,
)
from bpa.models.model_set import ModelSet
from bpa.models.policies.security_rule import SecurityRuleModel
from bpa.models.model_sets.security_rule import SecurityRuleModelSet
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager_profile(model_manager_factory):
    def populate_models(model_manager):
        avp_ms = model_manager.model_set_lookup["antivirus_profile"] = ModelSet()
        avp_ms.add(
            build_model(
                AntivirusProfileModel,
                model_manager,
                name="AV-Prof-DG-USA",
                location="DG-USA",
                decoders=[
                    AntivirusDecoder(
                        name="imap", action="alert", wildfire_action="reset-both"
                    ),
                    AntivirusDecoder(
                        name="pop3", action="alert", wildfire_action="drop"
                    ),
                ],
            )
        )
        avp_ms.add(
            build_model(
                AntivirusProfileModel,
                model_manager,
                name="AV-Prof-DG-Texas",
                location="DG-Texas",
                decoders=[],
            )
        )
        model_manager.model_set_lookup["security_rule"] = SecurityRuleModelSet()

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.ancestors = {
            "shared": ["shared"],
            "DG-USA": ["DG-USA", "shared"],
            "DG-Texas": ["DG-Texas", "DG-USA", "shared"],
            "DG-Plano": ["DG-Plano", "DG-Texas", "DG-USA", "shared"],
        }

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def security_rule(model_manager_profile):
    def _security_rule(**overrides):
        return build_model(SecurityRuleModel, model_manager_profile, **overrides)

    return _security_rule


@pytest.fixture
def adoption_manager(
    adoption_manager_factory, bp_manager_factory, model_manager_profile
):
    bp_manager = bp_manager_factory(model_manager_profile)
    return adoption_manager_factory(bp_manager)


@pytest.mark.integration
class TestAntivirusProfileMetric:
    def test_get_count_pass(self, security_rule, adoption_manager):
        rule = security_rule(
            rule_name="SecurityRuleUSA",
            action="allow",
            profile_antivirus="AV-Prof-DG-USA",
            location="DG-USA",
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        manager_ref = weakref.ref(adoption_manager)
        profile = AntivirusProfileMetric(rule, manager_ref)
        assert profile.get_adoption_result() == 1

    def test_get_count_fail(self, security_rule, adoption_manager):
        rule = security_rule(
            rule_name="SecurityRuleTexas",
            profile_antivirus="AV-Prof-DG-Texas",
            location="DG-Texas",
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        manager_ref = weakref.ref(adoption_manager)
        profile = AntivirusProfileMetric(rule, manager_ref)
        assert profile.get_adoption_result() == 0
