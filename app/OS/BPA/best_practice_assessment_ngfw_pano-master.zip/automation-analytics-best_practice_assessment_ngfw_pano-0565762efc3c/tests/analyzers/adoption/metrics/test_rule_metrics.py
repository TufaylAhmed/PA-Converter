from unittest.mock import MagicMock

import pytest

from bpa.analyzers.adoption.metrics.rule_metrics import RuleMetrics
from bpa.models.policies.security_rule import SecurityRuleModel
from bpa.models.network.zone import ZoneModel
from bpa.models.model_set import ModelSet
from bpa.models.model_sets.security_rule import SecurityRuleModelSet

from tests.utils.models.base import build_model


@pytest.fixture
def model_manager_profile(model_manager_factory):
    def populate_models(model_manager):
        model_manager.model_set_lookup["security_rule"] = SecurityRuleModelSet()

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def security_rule(model_manager_profile):
    def _security_rule(**overrides):
        return build_model(SecurityRuleModel, model_manager_profile, **overrides)

    return _security_rule


@pytest.fixture
def zone(model_manager_profile):
    def _zone(**overrides):
        return build_model(ZoneModel, model_manager_profile, **overrides)

    return _zone


@pytest.fixture
def adoption_manager(
    adoption_manager_factory, bp_manager_factory, model_manager_profile
):
    bp_manager = bp_manager_factory(model_manager_profile)
    return adoption_manager_factory(bp_manager)


@pytest.mark.integration
class TestRuleMetrics:
    def test_metric_user_id_enabled_count_1(self, security_rule, adoption_manager):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA",
            location="DG-USA",
            action="allow",
            source_users=["test"],
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_user_id_enabled() == 1

    def test_metric_user_id_enabled_count_0(self, security_rule, adoption_manager):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA",
            location="DG-USA",
            source_users=["any", "unknown"],
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_user_id_enabled() == 0

    def test_metric_app_id_enabled_count_1(self, security_rule, adoption_manager):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA",
            location="DG-USA",
            action="allow",
            applications=["test"],
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_app_id_enabled() == 1

    def test_metric_app_id_enabled_count_0(self, security_rule, adoption_manager):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA", location="DG-USA", applications=["any"]
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_app_id_enabled() == 0

    def test_metric_service_port_configured_count_1(
        self, security_rule, adoption_manager
    ):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA", location="DG-USA", services=["test"]
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_service_port_configured() == 0

    def test_metric_service_port_configured_count_0(
        self, security_rule, adoption_manager
    ):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA", location="DG-USA", applications=["any"]
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_service_port_configured() == 0

    def test_metric_log_start_enabled_count_1(self, security_rule, adoption_manager):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA", location="DG-USA", log_start_enabled=True
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_log_start() == 1

    def test_metric_log_start_enabled_count_0(self, security_rule, adoption_manager):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA", location="DG-USA", log_start_enabled=False
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_log_start() == 0

    def test_metric_log_end_enabled_count_1(self, security_rule, adoption_manager):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA", location="DG-USA", log_end_enabled=True
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_log_end() == 1

    def test_metric_log_end_enabled_count_0(self, security_rule, adoption_manager):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA", location="DG-USA", log_end_enabled=False
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_log_end() == 0

    def test_metric_log_forwarding_enabled_count_1(
        self, security_rule, adoption_manager
    ):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA", location="DG-USA", log_forwarding_profile="test"
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_log_forwarding_enabled() == 1

    def test_metric_log_forwarding_enabled_count_0(
        self, security_rule, adoption_manager
    ):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA", location="DG-USA", log_forwarding_profile="none"
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_log_forwarding_enabled() == 0

    def test_metric_zone_protection_profile_enabled_count_1(
        self, security_rule, zone, adoption_manager
    ):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA",
            location="DG-USA",
            source_zones=["test_zone"],
            action="allow",
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)

        zone = zone(name="test_zone", zone_protection_profile="test_zone_profile")
        rule.objects.model_set_lookup["zone"] = ModelSet()
        rule.objects.model_set_lookup["zone"].add(zone)

        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_zone_protection_profile_enabled() == 1

    def test_metric_zone_protection_profile_enabled_count_0(
        self, security_rule, zone, adoption_manager
    ):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA",
            location="DG-USA",
            source_zones=["test_other"],
            action="allow",
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)

        zone = zone(name="test_zone", zone_protection_profile="test_zone_profile")
        rule.objects.model_set_lookup["zone"] = ModelSet()
        rule.objects.model_set_lookup["zone"].add(zone)

        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_zone_protection_profile_enabled() == 0

    def test_metric_zone_protection_profile_enabled_count_0_empty_zone(
        self, security_rule, zone, adoption_manager
    ):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA",
            location="DG-USA",
            source_zones=[],
            action="allow",
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)

        zone = zone(name="test_zone", zone_protection_profile="test_zone_profile")
        rule.objects.model_set_lookup["zone"] = ModelSet()
        rule.objects.model_set_lookup["zone"].add(zone)

        metric = RuleMetrics(rule, adoption_manager)
        assert metric._metric_zone_protection_profile_enabled() == 0
