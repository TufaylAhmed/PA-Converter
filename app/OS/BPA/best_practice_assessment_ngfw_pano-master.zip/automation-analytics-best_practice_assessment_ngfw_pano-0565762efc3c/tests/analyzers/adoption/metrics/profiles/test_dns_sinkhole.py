import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.adoption.metrics.profiles.dns_sinkhole import (
    DnsSinkholeProfileMetric,
)
from bpa.models.objects.security_profile.anti_spyware_profile import (
    AntiSpywareProfileModel,
)
from bpa.models.policies.security_rule import SecurityRuleModel
from bpa.models.model_sets.security_rule import SecurityRuleModelSet
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager_profile(model_manager_factory):
    def populate_models(model_manager):
        asp_ms = model_manager.model_set_lookup["anti_spyware_profile"] = ModelSet()
        asp_ms.add(
            build_model(
                AntiSpywareProfileModel,
                model_manager,
                name="AS-Prof-DG-USA",
                location="DG-USA",
                dns_sinkhole=True,
            )
        )
        asp_ms.add(
            build_model(
                AntiSpywareProfileModel,
                model_manager,
                name="AS-Prof-DG-Texas",
                location="DG-Texas",
                dns_sinkhole=False,
            )
        )
        model_manager.model_set_lookup["security_rule"] = SecurityRuleModelSet()

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.ancestors = {
            "shared": ["shared"],
            "DG-USA": ["DG-USA", "shared"],
            "DG-Texas": ["DG-Texas", "DG-USA", "shared"],
            "DG-Plano": ["DG-Plano", "DG-Texas", "DG-USA", "shared"],
        }

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def security_rule(model_manager_profile):
    def _security_rule(**overrides):
        return build_model(SecurityRuleModel, model_manager_profile, **overrides)

    return _security_rule


@pytest.fixture
def adoption_manager(
    adoption_manager_factory, bp_manager_factory, model_manager_profile
):
    bp_manager = bp_manager_factory(model_manager_profile)
    return adoption_manager_factory(bp_manager)


@pytest.mark.integration
class TestDnsSinkholeProfileMetric:
    def test_dns_sinkhole_get_count_pass(self, security_rule, adoption_manager):
        rule = security_rule(
            rule_name="AS-Prof-DG-USA",
            action="allow",
            location="DG-USA",
            profile_anti_spyware="AS-Prof-DG-USA",
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        manager_ref = weakref.ref(adoption_manager)
        profile = DnsSinkholeProfileMetric(rule, manager_ref)
        assert profile.get_adoption_result() == 1

    def test_dns_sinkhole_get_count_fail(self, security_rule, adoption_manager):
        rule = security_rule(
            rule_name="AS-Prof-DG-TEXAS",
            location="DG-TEXAS",
            profile_anti_spyware="AS-Prof-DG-TEXAS",
        )
        rule.objects.model_set_lookup["security_rule"].add(rule)
        manager_ref = weakref.ref(adoption_manager)
        profile = DnsSinkholeProfileMetric(rule, manager_ref)
        assert profile.get_adoption_result() == 0
