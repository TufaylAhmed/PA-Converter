from unittest.mock import MagicMock

import pytest

from bpa.analyzers.adoption.manager import AdoptionAnalyzerManager
from bpa.analyzers.adoption.base_metric import AdoptionMetric


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def bp_manager(bp_manager_factory, model_manager):
    return bp_manager_factory(model_manager)


@pytest.mark.core
class TestAdoptionAnalyzerManager:
    def test_find_metrics(self, bp_manager):
        adoption_manager = AdoptionAnalyzerManager(bp_manager)
        metric_classes = adoption_manager.find_metrics()
        assert len(metric_classes) > 0
        assert all([issubclass(kls, AdoptionMetric) for kls in metric_classes])
