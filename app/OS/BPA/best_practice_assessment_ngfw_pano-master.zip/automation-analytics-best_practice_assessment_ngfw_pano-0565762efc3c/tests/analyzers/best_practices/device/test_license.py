# -*- coding: utf-8 -*-
import datetime
import weakref

import pytest

from bpa.analyzers.best_practices.device.license import LicenseAnalyzer
from bpa.analyzers.best_practices.manager import BestPracticesAnalyzerManager
from bpa.analyzers.best_practices.bp_check import BestPracticeWarning, BestPracticeNote
from bpa.models.license import License, LicenseInfo

from unittest.mock import Mock

check_info = BestPracticesAnalyzerManager.get_check_info()


class Test_check_threat_protection_license_warn:
    @pytest.mark.passing
    def test_passing(self):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.get("security_rule").using_threat_prevention = True
        lics = LicenseInfo()
        tp_lic = License(
            "Threat Prevention",
            "dummy",
            "123",
            datetime.date(2019, 5, 1),
            datetime.date(9999, 7, 1),
        )
        lics.add(tp_lic)
        model_manager.license_info = lics
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_threat_protection_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

    @pytest.mark.passing
    def test_passing_with_only_mandatory_fields(self):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.get("security_rule").using_threat_prevention = True

        # Test case 1
        lics = LicenseInfo()
        tp_lic = License(
            "Threat Prevention", "dummy", None, None, datetime.date(9999, 7, 1)
        )
        lics.add(tp_lic)
        model_manager.license_info = lics
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_threat_protection_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

        # Test case 2 - using from_tsf function
        lics = LicenseInfo()
        tp_lic = License.from_tsf(
            {
                "Feature": "Threat Prevention",
                "Description": "dummy",
                "Expires": "December 31, 9999",
            }
        )
        lics.add(tp_lic)
        model_manager.license_info = lics
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_threat_protection_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

    @pytest.mark.failing
    def test_failing(self):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.get("security_rule").using_threat_prevention = True
        model_manager.license_info = LicenseInfo()
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_threat_protection_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False

    @pytest.mark.none
    def test_skip_if_panorama(self):
        model_manager = Mock()
        model_manager.tree.panorama = True
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_threat_protection_license_warn()
        assert check is None

    @pytest.mark.none
    def test_skip_if_no_threat_prevention_usage(self):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.get("security_rule").using_threat_prevention = False
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_threat_protection_license_warn()
        assert check is None


class Test_check_wildfire_license_warn:
    wildfire_license_warn_test_data = [
        pytest.param(
            {
                "feature": "WildFire License",
                "description": "dummy",
                "serial_number": "123",
                "issue_date": datetime.date(2019, 5, 1),
                "expire_date": datetime.date(9999, 7, 1),
            },
            True,
            BestPracticeWarning,
            True,
            marks=pytest.mark.passing,
        ),
        pytest.param(
            {
                "feature": "WildFire License",
                "description": "dummy",
                "serial_number": "123",
                "issue_date": datetime.date(2019, 5, 1),
                "expire_date": datetime.date(9999, 7, 1),
            },
            False,
            BestPracticeNote,
            None,
            marks=pytest.mark.note,
        ),
        pytest.param(
            {
                "feature": "WildFire License",
                "description": "dummy",
                "serial_number": "123",
                "issue_date": None,
                "expire_date": datetime.date(2019, 1, 1),
            },
            False,
            None,
            None,
            marks=pytest.mark.none,
        ),
        pytest.param(
            {
                "feature": "WildFire License",
                "description": "dummy",
                "serial_number": "123",
                "issue_date": None,
                "expire_date": datetime.date(2019, 4, 1),
            },
            True,
            BestPracticeWarning,
            False,
            marks=pytest.mark.failing,
        ),
    ]

    @pytest.mark.parametrize(
        "wildfire_license_attrs,wildfire_check,expected_output, check_passed_value",
        wildfire_license_warn_test_data,
    )
    def test_check_wildfire_license_warn(
        self,
        wildfire_license_attrs,
        wildfire_check,
        expected_output,
        check_passed_value,
    ):

        model_manager = Mock()
        model_manager.tree.panorama = False
        license_info = LicenseInfo()
        license_info.add(License(**wildfire_license_attrs))
        model_manager.license_info = license_info
        model_manager.get("antivirus_profile").using_wildfire = wildfire_check
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_wildfire_license_warn()

        if expected_output is None:
            assert check == expected_output
        else:
            assert isinstance(check, expected_output)
            if not isinstance(check, BestPracticeNote):
                assert check.check_passed is check_passed_value

    @pytest.mark.passing
    def test_passing(self):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.get("antivirus_profile").using_wildfire = True
        lics = LicenseInfo()
        wf_lic = License(
            "WildFire License",
            "dummy",
            "123",
            datetime.date(2019, 5, 1),
            datetime.date(9999, 7, 1),
        )
        lics.add(wf_lic)
        model_manager.license_info = lics
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_wildfire_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

    @pytest.mark.passing
    def test_passing_with_only_mandatory_fields(self):
        # Basic setup
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.get("antivirus_profile").using_wildfire = True

        # Test case 1
        lics = LicenseInfo()
        wf_lic = License(
            "WildFire License", "dummy", None, None, datetime.date(9999, 7, 1)
        )
        lics.add(wf_lic)
        model_manager.license_info = lics
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_wildfire_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

        # Test case 2 - using from_tsf function
        lics = LicenseInfo()
        wf_lic = License.from_tsf(
            {
                "Feature": "WildFire License",
                "Description": "dummy",
                "Expires": "December 31, 9999",
            }
        )
        lics.add(wf_lic)
        model_manager.license_info = lics
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_wildfire_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

    @pytest.mark.failing
    def test_failing(self):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.get("antivirus_profile").using_wildfire = True
        model_manager.license_info = LicenseInfo()
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_wildfire_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False

    @pytest.mark.none
    def test_skip_if_panorama(self):
        model_manager = Mock()
        model_manager.tree.panorama = True
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_wildfire_license_warn()
        assert check is None


class Test_check_url_filtering_license_warn:
    @pytest.mark.passing
    def test_passing(self):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.get("security_rule").using_url_filtering = True
        lics = LicenseInfo()
        url_lic = License(
            "PAN-DB URL Filtering",
            "dummy",
            "123",
            datetime.date(2019, 5, 1),
            datetime.date(9999, 7, 1),
        )
        lics.add(url_lic)
        model_manager.license_info = lics
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_url_filtering_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

    @pytest.mark.passing
    def test_passing_with_only_mandatory_fields(self):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.get("security_rule").using_url_filtering = True

        # Test case 1
        lics = LicenseInfo()
        url_lic = License(
            "PAN-DB URL Filtering", "dummy", None, None, datetime.date(9999, 7, 1)
        )
        lics.add(url_lic)
        model_manager.license_info = lics
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_url_filtering_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

        # Test case 2
        lics = LicenseInfo()
        url_lic = License.from_tsf(
            {
                "Feature": "PAN-DB URL Filtering",
                "Description": "dummy",
                "Expires": "December 31, 9999",
            }
        )
        lics.add(url_lic)
        model_manager.license_info = lics
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_url_filtering_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

    @pytest.mark.failing
    def test_failing(self):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.get("security_rule").using_url_filtering = True
        model_manager.license_info = LicenseInfo()
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_url_filtering_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False

    @pytest.mark.none
    def test_skip_if_panorama(self):
        model_manager = Mock()
        model_manager.tree.panorama = True
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_url_filtering_license_warn()
        assert check is None

    @pytest.mark.none
    def test_skip_if_no_url_filtering_usage(self):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.get("security_rule").using_url_filtering = False
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_url_filtering_license_warn()
        assert check is None


class Test_check_gp_gateway_license_warn:
    gp_gateway_license_test_data = [
        # license valid and only clientless_vpn_enabled configured -> pass
        pytest.param(
            {
                "feature": "GlobalProtect Gateway",
                "description": "dummy",
                "serial_number": "123",
                "issue_date": datetime.date(2019, 5, 1),
                "expire_date": datetime.date(9999, 7, 1),
            },
            True,
            False,
            False,
            BestPracticeWarning,
            True,
            marks=pytest.mark.passing,
        ),
        # license valid and only multiple_external_gateways configured -> pass
        pytest.param(
            {
                "feature": "GlobalProtect Gateway",
                "description": "dummy",
                "serial_number": "123",
                "issue_date": datetime.date(2019, 5, 1),
                "expire_date": datetime.date(9999, 7, 1),
            },
            False,
            True,
            False,
            BestPracticeWarning,
            True,
            marks=pytest.mark.passing,
        ),
        # license valid and only hip_profiles_applied_on_rules configured -> pass
        pytest.param(
            {
                "feature": "GlobalProtect Gateway",
                "description": "dummy",
                "serial_number": "123",
                "issue_date": datetime.date(2019, 5, 1),
                "expire_date": datetime.date(9999, 7, 1),
            },
            False,
            False,
            True,
            BestPracticeWarning,
            True,
            marks=pytest.mark.passing,
        ),
        # only license is active -> note
        pytest.param(
            {
                "feature": "GlobalProtect Gateway",
                "description": "dummy",
                "serial_number": "123",
                "issue_date": datetime.date(2019, 5, 1),
                "expire_date": datetime.date(9999, 7, 1),
            },
            False,
            False,
            False,
            BestPracticeNote,
            None,
            marks=pytest.mark.note,
        ),
        # license expired and not configured anything-> Skip
        pytest.param(
            {
                "feature": "GlobalProtect Gateway",
                "description": "dummy",
                "serial_number": "123",
                "issue_date": None,
                "expire_date": datetime.date(2019, 1, 1),
            },
            False,
            None,  # false
            None,  # false
            None,
            None,
            marks=pytest.mark.none,
        ),
        # license expired and configured clientless_vpn_enabled -> Fail
        pytest.param(
            {
                "feature": "GlobalProtect Gateway",
                "description": "dummy",
                "serial_number": "123",
                "issue_date": None,
                "expire_date": datetime.date(2019, 4, 1),
            },
            True,
            False,
            False,
            BestPracticeWarning,
            False,
            marks=pytest.mark.failing,
        ),
        # license expired and configured multiple_external_gateways -> Fail
        pytest.param(
            {
                "feature": "GlobalProtect Gateway",
                "description": "dummy",
                "serial_number": "123",
                "issue_date": None,
                "expire_date": datetime.date(2019, 4, 1),
            },
            False,
            True,
            False,
            BestPracticeWarning,
            False,
            marks=pytest.mark.failing,
        ),
        # license expired and configured hip_profiles_applied_on_rules -> Fail
        pytest.param(
            {
                "feature": "GlobalProtect Gateway",
                "description": "dummy",
                "serial_number": "123",
                "issue_date": None,
                "expire_date": datetime.date(2019, 4, 1),
            },
            False,
            False,
            True,
            BestPracticeWarning,
            False,
            marks=pytest.mark.failing,
        ),
    ]

    @pytest.mark.parametrize(
        "gp_gateway_license_attr,gp_gateway_check,multiple_external_gateway,hip_profiles_applied_on_rules,expected_output, check_passed_value",
        gp_gateway_license_test_data,
    )
    def test_check_gp_gateway_license_warn(
        self,
        gp_gateway_license_attr,
        gp_gateway_check,
        multiple_external_gateway,
        hip_profiles_applied_on_rules,
        expected_output,
        check_passed_value,
        monkeypatch,
    ):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.tree.clientless_vpn_enabled = gp_gateway_check
        license_info = LicenseInfo()
        license_info.add(License(**gp_gateway_license_attr))
        model_manager.license_info = license_info
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)

        # Patching return of functions
        monkeypatch.setattr(
            analyzer,
            "multiple_external_gateways",
            lambda **kwargs: multiple_external_gateway,
        )
        monkeypatch.setattr(
            analyzer,
            "hip_profiles_applied_on_rules",
            lambda **kwargs: hip_profiles_applied_on_rules,
        )
        check = analyzer._check_gp_gateway_license_warn()
        if expected_output is None:
            assert check == expected_output
        else:
            assert isinstance(check, expected_output)
            if not isinstance(check, BestPracticeNote):
                assert check.check_passed is check_passed_value

    @pytest.mark.passing
    def test_passing_with_only_mandatory_fields(self, monkeypatch):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.tree.clientless_vpn_enabled = True
        lics = LicenseInfo()
        gp_lic = License(
            "GlobalProtect Gateway", "dummy", None, None, datetime.date(9999, 7, 1)
        )
        lics.add(gp_lic)
        model_manager.license_info = lics
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)

        # Patching return of functions
        monkeypatch.setattr(
            analyzer, "multiple_external_gateways", lambda **kwargs: False,
        )
        monkeypatch.setattr(
            analyzer, "hip_profiles_applied_on_rules", lambda **kwargs: False,
        )
        check = analyzer._check_gp_gateway_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

        lics = LicenseInfo()
        gp_lic = License.from_tsf(
            {
                "Feature": "GlobalProtect Gateway",
                "Description": "dummy",
                "Expires": "December 31, 9999",
            }
        )
        lics.add(gp_lic)
        model_manager.license_info = lics
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)

        # Patching return of functions
        monkeypatch.setattr(
            analyzer, "multiple_external_gateways", lambda **kwargs: False,
        )
        monkeypatch.setattr(
            analyzer, "hip_profiles_applied_on_rules", lambda **kwargs: False,
        )
        check = analyzer._check_gp_gateway_license_warn()
        assert check is not None
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

    @pytest.mark.none
    def test_skip_if_panorama(self):
        model_manager = Mock()
        model_manager.tree.panorama = True
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_gp_gateway_license_warn()
        assert check is None


class Test_check_dns_cloud_security_license_warn:
    dns_cloud_security_warn_test_data = [
        # pass
        pytest.param(
            {
                "feature": "DNS Security",
                "description": "dummy pass",
                "serial_number": "123",
                "issue_date": datetime.date(2019, 5, 1),
                "expire_date": datetime.date(2021, 7, 1),
            },
            10,
            True,
            BestPracticeWarning,
            True,
            marks=pytest.mark.passing,
        ),
        # note
        pytest.param(
            {
                "feature": "DNS Security",
                "description": "dummy note",
                "serial_number": "123",
                "issue_date": datetime.date(2019, 5, 1),
                "expire_date": datetime.date(2022, 7, 1),
            },
            10,
            False,
            BestPracticeNote,
            None,
            marks=pytest.mark.note,
        ),
        # skip
        pytest.param(
            {
                "feature": "DNS Security",
                "description": "dummy skip",
                "serial_number": "123",
                "issue_date": None,
                "expire_date": datetime.date(2018, 7, 1),
            },
            10,
            False,
            None,
            None,
            marks=pytest.mark.none,
        ),
        # fail
        pytest.param(
            {
                "feature": "DNS Security",
                "description": "dummy fail",
                "serial_number": "123",
                "issue_date": datetime.date(2019, 5, 1),
                "expire_date": datetime.date(2018, 4, 1),
            },
            10,
            True,
            BestPracticeWarning,
            False,
            marks=pytest.mark.failing,
        ),
    ]

    @pytest.mark.parametrize(
        "dns_license_attrs,version,dns_signature_check,expected_output,check_passed_value",
        dns_cloud_security_warn_test_data,
    )
    def test_check_is_dns_signature_set_in_profile(
        self,
        dns_license_attrs,
        version,
        dns_signature_check,
        expected_output,
        check_passed_value,
        monkeypatch,
    ):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.tree.version = version
        license_info = LicenseInfo()
        license_info.add(License(**dns_license_attrs))
        model_manager.license_info = license_info
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)

        # Patching return of functions
        monkeypatch.setattr(
            analyzer,
            "_is_dns_signature_check_in_profile",
            lambda **kwargs: dns_signature_check,
        )
        check = analyzer._check_dns_security_license_warn()
        if expected_output is None:
            assert check == expected_output
        else:
            assert isinstance(check, expected_output)
            if not isinstance(check, BestPracticeNote):
                assert check.check_passed is check_passed_value

    @pytest.mark.none
    def test_skip_if_panorama_dns_license(self):
        model_manager = Mock()
        model_manager.tree.panorama = True
        model_manager.tree.version = 10
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        check = analyzer._check_dns_security_license_warn()
        assert check is None

    version_test_data = [(8, None), (9, False), (10, False)]

    @pytest.mark.parametrize("version,expected_output", version_test_data)
    def test_check_version_dns_cloud_security(
        self, version, expected_output, monkeypatch
    ):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.tree.version = version
        lics = LicenseInfo()
        gp_lic = License(
            "DNS Security",
            "dummy",
            None,
            datetime.date(2019, 9, 1),
            datetime.date(9999, 7, 1),
        )
        lics.add(gp_lic)
        model_manager.license_info = lics
        manager_ref = weakref.ref(model_manager)
        analyzer = LicenseAnalyzer(manager_ref, check_info)
        # Patching return of functions
        monkeypatch.setattr(
            analyzer, "_is_dns_signature_check_in_profile", lambda **kwargs: True,
        )
        check = analyzer._check_dns_security_license_warn()
        if expected_output is None:
            assert check == expected_output
        else:
            assert isinstance(check, BestPracticeWarning)
