# -*- coding: utf-8 -*-
import weakref

import pytest

from bpa.analyzers.best_practices.device.authentication_profile import (
    AuthenticationProfilesAnalyzer,
)
from bpa.models.constants import NONE_LOWER
from bpa.models.device.authentication_profile import AuthenticationProfileModel


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def make_auth_profile(model_manager):
    """Helper factory for creating AuthenticationProfileModel instances.

    https://docs.pytest.org/en/latest/fixture.html#factories-as-fixtures
    """

    defaults = {
        "name": "dummy",
        "method": "local-database",
        "server_profile": "svr_prof",
        "allow_list": [],
        "lockout_time": 0,
        "failed_attempts": 0,
        "template_name": None,
        "location": "vsys1",
        "model_manager": weakref.ref(model_manager),
    }

    def _make_auth_profile(**overrides):
        attrs = {**defaults, **overrides}
        return AuthenticationProfileModel(**attrs)

    return _make_auth_profile


@pytest.mark.passing
@pytest.mark.failing
def test_external_admin_auth(model_manager, check_info, make_auth_profile):
    manager_ref = weakref.ref(model_manager)
    analyzer = AuthenticationProfilesAnalyzer(manager_ref, check_info)
    profs = {"vsys1": []}
    assert analyzer._check_external_admin_auth(profs).check_passed is False
    profs["vsys1"].append(make_auth_profile())
    assert analyzer._check_external_admin_auth(profs).check_passed is False
    profs["vsys1"].append(make_auth_profile(method="radius"))
    assert analyzer._check_external_admin_auth(profs).check_passed is True
    profs["vsys2"] = [
        make_auth_profile(method=NONE_LOWER),
        make_auth_profile(method="local-database"),
    ]
    assert analyzer._check_external_admin_auth(profs).check_passed is False
