# -*- coding: utf-8 -*-
from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.objects.hip_profile import HipProfileAnalyzer
from bpa.models.objects.hip_profile import HipProfileModel
from bpa.models.policies.security_rule import SecurityRuleModel
from bpa.models.model_set import ModelSet
from bpa.models.model_sets.security_rule import SecurityRuleModelSet
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        hip_model1 = HipProfileModel(
            location="DG-USA",
            model_manager=model_manager,
            name="HIP_Profile1",
            matches=["HIP-0"],
        )
        hip_model2 = HipProfileModel(
            location="DG-USA",
            model_manager=model_manager,
            name="HIP_Profile2",
            matches=["HIP-0"],
        )
        hip_model3 = HipProfileModel(
            location="Texas-DG",
            model_manager=model_manager,
            name="HIP_Profile1",
            matches=["HIP-0"],
        )
        hip_ms = ModelSet()
        hip_ms.add(hip_model1)
        hip_ms.add(hip_model2)
        hip_ms.add(hip_model3)
        model_manager.model_set_lookup["hip_profile"] = hip_ms
        security_model = build_model(
            SecurityRuleModel,
            model_manager,
            location="DG-USA",
            hip_profiles=["HIP_Profile1", "HIP_Profile2"],
            rule_name="security_rule_1",
        )

        sec_rule_model_set = SecurityRuleModelSet()
        sec_rule_model_set.add(security_model)
        model_manager.model_set_lookup["security_rule"] = sec_rule_model_set

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.ancestors = {
            "shared": ["shared"],
            "DG-USA": ["DG-USA", "shared"],
            "DG-Texas": ["DG-Texas", "DG-USA", "shared"],
            "DG-Plano": ["DG-Plano", "Texas-DG", "DG-USA", "shared"],
        }

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def hip_model(model_manager):
    def _hip_model(**overrides):
        return build_model(HipProfileModel, model_manager, **overrides)

    return _hip_model


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    return HipProfileAnalyzer(manager_ref, check_info)


class TestHipProfileAnalyzer:
    @pytest.mark.parametrize(
        "ngfw, valid_license, run_checks",
        [
            (True, True, False),
            (True, False, False),
            (False, True, False),
            (False, False, False),
        ],
    )
    def test_hip_profile_get_checks(check_info, ngfw, valid_license, run_checks):
        manager = MagicMock()
        manager().tree.ngfw = ngfw
        manager().license_info.has_active_gp_license.return_value = valid_license
        analyzer = HipProfileAnalyzer(manager, check_info)
        assert (len(analyzer.get_checks()) > 0) is run_checks
