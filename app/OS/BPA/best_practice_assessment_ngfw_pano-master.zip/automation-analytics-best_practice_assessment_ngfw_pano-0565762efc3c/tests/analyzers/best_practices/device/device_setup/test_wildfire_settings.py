# -*- coding: utf-8 -*-
from unittest.mock import MagicMock

import pytest
import weakref

from bpa.models.device.device_setup.wildfire import (
    WildFireSettings,
    SessionInfo,
    SizeLimits,
)
from bpa.analyzers.best_practices.bp_check import BestPracticeNote, BestPracticeWarning
from bpa.analyzers.best_practices.device.device_setup.wildfire_settings import (
    WildfireSettingsAnalyzer,
)
from tests.utils.models.base import build_skeleton


@pytest.fixture
def wildfire_settings_analyzer(check_info):
    return WildfireSettingsAnalyzer(MagicMock(), check_info)


@pytest.fixture
def model_manager_8x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_manager_8_1(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def wildfire_settings_analyzer_8x(model_manager_8x, check_info):
    manager_ref = weakref.ref(model_manager_8x)
    analyzer = WildfireSettingsAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def wildfire_settings_analyzer_8_1(model_manager_8_1, check_info):
    manager_ref = weakref.ref(model_manager_8_1)
    analyzer = WildfireSettingsAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def model_manager_9x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 9

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def wildfire_settings_analyzer_9x(model_manager_9x, check_info):
    manager_ref = weakref.ref(model_manager_9x)
    analyzer = WildfireSettingsAnalyzer(manager_ref, check_info)
    return analyzer


class Test_check_wildfire_public_cloud_note:
    @pytest.mark.passing
    def test_check_wildfire_public_cloud_note_passing(self, wildfire_settings_analyzer):
        model_instance = build_skeleton(
            WildFireSettings,
            wildfire_public_cloud="wildfire.paloaltonetworks.com",
            timezone=None,
        )
        check_result = wildfire_settings_analyzer._check_wildfire_public_cloud_note(
            model_instance, MagicMock()
        )
        assert check_result is None

    @pytest.mark.failing
    def test_check_wildfire_public_cloud_note_failing(self, wildfire_settings_analyzer):
        model_instance = build_skeleton(
            WildFireSettings,
            wildfire_public_cloud="wildfire.paloaltonetworks.com",
            timezone="not-none",
        )
        check_result = wildfire_settings_analyzer._check_wildfire_public_cloud_note(
            model_instance, MagicMock()
        )
        assert check_result.check_message is not None


class Test_check_pe_size_limit_warn:
    @pytest.mark.passing
    def test_check_pe_size_limit_warn_passing_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"pe": 10})
        )
        check_result = wildfire_settings_analyzer_8x._check_pe_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_pe_size_limit_warn_failing_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"pe": 9})
        )
        check_result = wildfire_settings_analyzer_8x._check_pe_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to set the file size limit for "pe" to a value of 10'
        )

    @pytest.mark.note
    def test_check_pe_size_limit_note_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"pe": 11})
        )
        check_result = wildfire_settings_analyzer_8x._check_pe_size_limit_warn(
            model_instance, MagicMock()
        )
        assert type(check_result) is BestPracticeNote

    test_9x_data = [
        pytest.param(16, BestPracticeWarning, True, marks=pytest.mark.passing),
        pytest.param(15, BestPracticeWarning, False, marks=pytest.mark.failing),
        pytest.param(17, BestPracticeNote, None, marks=pytest.mark.note),
    ]

    @pytest.mark.parametrize(
        "size_limit, check_result_instance, check_result_check_passed", test_9x_data
    )
    def test_check_pe_size_limit_9x(
        self,
        wildfire_settings_analyzer_9x,
        size_limit,
        check_result_instance,
        check_result_check_passed,
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"pe": size_limit})
        )
        check_result = wildfire_settings_analyzer_9x._check_pe_size_limit_warn(
            model_instance, MagicMock()
        )

        assert isinstance(check_result, check_result_instance)

        if check_result_instance is not BestPracticeNote:
            assert check_result.check_passed is check_result_check_passed


class Test_check_apk_size_limit_warn:
    @pytest.mark.passing
    def test_check_apk_size_limit_warn_passing_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"apk": 30})
        )
        check_result = wildfire_settings_analyzer_8x._check_apk_size_limit_warn(
            model_instance, MagicMock()
        )
        assert isinstance(check_result, BestPracticeWarning)
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_apk_size_limit_warn_failing_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"apk": 29})
        )
        check_result = wildfire_settings_analyzer_8x._check_apk_size_limit_warn(
            model_instance, MagicMock()
        )
        assert isinstance(check_result, BestPracticeWarning)
        assert check_result.check_passed is False

    @pytest.mark.note
    def test_check_apk_size_limit_note_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"apk": 31})
        )
        check_result = wildfire_settings_analyzer_8x._check_apk_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result is not None
        assert isinstance(check_result, BestPracticeNote)

    test_9x_data = [
        pytest.param(10, BestPracticeWarning, True, marks=pytest.mark.passing),
        pytest.param(9, BestPracticeWarning, False, marks=pytest.mark.failing),
        pytest.param(11, BestPracticeNote, None, marks=pytest.mark.note),
    ]

    @pytest.mark.parametrize(
        "size_limit, check_result_instance, check_result_check_passed", test_9x_data
    )
    def test_check_apk_size_limit_9x(
        self,
        wildfire_settings_analyzer_9x,
        size_limit,
        check_result_instance,
        check_result_check_passed,
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"apk": size_limit})
        )
        check_result = wildfire_settings_analyzer_9x._check_apk_size_limit_warn(
            model_instance, MagicMock()
        )

        assert isinstance(check_result, check_result_instance)

        if check_result_instance is not BestPracticeNote:
            assert check_result.check_passed is check_result_check_passed


class Test_check_pdf_size_limit_warn:
    @pytest.mark.passing
    def test_check_pdf_size_limit_warn_passing_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"pdf": 1000})
        )
        check_result = wildfire_settings_analyzer_8x._check_pdf_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_pdf_size_limit_warn_failing_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"pdf": 999})
        )
        check_result = wildfire_settings_analyzer_8x._check_pdf_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to set the file size limit for "pdf" to a value of 1000'
        )

    @pytest.mark.note
    def test_check_pdf_size_limit_note_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"pdf": 1001})
        )
        check_result = wildfire_settings_analyzer_8x._check_pdf_size_limit_warn(
            model_instance, MagicMock()
        )
        assert isinstance(check_result, BestPracticeNote)

    test_9x_data = [
        pytest.param(3072, BestPracticeWarning, True, marks=pytest.mark.passing),
        pytest.param(3071, BestPracticeWarning, False, marks=pytest.mark.failing),
        pytest.param(3073, BestPracticeNote, None, marks=pytest.mark.note),
    ]

    @pytest.mark.parametrize(
        "size_limit, check_result_instance, check_result_check_passed", test_9x_data
    )
    def test_check_pdf_size_limit_9x(
        self,
        wildfire_settings_analyzer_9x,
        size_limit,
        check_result_instance,
        check_result_check_passed,
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"pdf": size_limit})
        )
        check_result = wildfire_settings_analyzer_9x._check_pdf_size_limit_warn(
            model_instance, MagicMock()
        )

        assert isinstance(check_result, check_result_instance)

        if check_result_instance is not BestPracticeNote:
            assert check_result.check_passed is check_result_check_passed


class Test_check_ms_office_size_limit_warn:
    @pytest.mark.passing
    def test_check_ms_office_size_limit_warn_passing_8x(
        self, wildfire_settings_analyzer_8x
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"ms-office": 2000})
        )
        check_result = wildfire_settings_analyzer_8x._check_ms_office_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_ms_office_size_limit_warn_failing_8x(
        self, wildfire_settings_analyzer_8x
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"ms-office": 199})
        )
        check_result = wildfire_settings_analyzer_8x._check_ms_office_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to set the file size limit for "ms-office" to a value of 2000'
        )

    @pytest.mark.note
    def test_check_ms_office_size_limit_note_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"ms-office": 2001})
        )
        check_result = wildfire_settings_analyzer_8x._check_ms_office_size_limit_warn(
            model_instance, MagicMock()
        )
        assert isinstance(check_result, BestPracticeNote)

    test_9x_data = [
        pytest.param(16384, BestPracticeWarning, True, marks=pytest.mark.passing),
        pytest.param(16383, BestPracticeWarning, False, marks=pytest.mark.failing),
        pytest.param(16385, BestPracticeNote, None, marks=pytest.mark.note),
    ]

    @pytest.mark.parametrize(
        "size_limit, check_result_instance, check_result_check_passed", test_9x_data
    )
    def test_check_ms_office_size_limit_9x(
        self,
        wildfire_settings_analyzer_9x,
        size_limit,
        check_result_instance,
        check_result_check_passed,
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"ms-office": size_limit})
        )
        check_result = wildfire_settings_analyzer_9x._check_ms_office_size_limit_warn(
            model_instance, MagicMock()
        )

        assert isinstance(check_result, check_result_instance)

        if check_result_instance is not BestPracticeNote:
            assert check_result.check_passed is check_result_check_passed


class Test_check_jar_size_limit_warn:
    @pytest.mark.passing
    def test_check_jar_size_limit_warn_passing_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"jar": 5})
        )
        check_result = wildfire_settings_analyzer_8x._check_jar_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_jar_size_limit_warn_failing_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"jar": 4})
        )
        check_result = wildfire_settings_analyzer_8x._check_jar_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to set the file size limit for "jar" to a value of 5'
        )

    @pytest.mark.note
    def test_check_jar_size_limit_note_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"jar": 6})
        )
        check_result = wildfire_settings_analyzer_8x._check_jar_size_limit_warn(
            model_instance, MagicMock()
        )
        assert isinstance(check_result, BestPracticeNote)

    test_9x_data = [
        pytest.param(5, BestPracticeWarning, True, marks=pytest.mark.passing),
        pytest.param(4, BestPracticeWarning, False, marks=pytest.mark.failing),
        pytest.param(6, BestPracticeNote, None, marks=pytest.mark.note),
    ]

    @pytest.mark.parametrize(
        "size_limit, check_result_instance, check_result_check_passed", test_9x_data
    )
    def test_check_jar_size_limit_9x(
        self,
        wildfire_settings_analyzer_9x,
        size_limit,
        check_result_instance,
        check_result_check_passed,
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"jar": size_limit})
        )
        check_result = wildfire_settings_analyzer_9x._check_jar_size_limit_warn(
            model_instance, MagicMock()
        )

        assert isinstance(check_result, check_result_instance)

        if check_result_instance is not BestPracticeNote:
            assert check_result.check_passed is check_result_check_passed


class Test_check_flash_size_limit_warn:
    @pytest.mark.passing
    def test_check_flash_size_limit_warn_passing_8x(
        self, wildfire_settings_analyzer_8x
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"flash": 5})
        )
        check_result = wildfire_settings_analyzer_8x._check_flash_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_flash_size_limit_warn_failing_8x(
        self, wildfire_settings_analyzer_8x
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"flash": 4})
        )
        check_result = wildfire_settings_analyzer_8x._check_flash_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to set the file size limit for "flash" to a value of 5'
        )

    @pytest.mark.note
    def test_check_flash_size_limit_note_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"flash": 6})
        )
        check_result = wildfire_settings_analyzer_8x._check_flash_size_limit_warn(
            model_instance, MagicMock()
        )
        assert isinstance(check_result, BestPracticeNote)

    test_9x_data = [
        pytest.param(5, BestPracticeWarning, True, marks=pytest.mark.passing),
        pytest.param(4, BestPracticeWarning, False, marks=pytest.mark.failing),
        pytest.param(6, BestPracticeNote, None, marks=pytest.mark.note),
    ]

    @pytest.mark.parametrize(
        "size_limit, check_result_instance, check_result_check_passed", test_9x_data
    )
    def test_check_flash_size_limit_9x(
        self,
        wildfire_settings_analyzer_9x,
        size_limit,
        check_result_instance,
        check_result_check_passed,
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"flash": size_limit})
        )
        check_result = wildfire_settings_analyzer_9x._check_flash_size_limit_warn(
            model_instance, MagicMock()
        )

        assert isinstance(check_result, check_result_instance)

        if check_result_instance is not BestPracticeNote:
            assert check_result.check_passed is check_result_check_passed


class Test_check_maxosx_size_limit_warn:
    @pytest.mark.passing
    def test_check_macosx_size_limit_warn_passing_8x(
        self, wildfire_settings_analyzer_8x
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"MacOSX": 1})
        )
        check_result = wildfire_settings_analyzer_8x._check_macosx_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_macosx_size_limit_warn_failing_8x(
        self, wildfire_settings_analyzer_8x
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"MacOSX": 0})
        )
        check_result = wildfire_settings_analyzer_8x._check_macosx_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to set the file size limit for "MacOSX" to a value of 1'
        )

    @pytest.mark.note
    def test_check_macosx_size_limit_note_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"MacOSX": 2})
        )
        check_result = wildfire_settings_analyzer_8x._check_macosx_size_limit_warn(
            model_instance, MagicMock()
        )
        assert isinstance(check_result, BestPracticeNote)

    test_9x_data = [
        pytest.param(10, BestPracticeWarning, True, marks=pytest.mark.passing),
        pytest.param(9, BestPracticeWarning, False, marks=pytest.mark.failing),
        pytest.param(11, BestPracticeNote, None, marks=pytest.mark.note),
    ]

    @pytest.mark.parametrize(
        "size_limit, check_result_instance, check_result_check_passed", test_9x_data
    )
    def test_check_macosx_size_limit_9x(
        self,
        wildfire_settings_analyzer_9x,
        size_limit,
        check_result_instance,
        check_result_check_passed,
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"MacOSX": size_limit})
        )
        check_result = wildfire_settings_analyzer_9x._check_macosx_size_limit_warn(
            model_instance, MagicMock()
        )

        assert isinstance(check_result, check_result_instance)

        if check_result_instance is not BestPracticeNote:
            assert check_result.check_passed is check_result_check_passed


class Test_check_archive_size_limit_warn:
    @pytest.mark.passing
    def test_check_archive_size_limit_warn_passing_8x(
        self, wildfire_settings_analyzer_8x
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"archive": 10})
        )
        check_result = wildfire_settings_analyzer_8x._check_archive_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_archive_size_limit_warn_failing_8x(
        self, wildfire_settings_analyzer_8x
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"archive": 9})
        )
        check_result = wildfire_settings_analyzer_8x._check_archive_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to set the file size limit for "archive" to a value of 10'
        )

    @pytest.mark.note
    def test_check_archive_size_limit_note_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"archive": 11})
        )
        check_result = wildfire_settings_analyzer_8x._check_archive_size_limit_warn(
            model_instance, MagicMock()
        )
        assert isinstance(check_result, BestPracticeNote)

    test_9x_data = [
        pytest.param(50, BestPracticeWarning, True, marks=pytest.mark.passing),
        pytest.param(49, BestPracticeWarning, False, marks=pytest.mark.failing),
        pytest.param(51, BestPracticeNote, None, marks=pytest.mark.note),
    ]

    @pytest.mark.parametrize(
        "size_limit, check_result_instance, check_result_check_passed", test_9x_data
    )
    def test_check_archive_size_limit_9x(
        self,
        wildfire_settings_analyzer_9x,
        size_limit,
        check_result_instance,
        check_result_check_passed,
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"archive": size_limit})
        )
        check_result = wildfire_settings_analyzer_9x._check_archive_size_limit_warn(
            model_instance, MagicMock()
        )

        assert isinstance(check_result, check_result_instance)

        if check_result_instance is not BestPracticeNote:
            assert check_result.check_passed is check_result_check_passed


class Test_check_linux_size_limit_warn:
    @pytest.mark.passing
    def test_check_linux_size_limit_warn_passing_8x(
        self, wildfire_settings_analyzer_8x
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"linux": 2})
        )
        check_result = wildfire_settings_analyzer_8x._check_linux_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_linux_size_limit_warn_failing_8x(
        self, wildfire_settings_analyzer_8x
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"linux": 1})
        )
        check_result = wildfire_settings_analyzer_8x._check_linux_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to set the file size limit for "linux" to a value of 2'
        )

    @pytest.mark.note
    def test_check_linux_size_limit_note_8x(self, wildfire_settings_analyzer_8x):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"linux": 3})
        )
        check_result = wildfire_settings_analyzer_8x._check_linux_size_limit_warn(
            model_instance, MagicMock()
        )
        assert isinstance(check_result, BestPracticeNote)

    test_9x_data = [
        pytest.param(50, BestPracticeWarning, True, marks=pytest.mark.passing),
        pytest.param(49, BestPracticeWarning, False, marks=pytest.mark.failing),
        pytest.param(51, BestPracticeNote, None, marks=pytest.mark.note),
    ]

    @pytest.mark.parametrize(
        "size_limit, check_result_instance, check_result_check_passed", test_9x_data
    )
    def test_check_linux_size_limit_9x(
        self,
        wildfire_settings_analyzer_9x,
        size_limit,
        check_result_instance,
        check_result_check_passed,
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"linux": size_limit})
        )
        check_result = wildfire_settings_analyzer_9x._check_linux_size_limit_warn(
            model_instance, MagicMock()
        )

        assert isinstance(check_result, check_result_instance)

        if check_result_instance is not BestPracticeNote:
            assert check_result.check_passed is check_result_check_passed


class Test_check_script_size_limit_warn:
    @pytest.mark.passing
    def test_check_script_size_limit_warn_passing_8_1(
        self, wildfire_settings_analyzer_8_1
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"script": 20})
        )
        check_result = wildfire_settings_analyzer_8_1._check_script_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_script_size_limit_warn_failing_8_1(
        self, wildfire_settings_analyzer_8_1
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"script": 19})
        )
        check_result = wildfire_settings_analyzer_8_1._check_script_size_limit_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to set the file size limit for "script" to a value of 20'
        )

    @pytest.mark.note
    def test_check_script_size_limit_note_8_1(self, wildfire_settings_analyzer_8_1):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"script": 21})
        )
        check_result = wildfire_settings_analyzer_8_1._check_script_size_limit_warn(
            model_instance, MagicMock()
        )
        assert isinstance(check_result, BestPracticeNote)

    test_9x_data = [
        pytest.param(20, BestPracticeWarning, True, marks=pytest.mark.passing),
        pytest.param(19, BestPracticeWarning, False, marks=pytest.mark.failing),
        pytest.param(21, BestPracticeNote, None, marks=pytest.mark.note),
    ]

    @pytest.mark.parametrize(
        "size_limit, check_result_instance, check_result_check_passed", test_9x_data
    )
    def test_check_script_size_limit_9x(
        self,
        wildfire_settings_analyzer_9x,
        size_limit,
        check_result_instance,
        check_result_check_passed,
    ):
        model_instance = build_skeleton(
            WildFireSettings, size_limits=SizeLimits({"script": size_limit})
        )
        check_result = wildfire_settings_analyzer_9x._check_script_size_limit_warn(
            model_instance, MagicMock()
        )

        assert isinstance(check_result, check_result_instance)

        if check_result_instance is not BestPracticeNote:
            assert check_result.check_passed is check_result_check_passed


class Test_check_report_grayware_files_enabled_warn:
    @pytest.mark.passing
    def test_check_report_grayware_files_enabled_warn_passing(
        self, wildfire_settings_analyzer
    ):
        model_instance = build_skeleton(
            WildFireSettings, report_grayware_files_enabled=True
        )
        check_result = wildfire_settings_analyzer._check_report_grayware_files_enabled_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_report_grayware_files_enabled_warn_failing(
        self, wildfire_settings_analyzer
    ):
        model_instance = build_skeleton(
            WildFireSettings, report_grayware_files_enabled=False
        )
        check_result = wildfire_settings_analyzer._check_report_grayware_files_enabled_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to enable "Report Grayware Files"'
        )


class Test_check_session_info_settings_warn:
    @pytest.mark.passing
    def test_check_session_info_settings_warn_passing(self, wildfire_settings_analyzer):
        model_instance = build_skeleton(
            WildFireSettings,
            session_info=SessionInfo(
                source_ip_enabled=True,
                source_port_enabled=True,
                destination_ip_enabled=True,
                destination_port_enabled=True,
                virtual_system_enabled=True,
                application_enabled=True,
                user_enabled=True,
                url_enabled=True,
                file_name_enabled=True,
                email_sender_enabled=True,
                email_recipient_enabled=True,
                email_subject_enabled=True,
            ),
        )
        check_result = wildfire_settings_analyzer._check_session_info_settings_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_session_info_settings_warn_failing(self, wildfire_settings_analyzer):
        model_instance = build_skeleton(
            WildFireSettings, session_info=SessionInfo(url_enabled=False)
        )
        check_result = wildfire_settings_analyzer._check_session_info_settings_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
