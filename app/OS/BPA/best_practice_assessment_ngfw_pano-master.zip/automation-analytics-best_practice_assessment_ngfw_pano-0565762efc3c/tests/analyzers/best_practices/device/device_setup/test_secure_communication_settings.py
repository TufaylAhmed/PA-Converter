# -*- coding: utf-8 -*-
from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeNote, BestPracticeWarning
from bpa.models.device.device_setup import secure_comm
from bpa.models.device.certificate_profile import CertificateProfileModel
from bpa.models.model_set import ModelSet
from bpa.analyzers.best_practices.device.device_setup.secure_communication_settings import (
    SecureCommunicationSettingsAnalyzer,
)
from tests.utils.models.base import build_model, build_skeleton


@pytest.fixture
def secure_comm_analyzer(check_info):
    return SecureCommunicationSettingsAnalyzer(MagicMock(), check_info)


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):

        model_manager.tree = MagicMock()

    return model_manager_factory(populate_models=populate_models)


class Test_valid_cert_profile:
    def test_cert_profile_is_none(self, secure_comm_analyzer):
        assert secure_comm_analyzer.valid_cert_profile(None, "dummy_template") is False

    @pytest.mark.parametrize(
        "use_crl,use_ocsp,expected_value",
        [
            (True, True, True),
            (False, False, False),
            (True, False, False),
            (False, True, False),
        ],
    )
    def test_use_crl_use_ocsp(
        self, check_info, use_crl, use_ocsp, expected_value, model_manager
    ):
        cert_model = build_model(
            CertificateProfileModel,
            model_manager=model_manager,
            use_crl=use_crl,
            use_ocsp=use_ocsp,
            name="cert_prof",
            template_name="dummy_template",
        )
        model_set = model_manager.model_set_lookup["certificate_profile"] = ModelSet()
        model_set.add(cert_model)
        manager_ref = weakref.ref(model_manager)
        analyzer = SecureCommunicationSettingsAnalyzer(manager_ref, check_info)
        assert (
            analyzer.valid_cert_profile("cert_prof", "dummy_template") is expected_value
        )


class Test_check_server_communication:
    def test_ssl_tls_service_profile_not_configured(self, secure_comm_analyzer):
        server = build_skeleton(
            secure_comm.SecureServerComms, ssl_tls_service_profile=None
        )
        model_instance = build_skeleton(secure_comm.SecureCommSettings, server=server)
        check = secure_comm_analyzer._check_server_communication(
            model_instance, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False
        assert check.check_message == "SSL/TLS Service Profile should be configured"

    def test_cert_profile_not_configured(self, secure_comm_analyzer, monkeypatch):
        server = build_skeleton(
            secure_comm.SecureServerComms,
            ssl_tls_service_profile="ssl_tls",
            certificate_profile=None,
        )
        model_instance = build_skeleton(secure_comm.SecureCommSettings, server=server)
        monkeypatch.setattr(
            SecureCommunicationSettingsAnalyzer,
            "valid_cert_profile",
            lambda self, cert, template: False,
        )
        check = secure_comm_analyzer._check_server_communication(
            model_instance, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False
        assert (
            check.check_message
            == "Certificate Profile should be configured using CRL and OCSP"
        )

    def test_allow_custom_certificate_only_disabled(
        self, secure_comm_analyzer, monkeypatch
    ):
        server = build_skeleton(
            secure_comm.SecureServerComms,
            ssl_tls_service_profile="ssl_tls",
            certificate_profile="cert_prof",
            allow_custom_certificate_only=False,
        )
        model_instance = build_skeleton(secure_comm.SecureCommSettings, server=server)
        monkeypatch.setattr(
            SecureCommunicationSettingsAnalyzer,
            "valid_cert_profile",
            lambda self, cert, template: True,
        )
        check = secure_comm_analyzer._check_server_communication(
            model_instance, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False
        assert (
            check.check_message
            == "Allow Custom Certificate Only setting should be configured"
        )

    def test_passing(self, secure_comm_analyzer, monkeypatch):
        server = build_skeleton(
            secure_comm.SecureServerComms,
            ssl_tls_service_profile="ssl_tls",
            certificate_profile="cert_prof",
            allow_custom_certificate_only=True,
        )
        model_instance = build_skeleton(secure_comm.SecureCommSettings, server=server)
        monkeypatch.setattr(
            SecureCommunicationSettingsAnalyzer,
            "valid_cert_profile",
            lambda self, cert, template: True,
        )
        check = secure_comm_analyzer._check_server_communication(
            model_instance, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True


class Test_check_client_communication:
    def test_predefined_certificate_type(self, secure_comm_analyzer):
        client = build_skeleton(
            secure_comm.SecureClientComms, certificate_type="predefined"
        )
        model_instance = build_skeleton(secure_comm.SecureCommSettings, client=client)
        check = secure_comm_analyzer._check_client_communication(
            model_instance, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False
        assert (
            check.check_message
            == 'It is recommended to configure "Local" or "SCEP" Certificate Type'
        )

    def test_no_certificate(self, secure_comm_analyzer):
        client = build_skeleton(
            secure_comm.SecureClientComms, certificate_type="local", certificate=None
        )
        model_instance = build_skeleton(secure_comm.SecureCommSettings, client=client)
        check = secure_comm_analyzer._check_client_communication(
            model_instance, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False
        assert (
            check.check_message
            == "It is recommended to configure a certificate when Certificate Type is Local"
        )

    def test_no_scep_profile(self, secure_comm_analyzer):
        client = build_skeleton(
            secure_comm.SecureClientComms, certificate_type="scep", scep_profile=None
        )
        model_instance = build_skeleton(secure_comm.SecureCommSettings, client=client)
        check = secure_comm_analyzer._check_client_communication(
            model_instance, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False
        assert (
            check.check_message
            == "It is recommended to configure a SCEP Profile when Certificate Type is SCEP"
        )

    def test_invalid_cert_profile(self, secure_comm_analyzer, monkeypatch):
        client = build_skeleton(
            secure_comm.SecureClientComms,
            certificate_type="scep",
            scep_profile="scep_profile",
        )
        model_instance = build_skeleton(secure_comm.SecureCommSettings, client=client)
        monkeypatch.setattr(
            SecureCommunicationSettingsAnalyzer,
            "valid_cert_profile",
            lambda self, cert, template: False,
        )
        check = secure_comm_analyzer._check_client_communication(
            model_instance, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False
        assert (
            check.check_message
            == "It is recommended to configure a Certificate Profile using CRL and OCSP"
        )

    def test_passing(self, secure_comm_analyzer, monkeypatch):
        customize_communication = secure_comm.PanoramaCustomizeCommunication(
            high_availability=True, wildfire=True
        )
        client = secure_comm.SecureClientComms(
            certificate_type="scep",
            scep_profile="scep_profile",
            customize_communication=customize_communication,
        )
        model_instance = build_skeleton(secure_comm.SecureCommSettings, client=client)
        monkeypatch.setattr(
            SecureCommunicationSettingsAnalyzer,
            "valid_cert_profile",
            lambda self, cert, template: True,
        )
        check = secure_comm_analyzer._check_client_communication(
            model_instance, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

    @pytest.mark.parametrize(
        "ha,wf,label", [(True, False, "wildfire"), (False, True, "high_availability")]
    )
    def test_note(self, secure_comm_analyzer, monkeypatch, ha, wf, label):
        customize_communication = secure_comm.PanoramaCustomizeCommunication(
            high_availability=ha, wildfire=wf
        )
        client = secure_comm.SecureClientComms(
            certificate_type="scep",
            scep_profile="scep_profile",
            customize_communication=customize_communication,
        )
        model_instance = build_skeleton(secure_comm.SecureCommSettings, client=client)
        monkeypatch.setattr(
            SecureCommunicationSettingsAnalyzer,
            "valid_cert_profile",
            lambda self, cert, template: True,
        )
        check = secure_comm_analyzer._check_client_communication(
            model_instance, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeNote)
        assert check.check_severity == "Caution"
        assert (
            check.check_message
            == f"The following Customize Communication options should be enabled: {label}"
        )

    def test_no_customize_communication_options(
        self, secure_comm_analyzer, monkeypatch
    ):
        customize_communication = secure_comm.PanoramaCustomizeCommunication(
            high_availability=False, wildfire=False
        )
        client = secure_comm.SecureClientComms(
            certificate_type="scep",
            scep_profile="scep_profile",
            customize_communication=customize_communication,
        )
        model_instance = build_skeleton(secure_comm.SecureCommSettings, client=client)
        monkeypatch.setattr(
            SecureCommunicationSettingsAnalyzer,
            "valid_cert_profile",
            lambda self, cert, template: True,
        )
        check = secure_comm_analyzer._check_client_communication(
            model_instance, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False
        assert (
            check.check_message
            == "All Customize Communication options should be enabled"
        )
