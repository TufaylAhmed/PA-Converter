# -*- coding: utf-8 -*-
import weakref

import pytest

from bpa.analyzers.best_practices.device.authentication_profile import (
    AuthenticationProfileAnalyzer,
)
from bpa.models.device.authentication_profile import AuthenticationProfileModel


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.mark.parametrize(
    "test_input,expected", [(29, False), (30, True), (45, True), (46, False)]
)
@pytest.mark.passing
@pytest.mark.failing
def test_lockout_time(model_manager, check_info, test_input, expected):
    manager_ref = weakref.ref(model_manager)
    analyzer = AuthenticationProfileAnalyzer(manager_ref, check_info)
    profile = AuthenticationProfileModel(
        name="prof",
        method="idk",
        server_profile="sp",
        allow_list=[],
        lockout_time=test_input,
        failed_attempts=0,
        template_name=None,
        location=None,
        model_manager=manager_ref,
    )
    assert analyzer._check_lockout_time(profile).check_passed == expected


@pytest.mark.parametrize(
    "test_input,expected", [(4, True), (5, True), (6, False), (0, False)]
)
@pytest.mark.passing
@pytest.mark.failing
def test_failed_attempts(model_manager, check_info, test_input, expected):
    manager_ref = weakref.ref(model_manager)
    analyzer = AuthenticationProfileAnalyzer(manager_ref, check_info)
    profile = AuthenticationProfileModel(
        name="prof",
        method="idk",
        server_profile="sp",
        allow_list=[],
        lockout_time=0,
        failed_attempts=test_input,
        template_name=None,
        location=None,
        model_manager=manager_ref,
    )
    assert analyzer._check_failed_attempts(profile).check_passed == expected


@pytest.mark.parametrize(
    "test_input,expected", [([], True), (["abc"], True), (["all"], False)]
)
@pytest.mark.passing
@pytest.mark.failing
def test_allow_list(model_manager, check_info, test_input, expected):
    manager_ref = weakref.ref(model_manager)
    analyzer = AuthenticationProfileAnalyzer(manager_ref, check_info)
    profile = AuthenticationProfileModel(
        name="prof",
        method="idk",
        server_profile="sp",
        allow_list=test_input,
        lockout_time=0,
        failed_attempts=0,
        template_name=None,
        location=None,
        model_manager=manager_ref,
    )
    assert (analyzer._check_allow_list(profile) is None) == expected
