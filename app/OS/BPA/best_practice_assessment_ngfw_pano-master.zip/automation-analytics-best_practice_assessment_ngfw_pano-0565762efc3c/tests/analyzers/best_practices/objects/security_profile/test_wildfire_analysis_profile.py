# -*- coding: utf-8 -*-
import weakref

import pytest
from unittest.mock import MagicMock

from bpa.analyzers.best_practices.objects.security_profile.wildfire_analysis_profile import (
    WildfireAnalysisProfileAnalyzer,
)
from bpa.models.objects.security_profile.wildfire_analysis_profile import (
    WildfireAnalysisProfileModel,
    WildfireAnalysisProfileRule,
)


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 9.0

    return model_manager_factory(populate_tree=populate_tree)


@pytest.mark.passing
def test_rules_passing(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    profile_any_both = WildfireAnalysisProfileModel(
        location=None,
        model_manager=manager_ref,
        name="Wf-prof-any",
        rules=[
            WildfireAnalysisProfileRule(
                applications=["any"],
                file_types=["any"],
                direction="both",
                analysis="public-cloud",
            )
        ],
    )

    profile_any_upload_download = WildfireAnalysisProfileModel(
        location=None,
        model_manager=manager_ref,
        name="Wf-prof-any",
        rules=[
            WildfireAnalysisProfileRule(
                applications=["any"],
                file_types=["any"],
                direction="upload",
                analysis="public-cloud",
            ),
            WildfireAnalysisProfileRule(
                applications=["any"],
                file_types=["any"],
                direction="download",
                analysis="private-cloud",
            ),
        ],
    )

    profile_explicit_both = WildfireAnalysisProfileModel(
        location=None,
        model_manager=manager_ref,
        name="Wf-prof-all",
        rules=[
            WildfireAnalysisProfileRule(
                applications=["any"],
                file_types=[
                    "pe",
                    "apk",
                    "pdf",
                    "ms-office",
                    "jar",
                    "flash",
                    "MacOSX",
                    "archive",
                    "linux",
                    "script",
                    "email-link",
                ],
                direction="both",
                analysis="public-cloud",
            )
        ],
    )

    profile_explicit_both_split = WildfireAnalysisProfileModel(
        location=None,
        model_manager=manager_ref,
        name="Wf-prof-all",
        rules=[
            WildfireAnalysisProfileRule(
                applications=["any"],
                file_types=["pe", "apk", "pdf", "ms-office", "jar"],
                direction="both",
                analysis="public-cloud",
            ),
            WildfireAnalysisProfileRule(
                applications=["any"],
                file_types=[
                    "flash",
                    "MacOSX",
                    "archive",
                    "linux",
                    "script",
                    "email-link",
                ],
                direction="both",
                analysis="public-cloud",
            ),
        ],
    )

    profile_explicit_both_split_with_duplicates = WildfireAnalysisProfileModel(
        location=None,
        model_manager=manager_ref,
        name="Wf-prof-all",
        rules=[
            WildfireAnalysisProfileRule(
                applications=["any"],
                file_types=["pe", "apk", "pdf", "ms-office", "jar"],
                direction="both",
                analysis="public-cloud",
            ),
            WildfireAnalysisProfileRule(
                applications=["any"],
                file_types=[
                    "pdf",
                    "jar",
                    "flash",
                    "MacOSX",
                    "archive",
                    "linux",
                    "script",
                    "email-link",
                ],
                direction="both",
                analysis="public-cloud",
            ),
        ],
    )

    profile_explicit_upload_download = WildfireAnalysisProfileModel(
        location=None,
        model_manager=manager_ref,
        name="Wf-prof-all",
        rules=[
            WildfireAnalysisProfileRule(
                applications=["any"],
                file_types=[
                    "pe",
                    "apk",
                    "pdf",
                    "ms-office",
                    "jar",
                    "flash",
                    "MacOSX",
                    "archive",
                    "linux",
                    "script",
                    "email-link",
                ],
                direction="upload",
                analysis="public-cloud",
            ),
            WildfireAnalysisProfileRule(
                applications=["any"],
                file_types=[
                    "pe",
                    "apk",
                    "pdf",
                    "ms-office",
                    "jar",
                    "flash",
                    "MacOSX",
                    "archive",
                    "linux",
                    "script",
                    "email-link",
                ],
                direction="download",
                analysis="private-cloud",
            ),
        ],
    )
    analyzer = WildfireAnalysisProfileAnalyzer(manager_ref, check_info)
    assert analyzer._check_rules(profile_any_both).check_passed
    assert analyzer._check_rules(profile_any_upload_download).check_passed
    assert analyzer._check_rules(profile_explicit_both).check_passed
    assert analyzer._check_rules(profile_explicit_both_split).check_passed
    assert analyzer._check_rules(
        profile_explicit_both_split_with_duplicates
    ).check_passed
    assert analyzer._check_rules(profile_explicit_upload_download).check_passed


@pytest.mark.failing
def test_rules_failing(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)

    profile_any_both_specific_app = WildfireAnalysisProfileModel(
        location=None,
        model_manager=manager_ref,
        name="Wf-prof-any",
        rules=[
            WildfireAnalysisProfileRule(
                applications=["bugzilla"],
                file_types=["any"],
                direction="both",
                analysis="public-cloud",
            )
        ],
    )

    profile_any_upload_only = WildfireAnalysisProfileModel(
        location=None,
        model_manager=manager_ref,
        name="Wf-prof-any",
        rules=[
            WildfireAnalysisProfileRule(
                applications=["any"],
                file_types=["any"],
                direction="upload",
                analysis="public-cloud",
            )
        ],
    )

    profile_explicit_both_lacking_pe = WildfireAnalysisProfileModel(
        location=None,
        model_manager=manager_ref,
        name="Wf-prof-all",
        rules=[
            WildfireAnalysisProfileRule(
                applications=["any"],
                file_types=[
                    "apk",
                    "pdf",
                    "ms-office",
                    "jar",
                    "flash",
                    "MacOSX",
                    "archive",
                    "linux",
                    "script",
                    "email-link",
                ],
                direction="both",
                analysis="public-cloud",
            )
        ],
    )

    profile_explicit_download_only = WildfireAnalysisProfileModel(
        location=None,
        model_manager=manager_ref,
        name="Wf-prof-all",
        rules=[
            WildfireAnalysisProfileRule(
                applications=["any"],
                file_types=[
                    "pe",
                    "apk",
                    "pdf",
                    "ms-office",
                    "jar",
                    "flash",
                    "MacOSX",
                    "archive",
                    "linux",
                    "script",
                    "email-link",
                ],
                direction="download",
                analysis="private-cloud",
            )
        ],
    )

    analyzer = WildfireAnalysisProfileAnalyzer(manager_ref, check_info)
    assert not analyzer._check_rules(profile_any_both_specific_app).check_passed
    assert not analyzer._check_rules(profile_any_upload_only).check_passed
    assert not analyzer._check_rules(profile_explicit_both_lacking_pe).check_passed
    assert not analyzer._check_rules(profile_explicit_download_only).check_passed
