# -*- coding: utf-8 -*-
import weakref

import pytest

from bpa.analyzers.best_practices.device.authentication_sequence import (
    AuthenticationSequencesAnalyzer,
)
from bpa.models.device.authentication_sequence import AuthenticationSequenceModel


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def make_auth_sequence(model_manager):
    """Helper factory for creating AuthenticationSequenceModel instances.

    https://docs.pytest.org/en/latest/fixture.html#factories-as-fixtures
    """

    defaults = {
        "name": "dummy",
        "auth_profiles": [],
        "template_name": None,
        "location": "vsys1",
        "model_manager": weakref.ref(model_manager),
    }

    def _make_auth_sequence(**overrides):
        attrs = {**defaults, **overrides}
        return AuthenticationSequenceModel(**attrs)

    return _make_auth_sequence


@pytest.mark.passing
@pytest.mark.failing
def test_sequence_exists(model_manager, check_info, make_auth_sequence):
    manager_ref = weakref.ref(model_manager)
    analyzer = AuthenticationSequencesAnalyzer(manager_ref, check_info)
    seqs = {"vsys1": []}
    assert analyzer._check_sequence_exists(seqs).check_passed is False
    seqs["vsys1"].append(make_auth_sequence())
    assert analyzer._check_sequence_exists(seqs).check_passed is False
    seqs["vsys1"].append(make_auth_sequence(auth_profiles=["p1"]))
    assert analyzer._check_sequence_exists(seqs).check_passed is False
    seqs["vsys1"].append(make_auth_sequence(auth_profiles=["p1", "p2"]))
    assert analyzer._check_sequence_exists(seqs).check_passed is True
    seqs["vsys2"] = []
    assert analyzer._check_sequence_exists(seqs).check_passed is False
