import pytest

from bpa.analyzers.best_practices.bp_check import (
    BestPracticeCheck,
    BestPracticeWarning,
    BestPracticeNote,
    SecurityRuleWarning,
)


@pytest.mark.core
class TestBPCheck:
    def test_bp_meta_error(self, check_info):
        check_meta = check_info["11"]
        with pytest.raises(TypeError):
            BestPracticeCheck.get_check(**check_meta)

    def test_bp_warning_error(self, check_info):
        check_meta = check_info["11"]
        with pytest.raises(TypeError):
            BestPracticeWarning.get_check(**check_meta)

    def test_bp_warning(self, check_info):
        check_meta = check_info["11"]
        check = BestPracticeWarning.get_check(**check_meta, check_passed=False)
        assert isinstance(check, BestPracticeCheck)
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False

    def test_bp_note(self, check_info):
        check_meta = check_info["28"]
        check = BestPracticeNote.get_check(**check_meta, check_message="Blah blah")
        assert isinstance(check, BestPracticeCheck)
        assert isinstance(check, BestPracticeNote)
        assert check.check_severity == "Info"

    def test_sr_warning(self, check_info):
        check_meta = check_info["3"]
        check = SecurityRuleWarning.get_check(**check_meta)
        assert isinstance(check, BestPracticeCheck)
        assert isinstance(check, BestPracticeWarning)
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_passed is None
        assert check.check_excluded is False
