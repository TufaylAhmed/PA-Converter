import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeWarning
from bpa.analyzers.best_practices.network.global_protect_gateway import (
    GlobalProtectGatewayAnalyzer,
)
from bpa.models.constants import NONE
from bpa.models.network.global_protect import (
    GlobalProtectGatewayModel,
    GlobalProtectGatewayAgentConfig,
    GlobalProtectSiteToSiteTunnelSettingsModel,
)
from bpa.models.device.ssl_tls_service_profile import SslTlsServiceProfileModel
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model, build_skeleton


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        ssl_model_set = model_manager.model_set_lookup[
            "ssl_tls_service_profile"
        ] = ModelSet()
        ssl_tls_service_profile_pass = build_model(
            SslTlsServiceProfileModel,
            model_manager=model_manager,
            template_name="pass",
            location="DG-USA",
            name="test-1",
            min_version="tls1-2",
        )
        ssl_tls_service_profile_fail = build_model(
            SslTlsServiceProfileModel,
            model_manager=model_manager,
            template_name="fail",
            location="DG-USA",
            name="test-2",
            min_version="tls1-0",
        )
        ssl_model_set.add(ssl_tls_service_profile_pass)
        ssl_model_set.add(ssl_tls_service_profile_fail)

        gp_ststs_model_set = model_manager.model_set_lookup[
            "global_protect_site_to_site_tunnel_settings"
        ] = ModelSet()
        tunnel_settings_pass = build_model(
            GlobalProtectSiteToSiteTunnelSettingsModel,
            model_manager=model_manager,
            name="GP-Gwy-S",
            tunnel_monitoring_enabled=True,
            replay_attack_detection_enabled=True,
            ipsec_crypto_profile="test-crypto-profile",
            template_name="pass",
        )
        tunnel_settings_fail = build_model(
            GlobalProtectSiteToSiteTunnelSettingsModel,
            model_manager=model_manager,
            name="GP-Gwy-S",
            tunnel_monitoring_enabled=False,
            replay_attack_detection_enabled=False,
            ipsec_crypto_profile="test-crypto-profile",
            template_name="fail",
        )
        gp_ststs_model_set.add(tunnel_settings_pass)
        gp_ststs_model_set.add(tunnel_settings_fail)

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 7.0
        model_manager.tree.panorama = True
        model_manager.tree.ancestors = {"DG-USA": ["DG-USA", "shared"]}

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def global_protect_gateway(model_manager):
    def _global_protect_gateway(**overrides):
        return build_model(GlobalProtectGatewayModel, model_manager, **overrides)

    return _global_protect_gateway


@pytest.fixture
def global_protect_gateway_agent_config():
    def _global_protect_gateway_agent_config(**overrides):
        return build_skeleton(GlobalProtectGatewayAgentConfig, **overrides)

    return _global_protect_gateway_agent_config


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = GlobalProtectGatewayAnalyzer(manager_ref, check_info)
    return analyzer


class TestGpGatewayAnalyzer:

    """check_ssl_tls_service_profile"""

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_ssl_tls_service_profile_min_version_passing(
        self, analyzer, global_protect_gateway
    ):
        assert analyzer._check_ssl_tls_service_profile_min_version(
            global_protect_gateway(
                template_name="pass",
                location="DG-USA",
                ssl_tls_service_profile="test-1",
            )
        ).check_passed

    @pytest.mark.integration
    @pytest.mark.failing
    def test_check_ssl_tls_service_profile_min_version_failing(
        self, analyzer, global_protect_gateway
    ):
        assert not analyzer._check_ssl_tls_service_profile_min_version(
            global_protect_gateway(
                template_name="fail",
                location="DG-USA",
                ssl_tls_service_profile="test-2",
            )
        ).check_passed

    """check_certificate_profile"""

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_certificate_profile_passing(self, analyzer, global_protect_gateway):
        assert analyzer._check_certificate_profile(
            global_protect_gateway(certificate_profile="test-cert-profile")
        ).check_passed

    @pytest.mark.integration
    @pytest.mark.failing
    def test_check_certificate_profile_failing(self, analyzer, global_protect_gateway):
        assert not analyzer._check_certificate_profile(
            global_protect_gateway(certificate_profile=NONE)
        ).check_passed

    """check_access_routes"""

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_access_routes_passing(
        self, analyzer, global_protect_gateway, global_protect_gateway_agent_config
    ):
        assert analyzer._check_access_routes(
            global_protect_gateway(
                agent_configs=[
                    global_protect_gateway_agent_config(access_routes=["0.0.0.0/0"])
                ]
            )
        ).check_passed

    @pytest.mark.integration
    @pytest.mark.failing
    def test_check_access_routes_failing(
        self, analyzer, global_protect_gateway, global_protect_gateway_agent_config
    ):
        assert not analyzer._check_access_routes(
            global_protect_gateway(
                agent_configs=[global_protect_gateway_agent_config(access_routes=[])]
            )
        ).check_passed

    """
    check_replay_attack_detection

    This looks at the GlobalProtectSiteToSiteTunnelSettingsModels added in the model_manager fixture above
    to ensure that replay_attack_detection_enabled is enabled or not
    """

    test_data_check_replay_attack_detection = [
        pytest.param(
            "pass", True, 79, BestPracticeWarning, True, marks=pytest.mark.passing
        ),
        pytest.param(
            "fail", True, 79, BestPracticeWarning, False, marks=pytest.mark.failing
        ),
        pytest.param("pass", False, 79, None, None, marks=pytest.mark.none),
    ]

    @pytest.mark.parametrize(
        "template_name_value, tunnel_mode_enabled_value, expected_result_check_id, "
        "expected_result_instance, expected_check_passed_value",
        test_data_check_replay_attack_detection,
    )
    def test_check_replay_attack_detection(
        self,
        analyzer,
        global_protect_gateway,
        template_name_value,
        tunnel_mode_enabled_value,
        expected_result_check_id,
        expected_result_instance,
        expected_check_passed_value,
    ):
        check_result = analyzer._check_replay_attack_detection(
            global_protect_gateway(
                template_name=template_name_value,
                name="GP-Gwy",
                tunnel_mode_enabled=tunnel_mode_enabled_value,
            )
        )

        if expected_result_instance is None:
            assert check_result == expected_result_instance
        else:
            assert isinstance(check_result, expected_result_instance)
            assert check_result.check_passed is expected_check_passed_value
            assert check_result.check_id == expected_result_check_id

    """
    check_tunnel_monitoring

    This looks at the GlobalProtectSiteToSiteTunnelSettingsModels added in the model_manager fixture above
    to ensure that tunnel_monitoring_enabled is enabled or not
    """

    test_data_check_tunnel_monitoring = [
        pytest.param(
            "pass", True, 80, BestPracticeWarning, True, marks=pytest.mark.passing
        ),
        pytest.param(
            "fail", True, 80, BestPracticeWarning, False, marks=pytest.mark.failing
        ),
        pytest.param("pass", False, 80, None, None, marks=pytest.mark.none),
    ]

    @pytest.mark.parametrize(
        "template_name_value, tunnel_mode_enabled_value, expected_result_check_id, "
        "expected_result_instance, expected_check_passed_value",
        test_data_check_tunnel_monitoring,
    )
    def test_check_tunnel_monitoring(
        self,
        analyzer,
        global_protect_gateway,
        template_name_value,
        tunnel_mode_enabled_value,
        expected_result_check_id,
        expected_result_instance,
        expected_check_passed_value,
    ):
        check_result = analyzer._check_tunnel_monitoring(
            global_protect_gateway(
                template_name=template_name_value,
                name="GP-Gwy",
                tunnel_mode_enabled=tunnel_mode_enabled_value,
            )
        )

        if expected_result_instance is None:
            assert check_result == expected_result_instance
        else:
            assert isinstance(check_result, expected_result_instance)
            assert check_result.check_passed is expected_check_passed_value
            assert check_result.check_id == expected_result_check_id
