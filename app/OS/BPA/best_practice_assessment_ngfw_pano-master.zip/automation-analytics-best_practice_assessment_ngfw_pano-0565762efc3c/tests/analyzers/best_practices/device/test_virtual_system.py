from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeNote
from bpa.analyzers.best_practices.device.virtual_system import VirtualSystemAnalyzer
from bpa.models.device.virtual_system import VirtualSystemModel
from bpa.models.device.user_id_hub import UserIdHubModel
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 9.0

    return model_manager_factory(populate_tree=populate_tree)


class TestVirtualSystemAnalyzer:
    @pytest.mark.none
    def test_check_shared_user_id_none_one(self, model_manager, check_info):
        manager_ref = weakref.ref(model_manager)
        analyzer = VirtualSystemAnalyzer(manager_ref, check_info)
        vsys = [build_model(VirtualSystemModel, model_manager, name="vsys1")]
        hubs = [build_model(UserIdHubModel, model_manager, name="vsys1")]
        assert analyzer._check_shared_user_id(vsys, hubs) is None

    @pytest.mark.none
    def test_check_shared_user_id_none_shared(self, model_manager, check_info):
        manager_ref = weakref.ref(model_manager)
        analyzer = VirtualSystemAnalyzer(manager_ref, check_info)
        vsys = [
            build_model(VirtualSystemModel, model_manager, name="vsys1"),
            build_model(VirtualSystemModel, model_manager, name="vsys2"),
        ]
        hubs = [build_model(UserIdHubModel, model_manager, name="vsys1")]
        assert analyzer._check_shared_user_id(vsys, hubs) is None

    @pytest.mark.note
    def test_check_shared_user_id_note(self, model_manager, check_info):
        manager_ref = weakref.ref(model_manager)
        analyzer = VirtualSystemAnalyzer(manager_ref, check_info)
        vsys = [
            build_model(VirtualSystemModel, model_manager, name="vsys1"),
            build_model(VirtualSystemModel, model_manager, name="vsys2"),
        ]
        hubs = []
        check = analyzer._check_shared_user_id(vsys, hubs)
        assert isinstance(check, BestPracticeNote)
