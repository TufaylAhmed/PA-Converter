# -*- coding: utf-8 -*-
from unittest.mock import MagicMock

import pytest

from bpa.models.device.device_setup.min_password_complexity import (
    MinimumPasswordComplexitySettings,
)
from bpa.analyzers.best_practices.device.device_setup.minimum_password_complexity_settings import (
    MinimumPasswordComplexitySettingsAnalyzer,
)
from tests.utils.models.base import build_skeleton


@pytest.fixture
def min_password_analyzer(check_info):
    return MinimumPasswordComplexitySettingsAnalyzer(MagicMock(), check_info)


class Test_check_minimum_password_complexity_enabled:
    def test_check_minimum_password_complexity_enabled_passing(
        self, min_password_analyzer
    ):
        model_instance = build_skeleton(
            MinimumPasswordComplexitySettings,
            enabled=True,
            minimum_length=9,
            minimum_uppercase_letters=2,
            minimum_lowercase_letters=2,
            block_username_inclusion=True,
        )
        check_result = min_password_analyzer._check_minimum_password_complexity_enabled(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    def test_check_minimum_password_complexity_enabled_failing(
        self, min_password_analyzer
    ):
        model_instance = build_skeleton(
            MinimumPasswordComplexitySettings,
            enabled=False,
            minimum_length=1,
            minimum_uppercase_letters=1,
            minimum_lowercase_letters=1,
            block_username_inclusion=False,
        )
        check_result = min_password_analyzer._check_minimum_password_complexity_enabled(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
