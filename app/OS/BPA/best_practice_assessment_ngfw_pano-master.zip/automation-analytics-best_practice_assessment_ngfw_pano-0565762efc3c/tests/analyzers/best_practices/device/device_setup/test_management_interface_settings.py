# -*- coding: utf-8 -*-
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeNote, BestPracticeWarning
from bpa.analyzers.best_practices.device.device_setup.management_interface_settings import (
    ManagementInterfaceSettingsAnalyzer,
)
from bpa.models.device.device_setup.management_interface import (
    ManagementInterfaceSettings,
)
from tests.utils.models.base import build_skeleton


@pytest.fixture
def mgmt_interface_analyzer(check_info):
    return ManagementInterfaceSettingsAnalyzer(MagicMock(), check_info)


class Test_check_permitted_ip_addresses:
    def test_management_ip_address_is_none(self, mgmt_interface_analyzer):
        mgmt_interface = build_skeleton(
            ManagementInterfaceSettings, management_ip_address=None
        )
        check = mgmt_interface_analyzer._check_permitted_ip_addresses(
            mgmt_interface, device_setup=MagicMock()
        )
        assert check is None

    def test_no_permitted_ip_addresses_fail(self, mgmt_interface_analyzer):
        mgmt_interface = build_skeleton(
            ManagementInterfaceSettings,
            management_ip_address="127.0.0.1",
            permitted_ip_addresses=[],
        )
        check = mgmt_interface_analyzer._check_permitted_ip_addresses(
            mgmt_interface, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False
        assert check.check_message == "Permitted IP Addresses should be configured"

    def test_private_mgmt_ip_public_permitted_ip_addresses_fail(
        self, mgmt_interface_analyzer
    ):
        mgmt_interface = build_skeleton(
            ManagementInterfaceSettings,
            management_ip_address="192.168.0.1",
            permitted_ip_addresses=["192.168.255.255", "1.1.1.1"],
        )
        check = mgmt_interface_analyzer._check_permitted_ip_addresses(
            mgmt_interface, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False
        assert (
            check.check_message
            == "Only private IP addresses should be permitted. Please remove the following public IP addresses: ***.1.1.***"
        )

    def test_private_mgmt_ip_private_permitted_ip_addresses_passing(
        self, mgmt_interface_analyzer
    ):
        mgmt_interface = build_skeleton(
            ManagementInterfaceSettings,
            management_ip_address="192.168.0.1",
            permitted_ip_addresses=["192.168.255.255"],
        )
        check = mgmt_interface_analyzer._check_permitted_ip_addresses(
            mgmt_interface, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

    def test_public_mgmt_ip_note(self, mgmt_interface_analyzer):
        mgmt_interface = build_skeleton(
            ManagementInterfaceSettings,
            management_ip_address="8.8.8.8",
            permitted_ip_addresses=["1.1.1.1"],
        )
        check = mgmt_interface_analyzer._check_permitted_ip_addresses(
            mgmt_interface, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeNote)


@pytest.mark.parametrize(
    "telnet_disabled,http_disabled,check_passed",
    [
        (True, True, True),
        (False, False, False),
        (True, False, False),
        (False, True, False),
    ],
)
def test_check_disabled_services(
    mgmt_interface_analyzer, telnet_disabled, http_disabled, check_passed
):
    mgmt_interface = build_skeleton(
        ManagementInterfaceSettings,
        telnet_disabled=telnet_disabled,
        http_disabled=http_disabled,
    )
    check = mgmt_interface_analyzer._check_disabled_services(
        mgmt_interface, device_setup=MagicMock()
    )
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed is check_passed
