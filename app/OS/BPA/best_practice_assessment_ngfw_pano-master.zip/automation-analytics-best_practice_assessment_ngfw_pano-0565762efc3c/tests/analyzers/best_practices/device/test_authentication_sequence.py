# -*- coding: utf-8 -*-
import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.device.authentication_sequence import (
    AuthenticationSequenceAnalyzer,
)
from bpa.models.device.authentication_sequence import AuthenticationSequenceModel


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.ngfw = True

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def make_auth_sequence(model_manager):
    """Helper factory for creating AuthenticationSequenceModel instances.

    https://docs.pytest.org/en/latest/fixture.html#factories-as-fixtures
    """

    defaults = {
        "name": "dummy",
        "auth_profiles": [],
        "template_name": None,
        "location": "vsys1",
        "model_manager": weakref.ref(model_manager),
    }

    def _make_auth_sequence(**overrides):
        attrs = {**defaults, **overrides}
        return AuthenticationSequenceModel(**attrs)

    return _make_auth_sequence


@pytest.mark.note
def test_auth_seq_analyzer(model_manager, check_info, make_auth_sequence):
    manager_ref = weakref.ref(model_manager)
    analyzer = AuthenticationSequenceAnalyzer(manager_ref, check_info)
    # Returns a note when sequence has less then two profiles
    assert analyzer._check_auth_profiles(make_auth_sequence()).check_type == "Note"
    assert (
        analyzer._check_auth_profiles(
            make_auth_sequence(auth_profiles=["p1"])
        ).check_type
        == "Note"
    )
    # Two profiles, so no note returned
    assert (
        analyzer._check_auth_profiles(make_auth_sequence(auth_profiles=["p1", "p2"]))
        is None
    )
