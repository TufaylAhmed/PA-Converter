import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.policies.policy_based_forwarding_rule import (
    PolicyBasedForwardingRuleAnalyzer,
)
from bpa.models.policies.policy_based_forwarding_rule import (
    PolicyBasedForwardingRuleModel,
)
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.panorama = False

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = PolicyBasedForwardingRuleAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def policy_based_forwarding(model_manager):
    def _policy_based_forwarding(**overrides):
        return build_model(PolicyBasedForwardingRuleModel, model_manager, **overrides)

    return _policy_based_forwarding


class TestPolicyBasedForwardingRuleAnalyzer:

    """check_monitoring"""

    @pytest.mark.passing
    def test_check_monitoring_passing(self, analyzer, policy_based_forwarding):
        model = policy_based_forwarding(action="forward", monitor_enabled=True)
        assert analyzer._check_monitoring(model).check_passed is True

    @pytest.mark.failing
    def test_check_monitoring_failing(self, analyzer, policy_based_forwarding):
        model = policy_based_forwarding(action="forward", monitor_enabled=False)
        assert analyzer._check_monitoring(model).check_passed is False

    """check_forwarding_profile_ip"""

    @pytest.mark.passing
    def test_check_forwarding_profile_ip_passing(
        self, analyzer, policy_based_forwarding
    ):
        model = policy_based_forwarding(monitor_enabled=True, ip_address="0.0.0.0")
        assert analyzer._check_forwarding_profile_ip(model).check_passed is True

    @pytest.mark.failing
    def test_check_forwarding_profile_ip_failing(
        self, analyzer, policy_based_forwarding
    ):
        model = policy_based_forwarding(monitor_enabled=True, ip_address=None)
        assert analyzer._check_forwarding_profile_ip(model).check_passed is False
