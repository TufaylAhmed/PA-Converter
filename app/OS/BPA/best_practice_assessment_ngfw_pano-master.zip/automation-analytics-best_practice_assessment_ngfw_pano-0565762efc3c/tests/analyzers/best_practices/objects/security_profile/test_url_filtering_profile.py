import json
import os
import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.objects.security_profile.url_filtering_profile import (
    UrlFilteringProfileAnalyzer,
)
from bpa.models.objects.security_profile.url_filtering_profile import (
    UrlFilteringProfileModel,
    CredentialEnforcement,
)
from bpa import data_path
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        url_categories = json.load(
            open(os.path.join(data_path, "url_categories.json")))
        model_manager.tree = MagicMock()
        model_manager.tree.urldb = MagicMock()
        model_manager.tree.urldb = "paloaltonetworks"
        model_manager.tree.url_categories = MagicMock()
        model_manager.tree.url_categories = set(
            url_categories["paloaltonetworks"]
        )  # assumes in config: urldb = 'paloaltonetworks' not brightcloud

    return model_manager_factory(populate_models=populate_models)


@pytest.fixture
def url_filtering_profile(model_manager):
    def _url_filtering_profile(**overrides):
        return build_model(UrlFilteringProfileModel, model_manager, **overrides)

    return _url_filtering_profile


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = UrlFilteringProfileAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def analyzer_7(model_manager, check_info):
    model_manager.tree.version = 7
    manager_ref = weakref.ref(model_manager)
    analyzer = UrlFilteringProfileAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def analyzer_8(model_manager, check_info):
    model_manager.tree.version = 8
    manager_ref = weakref.ref(model_manager)
    analyzer = UrlFilteringProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestUrlFilteringProfileAnalyzer:

    """check_allow_categories"""

    @pytest.mark.passing
    def test_check_allow_categories_passing(self, analyzer, url_filtering_profile):

        assert (
            analyzer._check_allow_categories(
                url_filtering_profile(site_access_categories={"allow": []})
            ).check_passed
            is True
        )

    @pytest.mark.failing
    def test_check_allow_categories_failing(self, analyzer, url_filtering_profile):
        assert (
            analyzer._check_allow_categories(
                url_filtering_profile(site_access_categories={
                                      "allow": ["dating"]})
            ).check_passed
            is False
        )

    """check_block_categories"""

    @pytest.mark.passing
    def test_check_block_categories_passing(self, analyzer, url_filtering_profile):

        assert (
            analyzer._check_block_categories(
                url_filtering_profile(
                    site_access_categories={
                        "block": [
                            "hacking",
                            "malware",
                            "phishing",
                            "proxy-avoidance-and-anonymizers",
                            "command-and-control",
                            "unknown",
                            "dynamic-dns",
                            "extremism",
                            "copyright-infringement",
                            "parked",
                            "grayware",
                            "cryptocurrency"
                        ]
                    }
                )
            ).check_passed
            is True
        )

    @pytest.mark.passing
    def test_check_block_categories_failing2(self, analyzer, url_filtering_profile):

        assert (
            analyzer._check_block_categories(
                url_filtering_profile(
                    site_access_categories={
                        "block": [
                            "malware",
                            "phishing",
                            "proxy-avoidance-and-anonymizers",
                            "command-and-control",
                            "unknown",
                            "dynamic-dns",
                            "extremism",
                            "copyright-infringement",
                            "parked",
                        ]
                    }
                )
            ).check_passed
            is False
        )

    @pytest.mark.failing
    def test_check_block_categories_failing1(self, analyzer, url_filtering_profile):
        assert (
            analyzer._check_block_categories(
                url_filtering_profile(
                    site_access_categories={"block": ["web-advertisements"]}
                )
            ).check_passed
            is False
        )

    """check_url_profile_settings"""

    @pytest.mark.passing
    def test_check_url_profile_settings_passing(self, analyzer, url_filtering_profile):

        assert (
            analyzer._check_url_profile_settings(
                url_filtering_profile(log_container_page_only_enabled=True)
            ).check_passed
            is True
        )

    @pytest.mark.failing
    def test_check_url_profile_settings_failing(self, analyzer, url_filtering_profile):
        assert (
            analyzer._check_url_profile_settings(
                url_filtering_profile(log_container_page_only_enabled=False)
            ).check_passed
            is False
        )

    """_check_credential_phishing_mode"""

    @pytest.mark.excluding
    def test_check_credential_phishing_mode_none(
        self, analyzer_7, url_filtering_profile
    ):
        prof = url_filtering_profile()
        assert analyzer_7._check_credential_phishing_mode(prof) is None

    @pytest.mark.passing
    def test_check_credential_phishing_mode_passing(
        self, analyzer_8, url_filtering_profile
    ):
        prof = url_filtering_profile(
            credential_enforcement=CredentialEnforcement(
                mode="domain-credentials",
                log_severity="low",
                categories={
                    "alert": ["unknown"],
                    "block": ["web-advertisements", "web-hosting"],
                    "continue": ["translation"],
                    "allow": ["dating"],
                },
            )
        )
        assert analyzer_8._check_credential_phishing_mode(
            prof).check_passed is True

    @pytest.mark.note
    def test_check_credential_phishing_mode_note(
        self, analyzer_8, url_filtering_profile
    ):
        prof = url_filtering_profile(
            credential_enforcement=CredentialEnforcement(
                mode="ip-user",
                log_severity="low",
                categories={
                    "alert": ["unknown"],
                    "block": ["web-advertisements", "web-hosting"],
                    "continue": ["translation"],
                    "allow": ["dating"],
                },
            )
        )
        assert (
            analyzer_8._check_credential_phishing_mode(
                prof).check_severity == "Caution"
        )

    @pytest.mark.failing
    def test_check_credential_phishing_mode_failing(
        self, analyzer_8, url_filtering_profile
    ):
        prof = url_filtering_profile(
            credential_enforcement=CredentialEnforcement(
                mode="disabled",
                log_severity="low",
                categories={
                    "alert": ["unknown"],
                    "block": ["web-advertisements", "web-hosting"],
                    "continue": ["translation"],
                    "allow": ["dating"],
                },
            )
        )
        return analyzer_8._check_credential_phishing_mode(prof).check_passed is False

    def test_check_credential_phishing_mode_invalid(
        self, analyzer_8, url_filtering_profile
    ):
        prof = url_filtering_profile(
            credential_enforcement=CredentialEnforcement(
                mode="foobar",
                log_severity="low",
                categories={
                    "alert": ["unknown"],
                    "block": ["web-advertisements", "web-hosting"],
                    "continue": ["translation"],
                    "allow": ["dating"],
                },
            )
        )
        with pytest.raises(ValueError):
            analyzer_8._check_credential_phishing_mode(prof)


class Test_check_credential_theft:
    """
        1) NO Credential Enforcement Categories should be set to "allow"
        2) At least ONE Credential Enforcement Category should be set to "block"
        3) Log Severity should be set to medium, high, or critical
    """

    def test_none_if_less_than_pan_os_8(self, model_manager, check_info):
        model_manager.tree.version = 7.1
        manager_ref = weakref.ref(model_manager)
        analyzer = UrlFilteringProfileAnalyzer(manager_ref, check_info)
        url_prof = MagicMock()
        assert analyzer._check_credential_theft(url_prof) is None

    def test_fail_if_cred_enforcement_categories_allow(
        self, analyzer_8, url_filtering_profile
    ):
        assert (
            analyzer_8._check_credential_theft(
                url_filtering_profile(
                    credential_enforcement=CredentialEnforcement(
                        mode="dummy",
                        log_severity="high",
                        categories={
                            "allow": ["should_cause_failure_here"],
                            "block": ["dummy"],
                        },
                    )
                )
            ).check_passed
            is False
        )

    def test_fail_if_no_cred_enforcement_categories_block(
        self, analyzer_8, url_filtering_profile
    ):
        assert (
            analyzer_8._check_credential_theft(
                url_filtering_profile(
                    credential_enforcement=CredentialEnforcement(
                        mode="dummy",
                        log_severity="high",
                        categories={"allow": [], "block": []},
                    )
                )
            ).check_passed
            is False
        )

    @pytest.mark.parametrize("log_level", ["low", "informational"])
    def test_fail_if_low_info_logging(
        self, analyzer_8, url_filtering_profile, log_level
    ):
        assert (
            analyzer_8._check_credential_theft(
                url_filtering_profile(
                    credential_enforcement=CredentialEnforcement(
                        mode="dummy",
                        log_severity=log_level,
                        categories={"allow": [], "block": ["dummy"]},
                    )
                )
            ).check_passed
            is False
        )

    def test_passing_all_criterial(self, analyzer_8, url_filtering_profile):
        assert (
            analyzer_8._check_credential_theft(
                url_filtering_profile(
                    credential_enforcement=CredentialEnforcement(
                        mode="dummy",
                        log_severity="high",
                        categories={"allow": [], "block": ["dummy"]},
                    )
                )
            ).check_passed
            is True
        )
