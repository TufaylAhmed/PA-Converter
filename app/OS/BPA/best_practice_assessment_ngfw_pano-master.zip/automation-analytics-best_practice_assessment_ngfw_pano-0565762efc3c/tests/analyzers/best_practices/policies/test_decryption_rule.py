import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.policies.decryption_rule import (
    DecryptionRuleAnalyzer,
    DecryptionRulebaseAnalyzer,
)
from bpa.models.constants import NONE
from bpa.models.policies.decryption_rule import DecryptionRuleModel
from bpa.models.policies.security_rule import SecurityRuleModel
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def rule_analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = DecryptionRuleAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def rulebase_analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = DecryptionRulebaseAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def decryption_rule(model_manager):
    def _decryption_rule(**overrides):
        return build_model(DecryptionRuleModel, model_manager, **overrides)

    return _decryption_rule


@pytest.fixture
def security_rule(model_manager):
    def _security_rule(**overrides):
        return build_model(SecurityRuleModel, model_manager, **overrides)

    return _security_rule


class TestDecryptionRuleAnalyzer:
    """check_profile"""

    @pytest.mark.passing
    def test_check_profile_passing(self, rule_analyzer, decryption_rule):
        model = decryption_rule(decryption_profile="Something")
        assert rule_analyzer._check_profile(model).check_passed is True

    @pytest.mark.failing
    def test_check_profile_failing(self, rule_analyzer, decryption_rule):
        model = decryption_rule(decryption_profile=NONE)
        assert rule_analyzer._check_profile(model).check_passed is False


class TestDecryptionRulebaseAnalyzer:
    """check_ssh_proxy_ssh_tunnel"""

    @pytest.mark.passing
    def test_check_ssh_proxy_ssh_tunnel_passing(
        self, rulebase_analyzer, decryption_rule, security_rule
    ):
        decryption_rules = [
            decryption_rule(rule_type="ssh-proxy", name="test-decrypt-1"),
            decryption_rule(rule_type="ssh-proxy", name="test-decrypt-2"),
        ]
        security_rules = [
            security_rule(
                action="allow", applications=["ssh"], rule_name="test-security-1"
            ),
            security_rule(
                action="deny", applications=["ssh-tunnel"], rule_name="test-security-2"
            ),
            security_rule(
                action="drop", applications=["ssh-tunnel"], rule_name="test-security-3"
            ),
        ]
        check, settings = rulebase_analyzer._check_ssh_proxy_ssh_tunnel(
            decryption_rules, security_rules
        )
        assert check.check_passed is True
        assert type(settings) is dict

    @pytest.mark.failing
    def test_check_ssh_proxy_ssh_tunnel_failing(
        self, rulebase_analyzer, decryption_rule, security_rule
    ):
        decryption_rules = [decryption_rule(rule_type="ssh-proxy", location=None)]
        security_rules = []
        check, settings = rulebase_analyzer._check_ssh_proxy_ssh_tunnel(
            decryption_rules, security_rules
        )
        assert check.check_passed is False
        assert type(settings) is dict
