import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeNote
from bpa.analyzers.best_practices.objects.security_profile.dos_protection_profile import (
    DosProtectionProfileAnalyzer,
)
from bpa.models.objects.security_profile.dos_protection_profile import (
    DosProtectionProfileModel,
    FloodProtection,
)
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        model_manager.tree = MagicMock()

    return model_manager_factory(populate_models=populate_models)


@pytest.fixture
def dos_protection_profile(model_manager):
    def _dos_protection_profile(**overrides):
        return build_model(DosProtectionProfileModel, model_manager, **overrides)

    return _dos_protection_profile


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = DosProtectionProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestDosProtectionProfileAnalyzer:
    """check_flood_protection_enabled"""

    @pytest.mark.passing
    def test_check_flood_protection_enabled_passing(
        self, analyzer, dos_protection_profile
    ):
        assert (
            analyzer._check_flood_protection_enabled(
                dos_protection_profile(
                    flood_protections=[
                        FloodProtection(
                            flood_type="SYN",
                            alarm=100,
                            activate=230,
                            maximal=1200,
                            block_duration=331,
                            enabled=True,
                        ),
                        FloodProtection(
                            flood_type="UDP",
                            alarm=10001,
                            activate=10002,
                            maximal=40003,
                            block_duration=304,
                            enabled=True,
                        ),
                    ]
                )
            ).check_passed
            is True
        )

    @pytest.mark.failing
    def test_check_flood_protection_enabled_failing(
        self, analyzer, dos_protection_profile
    ):
        assert (
            analyzer._check_flood_protection_enabled(
                dos_protection_profile(
                    flood_protections=[
                        FloodProtection(
                            flood_type="SYN",
                            alarm=100,
                            activate=230,
                            maximal=1200,
                            block_duration=331,
                            enabled=False,
                        ),
                        FloodProtection(
                            flood_type="UDP",
                            alarm=10001,
                            activate=10002,
                            maximal=40003,
                            block_duration=304,
                            enabled=False,
                        ),
                    ]
                )
            ).check_passed
            is False
        )

    """check_flood_protection_default_values_note"""

    @pytest.mark.passing
    def test_check_flood_protection_default_values_passing(
        self, analyzer, dos_protection_profile
    ):
        assert (
            analyzer._check_flood_protection_default_values_note(
                dos_protection_profile(
                    flood_protections=[
                        FloodProtection(
                            flood_type="SYN",
                            alarm=101,
                            activate=230,
                            maximal=1200,
                            block_duration=300,
                            enabled=False,
                        ),
                        FloodProtection(
                            flood_type="UDP",
                            alarm=10001,
                            activate=10002,
                            maximal=40003,
                            block_duration=300,
                            enabled=False,
                        ),
                    ]
                )
            )
            is None
        )

    @pytest.mark.failing
    def test_check_flood_protection_default_values_failing(
        self, analyzer, dos_protection_profile
    ):
        check_result = analyzer._check_flood_protection_default_values_note(
            dos_protection_profile(
                flood_protections=[
                    FloodProtection(
                        flood_type="SYN",
                        alarm=100,
                        activate=230,
                        maximal=1200,
                        block_duration=331,
                        enabled=False,
                    ),
                    FloodProtection(
                        flood_type="UDP",
                        alarm=10001,
                        activate=10002,
                        maximal=40003,
                        block_duration=304,
                        enabled=False,
                    ),
                ]
            )
        )
        assert isinstance(check_result, BestPracticeNote)
        assert check_result.check_severity == "Caution"
