import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeWarning, BestPracticeNote
from bpa.analyzers.best_practices.network.global_protect_portal import (
    GlobalProtectPortalAnalyzer,
)
from bpa.models.constants import NONE
from bpa.models.network.global_protect import (
    GlobalProtectPortalModel,
    GlobalProtectPortalAgentConfig,
)
from bpa.models.device.ssl_tls_service_profile import SslTlsServiceProfileModel
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model, build_skeleton


@pytest.fixture
def model_manager(model_manager_factory):
    attrs = {
        "name": "test-profile",
        "certificate": "test-cert",
        "min_version": "tls1-2",
        "template_name": None,
    }

    def populate_models(model_manager):
        model_set = model_manager.model_set_lookup[
            "ssl_tls_service_profile"
        ] = ModelSet()
        pass_attrs = {
            **attrs,
            "template_name": "pass",
            "location": "DG-USA",
            "name": "test-1",
        }
        ssl_tls_profile_pass = build_model(
            SslTlsServiceProfileModel, model_manager, **pass_attrs
        )
        fail_attrs = {
            **attrs,
            "template_name": "fail",
            "location": "DG-USA",
            "name": "test-2",
            "min_version": "tls-1-0",
        }
        ssl_tls_profile_fail = build_model(
            SslTlsServiceProfileModel, model_manager, **fail_attrs
        )
        model_set.add(ssl_tls_profile_pass)
        model_set.add(ssl_tls_profile_fail)

    def pouplate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 7.0
        model_manager.tree.panorama = True
        model_manager.tree.ancestors = {"DG-USA": ["DG-USA", "shared"]}

    return model_manager_factory(
        populate_models=populate_models, populate_tree=pouplate_tree
    )


@pytest.fixture
def global_protect_portal(model_manager):
    def _global_protect_portal(**overrides):
        return build_model(GlobalProtectPortalModel, model_manager, **overrides)

    return _global_protect_portal


@pytest.fixture
def global_protect_portal_agent_config():
    def _global_protect_portal_agent_config(**overrides):
        return build_skeleton(GlobalProtectPortalAgentConfig, **overrides)

    return _global_protect_portal_agent_config


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = GlobalProtectPortalAnalyzer(manager_ref, check_info)
    return analyzer


class TestGpPortalAnalyzer:
    """_check_enforce_gp_connection_for_network_access"""

    @pytest.mark.passing
    def test_check_enforce_gp_connection_for_network_access_passing(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert analyzer._check_enforce_gp_connection_for_network_access(
            global_protect_portal(
                agent_configs=[
                    global_protect_portal_agent_config(
                        enforce_gp_connection_for_network_access=False
                    )
                ]
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_enforce_gp_connection_for_network_access_failing(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert not analyzer._check_enforce_gp_connection_for_network_access(
            global_protect_portal(
                agent_configs=[
                    global_protect_portal_agent_config(
                        enforce_gp_connection_for_network_access=True
                    )
                ]
            )
        ).check_passed

    """check_ssl_tls_service_profile_min_version"""

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_ssl_tls_service_profile_min_version_passing(
        self, analyzer, global_protect_portal
    ):
        assert analyzer._check_ssl_tls_service_profile_min_version(
            global_protect_portal(
                template_name="pass",
                location="DG-USA",
                ssl_tls_service_profile="test-1",
            )
        ).check_passed

    @pytest.mark.integration
    @pytest.mark.failing
    def test_check_ssl_tls_service_profile_min_version_failing(
        self, analyzer, global_protect_portal
    ):
        assert not analyzer._check_ssl_tls_service_profile_min_version(
            global_protect_portal(
                template_name="fail",
                location="DG-USA",
                ssl_tls_service_profile="test-2",
            )
        ).check_passed

    """check_certificate_profile"""

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_certificate_profile_passing(self, analyzer, global_protect_portal):
        assert analyzer._check_certificate_profile(
            global_protect_portal(certificate_profile="test-cert")
        ).check_passed

    @pytest.mark.integration
    @pytest.mark.failing
    def test_check_certificate_profile_failing(self, analyzer, global_protect_portal):
        assert not analyzer._check_certificate_profile(
            global_protect_portal(certificate_profile=NONE)
        ).check_passed

    """check_agent_trusted_root_ca"""

    @pytest.mark.note
    def test_check_agent_trusted_root_ca_passing(self, analyzer, global_protect_portal):
        check = analyzer._check_agent_trusted_root_ca(
            global_protect_portal(agent_trusted_root_ca=["trusted-ca"])
        )
        assert check is not None
        assert check.check_type == "Note"
        assert check.check_severity == "Caution"

    @pytest.mark.note
    def test_check_agent_trusted_root_ca_failing(self, analyzer, global_protect_portal):
        check = analyzer._check_agent_trusted_root_ca(
            global_protect_portal(agent_trusted_root_ca=[])
        )
        assert check is not None
        assert check.check_type == "Note"
        assert check.check_severity == "Info"

    """check_save_user_credentials"""

    @pytest.mark.passing
    def test_check_save_user_credentials_passing(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert analyzer._check_save_user_credentials(
            global_protect_portal(
                agent_configs=[
                    global_protect_portal_agent_config(save_user_credentials=None)
                ]
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_save_user_credentials_failing(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert not analyzer._check_save_user_credentials(
            global_protect_portal(
                agent_configs=[
                    global_protect_portal_agent_config(save_user_credentials="Yes")
                ]
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_save_user_credentials_failing_2(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert not analyzer._check_save_user_credentials(
            global_protect_portal(
                agent_configs=[
                    global_protect_portal_agent_config(
                        save_user_credentials="Save Username Only"
                    )
                ]
            )
        ).check_passed

    @pytest.mark.passing
    def test_check_save_user_credentials_passing_2(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert analyzer._check_save_user_credentials(
            global_protect_portal(
                agent_configs=[
                    global_protect_portal_agent_config(save_user_credentials="No")
                ]
            )
        ).check_passed

    @pytest.mark.passing
    def test_check_save_user_credentials_passing_3(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert analyzer._check_save_user_credentials(
            global_protect_portal(
                agent_configs=[
                    global_protect_portal_agent_config(
                        save_user_credentials="Only with User Fingerprint"
                    )
                ]
            )
        ).check_passed

    """check_two_factor_authentication"""

    @pytest.mark.passing
    def test_check_two_factor_authentication_passing(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert analyzer._check_two_factor_authentication(
            global_protect_portal(
                agent_configs=[
                    global_protect_portal_agent_config(
                        two_factor_authentication=["test-2fa"]
                    )
                ]
            )
        ).check_passed

    @pytest.mark.none
    def test_check_two_factor_authentication_note(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        check = analyzer._check_two_factor_authentication(
            global_protect_portal(
                agent_configs=[
                    global_protect_portal_agent_config(two_factor_authentication=[])
                ]
            )
        )
        assert isinstance(check, BestPracticeNote)

    """check_internal_host_detection_enabled"""

    @pytest.mark.passing
    def test_check_internal_host_detection_enabled_passing(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert analyzer._check_internal_host_detection_enabled(
            global_protect_portal(
                agent_configs=[
                    global_protect_portal_agent_config(
                        internal_host_detection_enabled=True
                    )
                ]
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_internal_host_detection_enabled_failing(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert not analyzer._check_internal_host_detection_enabled(
            global_protect_portal(
                agent_configs=[
                    global_protect_portal_agent_config(
                        internal_host_detection_enabled=False
                    )
                ]
            )
        ).check_passed

    """check_using_disable_gp_app"""

    @pytest.mark.passing
    def test_check_using_disable_gp_app_passing(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert analyzer._check_using_disable_gp_app(
            global_protect_portal(
                agent_configs=[global_protect_portal_agent_config(disable_timeout=400)]
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_using_disable_gp_app_failing(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert not analyzer._check_using_disable_gp_app(
            global_protect_portal(
                agent_configs=[global_protect_portal_agent_config(disable_timeout=500)]
            )
        ).check_passed

    """check_collect_hip_data_enabled"""

    @pytest.mark.passing
    def test_check_collect_hip_data_enabled_passing(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert analyzer._check_collect_hip_data_enabled(
            global_protect_portal(
                agent_configs=[
                    global_protect_portal_agent_config(collect_hip_data_enabled=True)
                ]
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_collect_hip_data_enabled_failing(
        self, analyzer, global_protect_portal, global_protect_portal_agent_config
    ):
        assert not analyzer._check_collect_hip_data_enabled(
            global_protect_portal(
                agent_configs=[
                    global_protect_portal_agent_config(collect_hip_data_enabled=False)
                ]
            )
        ).check_passed

    """check_satellite_ocsp_responder"""

    @pytest.mark.passing
    def test_check_satellite_ocsp_responder_passing(
        self, analyzer, global_protect_portal
    ):
        assert analyzer._check_satellite_ocsp_responder(
            global_protect_portal(
                satellites_configured=True, satellite_ocsp_responder="OCSP"
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_satellite_ocsp_responder_failing(
        self, analyzer, global_protect_portal
    ):
        assert not analyzer._check_satellite_ocsp_responder(
            global_protect_portal(
                satellites_configured=True, satellite_ocsp_responder=NONE
            )
        ).check_passed

    """check_satellite_trusted_root_ca"""
    test_data_check_satellite_trusted_root_ca = [
        pytest.param(False, None, None, None, marks=pytest.mark.none),
        pytest.param(True, [], BestPracticeWarning, False, marks=pytest.mark.failing),
        pytest.param(
            True, ["trusted-ca"], BestPracticeWarning, True, marks=pytest.mark.passing
        ),
    ]

    @pytest.mark.parametrize(
        "satellites_configured_value, satellite_trusted_root_ca_value, "
        "expected_check_instance, expected_check_passed_value",
        test_data_check_satellite_trusted_root_ca,
    )
    def test_check_satellite_trusted_root_ca(
        self,
        analyzer,
        global_protect_portal,
        satellites_configured_value,
        satellite_trusted_root_ca_value,
        expected_check_instance,
        expected_check_passed_value,
    ):
        check_result = analyzer._check_satellite_trusted_root_ca(
            global_protect_portal(
                satellites_configured=satellites_configured_value,
                satellite_trusted_root_ca=satellite_trusted_root_ca_value,
            )
        )

        if expected_check_instance is None:
            assert check_result == expected_check_instance
        else:
            assert isinstance(check_result, expected_check_instance)
            assert check_result.check_passed is expected_check_passed_value
