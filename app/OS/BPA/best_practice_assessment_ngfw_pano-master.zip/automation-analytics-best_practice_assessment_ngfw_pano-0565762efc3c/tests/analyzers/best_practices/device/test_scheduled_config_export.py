import pytest
import weakref

from unittest.mock import MagicMock

from bpa.analyzers.best_practices.bp_check import BestPracticeWarning
from bpa.models.device.scheduled_config_export import ScheduledConfigExportModel
from bpa.analyzers.best_practices.device.scheduled_config_export import (
    ScheduledConfigExportAnalyzer,
)
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 7.1

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = ScheduledConfigExportAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def scheduled_config_export(model_manager):

    # https://docs.pytest.org/en/latest/fixture.html#factories-as-fixtures
    models = []

    def _scheduled_config_export(**overrides):
        models.append(
            build_model(ScheduledConfigExportModel, model_manager, **overrides)
        )
        return models

    return _scheduled_config_export


class Test_ScheduledConfigExportAnalyzer:
    test_data_scheduled_config_export = [
        pytest.param(
            {
                "name": "test_1",
                "scheduled_export_start_time": "",
                "host_name": "10.0.0.102",
                "port": "2032",
                "enable": "yes",
            },
            BestPracticeWarning,
            False,
            marks=pytest.mark.failing,
        ),
        pytest.param(
            {
                "name": "test_2",
                "scheduled_export_start_time": "01:30",
                "host_name": "",
                "port": "2032",
                "enable": "yes",
            },
            BestPracticeWarning,
            False,
            marks=pytest.mark.failing,
        ),
        pytest.param(
            {
                "name": "test_3",
                "scheduled_export_start_time": "01:30",
                "host_name": "10.0.0.102",
                "port": "",
                "enable": "yes",
            },
            BestPracticeWarning,
            False,
            marks=pytest.mark.failing,
        ),
        pytest.param(
            {
                "name": "test_4",
                "scheduled_export_start_time": "01:30",
                "host_name": "10.0.0.102",
                "port": "2032",
                "enable": "no",
            },
            BestPracticeWarning,
            False,
            marks=pytest.mark.failing,
        ),
        pytest.param(
            {
                "name": "test_5",
                "scheduled_export_start_time": "01:30",
                "host_name": "10.0.0.102",
                "port": "2032",
                "enable": "yes",
            },
            BestPracticeWarning,
            True,
            marks=pytest.mark.passing,
        ),
    ]

    @pytest.mark.parametrize(
        "model_inputs, expected_output, check_passed", test_data_scheduled_config_export
    )
    def test_check_scheduled_config_export(
        self,
        model_manager,
        analyzer,
        scheduled_config_export,
        model_inputs,
        expected_output,
        check_passed,
    ):
        model_manager.tree.panorama = True
        _scheduled_config_export = scheduled_config_export(**model_inputs)

        check, settings = analyzer._check_scheduled_config_export_configured(
            _scheduled_config_export
        )

        if check.check_passed:
            assert check.check_id == 268
            assert type(check) == expected_output
            assert check.check_passed == check_passed
        else:
            assert check.check_id == 268
            assert type(check) == expected_output
            assert check.check_passed == check_passed

    @pytest.mark.none
    def test_skip_if_panorama(self, model_manager, analyzer):

        model_manager.tree.panorama = False
        config_export_data = []
        check, settings = analyzer._check_scheduled_config_export_configured(
            config_export_data
        )
        assert (check, settings) == (False, {})

    test_no_models_passed = [
        pytest.param(
            BestPracticeWarning,
            False,
            {"scheduled_config_export": "Scheduled Config Export not configured"},
            marks=pytest.mark.failing,
        ),
    ]

    @pytest.mark.parametrize(
        "expected_output,check_passed, data_setting", test_no_models_passed
    )
    def test_if_no_models_passed(
        self, model_manager, analyzer, expected_output, check_passed, data_setting
    ):

        model_manager.tree.panorama = True
        config_export_data = []
        check, settings = analyzer._check_scheduled_config_export_configured(
            config_export_data
        )
        if expected_output is None:
            return check is None
        else:
            assert type(check) == expected_output
            assert check.check_passed == check_passed
            assert settings == data_setting
