# -*- coding: utf-8 -*-
import datetime
import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.objects.security_profile.anti_spyware_profile import (
    AntiSpywareProfileAnalyzer,
)
from bpa.models.license import License, LicenseInfo
from bpa.models.objects.security_profile.anti_spyware_profile import (
    AntiSpywareProfileModel,
    AntiSpywareRule,
    EDLDomain,
    DnsSignature,
)
from bpa.models.objects.security_profile.common import ThreatException

from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def model_manager_9x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 9.0
        model_manager.tree.panorama = False

    def populate_other(model_manager):
        cur_time = datetime.date.today()
        next_time = cur_time + datetime.timedelta(days=2)
        lic = License("DNS Security", "Blah blah", "0123456789", cur_time, next_time)
        lic_info = LicenseInfo()
        lic_info.add(lic)
        model_manager.license_info = lic_info

    return model_manager_factory(
        populate_tree=populate_tree, populate_other=populate_other
    )


@pytest.fixture
def model_instance(model_manager):
    manager_ref = weakref.ref(model_manager)
    prof = AntiSpywareProfileModel(
        location=None,
        model_manager=manager_ref,
        name="Test AS Prof",
        botnet_threat_exceptions=["123"],
        dns_signature_packet_capture="extended-capture",
        passive_dns_monitoring_enabled=True,
        dns_sinkhole=True,
        sinkhole_ipv4="pan-sinkhole-default-ip",
        spyware_threat_exceptions=[
            ThreatException(name="10313", packet_capture="single-packet"),
            ThreatException(name="10522", packet_capture="extended-capture"),
            ThreatException(name="10286", packet_capture="disable"),
        ],
        edl_domains=[EDLDomain(name="default-paloalto-dns", action="sinkhole")],
        rules=[
            AntiSpywareRule(
                name="test-01",
                severity=["any"],
                action="default",
                category="any",
                packet_capture="disable",
            )
        ],
    )
    return prof


@pytest.mark.failing
def test_spyware_threat_exceptions_fail(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    prof = model_instance
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    prof.matches = []
    assert analyzer._check_spyware_threat_exceptions(prof).check_severity == "Caution"


@pytest.mark.passing
def test_spyware_threat_exceptions_pass(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    prof = model_instance
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    prof.spyware_threat_exceptions = []
    assert analyzer._check_spyware_threat_exceptions(prof) is None


@pytest.mark.failing
def test_botnet_threat_exceptions_fail(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    prof = model_instance
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    assert analyzer._check_botnet_threat_exceptions(prof).check_severity == "Caution"


@pytest.mark.passing
def test_botnet_threat_exceptions_pass(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    prof = model_instance
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    prof.botnet_threat_exceptions = []
    assert analyzer._check_botnet_threat_exceptions(prof) is None


@pytest.mark.integration
@pytest.mark.failing
def test_dns_sinkhole_enabled_fail(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    model_manager.tree = MagicMock()
    model_manager.tree.version = 8
    prof = model_instance
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    prof.dns_signature_packet_capture = "disable"
    assert not analyzer._check_dns_sinkhole_enabled(prof).check_passed


@pytest.mark.integration
@pytest.mark.passing
def test_dns_sinkhole_enabled_pass(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    model_manager.tree = MagicMock()
    model_manager.tree.version = 8
    prof = model_instance
    prof.dns_signature_packet_capture = "single-packet"
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    assert analyzer._check_dns_sinkhole_enabled(prof).check_passed


@pytest.mark.integration
@pytest.mark.failing
def test_passive_dns_monitoring_enabled_fail(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    model_manager.tree = MagicMock()
    model_manager.tree.version = 7
    prof = model_instance
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    prof.passive_dns_monitoring_enabled = False
    assert not analyzer._check_passive_dns_monitoring_enabled(prof).check_passed


@pytest.mark.integration
@pytest.mark.passing
def test_passive_dns_monitoring_enabled_pass(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    model_manager.tree = MagicMock()
    model_manager.tree.version = 7
    prof = model_instance
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    assert analyzer._check_passive_dns_monitoring_enabled(prof).check_passed


@pytest.mark.failing
def test_strict_profile_fail_01(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    prof = model_instance
    prof.rules = [
        AntiSpywareRule(
            name="test-01",
            severity=["medium"],
            action="drop",
            category="any",
            packet_capture="disable",
        ),
        AntiSpywareRule(
            name="test-02",
            severity=["high"],
            action="reset-both",
            category="any",
            packet_capture="single-packet",
        ),
        AntiSpywareRule(
            name="test-03",
            severity=["critical"],
            action="reset-client",
            category="any",
            packet_capture="single-packet",
        ),
    ]
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    assert not analyzer._check_strict_profile(prof).check_passed


@pytest.mark.passing
def test_strict_profile_fail_02(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    prof = model_instance
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    prof.rules = [
        AntiSpywareRule(
            name="test-01",
            severity=["high", "critical"],
            action="alert",
            category="any",
            packet_capture="single-packet",
        ),
        AntiSpywareRule(
            name="test-02",
            severity=["informational", "low"],
            action="default",
            category="any",
            packet_capture="disable",
        ),
        AntiSpywareRule(
            name="test-03",
            severity=["medium"],
            action="alert",
            category="any",
            packet_capture="single-packet",
        ),
    ]
    assert not analyzer._check_strict_profile(prof).check_passed


@pytest.mark.passing
def test_strict_profile_pass(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    prof = model_instance
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    prof.rules = [
        AntiSpywareRule(
            name="test-01",
            severity=["medium"],
            action="drop",
            category="any",
            packet_capture="single-packet",
        ),
        AntiSpywareRule(
            name="test-02",
            severity=["high"],
            action="reset-both",
            category="any",
            packet_capture="single-packet",
        ),
        AntiSpywareRule(
            name="test-03",
            severity=["critical"],
            action="reset-client",
            category="any",
            packet_capture="single-packet",
        ),
    ]
    assert analyzer._check_strict_profile(prof).check_passed


@pytest.mark.failing
def test_low_info_profile_fail(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    prof = model_instance
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    prof.rules = [
        AntiSpywareRule(
            name="test-01",
            severity=["informational"],
            action="drop",
            category="backdoor",
            packet_capture="disable",
        ),
        AntiSpywareRule(
            name="test-02",
            severity=["low"],
            action="reset-both",
            category="adware",
            packet_capture="single-packet",
        ),
    ]
    assert not analyzer._check_low_info_profile(prof).check_passed


@pytest.mark.passing
def test_low_info_profile_pass(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    prof = model_instance
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    prof.rules = [
        AntiSpywareRule(
            name="test-01",
            severity=["informational"],
            action="default",
            category="any",
            packet_capture="extended-capture",
        ),
        AntiSpywareRule(
            name="test-02",
            severity=["low"],
            action="reset-both",
            category="any",
            packet_capture="single-packet",
        ),
    ]
    assert analyzer._check_low_info_profile(prof).check_passed


@pytest.mark.note
def test_reset_action_note_none(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    prof = model_instance
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    assert analyzer._check_reset_action(prof) is None


@pytest.mark.failing
def test_reset_action_fail(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    prof = model_instance
    prof.rules = [
        AntiSpywareRule(
            name="test-01",
            severity=["informational"],
            action="reset-client",
            category="any",
            packet_capture="disable",
        )
    ]
    check = analyzer._check_reset_action(prof)
    assert check is not None
    assert check.check_type == "Note"


@pytest.mark.passing
def test_check_dns_cloud_security_passing(model_manager_9x, check_info):
    manager_ref = weakref.ref(model_manager_9x)
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    prof = build_model(
        AntiSpywareProfileModel,
        model_manager_9x,
        dns_signatures=[
            DnsSignature(
                name="default-paloalto-cloud",
                action="sinkhole",
                packet_capture="single-packet",
            )
        ],
    )
    check = analyzer._check_dns_cloud_security(prof)
    assert check is not None
    assert check.check_passed is True


@pytest.mark.failing
def test_check_dns_cloud_security_failing(model_manager_9x, check_info):
    manager_ref = weakref.ref(model_manager_9x)
    analyzer = AntiSpywareProfileAnalyzer(manager_ref, check_info)
    prof = build_model(
        AntiSpywareProfileModel,
        model_manager_9x,
        dns_signatures=[
            DnsSignature(
                name="default-paloalto-cloud",
                action="sinkhole",
                packet_capture="disable",
            )
        ],
    )
    check = analyzer._check_dns_cloud_security(prof)
    assert check is not None
    assert check.check_passed is False
