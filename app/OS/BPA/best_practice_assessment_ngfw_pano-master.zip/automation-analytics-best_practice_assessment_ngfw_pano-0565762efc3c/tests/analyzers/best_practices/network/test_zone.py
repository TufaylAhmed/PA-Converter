from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.network.zone import ZoneAnalyzer
from bpa.models.network.zone import ZoneModel
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def zone(model_manager):
    def _zone(**overrides):
        return build_model(ZoneModel, model_manager, **overrides)

    return _zone


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = ZoneAnalyzer(manager_ref, check_info)
    return analyzer


class TestZoneAnalyzer:

    """check_zone_protection_profile"""

    @pytest.mark.passing
    def test_check_zone_protection_profile_passing(self, analyzer, zone):
        assert analyzer._check_zone_protection_profile(
            zone(zone_protection_profile="zone-protection-profile-test")
        ).check_passed

    @pytest.mark.failing
    def test_check_zone_protection_profile_failing(self, analyzer, zone):
        assert not analyzer._check_zone_protection_profile(
            zone(zone_protection_profile=None)
        ).check_passed

    """check_user_id_acl_include"""

    @pytest.mark.passing
    def test_check_user_id_acl_include_passing(self, analyzer, zone):
        assert analyzer._check_user_id_acl_include(
            zone(user_id_enabled=True, using_acl_include_list=True)
        ).check_passed

    @pytest.mark.failing
    def test_check_user_id_acl_include_failing(self, analyzer, zone):
        assert not analyzer._check_user_id_acl_include(
            zone(user_id_enabled=True, using_acl_include_list=False)
        ).check_passed

    @pytest.mark.none
    def test_check_user_id_acl_include_skip(self, analyzer, zone):
        assert (
            analyzer._check_user_id_acl_include(
                zone(user_id_enabled=False, using_acl_include_list=False)
            )
            is None
        )

    """check_user_id_enabled"""

    @pytest.mark.note
    def test_check_user_id_enabled_note(self, analyzer, zone):
        assert analyzer._check_user_id_enabled(zone(user_id_enabled=True)) is not None

    @pytest.mark.note
    def test_check_user_id_enabled_note_none(self, analyzer, zone):
        assert not analyzer._check_user_id_enabled(zone(user_id_enabled=True)) is None

    """check_packet_buffer_protection_enabled"""

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_packet_buffer_protection_enabled_passing(self, analyzer, zone):
        assert analyzer._check_packet_buffer_protection_enabled(
            zone(packet_buffer_protection_enabled=True)
        ).check_passed

    @pytest.mark.integration
    @pytest.mark.failing
    def test_check_packet_buffer_protection_enabled_failing(self, analyzer, zone):
        assert not analyzer._check_packet_buffer_protection_enabled(
            zone(packet_buffer_protection_enabled=False)
        ).check_passed
