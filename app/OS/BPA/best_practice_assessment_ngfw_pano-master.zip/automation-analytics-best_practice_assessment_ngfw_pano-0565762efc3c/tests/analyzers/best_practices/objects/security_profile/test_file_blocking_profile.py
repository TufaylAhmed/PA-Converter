import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.objects.security_profile.file_blocking_profile import (
    FileBlockingProfileAnalyzer,
)
from bpa.models.objects.security_profile.file_blocking_profile import (
    FileBlockingProfileModel,
    FileBlockingRule,
)
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        model_manager.tree = MagicMock()

    return model_manager_factory(populate_models=populate_models)


@pytest.fixture
def file_blocking_profile(model_manager):
    def _file_blocking_profile(**overrides):
        return build_model(FileBlockingProfileModel, model_manager, **overrides)

    return _file_blocking_profile


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = FileBlockingProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestFileBlockingProfileAnalyzer:

    """check_alert_file_types"""

    @pytest.mark.passing
    def test_check_alert_file_types_passing(self, analyzer, file_blocking_profile):
        rule_list = [
            FileBlockingRule(
                applications=["any"],
                file_types=[
                    "7z",
                    "bat",
                    "chm",
                    "class",
                    "cpl",
                    "dll",
                    "exe",
                    "hlp",
                    "hta",
                    "jar",
                    "ocx",
                    "PE",
                    "pif",
                    "rar",
                    "scr",
                    "torrent",
                    "vbe",
                    "wsf",
                    "tar",
                    "cab",
                    "flash",
                    "msi",
                    "Multi-Level-Encoding",
                ],
                direction="both",
                action="block",
            ),
            FileBlockingRule(
                applications=["any"],
                file_types=["encrypted-rar", "encrypted-zip"],
                direction="both",
                action="continue",
            ),
            FileBlockingRule(
                applications=["any"],
                file_types=["any"],
                action="alert",
                direction="both",
            ),
            FileBlockingRule(
                applications=["any"],
                file_types=["any"],
                action="block",
                direction="both",
            ),
        ]
        assert (
            analyzer._check_alert_file_types(
                file_blocking_profile(rules=rule_list)
            ).check_passed
            is True
        )

    @pytest.mark.failing
    def test_check_alert_file_types_failing(self, analyzer, file_blocking_profile):
        assert (
            analyzer._check_alert_file_types(
                file_blocking_profile(
                    rules=[
                        FileBlockingRule(
                            applications=["any"],
                            file_types=["msi", "Multi-Level-Encoding"],
                            direction="both",
                            action="block",
                        ),
                        FileBlockingRule(
                            applications=["any"],
                            file_types=["encrypted-rar", "encrypted-zip"],
                            direction="both",
                            action="continue",
                        ),
                        FileBlockingRule(
                            applications=["any"],
                            file_types=["any"],
                            action="alert",
                            direction="both",
                        ),
                    ]
                )
            ).check_passed
            is False
        )
