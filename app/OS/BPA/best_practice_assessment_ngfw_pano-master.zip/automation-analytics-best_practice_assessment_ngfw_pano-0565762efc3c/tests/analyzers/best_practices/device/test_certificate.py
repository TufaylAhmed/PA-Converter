import pytest
import weakref

from unittest.mock import MagicMock

from bpa.analyzers.best_practices.bp_check import BestPracticeWarning
from bpa.models.device.certificate import CertificateModel
from bpa.analyzers.best_practices.device.certificate import CertificateAnalyzer
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def certificate(model_manager):
    def _certificate(**overrides):
        return build_model(CertificateModel, model_manager, **overrides)

    return _certificate


class Test_CertificateAnalyzer:

    test_data_heck_forward_decryption_certificate = [
        pytest.param(
            {"forward_trust_certificate": False, "forward_untrust_certificate": False},
            None,
            None,
            marks=pytest.mark.none,
        ),
        pytest.param(
            {"forward_trust_certificate": True, "forward_untrust_certificate": False},
            BestPracticeWarning,
            True,
            marks=pytest.mark.none,
        ),
        pytest.param(
            {"forward_trust_certificate": False, "forward_untrust_certificate": True},
            BestPracticeWarning,
            True,
            marks=pytest.mark.none,
        ),
        pytest.param(
            {"forward_trust_certificate": True, "forward_untrust_certificate": True},
            BestPracticeWarning,
            False,
            marks=pytest.mark.none,
        ),
    ]

    @pytest.mark.parametrize(
        "model_inputs, expected_return_type, expected_checked_passed",
        test_data_heck_forward_decryption_certificate,
    )
    def test_check_forward_decryption_certificate(
        self,
        model_manager,
        certificate,
        check_info,
        model_inputs,
        expected_return_type,
        expected_checked_passed,
    ):

        manager_ref = weakref.ref(model_manager)
        analyzer = CertificateAnalyzer(manager_ref, check_info)
        _certificate = certificate(**model_inputs)
        print(_certificate)
        result = analyzer._check_forward_decryption_certificate(_certificate)
        print(result)
        if expected_return_type is None:
            assert result is None
        else:
            assert result.check_id == 267
            assert type(result) == expected_return_type
            assert result.check_passed == expected_checked_passed
