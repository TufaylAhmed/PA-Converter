from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.device.log_settings import (
    LogSettingsConfigAnalyzer,
    LogSettingsSystemAnalyzer,
)

from bpa.analyzers.best_practices.bp_check import BestPracticeWarning, BestPracticeNote

from bpa.models.device.log_settings import (
    LogSettingsConfigModel,
    LogSettingsSystemModel,
)
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def log_settings_system(model_manager):
    def _log_settings_system(**overrides):
        return build_model(LogSettingsSystemModel, model_manager, **overrides)

    return _log_settings_system


@pytest.fixture
def log_settings_config(model_manager):
    def _log_settings_config(**overrides):
        return build_model(LogSettingsConfigModel, model_manager, **overrides)

    return _log_settings_config


@pytest.fixture
def system_analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = LogSettingsSystemAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def config_analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = LogSettingsConfigAnalyzer(manager_ref, check_info)
    return analyzer


class TestLogSettingSystemAnalyzer:

    """check_log_send_to_info"""

    @pytest.mark.passing
    def test_check_log_send_to_info_passing(self, system_analyzer, log_settings_system):
        assert system_analyzer._check_log_send_to_info(
            log_settings_system(log_send_to_info={"info"})
        ).check_passed

    @pytest.mark.failing
    def test_check_log_send_to_info_failing(self, system_analyzer, log_settings_system):
        assert not system_analyzer._check_log_send_to_info(
            log_settings_system(log_send_to_info={})
        ).check_passed

    """check_log_send_to_medium"""

    @pytest.mark.passing
    def test_check_log_send_to_medium_passing(
        self, system_analyzer, log_settings_system
    ):
        assert system_analyzer._check_log_send_to_medium(
            log_settings_system(log_send_to_medium={"medium"})
        ).check_passed

    @pytest.mark.failing
    def test_check_log_send_to_medium_failing(
        self, system_analyzer, log_settings_system
    ):
        assert not system_analyzer._check_log_send_to_medium(
            log_settings_system(log_send_to_medium={})
        ).check_passed

    """check_log_send_to_high"""

    @pytest.mark.passing
    def test_check_log_send_to_high_passing(self, system_analyzer, log_settings_system):
        assert system_analyzer._check_log_send_to_high(
            log_settings_system(log_send_to_high={"high"})
        ).check_passed

    @pytest.mark.failing
    def test_check_log_send_to_high_failing(self, system_analyzer, log_settings_system):
        assert not system_analyzer._check_log_send_to_high(
            log_settings_system(log_send_to_high={})
        ).check_passed

    """check_log_send_to_critical"""

    @pytest.mark.passing
    def test_check_log_send_to_critical_passing(
        self, system_analyzer, log_settings_system
    ):
        assert system_analyzer._check_log_send_to_critical(
            log_settings_system(log_send_to_critical={"critical", "high"})
        ).check_passed

    @pytest.mark.failing
    def test_check_log_send_to_critical_failing(
        self, system_analyzer, log_settings_system
    ):
        assert not system_analyzer._check_log_send_to_critical(
            log_settings_system(log_send_to_critical={})
        ).check_passed

    """check_log_send_to_critical_content_description_check_log_send_to_critical_content_description"""

    @pytest.mark.passing
    def test_check_log_send_to_critical_content_description_passing(
        self, system_analyzer, log_settings_system
    ):
        assert system_analyzer._check_log_send_to_critical_content_description(
            log_settings_system(
                critical_content_logs={
                    "(severity eq critical) and ( (description contains Content) or (description contains content) )"
                }
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_log_send_to_critical_content_description_failing(
        self, system_analyzer, log_settings_system
    ):
        system = log_settings_system()

        # Explicitly set conditions for BP 181 to fail
        system.log_send_to_critical = {}

        # BP 222 Fail condition
        system.critical_content_logs = {}

        check = system_analyzer._check_log_send_to_critical_content_description(system)
        assert isinstance(check, BestPracticeWarning)
        assert not check.check_passed

    @pytest.mark.note
    def test_check_log_send_to_critical_content_description_note(
        self, system_analyzer, log_settings_system
    ):
        system = log_settings_system()

        # Explicitly set conditions for BP 181 to pass
        system.log_send_to_critical = {"critical", "high"}

        # BP 222 Fail condition
        system.critical_content_logs = {}

        check = system_analyzer._check_log_send_to_critical_content_description(system)
        assert isinstance(check, BestPracticeNote)


class TestLogSettingConfigAnalyzer:

    """check_config_log"""

    @pytest.mark.passing
    def test_check_config_log_passing(self, config_analyzer, log_settings_config):
        assert config_analyzer._check_config_log(
            log_settings_config(
                config_logs_all=["critical", "medium"], config_logs_custom=["high"]
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_config_log_failing(self, config_analyzer, log_settings_config):
        assert not config_analyzer._check_config_log(
            log_settings_config(config_logs_all=[], config_logs_custom=[])
        ).check_passed
