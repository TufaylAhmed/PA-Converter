import weakref

import pytest

from bpa.analyzers.best_practices.network.ipsec_crypto_profile import (
    IpSecCryptoProfileAnalyzer,
)
from bpa.models.network.ipsec_crypto_profile import IpSecCryptoProfileModel
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def ipsec_crypto_profile(model_manager):
    def _ipsec_crypto_profile(**overrides):
        return build_model(IpSecCryptoProfileModel, model_manager, **overrides)

    return _ipsec_crypto_profile


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = IpSecCryptoProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestIpSecCryptoProfileAnalyzer:

    """check_protocol"""

    @pytest.mark.passing
    def test_check_protocol_passing(self, analyzer, ipsec_crypto_profile):
        assert analyzer._check_protocol(
            ipsec_crypto_profile(protocol="esp")
        ).check_passed

    @pytest.mark.failing
    def test_check_protocol_failing(self, analyzer, ipsec_crypto_profile):
        assert not analyzer._check_protocol(
            ipsec_crypto_profile(protocol="x")
        ).check_passed

    """check_encyrption_algorithms"""

    @pytest.mark.passing
    def test_check_encryption_algorithms_passing(self, analyzer, ipsec_crypto_profile):
        assert analyzer._check_encryption_algorithms(
            ipsec_crypto_profile(encryption_algorithms=["aes-128-gcm", "aes-256-gcm"])
        ).check_passed

    @pytest.mark.failing
    def test_check_encryption_algorithms_failing(self, analyzer, ipsec_crypto_profile):
        assert not analyzer._check_encryption_algorithms(
            ipsec_crypto_profile(encryption_algorithms=["abc"])
        ).check_passed

    """check_authentication_algorithms"""

    @pytest.mark.passing
    def test_check_authentication_algorithms_passing(
        self, analyzer, ipsec_crypto_profile
    ):
        assert analyzer._check_authentication_algorithms(
            ipsec_crypto_profile(authentication_algorithms=["sha256"])
        ).check_passed

    @pytest.mark.failing
    def test_check_authentication_algorithms_failing(
        self, analyzer, ipsec_crypto_profile
    ):
        assert not analyzer._check_authentication_algorithms(
            ipsec_crypto_profile(authentication_algorithms=["abc"])
        ).check_passed
