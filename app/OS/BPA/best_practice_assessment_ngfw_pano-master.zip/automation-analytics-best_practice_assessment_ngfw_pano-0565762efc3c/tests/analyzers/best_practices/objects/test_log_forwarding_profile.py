# -*- coding: utf-8 -*-
from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.objects.log_forwarding_profile import (
    LogForwardingProfileAnalyzer,
)
from bpa.models.objects.log_forwarding_profile import (
    LogForwardingProfileModel,
    Setting,
    MatchList,
)
from bpa.analyzers.best_practices.bp_check import BestPracticeWarning, BestPracticeNote


@pytest.fixture
def model_manager_7(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 7

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_manager_8(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_manager_8_1(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_instance_7(model_manager_7):
    manager_ref = weakref.ref(model_manager_7)
    prof = LogForwardingProfileModel(
        location=None,
        model_manager=manager_ref,
        name="LOG_FORWARDING_PROFILE_TEST",
        settings=[
            Setting(
                log_type="traffic",
                log_levels={
                    "any": {
                        "panorama": True,
                        "snmp": False,
                        "email": False,
                        "syslog": False,
                    }
                },
            ),
            Setting(
                log_type="threat",
                log_levels={
                    "informational": {
                        "panorama": True,
                        "snmp": False,
                        "email": False,
                        "syslog": False,
                    },
                    "low": {
                        "panorama": True,
                        "snmp": False,
                        "email": False,
                        "syslog": False,
                    },
                    "medium": {
                        "panorama": True,
                        "snmp": False,
                        "email": False,
                        "syslog": True,
                    },
                    "high": {
                        "panorama": True,
                        "snmp": True,
                        "email": False,
                        "syslog": False,
                    },
                    "critical": {
                        "panorama": False,
                        "snmp": False,
                        "email": False,
                        "syslog": False,
                    },
                },
            ),
            Setting(
                log_type="wildfire",
                log_levels={
                    "benign": {
                        "panorama": False,
                        "snmp": False,
                        "email": False,
                        "syslog": False,
                    },
                    "grayware": {
                        "panorama": True,
                        "snmp": False,
                        "email": False,
                        "syslog": False,
                    },
                    "malicious": {
                        "panorama": True,
                        "snmp": False,
                        "email": False,
                        "syslog": False,
                    },
                },
            ),
        ],
    )
    return prof


@pytest.fixture
def model_instance_8(model_manager_8):
    manager_ref = weakref.ref(model_manager_8)
    prof = LogForwardingProfileModel(
        location=None,
        model_manager=manager_ref,
        name="LF-1",
        settings=[
            MatchList(
                syslog=[],
                snmp=["SNMPT TRAP SEVER"],
                http=[],
                email=[],
                panorama=True,
                log_type="threat",
                filter="(severity eq critical)",
            ),
            MatchList(
                syslog=[],
                snmp=["SNMPT TRAP SEVER"],
                http=[],
                email=[],
                panorama=True,
                log_type="threat",
                filter="(severity eq high)",
            ),
            MatchList(
                syslog=[],
                snmp=["SNMPT TRAP SEVER"],
                http=[],
                email=[],
                panorama=True,
                log_type="threat",
                filter="(severity geq informational) and (severity leq medium)",
            ),
            MatchList(
                syslog=[],
                snmp=["SNMPT TRAP SEVER"],
                http=[],
                email=[],
                panorama=True,
                log_type="threat",
                filter="(severity eq low)",
            ),
            MatchList(
                syslog=[],
                snmp=["SNMPTTRAP SEVER"],
                http=[],
                email=[],
                panorama=False,
                log_type="traffic",
                filter="All Logs",
            ),
            MatchList(
                syslog=[],
                snmp=["SNMPT TRAP SEVER"],
                http=[],
                email=[],
                panorama=True,
                log_type="wildfire",
                filter="All Logs",
            ),
            MatchList(
                syslog=[],
                snmp=[],
                http=[],
                email=[],
                panorama=False,
                log_type="wildfire",
                filter="(verdict eq malicious) or (verdict eq phishing) or (verdict eq grayware)",
            ),
        ],
    )
    return prof


@pytest.fixture
def model_instance_8_1(model_manager_8_1):
    manager_ref = weakref.ref(model_manager_8_1)
    prof = LogForwardingProfileModel(
        location=None,
        model_manager=manager_ref,
        name="LOG_FORWARDING_PROFILE_TEST_PANOS_8.1",
        settings=[],
    )
    return prof


@pytest.mark.integration
@pytest.mark.failing
def test_log_forwarding_analyzer_fail_7x(model_instance_7, model_manager_7, check_info):
    model_manager_7.tree = MagicMock()
    model_manager_7.tree.version = 7
    manager_ref = weakref.ref(model_manager_7)
    prof = model_instance_7
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    prof.settings = []
    assert not analyzer._check_traffic_settings(prof).check_passed
    assert not analyzer._check_threat_settings(prof).check_passed
    assert not analyzer._check_wildfire_settings(prof).check_passed


@pytest.mark.integration
@pytest.mark.passing
def test_log_forwarding_analyzer_pass_7x(model_instance_7, model_manager_7, check_info):
    manager_ref = weakref.ref(model_manager_7)
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    prof = model_instance_7
    assert analyzer._check_traffic_settings(prof).check_passed

    prof.settings[1].log_levels["informational"] = {
        "panorama": True,
        "snmp": False,
        "email": False,
        "syslog": True,
    }
    prof.settings[1].log_levels["low"] = {
        "panorama": True,
        "snmp": False,
        "email": True,
        "syslog": False,
    }
    prof.settings[1].log_levels["critical"] = {
        "panorama": True,
        "snmp": True,
        "email": False,
        "syslog": False,
    }
    assert analyzer._check_threat_settings(prof).check_passed

    prof.settings[2].log_levels["grayware"] = {
        "panorama": True,
        "snmp": True,
        "email": False,
        "syslog": False,
    }
    prof.settings[2].log_levels["malicious"] = {
        "panorama": True,
        "snmp": False,
        "email": True,
        "syslog": False,
    }
    assert analyzer._check_wildfire_settings(prof).check_passed


@pytest.mark.integration
@pytest.mark.failing
def test_log_forwarding_analyzer_fail_8x(model_instance_8, model_manager_8, check_info):
    manager_ref = weakref.ref(model_manager_8)
    prof = model_instance_8
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    prof.settings = []
    assert not analyzer._check_traffic_settings(prof).check_passed
    assert not analyzer._check_threat_settings(prof).check_passed
    assert not analyzer._check_wildfire_settings(prof).check_passed
    assert analyzer._check_url_settings(prof) is None
    assert analyzer._check_auth_settings(prof) is None


@pytest.mark.integration
@pytest.mark.passing
def test_log_forwarding_analyzer_pass_8x(model_instance_8, model_manager_8, check_info):
    manager_ref = weakref.ref(model_manager_8)
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    prof = model_instance_8
    assert analyzer._check_traffic_settings(prof).check_passed
    assert analyzer._check_threat_settings(prof).check_passed
    assert analyzer._check_wildfire_settings(prof).check_passed


@pytest.mark.integration
@pytest.mark.note
def test_check_url_settings_note(model_instance_8_1, model_manager_8_1, check_info):
    manager_ref = weakref.ref(model_manager_8_1)
    prof = model_instance_8_1

    # Note Condition: No Filtering set
    prof.settings = []
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_url_settings(prof)
    assert isinstance(check, BestPracticeNote)

    prof.settings = [
        MatchList(
            syslog=[],
            snmp=[],
            http=[],
            email=[],
            panorama=False,
            log_type="traffic",
            filter="All Logs",
        )
    ]

    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_auth_settings(prof)
    assert isinstance(check, BestPracticeNote)


@pytest.mark.integration
@pytest.mark.failing
def test_check_url_settings_failing(model_instance_8_1, model_manager_8_1, check_info):
    manager_ref = weakref.ref(model_manager_8_1)
    prof = model_instance_8_1

    # Fail Condition: Filtering set but no fwd condition Set
    prof.settings = [
        MatchList(
            syslog=[],
            snmp=[],
            http=[],
            email=[],
            panorama=False,
            log_type="url",
            filter="All Logs",
        )
    ]
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_url_settings(prof)
    assert isinstance(check, BestPracticeWarning)
    assert not check.check_passed


@pytest.mark.integration
@pytest.mark.passing
def test_check_url_settings_passing(model_instance_8_1, model_manager_8_1, check_info):
    manager_ref = weakref.ref(model_manager_8_1)
    prof = model_instance_8_1

    # Testing for one location
    prof.settings = [
        MatchList(
            syslog=[],
            snmp=[],
            http=[],
            email=[],
            panorama=True,
            log_type="url",
            filter="All Logs",
        )
    ]
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_url_settings(prof)
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed

    # Testing for multiple locations
    prof.settings = [
        MatchList(
            syslog=[],
            snmp=["SNMPT TRAP SEVER"],
            http=[],
            email=[],
            panorama=True,
            log_type="url",
            filter="All Logs",
        )
    ]
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_url_settings(prof)
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed


@pytest.mark.integration
@pytest.mark.note
def test_check_auth_settings_note(model_instance_8_1, model_manager_8_1, check_info):
    manager_ref = weakref.ref(model_manager_8_1)
    prof = model_instance_8_1

    # Note Condition: No Filtering set
    prof.settings = []
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_auth_settings(prof)
    assert isinstance(check, BestPracticeNote)

    prof.settings = [
        MatchList(
            syslog=[],
            snmp=[],
            http=[],
            email=[],
            panorama=False,
            log_type="traffic",
            filter="All Logs",
        )
    ]

    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_auth_settings(prof)
    assert isinstance(check, BestPracticeNote)


@pytest.mark.integration
@pytest.mark.failing
def test_check_auth_settings_failing(model_instance_8_1, model_manager_8_1, check_info):
    manager_ref = weakref.ref(model_manager_8_1)
    prof = model_instance_8_1

    # Fail Condition: Filtering set but no fwd condition Set
    prof.settings = [
        MatchList(
            syslog=[],
            snmp=[],
            http=[],
            email=[],
            panorama=False,
            log_type="auth",
            filter="All Logs",
        )
    ]
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_auth_settings(prof)
    assert isinstance(check, BestPracticeWarning)
    assert not check.check_passed


@pytest.mark.integration
@pytest.mark.passing
def test_check_auth_settings_passing(model_instance_8_1, model_manager_8_1, check_info):
    manager_ref = weakref.ref(model_manager_8_1)
    prof = model_instance_8_1

    # Testing for one location
    prof.settings = [
        MatchList(
            syslog=[],
            snmp=[],
            http=[],
            email=[],
            panorama=True,
            log_type="auth",
            filter="All Logs",
        )
    ]
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_auth_settings(prof)
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed

    # Testing for multiple locations
    prof.settings = [
        MatchList(
            syslog=[],
            snmp=["SNMPT TRAP SEVER"],
            http=[],
            email=[],
            panorama=True,
            log_type="auth",
            filter="All Logs",
        )
    ]
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_auth_settings(prof)
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed


@pytest.mark.integration
@pytest.mark.failing
def test_check_threat_settings_failing(
    model_instance_8_1, model_manager_8_1, check_info
):
    manager_ref = weakref.ref(model_manager_8_1)
    prof = model_instance_8_1

    # Fail Condition: No Filtering set
    prof.settings = []
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_threat_settings(prof)
    assert isinstance(check, BestPracticeWarning)
    assert not check.check_passed

    # Fail Condition: Filtering set but no fwd condition Set
    prof.settings = [
        MatchList(
            syslog=[],
            snmp=[],
            http=[],
            email=[],
            panorama=False,
            log_type="threat",
            filter="All Logs",
        )
    ]
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_threat_settings(prof)
    assert isinstance(check, BestPracticeWarning)
    assert not check.check_passed


@pytest.mark.integration
@pytest.mark.passing
def test_check_threat_settings_passing(
    model_instance_8_1, model_manager_8_1, check_info
):
    manager_ref = weakref.ref(model_manager_8_1)
    prof = model_instance_8_1

    prof.settings = [
        MatchList(
            syslog=[],
            snmp=["SNMPT TRAP SEVER"],
            http=[],
            email=[],
            panorama=False,
            log_type="threat",
            filter="All Logs",
        ),
        MatchList(
            syslog=[],
            snmp=["SNMPT TRAP SEVER"],
            http=[],
            email=[],
            panorama=True,
            log_type="threat",
            filter="All Logs",
        ),
    ]
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_threat_settings(prof)
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed


@pytest.mark.integration
@pytest.mark.note
def test_check_threat_settings_note(model_instance_8_1, model_manager_8_1, check_info):
    manager_ref = weakref.ref(model_manager_8_1)
    prof = model_instance_8_1

    prof.settings = [
        MatchList(
            syslog=[],
            snmp=["SNMPT TRAP SEVER"],
            http=[],
            email=[],
            panorama=False,
            log_type="threat",
            filter="All Logs",
        )
    ]
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_threat_settings(prof)
    assert isinstance(check, BestPracticeNote)


@pytest.mark.integration
@pytest.mark.failing
def test_check_wildfire_settings_failing(
    model_instance_8_1, model_manager_8_1, check_info
):
    manager_ref = weakref.ref(model_manager_8_1)
    prof = model_instance_8_1

    # Fail Condition: No Filtering set
    prof.settings = []
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_wildfire_settings(prof)
    assert isinstance(check, BestPracticeWarning)
    assert not check.check_passed

    # Fail Condition: Filtering set but no fwd condition Set
    prof.settings = [
        MatchList(
            syslog=[],
            snmp=[],
            http=[],
            email=[],
            panorama=False,
            log_type="wildfire",
            filter="All Logs",
        )
    ]
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_wildfire_settings(prof)
    assert isinstance(check, BestPracticeWarning)
    assert not check.check_passed


@pytest.mark.integration
@pytest.mark.passing
def test_check_wildfire_settings_passing(
    model_instance_8_1, model_manager_8_1, check_info
):
    manager_ref = weakref.ref(model_manager_8_1)
    prof = model_instance_8_1

    prof.settings = [
        MatchList(
            syslog=[],
            snmp=["SNMPT TRAP SEVER"],
            http=[],
            email=[],
            panorama=False,
            log_type="wildfire",
            filter="All Logs",
        ),
        MatchList(
            syslog=[],
            snmp=["SNMPT TRAP SEVER"],
            http=[],
            email=[],
            panorama=True,
            log_type="wildfire",
            filter="All Logs",
        ),
    ]
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_wildfire_settings(prof)
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed


@pytest.mark.integration
@pytest.mark.note
def test_check_wildfire_settings_note(
    model_instance_8_1, model_manager_8_1, check_info
):
    manager_ref = weakref.ref(model_manager_8_1)
    prof = model_instance_8_1

    prof.settings = [
        MatchList(
            syslog=[],
            snmp=["SNMPT TRAP SEVER"],
            http=[],
            email=[],
            panorama=False,
            log_type="wildfire",
            filter="All Logs",
        )
    ]
    analyzer = LogForwardingProfileAnalyzer(manager_ref, check_info)
    check = analyzer._check_wildfire_settings(prof)
    assert isinstance(check, BestPracticeNote)
