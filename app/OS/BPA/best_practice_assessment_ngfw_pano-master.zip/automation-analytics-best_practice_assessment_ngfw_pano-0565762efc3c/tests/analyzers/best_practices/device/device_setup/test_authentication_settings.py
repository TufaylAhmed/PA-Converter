# -*- coding: utf-8 -*-
from unittest.mock import MagicMock
import builtins as PythonBuiltin
import weakref

import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeWarning, BestPracticeNote
from bpa.analyzers.best_practices.device.device_setup.authentication_settings import (
    AuthenticationSettingsAnalyzer,
)
from bpa.models.device.administrator import AdministratorModel
from bpa.models.device.authentication_profile import AuthenticationProfileModel
from bpa.models.device.authentication_sequence import AuthenticationSequenceModel
from bpa.models.device.device_setup.authentication import AuthenticationSettings
from bpa.models.device.device_setup.device_setup import DeviceSetupModel
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model, build_skeleton


@pytest.fixture
def authentication_analyzer(check_info):
    return AuthenticationSettingsAnalyzer(MagicMock(), check_info)


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        admin_model = build_model(
            AdministratorModel,
            model_manager=model_manager,
            name="admin_prof",
            authentication_profile="auth_prof",
            template_name="dummy_template",
        )
        model_set1 = model_manager.model_set_lookup["administrator"] = ModelSet()
        model_set1.add(admin_model)

        auth_profile = build_model(
            AuthenticationProfileModel,
            model_manager=model_manager,
            name="auth_prof",
            template_name="dummy_template",
            location="shared",
        )
        model_set2 = model_manager.model_set_lookup[
            "authentication_profile"
        ] = ModelSet()
        model_set2.add(auth_profile)

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 9.0

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def model_manager_old(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.0

    return model_manager_factory(populate_tree=populate_tree)


class Test_check_authentication_profile_warn:
    @staticmethod
    @pytest.fixture
    def base_model_manager(model_manager_factory):
        def populate_tree(model_manager):
            model_manager.tree = MagicMock()
            model_manager.tree.version = 9.0
            model_manager.tree.ancestors = {"shared": ["shared"]}

        return model_manager_factory(populate_tree=populate_tree)

    @staticmethod
    @pytest.fixture
    def authentication_analyzer(base_model_manager, check_info):
        manager_ref = weakref.ref(base_model_manager)
        return AuthenticationSettingsAnalyzer(manager_ref, check_info)

    @staticmethod
    @pytest.fixture
    def device_setup_model(base_model_manager):
        return build_model(
            DeviceSetupModel, base_model_manager, template_name="dummy_template"
        )

    @staticmethod
    @pytest.fixture
    def authentication_settings():
        return build_skeleton(
            AuthenticationSettings, authentication_profile="auth_prof"
        )

    @pytest.mark.failing
    def test_check_authentication_profile_warn__external_authentication_failing(
        self,
        authentication_analyzer,
        device_setup_model,
        authentication_settings,
        monkeypatch,
    ):

        # Patching return of functions
        monkeypatch.setattr(
            authentication_analyzer,
            "_has_external_authentication_setup",
            lambda **kwargs: False,
        )

        check = authentication_analyzer._check_authentication_profile_warn(
            auth_settings=authentication_settings, device_setup=device_setup_model
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False

    @pytest.mark.parametrize(
        "admins_configured, result_type, check_passed",
        [
            pytest.param(0, BestPracticeWarning, False, marks=pytest.mark.failing),
            pytest.param(1, BestPracticeWarning, True, marks=pytest.mark.passing),
            pytest.param(2, BestPracticeWarning, True, marks=pytest.mark.passing),
            pytest.param(3, BestPracticeNote, None, marks=pytest.mark.note),
        ],
    )
    def test_check_authentication_profile_warn__local_auth_admins(
        self,
        authentication_analyzer,
        device_setup_model,
        authentication_settings,
        admins_configured,
        result_type,
        check_passed,
        monkeypatch,
    ):

        # Patching/ Mocking return of functions
        def patch_get_models(*args):
            models_mock = MagicMock()
            models_mock.findall = MagicMock(return_value=[])
            return models_mock

        monkeypatch.setattr(
            authentication_analyzer,
            "_has_external_authentication_setup",
            lambda **kwargs: True,
        )
        monkeypatch.setattr(authentication_analyzer, "get_models", patch_get_models)
        monkeypatch.setattr(PythonBuiltin, "sum", lambda _: admins_configured)

        check = authentication_analyzer._check_authentication_profile_warn(
            auth_settings=authentication_settings, device_setup=device_setup_model
        )
        assert type(check) == result_type
        if check_passed is not None:
            assert check.check_passed is check_passed

        if check_passed is not True:
            assert str(admins_configured) in check.check_message

    def test_has_external_authentication_setup__nothing_configured(
        self, authentication_analyzer, device_setup_model, monkeypatch
    ):

        # Patching/ Mocking return of functions
        auth_settings_mock = MagicMock()
        auth_settings_mock.authentication_profile = None

        def patch_get_models(*args):
            models_mock = MagicMock()
            models_mock.findall = MagicMock(return_value=[])
            return models_mock

        monkeypatch.setattr(authentication_analyzer, "get_models", patch_get_models)

        _has_external_authentication = authentication_analyzer._has_external_authentication_setup(
            auth_settings=auth_settings_mock, device_setup=device_setup_model
        )
        assert _has_external_authentication is False

    def test_has_external_authentication_setup__auth_settings_configured(
        self, authentication_analyzer, device_setup_model, monkeypatch
    ):

        # Patching/ Mocking return of functions
        auth_settings_mock = MagicMock()
        auth_settings_mock.authentication_profile = "Test-Profile"

        def patch_get_models(*args):
            models_mock = MagicMock()
            models_mock.findall = MagicMock(return_value=[])
            return models_mock

        monkeypatch.setattr(authentication_analyzer, "get_models", patch_get_models)

        monkeypatch.setattr(
            authentication_analyzer,
            "_validate_external_authentication",
            lambda **kwargs: True,
        )
        _has_external_authentication = authentication_analyzer._has_external_authentication_setup(
            auth_settings=auth_settings_mock, device_setup=device_setup_model
        )
        assert _has_external_authentication is True

        monkeypatch.setattr(
            authentication_analyzer,
            "_validate_external_authentication",
            lambda **kwargs: False,
        )
        _has_external_authentication = authentication_analyzer._has_external_authentication_setup(
            auth_settings=auth_settings_mock, device_setup=device_setup_model
        )
        assert _has_external_authentication is False

    def test_has_external_authentication_setup__administrators_configured(
        self, authentication_analyzer, device_setup_model, monkeypatch
    ):

        # Common Patching and Mocking
        auth_settings_mock = MagicMock()
        auth_settings_mock.authentication_profile = None

        mock_admins = MagicMock()

        # Case 1: None of the administrators have authentication profile set
        mock_admins.findall = MagicMock(
            return_value=[
                MagicMock(authentication_profile=None),
                MagicMock(authentication_profile=None),
            ]
        )

        monkeypatch.setattr(
            authentication_analyzer, "get_models", lambda _: mock_admins
        )
        _has_external_authentication = authentication_analyzer._has_external_authentication_setup(
            auth_settings=auth_settings_mock, device_setup=device_setup_model
        )
        assert _has_external_authentication is False

        # Case 2: The administrators have authentication profile set but not external authentication
        mock_admins.findall = MagicMock(
            return_value=[
                MagicMock(authentication_profile="Prof 1"),
                MagicMock(authentication_profile="Prof 2"),
            ]
        )
        monkeypatch.setattr(
            authentication_analyzer, "get_models", lambda _: mock_admins
        )
        monkeypatch.setattr(
            authentication_analyzer,
            "_validate_external_authentication",
            lambda **kwargs: False,
        )

        _has_external_authentication = authentication_analyzer._has_external_authentication_setup(
            auth_settings=auth_settings_mock, device_setup=device_setup_model
        )
        assert _has_external_authentication is False

        # Case 3: The administrators have authentication profile set with external authentication
        mock_admins.findall = MagicMock(
            return_value=[
                MagicMock(authentication_profile="Prof 1"),
                MagicMock(authentication_profile="Prof 2"),
            ]
        )
        monkeypatch.setattr(
            authentication_analyzer, "get_models", lambda _: mock_admins
        )

        monkeypatch.setattr(
            authentication_analyzer,
            "_validate_external_authentication",
            lambda **kwargs: MagicMock(side_effect=[False, True]),
        )
        _has_external_authentication = authentication_analyzer._has_external_authentication_setup(
            auth_settings=auth_settings_mock, device_setup=device_setup_model
        )
        assert _has_external_authentication is True

    def test_validate_external_authentication(
        self, base_model_manager, authentication_analyzer, device_setup_model
    ):
        _template_name = device_setup_model.template_name

        # Case 1 Neither Authentication Profile nor Authentication Sequence Set
        result = authentication_analyzer._validate_external_authentication(
            profile_or_seq_name="dummy_name", template_name=_template_name
        )
        assert result is False

        # Case 2 Authentication Profile Set but without external method (method="none")
        auth_profile = build_model(
            AuthenticationProfileModel,
            model_manager=base_model_manager,
            name="auth_prof",
            template_name=_template_name,
            location="shared",
            method="none",
        )

        auth_prof_set = base_model_manager.model_set_lookup[
            "authentication_profile"
        ] = ModelSet()
        auth_prof_set.add(auth_profile)

        result = authentication_analyzer._validate_external_authentication(
            profile_or_seq_name="auth_prof", template_name=_template_name
        )
        assert result is False

        # Case 3 Authentication Profile Set but without external method (method="local-database")
        auth_profile = build_model(
            AuthenticationProfileModel,
            model_manager=base_model_manager,
            name="auth_prof",
            template_name=_template_name,
            location="shared",
            method="local-database",
        )

        auth_prof_set = base_model_manager.model_set_lookup[
            "authentication_profile"
        ] = ModelSet()
        auth_prof_set.add(auth_profile)

        result = authentication_analyzer._validate_external_authentication(
            profile_or_seq_name="auth_prof", template_name=_template_name
        )
        assert result is False

        # Case 4 Authentication Profile Set but with external method (method="radius")
        auth_profile = build_model(
            AuthenticationProfileModel,
            model_manager=base_model_manager,
            name="auth_prof",
            template_name=_template_name,
            location="shared",
            method="radius",
        )

        auth_prof_set = base_model_manager.model_set_lookup[
            "authentication_profile"
        ] = ModelSet()
        auth_prof_set.add(auth_profile)

        result = authentication_analyzer._validate_external_authentication(
            profile_or_seq_name="auth_prof", template_name=_template_name
        )
        assert result is True

        # Reset Auth Profiles
        base_model_manager.model_set_lookup["authentication_profile"] = ModelSet()

        # Case 5 Authentication Seq Set but without any Profiles
        _seq_name = "auth_seq_1"
        auth_sequence = build_model(
            AuthenticationSequenceModel,
            model_manager=base_model_manager,
            name=_seq_name,
            template_name=_template_name,
            location="shared",
            # method="radius"
        )

        auth_seq_set = base_model_manager.model_set_lookup[
            "authentication_sequence"
        ] = ModelSet()
        auth_seq_set.add(auth_sequence)

        result = authentication_analyzer._validate_external_authentication(
            profile_or_seq_name=_seq_name, template_name=_template_name
        )
        assert result is False

        # Case 6 Authentication Seq Set with Auth Profiles that don't have external method
        _prof_name = "auth_prof"
        auth_profile = build_model(
            AuthenticationProfileModel,
            model_manager=base_model_manager,
            name=_prof_name,
            template_name=_template_name,
            location="shared",
            method="none",
        )

        auth_prof_set = base_model_manager.model_set_lookup[
            "authentication_profile"
        ] = ModelSet()
        auth_prof_set.add(auth_profile)

        _seq_name = "auth_seq_1"
        auth_sequence = build_model(
            AuthenticationSequenceModel,
            model_manager=base_model_manager,
            name=_seq_name,
            template_name=_template_name,
            auth_profiles=[_prof_name],
            location="shared",
        )

        auth_seq_set = base_model_manager.model_set_lookup[
            "authentication_sequence"
        ] = ModelSet()
        auth_seq_set.add(auth_sequence)

        result = authentication_analyzer._validate_external_authentication(
            profile_or_seq_name=_seq_name, template_name=_template_name
        )
        assert result is False

        # Case 6 Authentication Seq Set with Auth Profiles that have external method as first
        _prof_name_1 = "auth_prof_1"
        auth_profile_1 = build_model(
            AuthenticationProfileModel,
            model_manager=base_model_manager,
            name=_prof_name_1,
            template_name=_template_name,
            location="shared",
            method="radius",
        )
        _prof_name_2 = "auth_prof_2"
        auth_profile_2 = build_model(
            AuthenticationProfileModel,
            model_manager=base_model_manager,
            name=_prof_name_2,
            template_name=_template_name,
            location="shared",
            method="none",
        )

        auth_prof_set = base_model_manager.model_set_lookup[
            "authentication_profile"
        ] = ModelSet()
        auth_prof_set.add(auth_profile_1)
        auth_prof_set.add(auth_profile_2)

        _seq_name = "auth_seq_1"
        auth_sequence = build_model(
            AuthenticationSequenceModel,
            model_manager=base_model_manager,
            name=_seq_name,
            template_name=_template_name,
            auth_profiles=[_prof_name_1, _prof_name_2],
            location="shared",
        )

        auth_seq_set = base_model_manager.model_set_lookup[
            "authentication_sequence"
        ] = ModelSet()
        auth_seq_set.add(auth_sequence)

        result = authentication_analyzer._validate_external_authentication(
            profile_or_seq_name=_seq_name, template_name=_template_name
        )
        assert result is True

        # Case 6 Authentication Seq Set with Auth Profiles that have external method is not first
        _prof_name_1 = "auth_prof_1"
        auth_profile_1 = build_model(
            AuthenticationProfileModel,
            model_manager=base_model_manager,
            name=_prof_name_1,
            template_name=_template_name,
            location="shared",
            method="none",
        )
        _prof_name_2 = "auth_prof_2"
        auth_profile_2 = build_model(
            AuthenticationProfileModel,
            model_manager=base_model_manager,
            name=_prof_name_2,
            template_name=_template_name,
            location="shared",
            method="radius",
        )

        auth_prof_set = base_model_manager.model_set_lookup[
            "authentication_profile"
        ] = ModelSet()
        auth_prof_set.add(auth_profile_1)
        auth_prof_set.add(auth_profile_2)

        _seq_name = "auth_seq_1"
        auth_sequence = build_model(
            AuthenticationSequenceModel,
            model_manager=base_model_manager,
            name=_seq_name,
            template_name=_template_name,
            auth_profiles=[_prof_name_1, _prof_name_2],
            location="shared",
        )

        auth_seq_set = base_model_manager.model_set_lookup[
            "authentication_sequence"
        ] = ModelSet()
        auth_seq_set.add(auth_sequence)

        result = authentication_analyzer._validate_external_authentication(
            profile_or_seq_name=_seq_name, template_name=_template_name
        )
        assert result is False


@pytest.mark.parametrize(
    "cert_profile_name,check_passed,check_message",
    [
        ("cert_prof", True, None),
        (None, False, "It is recommended to configure a certification profile."),
    ],
)
def test_check_certificate_profile_warn(
    authentication_analyzer,
    cert_profile_name,
    check_passed,
    check_message,
    model_manager,
):
    authentication = build_skeleton(
        AuthenticationSettings, certificate_profile=cert_profile_name
    )
    check = authentication_analyzer._check_certificate_profile_warn(
        authentication, device_setup=MagicMock()
    )
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed is check_passed
    assert check.check_message == check_message


@pytest.mark.parametrize(
    "idle_timeout,check_passed", [(0, False), (1, True), (10, True), (11, False)]
)
def test_check_idle_timeout_warn(
    authentication_analyzer, idle_timeout, check_passed, model_manager
):
    authentication = build_skeleton(AuthenticationSettings, idle_timeout=idle_timeout)
    check = authentication_analyzer._check_idle_timeout_warn(
        authentication, device_setup=MagicMock()
    )
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed is check_passed


@pytest.mark.parametrize(
    "failed_attempts,check_passed,check_message",
    [
        (4, True, None),
        (5, True, None),
        (
            6,
            False,
            "It is recommended to configure the number of failed attempts to a value ranging from 1 to 5.",
        ),
        (
            0,
            False,
            "It is recommended to configure the number of failed attempts to a value ranging from 1 to 5.",
        ),
    ],
)
def test_check_failed_attempts_warn(
    authentication_analyzer, failed_attempts, check_passed, check_message, model_manager
):
    authentication = build_skeleton(
        AuthenticationSettings, failed_attempts=failed_attempts
    )
    check = authentication_analyzer._check_failed_attempts_warn(
        authentication, device_setup=MagicMock()
    )
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed is check_passed
    assert check.check_message == check_message


@pytest.mark.parametrize(
    "lockout_time,check_passed",
    [(29, False), (30, True), (31, True), (44, True), (45, True), (46, False)],
)
def test_check_lockout_time_warn(
    authentication_analyzer, lockout_time, check_passed, model_manager
):
    authentication = build_skeleton(AuthenticationSettings, lockout_time=lockout_time)
    check = authentication_analyzer._check_lockout_time_warn(
        authentication, device_setup=MagicMock()
    )
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed is check_passed


@pytest.mark.passing
def test_check_api_key_lifetime_warn_pass(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    authentication_analyzer = AuthenticationSettingsAnalyzer(manager_ref, check_info)
    authentication = build_skeleton(AuthenticationSettings, api_key_lifetime=60)
    check = authentication_analyzer._check_api_key_lifetime_warn(
        authentication, device_setup=MagicMock()
    )
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed


@pytest.mark.failing
def test_check_api_key_lifetime_warn_fail(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    authentication_analyzer = AuthenticationSettingsAnalyzer(manager_ref, check_info)
    authentication = build_skeleton(AuthenticationSettings, api_key_lifetime=0)
    check = authentication_analyzer._check_api_key_lifetime_warn(
        authentication, device_setup=MagicMock()
    )
    assert isinstance(check, BestPracticeWarning)
    assert not check.check_passed


@pytest.mark.none
def test_check_api_key_lifetime_warn_none(model_manager_old, check_info):
    manager_ref = weakref.ref(model_manager_old)
    authentication_analyzer = AuthenticationSettingsAnalyzer(manager_ref, check_info)
    authentication = build_skeleton(AuthenticationSettings, api_key_lifetime=60)
    check = authentication_analyzer._check_api_key_lifetime_warn(
        authentication, device_setup=MagicMock()
    )
    assert check is None
