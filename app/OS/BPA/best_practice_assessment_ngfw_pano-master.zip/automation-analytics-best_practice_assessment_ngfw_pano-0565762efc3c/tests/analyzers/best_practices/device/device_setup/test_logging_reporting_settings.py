# -*- coding: utf-8 -*-
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeNote, BestPracticeWarning
from bpa.analyzers.best_practices.device.device_setup.logging_reporting_settings import (
    LoggingReportingSettingsAnalyzer,
)
from bpa.models.device.device_setup.logging_reporting_settings.logging_reporting import (
    LoggingReportingSettings,
)
from bpa.models.monitor.pdf_reports.pdf_report_group import PdfReportGroupModel
from bpa.models.monitor.pdf_reports.pdf_summary_report import PdfSummaryReportModel
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model, build_skeleton


@pytest.fixture
def logging_reporting_analyzer(check_info):
    return LoggingReportingSettingsAnalyzer(MagicMock(), check_info)


class Test_check_log_on_high_dp_load_enabled:
    def test_log_on_high_dp_load_enabled_is_none(self, logging_reporting_analyzer):
        logging_reporting = build_skeleton(
            LoggingReportingSettings, log_on_high_dp_load_enabled=None
        )
        check = logging_reporting_analyzer._check_log_on_high_dp_load_enabled(
            logging_reporting, device_setup=MagicMock()
        )
        assert check is None

    @pytest.mark.parametrize("test_input,check_passed", [(True, True), (False, False)])
    def test_enabled(self, test_input, check_passed, logging_reporting_analyzer):
        logging_reporting = build_skeleton(
            LoggingReportingSettings, log_on_high_dp_load_enabled=test_input
        )
        check = logging_reporting_analyzer._check_log_on_high_dp_load_enabled(
            logging_reporting, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is check_passed


class Test_check_log_forwarding_from_device:
    def test_log_forwarding_from_device_enabled_is_none(
        self, logging_reporting_analyzer
    ):
        logging_reporting = build_skeleton(
            LoggingReportingSettings, log_forwarding_from_device_enabled=None
        )
        check = logging_reporting_analyzer._check_log_forwarding_from_device(
            logging_reporting, device_setup=MagicMock()
        )
        assert check is None

    @pytest.mark.parametrize("test_input,check_passed", [(True, True), (False, False)])
    def test_enabled(self, test_input, check_passed, logging_reporting_analyzer):
        logging_reporting = build_skeleton(
            LoggingReportingSettings, log_forwarding_from_device_enabled=test_input
        )
        check = logging_reporting_analyzer._check_log_forwarding_from_device(
            logging_reporting, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is check_passed


class Test_check_log_retention_period:
    def test_log_retention_period(self, logging_reporting_analyzer):
        logging_reporting = build_skeleton(LoggingReportingSettings)
        check = logging_reporting_analyzer._check_log_retention_period(
            logging_reporting, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeNote)


class Test_check_predefined_reports:
    def test_predefined_reports_not_none_template(self, logging_reporting_analyzer):
        device_setup = MagicMock()
        device_setup.template_name = "Not-None"
        check_result = logging_reporting_analyzer._check_predefined_reports(
            MagicMock(), device_setup=device_setup
        )
        assert check_result is None

    def test_predefined_reports(self, logging_reporting_analyzer):
        device_setup = MagicMock()

        def get(model_key):
            pdf_report_group = build_model(
                PdfReportGroupModel,
                model_manager=MagicMock(),
                name="Anything",
                reports=["top-rules"],
            )
            pdf_summary_report = build_model(
                PdfSummaryReportModel,
                model_manager=MagicMock(),
                name="Anything",
                reports=["top-sources"],
            )
            group_ms = ModelSet()
            summary_ms = ModelSet()
            group_ms.add(pdf_report_group)
            summary_ms.add(pdf_summary_report)
            manager = {"pdf_report_group": group_ms, "pdf_summary_report": summary_ms}
            return manager[model_key]

        device_setup.objects.get = MagicMock(side_effect=get)
        device_setup.template_name = None
        # risky-users report will be unused by any report causing the note
        device_setup.predefined_reports.enabled_predefined_reports = [
            "top-rules",
            "top-sources",
            "risky-users",
        ]
        check = logging_reporting_analyzer._check_predefined_reports(
            MagicMock(), device_setup=device_setup
        )
        assert isinstance(check, BestPracticeNote)
        # all reports are used causing None response
        device_setup.predefined_reports.enabled_predefined_reports = [
            "top-rules",
            "top-sources",
        ]
        check = logging_reporting_analyzer._check_predefined_reports(
            MagicMock(), device_setup=device_setup
        )
        assert check is None
