import weakref

import pytest

from bpa.analyzers.best_practices.device.server_profiles import (
    LdapServerProfileAnalyzer,
)
from bpa.models.device.server_profiles import LdapServerProfileModel
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def ldap_server_profile(model_manager):
    def _ldap_server_profile(**overrides):
        return build_model(LdapServerProfileModel, model_manager, **overrides)

    return _ldap_server_profile


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = LdapServerProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestLdapServerProfileAnalyzer:

    """check_require_ssl_tls_secured_connection"""

    @pytest.mark.passing
    def test_check_require_ssl_tls_secured_connection_passing(
        self, analyzer, ldap_server_profile
    ):
        assert analyzer._check_require_ssl_tls_secured_connection(
            ldap_server_profile(require_ssl_tls_secured_connection=True)
        ).check_passed

    @pytest.mark.failing
    def test_check_require_ssl_tls_secured_connection_failing(
        self, analyzer, ldap_server_profile
    ):
        assert not analyzer._check_require_ssl_tls_secured_connection(
            ldap_server_profile(require_ssl_tls_secured_connection=False)
        ).check_passed

    """check_verify_server_certificate_for_ssl_sessions"""

    @pytest.mark.passing
    def test_check_verify_server_certificate_for_ssl_sessions_passing(
        self, analyzer, ldap_server_profile
    ):
        assert analyzer._check_verify_server_certificate_for_ssl_sessions(
            ldap_server_profile(verify_server_certificate_for_ssl_sessions=True)
        ).check_passed

    @pytest.mark.failing
    def test_check_verify_server_certificate_for_ssl_sessions_failing(
        self, analyzer, ldap_server_profile
    ):
        assert not analyzer._check_verify_server_certificate_for_ssl_sessions(
            ldap_server_profile(verify_server_certificate_for_ssl_sessions=False)
        ).check_passed

    """check_server_redundancy"""

    @pytest.mark.passing
    def test_check_server_redundancy_passing(self, analyzer, ldap_server_profile):
        assert analyzer._check_server_redundancy(
            ldap_server_profile(server_list=["1.1.1.1", "2.2.2.2"])
        ).check_passed

    @pytest.mark.failing
    def test_check_server_redundancy_failing(self, analyzer, ldap_server_profile):
        assert not analyzer._check_server_redundancy(
            ldap_server_profile(server_list=["1.1.1.1"])
        ).check_passed
