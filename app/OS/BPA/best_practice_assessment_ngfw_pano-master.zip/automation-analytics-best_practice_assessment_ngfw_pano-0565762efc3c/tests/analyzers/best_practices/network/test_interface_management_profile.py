import weakref

import pytest

from bpa.analyzers.best_practices.network.interface_management_profile import (
    InterfaceManagementProfileAnalyzer,
)
from bpa.models.network.interface_management_profile import (
    InterfaceManagementProfileModel,
)
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def interface_management_profile(model_manager):
    def _interface_management_profile(**overrides):
        return build_model(InterfaceManagementProfileModel, model_manager, **overrides)

    return _interface_management_profile


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = InterfaceManagementProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestInterfaceManagementProfileAnalyzer:

    """check_protocols"""

    @pytest.mark.passing
    def test_check_protocols_passing(self, analyzer, interface_management_profile):
        assert analyzer._check_protocols(
            interface_management_profile(protocols={"https", "ssh"})
        ).check_passed

    @pytest.mark.failing
    def test_check_protocols_failing(self, analyzer, interface_management_profile):
        assert not analyzer._check_protocols(
            interface_management_profile(protocols={"http"})
        ).check_passed
        assert not analyzer._check_protocols(
            interface_management_profile(protocols={"telnet"})
        ).check_passed
        assert not analyzer._check_protocols(
            interface_management_profile(protocols={"http", "telnet"})
        ).check_passed
