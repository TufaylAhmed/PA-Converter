from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.device.template import TemplateAnalyzer
from bpa.analyzers.best_practices.bp_check import BestPracticeNote
from bpa.models.device.template import TemplateModel
from bpa.models.device.template_stack import TemplateStackModel
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager_8_1(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_manager_8_0(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.0

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def template_analyzer(model_manager_8_0, check_info):
    manager_ref = weakref.ref(model_manager_8_0)
    analyzer = TemplateAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def template_stack_analyzer(model_manager_8_1, check_info):
    manager_ref = weakref.ref(model_manager_8_1)
    analyzer = TemplateAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def templates_8_0(model_manager_8_0):
    templates = []
    templates.append(
        build_model(
            TemplateModel,
            model_manager_8_0,
            name="TemplateA",
            devices=["00000777711117"],
        )
    )
    templates.append(
        build_model(
            TemplateModel,
            model_manager_8_0,
            name="TemplateB",
            devices=["00000777711117"],
        )
    )
    return templates


@pytest.fixture
def template_stacks_8_1(model_manager_8_1):
    template_stacks = []
    template_stacks.append(
        build_model(
            TemplateStackModel,
            model_manager_8_1,
            name="TemplateStackA",
            devices=["00000777711117"],
        )
    )
    template_stacks.append(
        build_model(
            TemplateStackModel,
            model_manager_8_1,
            name="TemplateStackB",
            devices=["00000777711117"],
        )
    )
    return template_stacks


class TestTemplateAnalyzer:

    """check_template_for_devices"""

    @pytest.mark.passing
    def test_check_template_for_devices_passing(self, template_analyzer, templates_8_0):
        assert template_analyzer._check_template_for_devices(templates_8_0) is None

    @pytest.mark.failing
    def test_check_template_for_devices_failing(
        self, model_manager_8_0, template_analyzer, templates_8_0
    ):
        templates_8_0.append(
            build_model(TemplateModel, model_manager_8_0, name="TemplateC", devices=[])
        )
        check = template_analyzer._check_template_for_devices(templates_8_0)
        assert isinstance(check, BestPracticeNote)


class TestTemplateStackAnalyzer:

    """check_stack_for_devices"""

    @pytest.mark.passing
    def test_check_config_log_passing(
        self, template_stack_analyzer, template_stacks_8_1
    ):
        assert (
            template_stack_analyzer._check_stack_for_devices(template_stacks_8_1)
            is None
        )

    @pytest.mark.failing
    def test_check_config_log_failing(
        self, model_manager_8_1, template_stack_analyzer, template_stacks_8_1
    ):
        template_stacks_8_1.append(
            build_model(
                TemplateStackModel, model_manager_8_1, name="TemplateStackC", devices=[]
            )
        )
        check = template_stack_analyzer._check_stack_for_devices(template_stacks_8_1)
        assert isinstance(check, BestPracticeNote)
