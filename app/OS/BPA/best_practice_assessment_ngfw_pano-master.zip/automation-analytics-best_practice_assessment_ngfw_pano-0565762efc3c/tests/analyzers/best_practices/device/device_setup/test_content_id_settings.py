# -*- coding: utf-8 -*-
from unittest.mock import MagicMock

import pytest
import weakref

from bpa.models.device.device_setup.content_id import ContentIdSettings
from bpa.analyzers.best_practices.device.device_setup.content_id_settings import (
    ContentIDSettingsAnalyzer,
)
from tests.utils.models.base import build_skeleton


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.ngfw = True

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def content_id_settings_analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = ContentIDSettingsAnalyzer(manager_ref, check_info)
    return analyzer


class Test_check_use_x_forwarded_for_enabled_note:
    @pytest.mark.passing
    def test_check_use_x_forwarded_for_enabled_note_passing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(
            ContentIdSettings, use_x_forwarded_for_enabled=True
        )
        check_result = content_id_settings_analyzer._check_use_x_forwarded_for_enabled_note(
            model_instance, MagicMock()
        )
        assert check_result is None

    @pytest.mark.failing
    def test_check_use_x_forwarded_for_enabled_note_failing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(
            ContentIdSettings, use_x_forwarded_for_enabled=False
        )
        check_result = content_id_settings_analyzer._check_use_x_forwarded_for_enabled_note(
            model_instance, MagicMock()
        )
        assert check_result.check_severity == "Caution"
        assert (
            check_result.check_message
            == 'If proxy is configured, it is recommended to enable "Use X-Forwarded-For Header in User ID"'
        )


class Test_check_strip_x_forwarded_for_enabled_note:
    @pytest.mark.passing
    def test_check_strip_x_forwarded_for_enabled_note_passing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(
            ContentIdSettings, strip_x_forwarded_for_enabled=True
        )
        check_result = content_id_settings_analyzer._check_strip_x_forwarded_for_enabled_note(
            model_instance, MagicMock()
        )
        assert check_result is None

    @pytest.mark.failing
    def test_check_strip_x_forwarded_for_enabled_note_failing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(
            ContentIdSettings, strip_x_forwarded_for_enabled=False
        )
        check_result = content_id_settings_analyzer._check_strip_x_forwarded_for_enabled_note(
            model_instance, MagicMock()
        )
        assert check_result.check_severity == "Caution"
        assert (
            check_result.check_message
            == 'If proxy is configured, it is recommended to enable "Strip X-Forwarded-For Header"'
        )


class Test_check_allow_forwarding_decrypted_content_warn:
    @pytest.mark.passing
    def test_check_allow_forwarding_decrypted_content_warn_passing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(
            ContentIdSettings, vsys_not_forwarding_decrypted_content=[]
        )
        check_result = content_id_settings_analyzer._check_allow_forwarding_decrypted_content_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_allow_forwarding_decrypted_content_warn_failing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(
            ContentIdSettings, vsys_not_forwarding_decrypted_content=["something"]
        )
        check_result = content_id_settings_analyzer._check_allow_forwarding_decrypted_content_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert check_result.check_message is not None


class Test_check_exceed_tcp_queue_disabled_warn:
    @pytest.mark.passing
    def test_check_exceed_tcp_queue_disabled_warn_passing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(
            ContentIdSettings, exceed_tcp_queue_enabled=False
        )
        check_result = content_id_settings_analyzer._check_exceed_tcp_queue_disabled_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_exceed_tcp_queue_disabled_warn_failing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(
            ContentIdSettings, exceed_tcp_queue_enabled=True
        )
        check_result = content_id_settings_analyzer._check_exceed_tcp_queue_disabled_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to disable "Forward Segments Exceeding TCP Content Inspection Queue"'
        )


class Test_check_exceed_udp_queue_disabled_warn:
    @pytest.mark.passing
    def test_check_exceed_udp_queue_disabled_warn_passing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(
            ContentIdSettings, exceed_udp_queue_enabled=False
        )
        check_result = content_id_settings_analyzer._check_exceed_udp_queue_disabled_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_exceed_udp_queue_disabled_warn_failing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(
            ContentIdSettings, exceed_udp_queue_enabled=True
        )
        check_result = content_id_settings_analyzer._check_exceed_udp_queue_disabled_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to disable "Forward Datagrams Exceeding UDP Content Inspection Queue"'
        )


class Test_check_exceed_appID_queue_disabled_warn:
    @pytest.mark.passing
    def test_check_exceed_appID_queue_disabled_warn_passing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(
            ContentIdSettings, exceed_appID_queue_enabled=False
        )
        check_result = content_id_settings_analyzer._check_exceed_appID_queue_disabled_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_exceed_appID_queue_disabled_warn_failing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(
            ContentIdSettings, exceed_appID_queue_enabled=True
        )
        check_result = content_id_settings_analyzer._check_exceed_appID_queue_disabled_warn(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to disable "Forward Segments Exceeding TCP APP-ID Inspection Queue"'
        )


class Test_check_http_partial_enabled:
    @pytest.mark.passing
    def test_check_http_partial_enabled_warn_passing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(ContentIdSettings, allow_http_range=False)
        check_result = content_id_settings_analyzer._check_http_partial_enabled(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is True

    @pytest.mark.failing
    def test_check_http_partial_enabled_warn_failing(
        self, content_id_settings_analyzer
    ):
        model_instance = build_skeleton(ContentIdSettings, allow_http_range=True)
        check_result = content_id_settings_analyzer._check_http_partial_enabled(
            model_instance, MagicMock()
        )
        assert check_result.check_passed is False
        assert (
            check_result.check_message
            == 'It is recommended to disable "Allow HTTP partial response"'
        )
