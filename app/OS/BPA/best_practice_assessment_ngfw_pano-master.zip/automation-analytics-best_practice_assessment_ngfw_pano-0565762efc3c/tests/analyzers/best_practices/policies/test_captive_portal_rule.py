import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.policies.captive_portal_rule import (
    CaptivePortalRuleAnalyzer,
)
from bpa.models.device.authentication_profile import AuthenticationProfileModel
from bpa.models.device.authentication_sequence import AuthenticationSequenceModel
from bpa.models.objects.authentication_object import AuthenticationObjectModel
from bpa.models.policies.captive_portal_rule import CaptivePortalRuleModel
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        # Used in profile searches
        profile = build_model(
            AuthenticationProfileModel,
            model_manager,
            location="shared",
            name="test-profile",
            method="kerberos",
        )
        profile_ms = model_manager.model_set_lookup[
            "authentication_profile"
        ] = ModelSet()
        profile_ms.add(profile)

        # Used in sequence searches
        seq_ms = model_manager.model_set_lookup["authentication_sequence"] = ModelSet()
        seq_ms.add(
            build_model(
                AuthenticationSequenceModel,
                model_manager,
                location="shared",
                name="test-sequence",
                auth_profiles=[profile.name],
            )
        )

        # Used in object/profile/sequence searches
        obj_ms = model_manager.model_set_lookup["authentication_object"] = ModelSet()
        obj_ms.add(
            build_model(
                AuthenticationObjectModel,
                model_manager,
                location="shared",
                name="test-object-1",
                authentication_method="web-form",
            )
        )
        obj_ms.add(
            build_model(
                AuthenticationObjectModel,
                model_manager,
                location="shared",
                name="test-object-2",
                authentication_method="bogus",
                authentication_profile="test-profile",
            )
        )
        obj_ms.add(
            build_model(
                AuthenticationObjectModel,
                model_manager,
                location="shared",
                name="test-object-3",
                authentication_method="bogus",
                authentication_profile="test-sequence",
            )
        )
        obj_ms.add(
            build_model(
                AuthenticationObjectModel,
                model_manager,
                location="shared",
                name="test-object-4",
                authentication_method="bogus",
                authentication_profile="test-bogus",
            )
        )

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8
        model_manager.tree.ancestors = {"shared": ["shared"]}

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = CaptivePortalRuleAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def captive_portal_rule(model_manager):
    def _captive_portal_rule(**overrides):
        return build_model(CaptivePortalRuleModel, model_manager, **overrides)

    return _captive_portal_rule


class TestCaptivePortalRuleAnalyzer:

    """check_internal_zones"""

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_internal_zones_passing_with_action(
        self, analyzer, captive_portal_rule
    ):
        model = captive_portal_rule(action="web-form")
        assert analyzer._check_internal_zones(model).check_passed

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_internal_zones_passing_with_auth_obj(
        self, analyzer, captive_portal_rule
    ):
        model = captive_portal_rule(action="test-object-1", location="shared")
        assert analyzer._check_internal_zones(model).check_passed

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_internal_zones_passing_with_auth_prof(
        self, analyzer, captive_portal_rule
    ):
        model = captive_portal_rule(action="test-object-2", location="shared")
        assert analyzer._check_internal_zones(model).check_passed

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_internal_zones_passing_with_auth_seq(
        self, analyzer, captive_portal_rule
    ):
        model = captive_portal_rule(action="test-object-3", location="shared")
        assert analyzer._check_internal_zones(model).check_passed

    @pytest.mark.integration
    @pytest.mark.failing
    def test_check_internal_zones_failing_with_action(
        self, analyzer, captive_portal_rule
    ):
        model = captive_portal_rule(action="browser-challenge")
        assert not analyzer._check_internal_zones(model).check_passed

    @pytest.mark.integration
    @pytest.mark.failing
    def test_check_internal_zones_failing_with_auth_obj(
        self, analyzer, captive_portal_rule
    ):
        model = captive_portal_rule(action="test-object-4", location="shared")
        assert not analyzer._check_internal_zones(model).check_passed

    """check_services"""

    @pytest.mark.passing
    def test_check_services_passing(self, analyzer, captive_portal_rule):
        model = captive_portal_rule(services=["any"])
        assert analyzer._check_services(model).check_passed

    @pytest.mark.failing
    def test_check_services_failing(self, analyzer, captive_portal_rule):
        model = captive_portal_rule(services=["service-http"])
        assert not analyzer._check_services(model).check_passed

    """check_no_action"""

    @pytest.mark.note
    def test_check_no_action_note(self, analyzer, captive_portal_rule):
        model = captive_portal_rule(action="no-captive-portal")
        check = analyzer._check_no_action(model)
        assert check is not None
        assert check.check_type == "Note"

    @pytest.mark.note
    def test_check_no_action_none(self, analyzer, captive_portal_rule):
        model = captive_portal_rule(action="something-else")
        assert analyzer._check_no_action(model) is None

    """check_timeout"""

    @pytest.mark.note
    def test_check_timeout_note(self, analyzer, captive_portal_rule):
        model = captive_portal_rule(timeout=60)
        check = analyzer._check_timeout(model)
        assert check is not None
        assert check.check_type == "Note"

    @pytest.mark.note
    def test_check_timeout_none(self, analyzer, captive_portal_rule):
        model = captive_portal_rule(timeout=500)
        check = analyzer._check_timeout(model)
        assert check is not None
        assert check.check_type == "Note"
