from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.device.server_profiles import (
    SyslogServerProfileAnalyzer,
)
from bpa.models.device.server_profiles import SyslogServerProfileModel
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.panorama = False

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def syslog_server_profile(model_manager):
    def _syslog_server_profile(**overrides):
        return build_model(SyslogServerProfileModel, model_manager, **overrides)

    return _syslog_server_profile


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = SyslogServerProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestSyslogServerProfileAnalyzer:

    """check_transport"""

    @pytest.mark.passing
    def test_check_transport_passing(self, analyzer, syslog_server_profile):
        assert analyzer._check_transport(
            syslog_server_profile(transport="SSL")
        ).check_passed

    @pytest.mark.failing
    def test_check_transport_failing(self, analyzer, syslog_server_profile):
        assert not analyzer._check_transport(
            syslog_server_profile(transport="HTTP")
        ).check_passed
