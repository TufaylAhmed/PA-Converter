# -*- coding: utf-8 -*-
from unittest.mock import MagicMock

import pytest
import weakref

from bpa.analyzers.best_practices.bp_check import BestPracticeWarning
from bpa.analyzers.best_practices.device.device_setup.policy_rulebase import (
    PolicyRulebaseAnalyzer,
)
from bpa.models.device.device_setup.policy_rulebase import PolicyRulebase
from tests.utils.models.base import build_skeleton


@pytest.fixture
def model_manager_8x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.0

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_manager_9x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 9.0

    return model_manager_factory(populate_tree=populate_tree)


class Test_check_rule_hit_count_enabled:
    @pytest.mark.none
    def test_rule_hit_count_enabled_skipped(self, model_manager_8x, check_info):
        manager_ref = weakref.ref(model_manager_8x)
        policy_rulebase_analyzer = PolicyRulebaseAnalyzer(manager_ref, check_info)
        policy_rulebase = build_skeleton(PolicyRulebase, rule_hit_count=True)
        check = policy_rulebase_analyzer._check_rule_hit_count_enabled(
            policy_rulebase, device_setup=MagicMock()
        )
        assert check is None

    @pytest.mark.passing
    def test_rule_hit_count_enabled_passed(self, model_manager_9x, check_info):
        manager_ref = weakref.ref(model_manager_9x)
        policy_rulebase_analyzer = PolicyRulebaseAnalyzer(manager_ref, check_info)
        policy_rulebase = build_skeleton(PolicyRulebase, rule_hit_count=True)
        check = policy_rulebase_analyzer._check_rule_hit_count_enabled(
            policy_rulebase, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)

    @pytest.mark.failing
    def test_rule_hit_count_enabled_failed(self, model_manager_9x, check_info):
        manager_ref = weakref.ref(model_manager_9x)
        policy_rulebase_analyzer = PolicyRulebaseAnalyzer(manager_ref, check_info)
        policy_rulebase = build_skeleton(PolicyRulebase, rule_hit_count=False)
        check = policy_rulebase_analyzer._check_rule_hit_count_enabled(
            policy_rulebase, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
