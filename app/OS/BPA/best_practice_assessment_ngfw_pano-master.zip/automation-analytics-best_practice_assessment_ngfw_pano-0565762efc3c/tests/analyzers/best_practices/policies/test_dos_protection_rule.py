import weakref

import pytest

from bpa.analyzers.best_practices.policies.dos_protection_rule import (
    DosProtectionRuleAnalyzer,
)
from bpa.models.policies.dos_protection_rule import DosProtectionRuleModel
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = DosProtectionRuleAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def dos_protection_rule(model_manager):
    def _dos_protection_rule(**overrides):
        return build_model(DosProtectionRuleModel, model_manager, **overrides)

    return _dos_protection_rule


class TestDosProtectionRuleAnalyzer:
    @pytest.mark.passing
    def test_check_protect_deny_rules_passing(self, analyzer, dos_protection_rule):
        dos_rule = dos_protection_rule(action="protect", name="test-decrypt-1")

        check = analyzer._check_protect_deny_rules(dos_rule)
        assert check.check_passed

    @pytest.mark.failing
    def test_check_nothing_deny_rules_failing(self, analyzer, dos_protection_rule):
        dos_rule = dos_protection_rule(action="deny", name="test-decrypt-1")
        check = analyzer._check_protect_deny_rules(dos_rule)
        assert not check.check_passed
