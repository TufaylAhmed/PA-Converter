import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.policies.app_override import AppOverrideAnalyzer
from bpa.models.default_value import DefaultValue
from bpa.models.objects.application import ApplicationModel
from bpa.models.objects.service import ServiceModel
from bpa.models.policies.app_override import AppOverrideModel
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        svc_ms = model_manager.model_set_lookup["service"] = ModelSet()
        svc_ms.add(build_model(ServiceModel, model_manager, name="Svc-1", timeout=10))

        app_ms = model_manager.model_set_lookup["application"] = ModelSet()

        # Set defaults on good application
        good_app = build_model(ApplicationModel, model_manager, name="App-1")
        for k, v in good_app.__dict__.items():
            if k.endswith("timeout"):
                setattr(good_app, k, DefaultValue(0))
        app_ms.add(good_app)

        # Set custom on bad application
        bad_app = build_model(ApplicationModel, model_manager, name="App-2")
        for k, v in bad_app.__dict__.items():
            if k.endswith("timeout"):
                setattr(bad_app, k, 10)
        app_ms.add(bad_app)

        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1

    return model_manager_factory(populate_models=populate_models)


class TestAppOverrideAnalyzer:
    @pytest.mark.failing
    def test_app_override_failing(self, model_manager, check_info):
        manager_ref = weakref.ref(model_manager)
        analyzer = AppOverrideAnalyzer(manager_ref, check_info)
        override = build_model(AppOverrideModel, model_manager, name="Override-1")
        assert not analyzer._check_app_override(override).check_passed

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_custom_app_passing(self, model_manager, check_info):
        manager_ref = weakref.ref(model_manager)
        analyzer = AppOverrideAnalyzer(manager_ref, check_info)
        override = build_model(
            AppOverrideModel, model_manager, name="Override-1", application="App-1"
        )
        assert analyzer._check_custom_app(override).check_passed

    @pytest.mark.integration
    @pytest.mark.none
    def test_check_custom_app_none(self, model_manager, check_info):
        model_manager.tree.version = 7
        manager_ref = weakref.ref(model_manager)
        analyzer = AppOverrideAnalyzer(manager_ref, check_info)
        override = build_model(
            AppOverrideModel, model_manager, name="Override-1", application="App-1"
        )
        assert analyzer._check_custom_app(override) is None

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_custom_app_failing(self, model_manager, check_info):
        manager_ref = weakref.ref(model_manager)
        analyzer = AppOverrideAnalyzer(manager_ref, check_info)
        override = build_model(
            AppOverrideModel, model_manager, name="Override-2", application="App-2"
        )
        assert not analyzer._check_custom_app(override).check_passed
