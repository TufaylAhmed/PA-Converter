# -*- coding: utf-8 -*-
from unittest.mock import MagicMock

import pytest
import weakref

from bpa.analyzers.best_practices.bp_check import BestPracticeWarning
from bpa.analyzers.best_practices.device.device_setup.services_settings import (
    ServicesSettingsAnalyzer,
)
from bpa.models.device.device_setup.services import ServicesSettings
from tests.utils.models.base import build_skeleton


@pytest.fixture
def model_manager_8x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.0

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_manager_9x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 9.0

    return model_manager_factory(populate_tree=populate_tree)


class Test_check_fqdn_refresh_time:
    @pytest.mark.passing
    def test_check_fqdn_refresh_time_passing(self, model_manager_9x, check_info):
        manager_ref = weakref.ref(model_manager_9x)
        service_settings_analyzer = ServicesSettingsAnalyzer(manager_ref, check_info)
        service_settings = build_skeleton(ServicesSettings, fqdn_refresh_time=30)
        check = service_settings_analyzer._check_fqdn_refresh_time(
            service_settings, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

    @pytest.mark.failing
    def test_check_fqdn_refresh_time_failing(self, model_manager_9x, check_info):
        manager_ref = weakref.ref(model_manager_9x)
        service_settings_analyzer = ServicesSettingsAnalyzer(manager_ref, check_info)
        service_settings = build_skeleton(ServicesSettings, fqdn_refresh_time=35)
        check = service_settings_analyzer._check_fqdn_refresh_time(
            service_settings, device_setup=MagicMock()
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False

    @pytest.mark.none
    def test_check_fqdn_refresh_time_none(self, model_manager_8x, check_info):
        manager_ref = weakref.ref(model_manager_8x)
        service_settings_analyzer = ServicesSettingsAnalyzer(manager_ref, check_info)
        service_settings = build_skeleton(ServicesSettings, fqdn_refresh_time=30)
        check = service_settings_analyzer._check_fqdn_refresh_time(
            service_settings, device_setup=MagicMock()
        )
        assert check is None
