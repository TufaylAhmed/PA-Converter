from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.device.high_availability import (
    HighAvailabilityAnalyzer,
)
from bpa.models.constants import NONE
from bpa.models.device.high_availability import (
    HighAvailabilityModel,
    GeneralConfig,
    LinkPathMonitoringConfig,
    Ha1Config,
    Ha2Config,
    Ha3Config,
    LinkGroup,
    PathGroup,
)
from tests.utils.models.base import build_model, build_skeleton


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 9
        model_manager.tree.panorama = False

    def populate_other(model_manager):
        model_manager.system_info = {}
        for category in HighAvailabilityAnalyzer.content_categories:
            model_manager.system_info[f"ha-local-{category}"] = "1111-1111"
            model_manager.system_info[f"ha-peer-{category}"] = "0000-0000"

    return model_manager_factory(
        populate_tree=populate_tree, populate_other=populate_other
    )


@pytest.fixture
def high_availability(model_manager):
    def _high_availability(**overrides):
        return build_model(HighAvailabilityModel, model_manager, **overrides)

    return _high_availability


@pytest.fixture
def general_config(model_manager):
    def _general_config(**overrides):
        return build_skeleton(GeneralConfig, **overrides)

    return _general_config


@pytest.fixture
def link_path_monitoring(model_manager):
    def _link_path_monitoring(**overrides):
        return build_skeleton(LinkPathMonitoringConfig, **overrides)

    return _link_path_monitoring


@pytest.fixture
def ha1_config(model_manager):
    def _ha1_config(**overrides):
        return build_skeleton(Ha1Config, **overrides)

    return _ha1_config


@pytest.fixture
def ha2_config(model_manager):
    def _ha2_config(**overrides):
        return build_skeleton(Ha2Config, **overrides)

    return _ha2_config


@pytest.fixture
def ha3_config(model_manager):
    def _ha3_config(**overrides):
        return build_skeleton(Ha3Config, **overrides)

    return _ha3_config


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = HighAvailabilityAnalyzer(manager_ref, check_info)
    return analyzer


class TestUserIdAnalyzer:

    """check_config_sync"""

    @pytest.mark.passing
    def test_check_config_sync_passing(
        self, analyzer, high_availability, general_config
    ):
        assert analyzer._check_config_sync(
            high_availability(
                ha_enabled=True, general_config=general_config(config_sync_enabled=True)
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_config_sync_failing(
        self, analyzer, high_availability, general_config
    ):
        assert not analyzer._check_config_sync(
            high_availability(
                ha_enabled=True,
                general_config=general_config(config_sync_enabled=False),
            )
        ).check_passed

    """check_peer_ip_backup"""

    @pytest.mark.passing
    def test_check_peer_ip_backup_passing(
        self, analyzer, high_availability, general_config
    ):
        assert analyzer._check_peer_ip_backup(
            high_availability(
                ha_enabled=True, general_config=general_config(peer_ip_backup="1.1.1.1")
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_peer_ip_backup_failing(
        self, analyzer, high_availability, general_config
    ):
        assert not analyzer._check_peer_ip_backup(
            high_availability(
                ha_enabled=True, general_config=general_config(peer_ip_backup=NONE)
            )
        ).check_passed

    """check_passive_link_state"""

    @pytest.mark.passing
    def test_check_passive_link_state_passing(
        self, analyzer, high_availability, general_config
    ):
        assert analyzer._check_passive_link_state(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    mode="active-passive", passive_link_state="auto"
                ),
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_passive_link_state_failing(
        self, analyzer, high_availability, general_config
    ):
        assert not analyzer._check_passive_link_state(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    mode="active-passive", passive_link_state="not-auto"
                ),
            )
        ).check_passed

    """check_preemptive_enabled_note"""

    @pytest.mark.note
    def test_check_preemptive_enabled_note_enabled(
        self, analyzer, high_availability, general_config
    ):
        assert (
            analyzer._check_preemptive_enabled_note(
                high_availability(
                    ha_enabled=True,
                    general_config=general_config(preemptive_enabled=True),
                )
            ).check_message
            == "Enabling Preemptive is good if we want the primary device to resume as active. "
            "If we want minimal failover events or want to do root cause analysis for failover "
            "events, Preemptive should be disabled."
        )

    @pytest.mark.note
    def test_check_preemptive_enabled_note_disabled(
        self, analyzer, high_availability, general_config
    ):
        assert (
            analyzer._check_preemptive_enabled_note(
                high_availability(
                    ha_enabled=True,
                    general_config=general_config(preemptive_enabled=False),
                )
            ).check_message
            == "Disabling Preemptive is good in environments that need minimal failover events "
            "or want to do root cause analysis for failover event. If we want the primary device "
            "to resume as active, Preemptive should be enabled."
        )

    """check_heartbeat_backup_enabled"""

    @pytest.mark.passing
    def test_check_heartbeat_backup_enabled_passing(
        self, analyzer, high_availability, general_config, ha1_config
    ):
        assert analyzer._check_heartbeat_backup_enabled(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    heartbeat_backup_enabled=True,
                    ha1_config=ha1_config(backup_port="test"),
                ),
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_heartbeat_backup_enabled_failing(
        self, analyzer, high_availability, general_config, ha1_config
    ):
        assert not analyzer._check_heartbeat_backup_enabled(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    heartbeat_backup_enabled=False,
                    ha1_config=ha1_config(backup_port="test"),
                ),
            )
        ).check_passed

    """check_timers"""

    @pytest.mark.passing
    def test_check_timers_passing(self, analyzer, high_availability, general_config):
        assert analyzer._check_timers(
            high_availability(
                ha_enabled=True, general_config=general_config(timers="recommended")
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_timers_failing(self, analyzer, high_availability, general_config):
        assert not analyzer._check_timers(
            high_availability(
                ha_enabled=True, general_config=general_config(timers=NONE)
            )
        ).check_passed

    """check_ha1_encryption_enabled"""

    @pytest.mark.passing
    def test_check_ha1_encryption_enabled_passing(
        self, analyzer, high_availability, general_config, ha1_config
    ):
        assert analyzer._check_ha1_encryption_enabled(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    ha1_config=ha1_config(encryption_enabled=True)
                ),
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_ha1_encryption_enabled_failing(
        self, analyzer, high_availability, general_config, ha1_config
    ):
        assert not analyzer._check_ha1_encryption_enabled(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    ha1_config=ha1_config(encryption_enabled=False)
                ),
            )
        ).check_passed

    """check_ha2_session_sync_enabled"""

    @pytest.mark.passing
    def test_check_ha2_session_sync_enabled_passing(
        self, analyzer, high_availability, general_config, ha2_config
    ):
        assert analyzer._check_ha2_session_sync_enabled(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    ha2_config=ha2_config(session_sync_enabled=True)
                ),
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_ha2_session_sync_enabled_failing(
        self, analyzer, high_availability, general_config, ha2_config
    ):
        assert not analyzer._check_ha2_session_sync_enabled(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    ha2_config=ha2_config(session_sync_enabled=False)
                ),
            )
        ).check_passed

    """check_ha2_keep_alive_enabled"""

    @pytest.mark.passing
    def test_check_ha2_keep_alive_enabled_passing(
        self, analyzer, high_availability, general_config, ha2_config
    ):
        assert analyzer._check_ha2_keep_alive_enabled(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    ha2_config=ha2_config(keep_alive_enabled=True)
                ),
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_ha2_keep_alive_enabled_failing(
        self, analyzer, high_availability, general_config, ha2_config
    ):
        assert not analyzer._check_ha2_keep_alive_enabled(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    ha2_config=ha2_config(keep_alive_enabled=False)
                ),
            )
        ).check_passed

    """check_ha2_action"""

    @pytest.mark.passing
    def test_check_ha2_action_passing(
        self, analyzer, high_availability, general_config, ha2_config
    ):
        assert analyzer._check_ha2_action(
            high_availability(
                ha_enabled=True,
                general_config=general_config(ha2_config=ha2_config(action="log-only")),
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_ha2_action_failing(
        self, analyzer, high_availability, general_config, ha2_config
    ):
        assert not analyzer._check_ha2_action(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    ha2_config=ha2_config(action="not-log-only")
                ),
            )
        ).check_passed

    """check_ha3_interface"""

    @pytest.mark.passing
    def test_check_ha3_interface_passing(
        self, analyzer, high_availability, general_config, ha3_config
    ):
        assert analyzer._check_ha3_interface(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    mode="active-active", ha3_config=ha3_config(interface="1.1.1.1")
                ),
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_ha3_interface_failing(
        self, analyzer, high_availability, general_config, ha3_config
    ):
        assert not analyzer._check_ha3_interface(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    mode="active-active", ha3_config=ha3_config(interface=NONE)
                ),
            )
        ).check_passed

    """check_ha3_session_owner_selection"""

    @pytest.mark.passing
    def test_check_ha3_session_owner_selection_passing(
        self, analyzer, high_availability, general_config, ha3_config
    ):
        assert analyzer._check_ha3_session_owner_selection(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    mode="active-active",
                    ha3_config=ha3_config(session_owner_selection="first-packet"),
                ),
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_ha3_session_owner_selection_failing(
        self, analyzer, high_availability, general_config, ha3_config
    ):
        assert not analyzer._check_ha3_session_owner_selection(
            high_availability(
                ha_enabled=True,
                general_config=general_config(
                    mode="active-active",
                    ha3_config=ha3_config(session_owner_selection="primary-device"),
                ),
            )
        ).check_passed

    """check_link_path_monitoring"""

    @pytest.mark.passing
    def test_check_link_path_monitoring_passing(
        self, analyzer, high_availability, link_path_monitoring
    ):
        assert analyzer._check_link_path_monitoring(
            high_availability(
                ha_enabled=True,
                link_path_monitoring_config=link_path_monitoring(
                    path_monitoring_enabled=True, link_monitoring_enabled=False
                ),
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_link_path_monitoring_failing(
        self, analyzer, high_availability, link_path_monitoring
    ):
        assert not analyzer._check_link_path_monitoring(
            high_availability(
                ha_enabled=True,
                link_path_monitoring_config=link_path_monitoring(
                    path_monitoring_enabled=False, link_monitoring_enabled=False
                ),
            )
        ).check_passed

    """check_link_monitoring_groups"""

    @pytest.mark.passing
    def test_check_link_monitoring_groups_passing(
        self, analyzer, high_availability, link_path_monitoring
    ):
        assert analyzer._check_link_monitoring_groups(
            high_availability(
                ha_enabled=True,
                link_path_monitoring_config=link_path_monitoring(
                    link_monitoring_enabled=True,
                    link_monitoring_groups=[
                        LinkGroup(name="a"),
                        LinkGroup(name="b"),
                        LinkGroup(name="c"),
                    ],
                ),
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_link_monitoring_groups_failing(
        self, analyzer, high_availability, link_path_monitoring
    ):
        assert not analyzer._check_link_monitoring_groups(
            high_availability(
                ha_enabled=True,
                link_path_monitoring_config=link_path_monitoring(
                    link_monitoring_enabled=True, link_monitoring_groups=[]
                ),
            )
        ).check_passed

    """check_path_monitoring_groups"""

    @pytest.mark.passing
    def test_check_path_monitoring_groups_passing(
        self, analyzer, high_availability, link_path_monitoring
    ):
        assert analyzer._check_path_monitoring_groups(
            high_availability(
                ha_enabled=True,
                link_path_monitoring_config=link_path_monitoring(
                    path_monitoring_enabled=True,
                    path_monitoring_groups=[
                        PathGroup(name="a", group_destination_ip="1.2.3.4"),
                        PathGroup(name="b", group_destination_ip="1.2.3.5"),
                        PathGroup(name="c", group_destination_ip="1.2.3.6"),
                    ],
                ),
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_path_monitoring_groups_failing(
        self, analyzer, high_availability, link_path_monitoring
    ):
        assert not analyzer._check_path_monitoring_groups(
            high_availability(
                ha_enabled=True,
                link_path_monitoring_config=link_path_monitoring(
                    path_monitoring_enabled=True, path_monitoring_groups=[]
                ),
            )
        ).check_passed

    """check_pair_content_version"""

    @pytest.mark.note
    def test_check_pair_content_version_note(
        self, analyzer, high_availability, link_path_monitoring
    ):
        result = analyzer._check_pair_content_version(high_availability)
        assert result.check_severity == "Info"

    @pytest.mark.none
    def test_check_pair_content_version_none(
        self, analyzer, high_availability, link_path_monitoring
    ):
        analyzer.objects.tree.panorama = True
        result = analyzer._check_pair_content_version(high_availability)
        assert result is None
