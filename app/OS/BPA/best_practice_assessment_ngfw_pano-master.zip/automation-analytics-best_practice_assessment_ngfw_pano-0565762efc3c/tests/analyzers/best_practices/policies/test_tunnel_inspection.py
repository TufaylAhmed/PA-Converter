import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.policies.tunnel_inspection import (
    TunnelInspectionAnalyzer,
)
from bpa.models.policies.tunnel_inspection import TunnelInspectionModel
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager_8x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_manager_9x(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 9.0

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def analyzer_8x(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = TunnelInspectionAnalyzer(manager_ref, check_info)
    return analyzer


@pytest.fixture
def tunnel_inspection(model_manager):
    def _tunnel_inspection(**overrides):
        return build_model(TunnelInspectionModel, model_manager, **overrides)

    return _tunnel_inspection


class TestTunnelInspectionRulebaseAnalyzer:
    @pytest.mark.passing
    def test_security_options_enabled_passing(self, model_manager_9x, check_info):
        manager_ref = weakref.ref(model_manager_9x)
        analyzer = TunnelInspectionAnalyzer(manager_ref, check_info)
        model = build_model(
            TunnelInspectionModel,
            model_manager_9x,
            tunnel_protocols=["vxlan"],
            tunnel_source_zone="src1",
            tunnel_dest_zone="dst1",
        )
        check = analyzer._check_security_options_enabled(model)
        assert check.check_passed is True

    @pytest.mark.failing
    def test_security_options_enabled_failing(self, model_manager_9x, check_info):
        manager_ref = weakref.ref(model_manager_9x)
        analyzer = TunnelInspectionAnalyzer(manager_ref, check_info)
        model = build_model(
            TunnelInspectionModel, model_manager_9x, tunnel_protocols=["vxlan"]
        )
        check = analyzer._check_security_options_enabled(model)
        assert check.check_passed is False

    @pytest.mark.none
    def test_security_options_enabled_skip_protocol(self, model_manager_9x, check_info):
        manager_ref = weakref.ref(model_manager_9x)
        analyzer = TunnelInspectionAnalyzer(manager_ref, check_info)
        model = build_model(
            TunnelInspectionModel, model_manager_9x, tunnel_protocols=["gre"]
        )
        assert analyzer._check_security_options_enabled(model) is None

    @pytest.mark.none
    def test_security_options_enabled_none(self, model_manager_8x, check_info):
        manager_ref = weakref.ref(model_manager_8x)
        analyzer = TunnelInspectionAnalyzer(manager_ref, check_info)
        model = build_model(TunnelInspectionModel, model_manager_8x)
        assert analyzer._check_security_options_enabled(model) is None
