# -*- coding: utf-8 -*-
from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.objects.security_profile.antivirus_profile import (
    AntivirusProfileAnalyzer,
)
from bpa.models.objects.security_profile.antivirus_profile import AntivirusProfileModel
from bpa.models.model_sets.security_rule import SecurityRuleModelSet
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        avp_ms = model_manager.model_set_lookup["antivirus_profile"] = ModelSet()
        avp_ms.add(
            build_model(
                AntivirusProfileModel,
                model_manager,
                name="Prof-DG-USA-1",
                location="DG-USA",
            )
        )
        # NOTE: No security rules defined here
        model_manager.model_set_lookup["security_rule"] = SecurityRuleModelSet()

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 7.0
        model_manager.tree.ancestors = {
            "shared": ["shared"],
            "DG-USA": ["DG-USA", "shared"],
            "DG-Texas": ["DG-Texas", "DG-USA", "shared"],
            "DG-Plano": ["DG-Plano", "DG-Texas", "DG-USA", "shared"],
        }
        model_manager.tree.descendants = {
            "shared": {"shared", "DG-USA", "DG-Texas", "DG-Plano"},
            "DG-USA": {"DG-USA", "DG-Texas", "DG-Plano"},
            "DG-Texas": {"DG-Texas", "DG-Plano"},
            "DG-Plano": {"DG-Plano"},
        }

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def antivirus_profile(model_manager):
    def _antivirus_profile(**overrides):
        return build_model(AntivirusProfileModel, model_manager, **overrides)

    return _antivirus_profile


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = AntivirusProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestSecurityProfileAnalyzerEmpty:
    @pytest.mark.integration
    def test_get_results_empty(self, analyzer):
        results = analyzer.get_results()
        assert results is not None
        assert len(results) == 1
        assert results[0].configuration["rules_using_profile"] == 0
        assert results[0].configuration["rules_using_profile_pct"] == "N/A"
