# -*- coding: utf-8 -*-
import weakref

import pytest

from bpa.analyzers.best_practices.device.admin_role import AdminRoleAnalyzer
from bpa.models.device.admin_role import AdminRoleModel


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def make_admin_role(model_manager):
    """Helper factory for creating AuthenticationSequenceModel instances.

    https://docs.pytest.org/en/latest/fixture.html#factories-as-fixtures
    """

    defaults = {
        "name": "dummy",
        "template_name": None,
        "model_manager": weakref.ref(model_manager),
    }

    def _make_admin_role(**overrides):
        attrs = {**defaults, **overrides}
        return AdminRoleModel(**attrs)

    return _make_admin_role


@pytest.mark.note
def test_admin_roles_exist(model_manager, make_admin_role, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = AdminRoleAnalyzer(manager_ref, check_info)
    print("Test")
    assert analyzer._check_custom_admin_roles([make_admin_role()]) is None


@pytest.mark.note
def test_admin_roles_missing(model_manager, make_admin_role, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = AdminRoleAnalyzer(manager_ref, check_info)
    check = analyzer._check_custom_admin_roles([])
    assert check is not None
    assert check.check_type == "Note"
