# -*- coding: utf-8 -*-
from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeWarning
from bpa.analyzers.best_practices.device.device_setup.general_settings import (
    GeneralSettingsAnalyzer,
)
from bpa.models.device.certificate import CertificateModel
from bpa.models.device.device_setup.device_setup import DeviceSetupModel
from bpa.models.device.device_setup.general import GeneralSettings
from bpa.models.device.ssl_tls_service_profile import SslTlsServiceProfileModel
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model, build_skeleton


@pytest.fixture
def make_general_settings():
    """Helper factory for creating AuthenticationSequenceModel instances.

    https://docs.pytest.org/en/latest/fixture.html#factories-as-fixtures
    """

    defaults = {
        "login_banner_enabled": False,
        "auto_acquire_commit_lock_enabled": False,
        "ssl_tls_service_profile": None,
        "hostname": None,
        "cert_expiration_check_enabled": None,
    }

    def _make_general_settings(**overrides):
        attrs = {**defaults, **overrides}
        return GeneralSettings(**attrs)

    return _make_general_settings


@pytest.fixture
def general_analyzer(check_info):
    return GeneralSettingsAnalyzer(MagicMock(), check_info)


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        cert_model = build_model(
            CertificateModel,
            model_manager=model_manager,
            name="cert_prof",
            template_name="dummy_template",
            issuer_hash="hash1",
            subject_hash="hash2",
        )
        cert_model_fail = build_model(
            CertificateModel,
            model_manager=model_manager,
            name="cert_prof",
            template_name="fail_template",
            issuer_hash="hash1",
            subject_hash="hash1",
        )

        model_set1 = model_manager.model_set_lookup["certificate"] = ModelSet()
        model_set1.add(cert_model)
        model_set1.add(cert_model_fail)

        ssl_model = build_model(
            SslTlsServiceProfileModel,
            model_manager=model_manager,
            name="dummy",
            certificate="cert_prof",
            template_name="dummy_template",
            location="test_local",
        )
        ssl_model_fail = build_model(
            SslTlsServiceProfileModel,
            model_manager=model_manager,
            name="dummy",
            certificate="cert_prof",
            template_name="fail_template",
            location="test_local",
        )
        ssl_model_fail2 = build_model(
            SslTlsServiceProfileModel,
            model_manager=model_manager,
            name="dummy",
            certificate="cert_prof",
            template_name="random_template",
            location="test_local",
        )
        model_set2 = model_manager.model_set_lookup[
            "ssl_tls_service_profile"
        ] = ModelSet()
        model_set2.add(ssl_model)
        model_set2.add(ssl_model_fail)
        model_set2.add(ssl_model_fail2)

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.mark.parametrize("test_input,expected", [(False, False), (True, True)])
def test_check_login_banner_enabled(
    general_analyzer, model_manager, test_input, expected
):
    general = MagicMock(login_banner_enabled=test_input)
    device = build_model(
        DeviceSetupModel, model_manager, template_name="dummy_template"
    )
    check = general_analyzer._check_login_banner_enabled(general, device)
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed is expected


@pytest.mark.parametrize("test_input,expected", [(False, False), (True, True)])
def test_check_auto_acquire_commit_lock_enabled(
    general_analyzer, model_manager, test_input, expected
):
    general = MagicMock(auto_acquire_commit_lock_enabled=test_input)
    device = build_model(
        DeviceSetupModel, model_manager, template_name="dummy_template"
    )
    check = general_analyzer._check_auto_acquire_commit_lock_enabled(general, device)
    assert isinstance(check, BestPracticeWarning)
    assert check.check_passed is expected


class Test_check_cert_expiration_check_enabled:
    def test_type(self, general_analyzer, model_manager):
        general = MagicMock(ssl_tls_service_profile=None)
        device = build_model(
            DeviceSetupModel, model_manager, template_name="dummy_template"
        )
        check = general_analyzer._check_cert_expiration_check_enabled(general, device)
        assert isinstance(check, BestPracticeWarning)

    def test_ssl_tls_service_profile_none(self, general_analyzer, model_manager):
        general = MagicMock(ssl_tls_service_profile=None)
        device = build_model(
            DeviceSetupModel, model_manager, template_name="dummy_template"
        )
        check = general_analyzer._check_cert_expiration_check_enabled(general, device)
        assert check.check_passed is False
        assert check.check_message == "The SSL/TLS Service Profile is not configured"

    def test_cert_expiration_disabled(self, general_analyzer, model_manager):
        general = MagicMock(
            ssl_tls_service_profile="dummy", cert_expiration_check_enabled=False
        )
        device = build_model(
            DeviceSetupModel, model_manager, template_name="dummy_template"
        )
        check = general_analyzer._check_cert_expiration_check_enabled(general, device)
        assert check.check_passed is False
        assert (
            check.check_message
            == 'It is recommended to enable "Certification Expiration Check"'
        )

    def test_ssl_tls_service_profile_missing_cert(self, check_info, model_manager):
        general = build_skeleton(
            GeneralSettings,
            ssl_tls_service_profile="dummy",
            cert_expiration_check_enabled=True,
        )
        # mocking the ssl_tls_service_profile object
        manager_ref = weakref.ref(model_manager)
        general_analyzer = GeneralSettingsAnalyzer(manager_ref, check_info)
        device = build_model(
            DeviceSetupModel, model_manager, template_name="random_template"
        )
        check = general_analyzer._check_cert_expiration_check_enabled(general, device)
        assert check.check_passed is False
        assert (
            check.check_message
            == "SSL/TLS Service Profile does not have a certificate configured"
        )

    def test_using_self_signed_cert(self, check_info, model_manager):
        general = build_skeleton(
            GeneralSettings,
            ssl_tls_service_profile="dummy",
            cert_expiration_check_enabled=True,
        )
        # mocking the ssl_tls_service_profile and certificate objects
        manager_ref = weakref.ref(model_manager)
        general_analyzer = GeneralSettingsAnalyzer(manager_ref, check_info)
        device = build_model(
            DeviceSetupModel, model_manager, template_name="fail_template"
        )
        check = general_analyzer._check_cert_expiration_check_enabled(general, device)
        assert check.check_passed is False
        assert (
            check.check_message
            == "SSL/TLS Service Profile is using a self signed certificate"
        )

    def test_passing(self, check_info, model_manager):
        general = build_skeleton(
            GeneralSettings,
            ssl_tls_service_profile="dummy",
            cert_expiration_check_enabled=True,
        )
        manager_ref = weakref.ref(model_manager)
        general_analyzer = GeneralSettingsAnalyzer(manager_ref, check_info)
        device = build_model(
            DeviceSetupModel, model_manager, template_name="dummy_template"
        )
        assert (
            general_analyzer._check_cert_expiration_check_enabled(
                general, device
            ).check_passed
            is True
        )


class Test_check_hostname:
    def test_in_template(self, general_analyzer, model_manager):
        device_setup = build_model(
            DeviceSetupModel, model_manager=model_manager, template_name="temp"
        )
        assert general_analyzer._check_hostname(MagicMock(), device_setup) is None

    @pytest.mark.parametrize(
        "test_input,expected",
        [("localhost", False), (None, False), ("my-host.com", True)],
    )
    def test_localhost(self, general_analyzer, model_manager, test_input, expected):
        device_setup = build_model(
            DeviceSetupModel, model_manager=model_manager, template_name=None
        )
        check = general_analyzer._check_hostname(
            MagicMock(hostname=test_input), device_setup
        )
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is expected
