import pytest
from collections import defaultdict
from unittest.mock import MagicMock

from bpa.analyzers.best_practices.objects.utils import get_percent


@pytest.fixture
def mock_best_practice_result():
    def _mock_best_practice_result(location, name):
        result = MagicMock()
        result.configuration = {"location": location, "name": name}
        return result

    return _mock_best_practice_result


@pytest.fixture
def mock_tree_descendants():
    def _mock_tree_descendants(location):
        _tree = defaultdict(set)
        _tree[location] = set()
        return _tree

    return _mock_tree_descendants


@pytest.fixture
def mock_rule():
    def _mock_rule(action: str, rule_enabled: bool):
        rule = MagicMock()
        rule.action = action
        rule.rule_enabled = rule_enabled
        return rule

    return _mock_rule


class Test_get_percent:
    @staticmethod
    def add_to_rule_ms_map(mapping: defaultdict, location: str, rule):
        mapping[(location,)].append(rule)

    @staticmethod
    def add_to_profiles_with_rules(
        mapping: defaultdict, location: str, name: str, rule
    ):
        mapping[(location, name)].append(rule)

    @pytest.mark.passing
    def test_passing_no_result(self):
        results = []
        rule_ms_map = defaultdict()
        profile_with_rules = defaultdict()
        tree_descendants = defaultdict()

        get_percent_output = get_percent(
            results=results,
            rule_ms_map=rule_ms_map,
            profiles_with_rules=profile_with_rules,
            tree_descendants=tree_descendants,
        )

        assert type(get_percent_output) is list
        assert len(get_percent_output) == 0

    @pytest.mark.passing
    def test_passing_all_profiles_using(
        self, mock_best_practice_result, mock_rule, mock_tree_descendants
    ):

        _location = "LOCATION"
        _name = "NAME"
        _rule_action = "allow"
        _rule_enabled = True

        results = list()
        results.append(mock_best_practice_result(location=_location, name=_name))

        # Create a mocked rule
        mocked_rule = mock_rule(action=_rule_action, rule_enabled=_rule_enabled)

        profile_with_rules = defaultdict(list)
        self.add_to_profiles_with_rules(
            mapping=profile_with_rules, location=_location, name=_name, rule=mocked_rule
        )

        rule_ms_map = defaultdict(list)
        self.add_to_rule_ms_map(
            mapping=rule_ms_map, location=_location, rule=mocked_rule
        )

        tree_descendants = mock_tree_descendants(location=_location)

        get_percent_output = get_percent(
            results=results,
            rule_ms_map=rule_ms_map,
            profiles_with_rules=profile_with_rules,
            tree_descendants=tree_descendants,
        )

        assert type(get_percent_output) is list
        assert len(get_percent_output) == 1
        assert get_percent_output[0].configuration["rules_using_profile"] == 1
        assert get_percent_output[0].configuration["rules_using_profile_pct"] == "100%"

    @pytest.mark.passing
    def test_no_profiles_using_rules(
        self, mock_best_practice_result, mock_rule, mock_tree_descendants
    ):

        _location = "LOCATION"
        _name = "NAME"
        _rule_action = "allow"
        _rule_enabled = True

        results = list()
        results.append(mock_best_practice_result(location=_location, name=_name))

        # Create a mocked rule
        mocked_rule = mock_rule(action=_rule_action, rule_enabled=_rule_enabled)

        profile_with_rules = defaultdict(list)

        rule_ms_map = defaultdict(list)
        self.add_to_rule_ms_map(
            mapping=rule_ms_map, location=_location, rule=mocked_rule
        )

        tree_descendants = mock_tree_descendants(location=_location)

        get_percent_output = get_percent(
            results=results,
            rule_ms_map=rule_ms_map,
            profiles_with_rules=profile_with_rules,
            tree_descendants=tree_descendants,
        )

        assert type(get_percent_output) is list
        assert len(get_percent_output) == 1
        assert get_percent_output[0].configuration["rules_using_profile"] == 0
        assert get_percent_output[0].configuration["rules_using_profile_pct"] == "0%"

    @pytest.mark.passing
    def test_no_rules_that_can_use_profile(
        self, mock_best_practice_result, mock_rule, mock_tree_descendants
    ):

        _location = "LOCATION"
        _name = "NAME"
        _rule_action = "allow"
        _rule_enabled = True

        results = list()
        results.append(mock_best_practice_result(location=_location, name=_name))

        # Create a mocked rule
        mocked_rule = mock_rule(action=_rule_action, rule_enabled=_rule_enabled)

        profile_with_rules = defaultdict(list)
        self.add_to_profiles_with_rules(
            mapping=profile_with_rules, location=_location, name=_name, rule=mocked_rule
        )

        rule_ms_map = defaultdict(list)
        # self.add_to_rule_ms_map(mapping=rule_ms_map, location=_location, rule=mocked_rule)

        tree_descendants = mock_tree_descendants(location=_location)

        get_percent_output = get_percent(
            results=results,
            rule_ms_map=rule_ms_map,
            profiles_with_rules=profile_with_rules,
            tree_descendants=tree_descendants,
        )

        assert type(get_percent_output) is list
        assert len(get_percent_output) == 1
        assert get_percent_output[0].configuration["rules_using_profile"] == 1
        assert get_percent_output[0].configuration["rules_using_profile_pct"] == "N/A"

    filtering_test_data = [
        # Testing for scenarios where Enabled action=Allow
        # Testing rules matching the filtering condition
        ("allow", True, {"action": "allow", "rule_enabled": True}, 1, 1, "100%"),
        # Testing rules are not matching the filtering condition
        ("allow", True, {"action": "allow", "rule_enabled": False}, 1, 0, "N/A"),
        # Testing for scenarios where Enabled and action does not matter
        # Testing rules match the filtering condition
        ("", True, {"rule_enabled": True}, 1, 1, "100%"),
        # Testing rules are not matching the filtering condition
        ("", True, {"rule_enabled": False}, 1, 0, "N/A"),
    ]

    @pytest.mark.parametrize(
        "rule_action,rule_enabled,filters,expected_output_len,expected_rules_using_profile,expected_rules_using_profile_pct",
        filtering_test_data,
    )
    def test_filters(
        self,
        mock_best_practice_result,
        mock_rule,
        mock_tree_descendants,
        rule_action,
        rule_enabled,
        filters,
        expected_output_len,
        expected_rules_using_profile,
        expected_rules_using_profile_pct,
    ):

        _location = "LOCATION"
        _name = "NAME"
        _rule_action = rule_action
        _rule_enabled = rule_enabled

        results = list()
        results.append(mock_best_practice_result(location=_location, name=_name))

        # Create a mocked rule
        mocked_rule = mock_rule(action=_rule_action, rule_enabled=_rule_enabled)

        profile_with_rules = defaultdict(list)
        self.add_to_profiles_with_rules(
            mapping=profile_with_rules, location=_location, name=_name, rule=mocked_rule
        )

        rule_ms_map = defaultdict(list)
        self.add_to_rule_ms_map(
            mapping=rule_ms_map, location=_location, rule=mocked_rule
        )

        tree_descendants = mock_tree_descendants(location=_location)

        get_percent_output = get_percent(
            results=results,
            rule_ms_map=rule_ms_map,
            profiles_with_rules=profile_with_rules,
            tree_descendants=tree_descendants,
            rule_filters=filters,
        )

        assert type(get_percent_output) is list
        assert len(get_percent_output) == expected_output_len
        if expected_output_len > 0:
            assert (
                get_percent_output[0].configuration["rules_using_profile"]
                == expected_rules_using_profile
            )
            assert (
                get_percent_output[0].configuration["rules_using_profile_pct"]
                == expected_rules_using_profile_pct
            )
