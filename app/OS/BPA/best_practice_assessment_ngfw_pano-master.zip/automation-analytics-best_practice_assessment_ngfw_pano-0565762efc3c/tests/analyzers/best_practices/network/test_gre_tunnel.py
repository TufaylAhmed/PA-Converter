import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeWarning
from bpa.analyzers.best_practices.network.gre_tunnel import GreTunnelAnalyzer
from bpa.models.network.gre_tunnel import GreTunnelModel
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager_8x(model_manager_factory):
    def pouplate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1

    return model_manager_factory(populate_tree=pouplate_tree)


@pytest.fixture
def model_manager_9x(model_manager_factory):
    def pouplate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 9.0

    return model_manager_factory(populate_tree=pouplate_tree)


class TestGreTunnelAnalyzer:
    @pytest.mark.passing
    def test_check_gre_tunnel_keep_alive_enabled_passing(
        self, model_manager_9x, check_info
    ):
        manager_ref = weakref.ref(model_manager_9x)
        analyzer = GreTunnelAnalyzer(manager_ref, check_info)
        model = build_model(GreTunnelModel, model_manager_9x, keep_alive_enable=True)
        check = analyzer._check_keep_alive_enabled(model)
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is True

    @pytest.mark.failing
    def test_check_gre_tunnel_keep_alive_enabled_failing(
        self, model_manager_9x, check_info
    ):
        manager_ref = weakref.ref(model_manager_9x)
        analyzer = GreTunnelAnalyzer(manager_ref, check_info)
        model = build_model(GreTunnelModel, model_manager_9x, keep_alive_enable=False)
        check = analyzer._check_keep_alive_enabled(model)
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed is False

    @pytest.mark.none
    def test_check_gre_tunnel_keep_alive_enabled_skipped(
        self, model_manager_8x, check_info
    ):
        manager_ref = weakref.ref(model_manager_8x)
        analyzer = GreTunnelAnalyzer(manager_ref, check_info)
        model = build_model(GreTunnelModel, model_manager_8x)
        assert analyzer._check_keep_alive_enabled(model) is None
