# -*- coding: utf-8 -*-
from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.objects.security_profile.common import (
    SecurityProfileAnalyzer,
)
from bpa.models.objects.security_profile.antivirus_profile import AntivirusProfileModel
from bpa.models.policies.security_rule import SecurityRuleModel
from bpa.models.model_sets.security_rule import SecurityRuleModelSet
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        avp_ms = model_manager.model_set_lookup["antivirus_profile"] = ModelSet()
        avp_ms.add(
            build_model(
                AntivirusProfileModel,
                model_manager,
                name="AV-Prof-DG-USA",
                location="DG-USA",
            )
        )

        security_model1 = build_model(
            SecurityRuleModel,
            model_manager,
            location="DG-USA",
            action="allow",
            rule_name="security_rule_USA",
            profile_antivirus="AV-Prof-DG-USA",
        )

        sr_ms = model_manager.model_set_lookup["security_rule"] = SecurityRuleModelSet()
        sr_ms.add(security_model1)

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.ancestors = {
            "shared": ["shared"],
            "DG-USA": ["DG-USA", "shared"],
            "DG-Texas": ["DG-Texas", "DG-USA", "shared"],
            "DG-Plano": ["DG-Plano", "Texas-DG", "DG-USA", "shared"],
        }

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def antivirus_profile(model_manager):
    def _antivirus_profile(**overrides):
        return build_model(AntivirusProfileModel, model_manager, **overrides)

    return _antivirus_profile


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = SecurityProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestSecurityProfileAnalyzer:

    """check_unused_security_profile"""

    @pytest.mark.integration
    @pytest.mark.note
    def test_unused_security_profile_note(self, analyzer, antivirus_profile):
        check = analyzer._check_unused_security_profile(
            antivirus_profile(name="AV-Prof-DG-Texas", location="DG-Texas")
        )
        assert check.check_severity == "Info"

    @pytest.mark.hack
    @pytest.mark.integration
    @pytest.mark.note
    def test_unused_security_profile_note_none(self, analyzer, antivirus_profile):
        check = analyzer._check_unused_security_profile(
            antivirus_profile(name="AV-Prof-DG-USA", location="DG-USA")
        )
        assert check is None
