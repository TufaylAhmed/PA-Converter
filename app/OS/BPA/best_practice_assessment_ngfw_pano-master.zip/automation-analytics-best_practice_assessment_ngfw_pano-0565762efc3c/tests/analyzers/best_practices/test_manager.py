from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.manager import BestPracticesAnalyzerManager
from bpa.analyzers.best_practices.base_analyzer import BestPracticesAnalyzer
from bpa.analyzers.best_practices.device.administrator import AdministratorAnalyzer


@pytest.mark.core
def test_create():
    model_manager = MagicMock()
    analyzer_manager = BestPracticesAnalyzerManager(model_manager)
    assert analyzer_manager is not None

    # Lookup populated at startup
    assert analyzer_manager.analyzer_lookup is not None
    assert type(analyzer_manager.analyzer_lookup) is dict
    assert len(analyzer_manager.analyzer_lookup) > 0

    # Inspect lookup key
    assert "administrator" in analyzer_manager.analyzer_lookup.keys()
    analyzer = analyzer_manager.analyzer_lookup["administrator"]
    assert issubclass(analyzer, BestPracticesAnalyzer)
    assert issubclass(analyzer, AdministratorAnalyzer)
