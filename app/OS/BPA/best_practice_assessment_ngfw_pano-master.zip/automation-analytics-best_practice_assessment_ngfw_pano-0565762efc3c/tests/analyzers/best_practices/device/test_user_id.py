import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeWarning
from bpa.analyzers.best_practices.device.user_id import UserIdAnalyzer
from bpa.models.constants import NONE_LOWER
from bpa.models.device.user_id import (
    UserIdModel,
    CaptivePortalSetting,
    GroupMapping,
    CustomGroup,
    UserIdAgent,
    TerminalServicesAgent,
    ServerMonitor,
)
from bpa.models.device.certificate_profile import CertificateProfileModel
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model, build_skeleton


@pytest.fixture
def model_manager_9(model_manager_factory):
    def populate_tree(model_manager_9):
        model_manager_9.tree = MagicMock()
        model_manager_9.tree.version = 9.0

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_manager_8(model_manager_factory):
    def populate_models(model_manager_8):
        cert_prof_ms = model_manager_8.model_set_lookup[
            "certificate_profile"
        ] = ModelSet()
        cert_prof_ms.add(
            build_model(CertificateProfileModel, model_manager_8, name="Cert-Prof-1")
        )

    def populate_tree(model_manager_8):
        model_manager_8.tree = MagicMock()
        model_manager_8.tree.version = 8.1

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def user_id(model_manager_8):
    def _user_id(**overrides):
        return build_model(UserIdModel, model_manager_8, **overrides)

    return _user_id


@pytest.fixture
def captive_portal_setting(model_manager_8):
    def _captive_portal_setting(**overrides):
        return build_skeleton(CaptivePortalSetting, **overrides)

    return _captive_portal_setting


@pytest.fixture
def group_mapping(model_manager_8):
    def _group_mapping(**overrides):
        return build_skeleton(GroupMapping, **overrides)

    return _group_mapping


@pytest.fixture
def analyzer(model_manager_8, check_info):
    manager_ref = weakref.ref(model_manager_8)
    analyzer = UserIdAnalyzer(manager_ref, check_info)
    return analyzer


class TestUserIdAnalyzer:

    """check_included_networks"""

    @pytest.mark.failing
    def test_check_included_networks_passing(self, analyzer, user_id):
        assert not analyzer._check_included_networks(
            user_id(include_networks=[])
        ).check_passed

    @pytest.mark.passing
    def test_check_included_networks_failing(self, analyzer, user_id):
        assert analyzer._check_included_networks(
            user_id(include_networks=["1.1.1.1"])
        ).check_passed

    """check_user_id note"""

    @pytest.mark.note
    def test_check_user_id_passing(self, analyzer, user_id):
        assert (
            analyzer._check_user_id(user_id()).check_message
            == "Use a dedicated server account for user ID with minimal permissions necessary"
        )

    """check_server_log_monitor_frequency"""

    @pytest.mark.passing
    def test_check_server_log_monitor_frequency_passing(self, analyzer, user_id):
        assert analyzer._check_server_log_monitor_frequency(
            user_id(server_log_monitor_frequency=20)
        ).check_passed

    @pytest.mark.failing
    def test_check_server_log_monitor_frequency_failing(self, analyzer, user_id):
        assert not analyzer._check_server_log_monitor_frequency(
            user_id(server_log_monitor_frequency=35)
        ).check_passed

    """check_probing_enabled"""

    @pytest.mark.passing
    def test_check_probing_enabled_passing(self, analyzer, user_id):
        assert analyzer._check_probing_enabled(
            user_id(probing_enabled=False)
        ).check_passed

    @pytest.mark.failing
    def test_check_probing_enabled_failing(self, analyzer, user_id):
        assert not analyzer._check_probing_enabled(
            user_id(probing_enabled=True)
        ).check_passed

    """check_user_id_timeout_enabled"""

    @pytest.mark.passing
    def test_check_user_id_timeout_enabled_passing(self, analyzer, user_id):
        assert analyzer._check_user_id_timeout_enabled(
            user_id(user_id_timeout_enabled=True)
        ).check_passed

    @pytest.mark.failing
    def test_check_user_id_timeout_enabled_failing(self, analyzer, user_id):
        assert not analyzer._check_user_id_timeout_enabled(
            user_id(user_id_timeout_enabled=False)
        ).check_passed

    """check_user_id_timeout_warning"""

    @pytest.mark.passing
    def test_check_user_id_timeout_warning_passing(self, analyzer, user_id):
        assert analyzer._check_user_id_timeout_warning(
            user_id(user_id_timeout=65)
        ).check_passed

    @pytest.mark.failing
    def test_check_user_id_timeout_warning_failing(self, analyzer, user_id):
        assert not analyzer._check_user_id_timeout_warning(
            user_id(user_id_timeout=50)
        ).check_passed

    """check_user_id_timeout_note"""

    @pytest.mark.note
    def test_check_user_id_timeout_note_passing(self, analyzer, user_id):
        assert analyzer._check_user_id_timeout_note(
            user_id(user_id_timeout_enabled=True)
        )

    @pytest.mark.note
    def test_check_user_id_timeout_note_failing(self, analyzer, user_id):
        assert not analyzer._check_user_id_timeout_note(
            user_id(user_id_timeout_enabled=False)
        )

    """check_server_monitors"""

    @pytest.mark.passing
    def test_check_server_monitors_passing(self, analyzer, user_id):
        assert analyzer._check_server_monitors(
            user_id(server_monitors=["1.1.1.1", "2.2.2.2"])
        ).check_passed

    @pytest.mark.failing
    def test_check_server_monitors_failing(self, analyzer, user_id):
        assert not analyzer._check_server_monitors(
            user_id(server_monitors=["1.1.1.1"])
        ).check_passed

    """check_included_groups"""

    @pytest.mark.passing
    def test_check_included_groups_passing(self, analyzer, user_id, group_mapping):
        assert analyzer._check_included_groups(
            user_id(group_mappings=[group_mapping(included_groups_used=True)])
        ).check_passed

    @pytest.mark.failing
    def test_check_included_groups_failing(self, analyzer, user_id, group_mapping):
        assert not analyzer._check_included_groups(
            user_id(group_mappings=[group_mapping(included_groups_used=False)])
        ).check_passed

    """check_captive_portal_enabled"""

    @pytest.mark.passing
    def test_check_captive_portal_enabled_passing(
        self, analyzer, user_id, captive_portal_setting
    ):
        assert analyzer._check_captive_portal_enabled(
            user_id(captive_portal_setting=captive_portal_setting(enabled=True))
        ).check_passed

    @pytest.mark.failing
    def test_check_captive_portal_enabled_failing(
        self, analyzer, user_id, captive_portal_setting
    ):
        assert not analyzer._check_captive_portal_enabled(
            user_id(captive_portal_setting=captive_portal_setting(enabled=False))
        ).check_passed

    """check_captive_portal_mode"""

    @pytest.mark.passing
    def test_check_captive_portal_mode_passing(
        self, analyzer, user_id, captive_portal_setting
    ):
        assert analyzer._check_captive_portal_mode(
            user_id(captive_portal_setting=captive_portal_setting(mode="redirect"))
        ).check_passed

    @pytest.mark.failing
    def test_check_captive_portal_mode_failing(
        self, analyzer, user_id, captive_portal_setting
    ):
        assert not analyzer._check_captive_portal_mode(
            user_id(captive_portal_setting=captive_portal_setting(mode=NONE_LOWER))
        ).check_passed

    """check_captive_portal_session_cookie_timeout"""

    @pytest.mark.passing
    def test_check_captive_portal_session_cookie_timeout_passing(
        self, analyzer, user_id, captive_portal_setting
    ):
        assert analyzer._check_captive_portal_session_cookie_timeout(
            user_id(
                captive_portal_setting=captive_portal_setting(
                    session_cookie_enabled=True, session_cookie_timeout=400
                )
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_captive_portal_session_cookie_timeout_failing(
        self, analyzer, user_id, captive_portal_setting
    ):
        assert not analyzer._check_captive_portal_session_cookie_timeout(
            user_id(
                captive_portal_setting=captive_portal_setting(
                    session_cookie_enabled=True, session_cookie_timeout=500
                )
            )
        ).check_passed

    """check_captive_portal_ssl_tls_service_profile"""

    @pytest.mark.passing
    def test_check_captive_portal_ssl_tls_service_profile_passing(
        self, analyzer, user_id, captive_portal_setting
    ):
        assert analyzer._check_captive_portal_ssl_tls_service_profile(
            user_id(
                captive_portal_setting=captive_portal_setting(
                    ssl_tls_service_profile_min_version="tls1-2"
                )
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_captive_portal_ssl_tls_service_profile_failing(
        self, analyzer, user_id, captive_portal_setting
    ):
        assert not analyzer._check_captive_portal_ssl_tls_service_profile(
            user_id(
                captive_portal_setting=captive_portal_setting(
                    ssl_tls_service_profile_min_version="tls1-0"
                )
            )
        ).check_passed

    """check_connection_security_configured"""

    def test_check_connection_security_configured_none(self, analyzer, user_id):
        assert (
            analyzer._check_connection_security_configured(
                user_id(user_id_agents=[], terminal_services_agents=[])
            )
            is None
        )

    @pytest.mark.passing
    @pytest.mark.integration
    def test_check_connection_security_configured_passing(self, analyzer, user_id):
        assert analyzer._check_connection_security_configured(
            user_id(
                user_id_agents=[UserIdAgent(name="User-1", enabled=True)],
                terminal_services_agents=[
                    TerminalServicesAgent(
                        name="Term-Serv-1", host="1.2.3.4", port="53", enabled=True
                    )
                ],
                connection_security_profile="Cert-Prof-1",
            )
        ).check_passed

    @pytest.mark.failing
    @pytest.mark.integration
    def test_check_connection_security_configured_failing(self, analyzer, user_id):
        assert not analyzer._check_connection_security_configured(
            user_id(
                user_id_agents=[UserIdAgent(name="User-1", enabled=True)],
                terminal_services_agents=[],
                connection_security_profile=None,
            )
        ).check_passed

    @pytest.mark.passing
    def test_check_custom_group_passing(self, analyzer, user_id):
        assert (
            analyzer._check_custom_group(
                user_id(
                    group_mappings=[
                        GroupMapping(
                            name="grp-map",
                            custom_groups=[
                                CustomGroup(
                                    name="hello-1", ldap_filter="(description=hello1)"
                                ),
                                CustomGroup(
                                    name="hello-2", ldap_filter="(description=hello2)"
                                ),
                            ],
                        )
                    ]
                )
            ).check_severity
            == "Info"
        )

    @pytest.mark.failing
    def test_check_custom_group_failing(self, analyzer, user_id):
        assert (
            analyzer._check_custom_group(
                user_id(group_mappings=[GroupMapping(name="grp-map", custom_groups=[])])
            ).check_severity
            == "Caution"
        )

    @pytest.mark.none
    def test_check_custom_group_none(self, analyzer, user_id):
        assert analyzer._check_custom_group(user_id(group_mappings=[])) is None

    @pytest.mark.passing
    def test_check_transport_protocol_passing(self, model_manager_9, check_info):
        manager_ref = weakref.ref(model_manager_9)
        analyzer = UserIdAnalyzer(manager_ref, check_info)
        user_id = build_model(
            UserIdModel,
            model_manager_9,
            server_monitors=[
                ServerMonitor(name="monitor-1", transport_protocol="WinRM-HTTP")
            ],
        )
        check = analyzer._check_transport_protocol(user_id)
        assert isinstance(check, BestPracticeWarning)
        assert check.check_passed

    @pytest.mark.failing
    def test_check_transport_protocol_failing(self, model_manager_9, check_info):
        manager_ref = weakref.ref(model_manager_9)
        analyzer = UserIdAnalyzer(manager_ref, check_info)
        user_id = build_model(
            UserIdModel,
            model_manager_9,
            server_monitors=[ServerMonitor(name="monitor-1")],
        )
        check = analyzer._check_transport_protocol(user_id)
        assert isinstance(check, BestPracticeWarning)
        assert not check.check_passed

    @pytest.mark.none
    def test_check_transport_protocol_none(self, model_manager_8, check_info):
        manager_ref = weakref.ref(model_manager_8)
        analyzer = UserIdAnalyzer(manager_ref, check_info)
        user_id = build_model(UserIdModel, model_manager_8)
        check = analyzer._check_transport_protocol(user_id)
        assert check is None
