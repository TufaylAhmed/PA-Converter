import weakref
from datetime import datetime, timedelta
from unittest.mock import MagicMock, patch

import pytest

from bpa.analyzers.best_practices.policies.security_rule import (
    SecurityRuleAnalyzer,
    SecurityRulebaseAnalyzer,
)
from bpa.models.constants import NONE_LOWER
from bpa.models.manager import ModelManager
from bpa.models.model_set import ModelSet
from bpa.models.network.zone import ZoneModel
from bpa.models.device.dynamic_updates import DynamicUpdatesModel
from bpa.models.objects.application_filter import ApplicationFilterModel
from bpa.models.objects.schedules import SchedulesModel, SchedulesRange
from bpa.models.objects.security_profile.common import SecurityProfileGroupModel
from bpa.models.policies.security_rule import SecurityRuleModel
from tests.utils.models.base import build_model
from bpa.analyzers.best_practices.bp_check import SecurityRuleWarning


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        sched_ms = model_manager.model_set_lookup["schedules"] = ModelSet()
        sched_ms.add(
            build_model(SchedulesModel, model_manager, location="loc-1", name="sched-1")
        )
        sched_ms.add(
            build_model(SchedulesModel, model_manager, location="loc-2", name="sched-2")
        )
        prof_grp_ms = model_manager.model_set_lookup[
            "security_profile_group"
        ] = ModelSet()
        prof_grp_ms.add(
            build_model(
                SecurityProfileGroupModel,
                model_manager,
                antivirus="virus-1",
                anti_spyware="spyware-1",
                vulnerability_protection="vuln-1",
                location="loc-1",
                name="grp-1",
            )
        )
        prof_grp_ms.add(
            build_model(
                SecurityProfileGroupModel,
                model_manager,
                antivirus="virus-2",
                anti_spyware="spyware-2",
                vulnerability_protection="vuln-2",
                location="loc-2",
                name="grp-2",
            )
        )
        zone_ms = model_manager.model_set_lookup["zone"] = ModelSet()
        zone_ms.add(
            build_model(
                ZoneModel,
                model_manager,
                name="zone-1",
                location="loc-1",
                template_name=None,
            )
        )

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8
        model_manager.tree.panorama = True
        model_manager.tree.ancestors = {
            "shared": ["shared"],
            "loc-1": ["loc-1", "shared"],
            "loc-2": ["loc-2", "shared"],
        }

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def model_manager_2(model_manager_factory):
    def populate_models(model_manager):
        filters_ms = model_manager.model_set_lookup["application_filter"] = ModelSet()
        filters_ms.add(
            build_model(
                ApplicationFilterModel,
                model_manager,
                name="filter-1",
                location="loc-1",
                new_app_id_enabled=True,
            )
        )
        filters_ms.add(
            build_model(
                ApplicationFilterModel,
                model_manager,
                name="filter-2",
                location="loc-2",
                new_app_id_enabled=False,
            )
        )
        updates_ms = model_manager.model_set_lookup["dynamic_updates"] = ModelSet()
        updates_ms.add(build_model(DynamicUpdatesModel, model_manager, update_types={}))

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1
        model_manager.tree.panorama = False
        model_manager.tree.ancestors = {
            "shared": ["shared"],
            "loc-1": ["loc-1", "shared"],
            "loc-2": ["loc-2", "shared"],
        }

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def rule_analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    rule_analyzer = SecurityRuleAnalyzer(manager_ref, check_info)
    return rule_analyzer


@pytest.fixture
def rulebase_analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    rulebase_analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
    return rulebase_analyzer


@pytest.fixture
def security_rule(model_manager):
    def _security_rule(**overrides):
        return build_model(SecurityRuleModel, model_manager, **overrides)

    return _security_rule


class TestSecurityRuleAnalyzer:

    """check_description"""

    @pytest.mark.excluding
    def test_check_description_excluding(self, rule_analyzer, security_rule):
        model = security_rule(rule_name="interzone-default")
        assert rule_analyzer._check_description(model).check_excluded

    @pytest.mark.passing
    def test_check_description_passing(self, rule_analyzer, security_rule):
        model = security_rule(
            rule_name="block-to-outside", description="Something useful"
        )
        assert rule_analyzer._check_description(model).check_passed

    @pytest.mark.failing
    def test_check_description_failing(self, rule_analyzer, security_rule):
        model = security_rule(rule_name="block-to-outside")
        assert not rule_analyzer._check_description(model).check_passed

    """check_source_destination"""

    @pytest.mark.excluding
    def test_check_source_destination_excluding(self, rule_analyzer, security_rule):
        model = security_rule(rule_type="intrazone")
        assert rule_analyzer._check_source_destination(model).check_excluded

    @pytest.mark.passing
    def test_check_source_destination_passing(self, rule_analyzer, security_rule):
        model = security_rule(
            action="allow",
            source_zones=["any"],
            source_addresses=["any"],
            dest_zones=["blah"],
            dest_addresses=["blah"],
        )
        assert rule_analyzer._check_source_destination(model).check_passed

    @pytest.mark.failing
    def test_check_source_destination_failing(self, rule_analyzer, security_rule):
        model = security_rule(
            action="allow",
            source_zones=["any"],
            source_addresses=["any"],
            dest_zones=["any"],
            dest_addresses=["any"],
        )
        assert not rule_analyzer._check_source_destination(model).check_passed

    """check_service"""

    @pytest.mark.excluding
    def test_check_service_excluding(self, rule_analyzer, security_rule):
        model = security_rule(action="not-allow", rule_type="intrazone")
        assert rule_analyzer._check_service(model).check_excluded

    @pytest.mark.passing
    def test_check_service_passing(self, rule_analyzer, security_rule):
        model = security_rule(services=["apache"], action="allow")
        assert rule_analyzer._check_service(model).check_passed

    @pytest.mark.failing
    def test_check_service_failing(self, rule_analyzer, security_rule):
        model = security_rule(services=["any"], action="allow")
        assert not rule_analyzer._check_service(model).check_passed

    """check_application"""

    @pytest.mark.excluding
    def test_check_application_excluding(self, rule_analyzer, security_rule):
        model = security_rule(action="allow", rule_type="intrazone")
        assert rule_analyzer._check_application(model).check_excluded

    @pytest.mark.passing
    def test_check_application_passing(self, rule_analyzer, security_rule):
        model = security_rule(action="allow", applications=["warcraft"])
        assert rule_analyzer._check_application(model).check_passed

    @pytest.mark.failing
    def test_check_application_failing(self, rule_analyzer, security_rule):
        model = security_rule(action="allow", applications=["any"])
        assert not rule_analyzer._check_application(model).check_passed

    """check_app_id_service"""

    @pytest.mark.excluding
    def test_check_app_id_service_excluding(self, rule_analyzer, security_rule):
        model = security_rule(rule_type="intrazone")
        assert rule_analyzer._check_app_id_service(model).check_excluded
        model2 = security_rule(action="deny")
        assert rule_analyzer._check_app_id_service(model2).check_excluded

    @pytest.mark.passing
    def test_check_app_id_service_passing(self, rule_analyzer, security_rule):
        model = security_rule(applications=["warcraft"], services=["apache"])
        assert not rule_analyzer._check_app_id_service(model).check_passed

    @pytest.mark.failing
    def test_check_app_id_service_failing(self, rule_analyzer, security_rule):
        model = security_rule(applications=[], services=["any"])
        assert not rule_analyzer._check_app_id_service(model).check_passed

    """check_log_start"""

    @pytest.mark.passing
    def test_check_log_start_passing(self, rule_analyzer, security_rule):
        model = security_rule(log_start_enabled=False)
        assert rule_analyzer._check_log_start(model).check_passed

    @pytest.mark.failing
    def test_check_log_start_failing(self, rule_analyzer, security_rule):
        model = security_rule(log_start_enabled=True)
        assert not rule_analyzer._check_log_start(model).check_passed

    """check_log_forwarding"""

    @pytest.mark.passing
    def test_check_log_forwarding_passing(self, rule_analyzer, security_rule):
        model = security_rule(log_forwarding_profile="blah")
        assert rule_analyzer._check_log_forwarding(model).check_passed

    @pytest.mark.failing
    def test_check_log_forwarding_failing(self, rule_analyzer, security_rule):
        model = security_rule(log_forwarding_profile=NONE_LOWER)
        assert not rule_analyzer._check_log_forwarding(model).check_passed

    """check_expired_non_recurring_schedule"""

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_expired_non_recurring_schedule_passing(
        self, rule_analyzer, security_rule
    ):
        security_model = security_rule()
        assert rule_analyzer._check_expired_non_recurring_schedule(
            security_model
        ).check_passed

    @pytest.mark.hack
    @pytest.mark.integration
    @pytest.mark.failing
    def test_check_expired_non_recurring_schedule_failing(
        self, rule_analyzer, security_rule
    ):
        security_model = security_rule(location="loc-1", schedule="sched-1")
        schedules_model = rule_analyzer.objects.get("schedules").find(
            location="loc-1", name="sched-1"
        )
        schedules_model.schedule_ranges = [
            SchedulesRange(
                start_time=datetime.now() - timedelta(minutes=60),
                end_time=datetime.now() - timedelta(minutes=30),
            ),
            SchedulesRange(
                start_time=datetime.now() + timedelta(minutes=30),
                end_time=datetime.now() + timedelta(minutes=60),
            ),
        ]
        assert not rule_analyzer._check_expired_non_recurring_schedule(
            security_model
        ).check_passed

    """check_disable_server_response_inspection_enabled"""

    @pytest.mark.passing
    def test_check_disable_server_response_inspection_enabled_passing(
        self, rule_analyzer, security_rule
    ):
        model = security_rule(disable_server_response_inspection_enabled=False)
        assert (
            bool(rule_analyzer._check_disable_server_response_inspection_enabled(model))
            is True
        )

    @pytest.mark.failing
    def test_check_disable_server_response_inspection_enabled_failing(
        self, rule_analyzer, security_rule
    ):
        model = security_rule(disable_server_response_inspection_enabled=True)
        assert (
            bool(rule_analyzer._check_disable_server_response_inspection_enabled(model))
            is False
        )


class TestSecurityRulebaseAnalyzer:

    """check_quic_deny_rule"""

    @pytest.mark.passing
    def test_check_quic_deny_rule_passing(
        self, rulebase_analyzer, security_rule, check_info
    ):
        proper_quic_rule = security_rule(
            rule_enabled=True,
            action="deny",
            applications=["quic"],
            location="shared",
            rulebase="pre-rulebase",
        )
        pre_rulebase_allow_rule = security_rule(
            rule_enabled=True,
            action="allow",
            applications=["app"],
            location="shared",
            rulebase="pre-rulebase",
        )
        general_allow_rule = security_rule(
            rule_enabled=True, action="allow", applications=["app"]
        )
        general_deny_rule = security_rule(
            rule_enabled=True, action="deny", applications=["app"]
        )
        # in panoramas:
        # proper quic rule must come before any rules
        # with action="allow", rulebase="pre-rulebase" and location="shared"

        # in ngfws:
        # proper quic rule must come before any rules
        # with action="allow"

        pano_rules = [general_deny_rule, proper_quic_rule, pre_rulebase_allow_rule]
        ngfw_rules = [general_deny_rule, proper_quic_rule, general_allow_rule]

        pano_mm = ModelManager()
        pano_mm.tree = MagicMock()
        pano_mm.tree.panorama = True
        pano_mm.tree.ngfw = False
        pano_mm_ref = weakref.ref(pano_mm)
        pano_analyzer = SecurityRulebaseAnalyzer(pano_mm_ref, check_info)

        pano_check, _ = pano_analyzer._check_quic_deny_rule(pano_rules)
        assert pano_check.check_passed is True

        ngfw_mm = ModelManager()
        ngfw_mm.tree = MagicMock()
        ngfw_mm.tree.panorama = False
        ngfw_mm.tree.ngfw = True
        ngfw_mm_ref = weakref.ref(ngfw_mm)
        ngfw_analyzer = SecurityRulebaseAnalyzer(ngfw_mm_ref, check_info)

        ngfw_check, _ = ngfw_analyzer._check_quic_deny_rule(ngfw_rules)
        assert ngfw_check.check_passed is True

    @pytest.mark.failing
    def test_check_quic_deny_rule_failing(
        self, rulebase_analyzer, security_rule, check_info
    ):
        # this check only applies to rules which are enabled

        # a proper quic rule is defined to have:
        # action=deny and "quic" in applications
        proper_quic_rule = security_rule(
            rule_enabled=True,
            action="deny",
            applications=["quic"],
            location="shared",
            rulebase="pre-rulebase",
        )
        pre_rulebase_allow_rule = security_rule(
            rule_enabled=True,
            action="allow",
            applications=["app"],
            location="shared",
            rulebase="pre-rulebase",
        )
        general_allow_rule = security_rule(
            rule_enabled=True, action="allow", applications=["app"]
        )
        general_deny_rule = security_rule(
            rule_enabled=True, action="deny", applications=["app"]
        )
        # in panoramas:
        # proper quic rule must come before any rules
        # with action="allow", rulebase="pre-rulebase" and location="shared"

        # in ngfws:
        # proper quic rule must come before any rules
        # with action="allow"

        # this is the failing case of the test, we will violate these rules

        pano_rules = [pre_rulebase_allow_rule, general_deny_rule, proper_quic_rule]
        ngfw_rules = [general_allow_rule, general_deny_rule, proper_quic_rule]
        no_quic_rules = [general_allow_rule, general_deny_rule]

        pano_mm = ModelManager()
        pano_mm.tree = MagicMock()
        pano_mm.tree.panorama = True
        pano_mm.tree.ngfw = False
        pano_mm_ref = weakref.ref(pano_mm)
        pano_analyzer = SecurityRulebaseAnalyzer(pano_mm_ref, check_info)

        pano_check, _ = pano_analyzer._check_quic_deny_rule(pano_rules)
        assert pano_check.check_passed is False

        ngfw_mm = ModelManager()
        ngfw_mm.tree = MagicMock()
        ngfw_mm.tree.panorama = False
        ngfw_mm.tree.ngfw = True
        ngfw_mm_ref = weakref.ref(ngfw_mm)
        ngfw_analyzer = SecurityRulebaseAnalyzer(ngfw_mm_ref, check_info)

        ngfw_check, _ = ngfw_analyzer._check_quic_deny_rule(ngfw_rules)
        assert ngfw_check.check_passed is False

        # the last failing case is no proper quic rule exists at all

        no_quic_check, _ = ngfw_analyzer._check_quic_deny_rule(no_quic_rules)
        assert no_quic_check.check_passed is False

    """check_intrazone_default_rule"""

    _any = ["any"]

    @pytest.mark.failing
    def test_check_intrazone_default_rule_no_rules(self, rulebase_analyzer):
        rules = []
        check, _ = rulebase_analyzer._check_intrazone_default_rule(rules)
        assert check.check_passed is False

    @pytest.mark.passing
    def test_check_intrazone_default_rule_universal_type_passing(
        self, rulebase_analyzer, security_rule
    ):
        rule = security_rule(
            rule_type="universal",
            rule_enabled=True,
            action="allow",
            log_end_enabled=True,
            applications=self._any,
            hip_profiles=self._any,
            services=self._any,
            source_addresses=self._any,
            source_users=self._any,
            source_zones=["zone1"],
            dest_addresses=self._any,
            dest_zones=["zone1"],
            profile_antivirus="test",
            profile_anti_spyware="test",
            profile_vulnerability_protection="test",
        )
        check, _ = rulebase_analyzer._check_intrazone_default_rule([rule])
        assert check.check_passed is True

    @pytest.mark.passing
    def test_check_intrazone_default_rule_intrazone_type_passing(
        self, rulebase_analyzer, security_rule
    ):
        rule = security_rule(
            rule_type="intrazone",
            rule_enabled=True,
            action="allow",
            log_end_enabled=True,
            applications=self._any,
            hip_profiles=self._any,
            services=self._any,
            source_addresses=self._any,
            source_users=self._any,
            dest_addresses=self._any,
            profile_antivirus="test",
            profile_anti_spyware="test",
            profile_vulnerability_protection="test",
        )
        check, _ = rulebase_analyzer._check_intrazone_default_rule([rule])
        rule2 = security_rule(
            rule_type="intrazone",
            rule_enabled=True,
            action="deny",
            log_end_enabled=True,
            applications=self._any,
            hip_profiles=self._any,
            services=self._any,
            source_addresses=self._any,
            source_users=self._any,
            dest_addresses=self._any,
            profile_antivirus="test",
            profile_anti_spyware="test",
            profile_vulnerability_protection="test",
        )
        check2, _ = rulebase_analyzer._check_intrazone_default_rule([rule2])
        assert check.check_passed is True
        assert check2.check_excluded is True

    @pytest.mark.integration
    @pytest.mark.failing
    def test_check_intrazone_default_rule_failing(
        self, rulebase_analyzer, security_rule
    ):
        rules = [
            security_rule(
                location="loc-1",
                rule_name="intrazone-default",
                action="deny",
                log_end_enabled=True,
                profile_group="grp-1",
            ),
            security_rule(
                location="loc-2",
                rule_type="intrazone",
                action="deny",
                log_end_enabled=True,
                profile_group="grp-2",
            ),
        ]
        check, settings = rulebase_analyzer._check_intrazone_default_rule(rules)
        assert check.check_passed is False
        assert type(settings) is dict

    """check_interzone_default_rule"""

    @pytest.mark.passing
    def test_check_interzone_default_rule_passing(
        self, rulebase_analyzer, security_rule
    ):
        rules = [
            security_rule(
                rule_type="interzone",
                rule_enabled=True,
                action="deny",
                log_end_enabled=True,
                applications=self._any,
                hip_profiles=self._any,
                services=self._any,
                source_addresses=self._any,
                source_users=self._any,
                source_zones=self._any,
                dest_addresses=self._any,
                dest_zones=self._any,
            )
        ]
        check, settings = rulebase_analyzer._check_interzone_default_rule(rules)
        assert check.check_passed is True
        assert type(settings) is dict

    @pytest.mark.failing
    def test_check_interzone_default_rule_failing(
        self, rulebase_analyzer, security_rule
    ):
        rules = [
            security_rule(rule_type="interzone", action="allow", log_end_enabled=False),
            security_rule(rule_type="interzone", action="allow", log_end_enabled=False),
        ]
        check, settings = rulebase_analyzer._check_interzone_default_rule(rules)
        assert check.check_passed is False
        assert type(settings) is dict

    """check_disabled_rules"""

    @pytest.mark.passing
    def test_check_disabled_rules_passing(self, rulebase_analyzer, security_rule):
        rules = [security_rule(rule_enabled=True), security_rule(rule_enabled=True)]
        check, settings = rulebase_analyzer._check_disabled_rules(rules)
        assert check.check_passed is True
        assert type(settings) is dict

    @pytest.mark.failing
    def test_check_disabled_rules_failing(self, rulebase_analyzer, security_rule):
        rules = [security_rule(rule_enabled=True), security_rule(rule_enabled=False)]
        check, settings = rulebase_analyzer._check_disabled_rules(rules)
        assert check.check_passed is False
        assert type(settings) is dict

    """check_rules_using_hip_profile"""

    @pytest.mark.passing
    def test_check_rules_using_hip_profile_passing(
        self, rulebase_analyzer, security_rule
    ):
        rules = [
            security_rule(hip_profiles=["hip-1", "hip-2", "hip-3"]),
            security_rule(hip_profiles=["hip-1", "hip-2", "hip-3"]),
        ]
        check, settings = rulebase_analyzer._check_rules_using_hip_profile(rules)
        assert check.check_passed is True
        assert type(settings) is dict

    @pytest.mark.failing
    def test_check_rules_using_hip_profile_failing(
        self, rulebase_analyzer, security_rule
    ):
        rules = [security_rule(hip_profiles=[]), security_rule(hip_profiles=[])]
        check, settings = rulebase_analyzer._check_rules_using_hip_profile(rules)
        assert check.check_passed is False
        assert type(settings) is dict


def easy_init(self, **kwargs):
    for key, val in kwargs.items():
        setattr(self, key, val)


class Test_check_user_id_rules_without_user_id_on_zone:
    def test_skip_if_panorama(self, check_info):
        model_manager = ModelManager()
        model_manager.tree = MagicMock()
        model_manager.tree.panorama = True
        manager_ref = weakref.ref(model_manager)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        rules = []
        check, settings = analyzer._check_user_id_rules_without_user_id_on_zone(rules)
        assert (check, settings) == (None, None)

    def test_skip_if_no_user_id_rules(self, check_info):
        model_manager = ModelManager()
        model_manager.tree = MagicMock()
        model_manager.tree.panorama = False
        manager_ref = weakref.ref(model_manager)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        rules = []
        check, settings = analyzer._check_user_id_rules_without_user_id_on_zone(rules)
        assert (check, settings) == (None, None)

    @pytest.mark.parametrize(
        "override",
        [{"source_users": ["any"]}, {"rule_enabled": False}, {"action": "deny"}],
    )
    def test_skip_if_no_enabled_allow_rules_with_user_id(self, check_info, override):
        model_manager = ModelManager()
        model_manager.tree = MagicMock()
        model_manager.tree.panorama = False
        manager_ref = weakref.ref(model_manager)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        attrs = {"source_users": ["admin"], "rule_enabled": True, "action": "allow"}
        attrs = {**attrs, **override}
        with patch.object(SecurityRuleModel, "__init__", easy_init):
            rules = [SecurityRuleModel(**attrs)]
        check, settings = analyzer._check_user_id_rules_without_user_id_on_zone(rules)
        assert (check, settings) == (None, None)

    def test_fail_if_source_zone_without_user_id_enabled(self, check_info):
        model_manager = ModelManager()
        model_manager.tree = MagicMock()
        model_manager.tree.panorama = False
        zones = ModelSet()
        with patch.object(ZoneModel, "__init__", easy_init):
            zone = ZoneModel(
                name="no_user_id_zone",
                user_id_enabled=False,
                location="vsys1",
                template_name=None,
            )
        zones.add(zone)
        model_manager.model_set_lookup[ZoneModel.build_model_key()] = zones
        manager_ref = weakref.ref(model_manager)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        with patch.object(SecurityRuleModel, "__init__", easy_init):
            rule = SecurityRuleModel(
                source_users=["admin"],
                source_zones=["no_user_id_zone"],
                location="vsys1",
                rule_enabled=True,
                action="allow",
            )
        rules = [rule]
        check, settings = analyzer._check_user_id_rules_without_user_id_on_zone(rules)
        assert check.check_passed is False

    def test_passing(self, check_info):
        model_manager = ModelManager()
        model_manager.tree = MagicMock()
        model_manager.tree.panorama = False
        zones = ModelSet()
        with patch.object(ZoneModel, "__init__", easy_init):
            zone = ZoneModel(
                name="user_id_zone",
                user_id_enabled=True,
                location="vsys1",
                template_name=None,
            )
        zones.add(zone)
        model_manager.model_set_lookup[ZoneModel.build_model_key()] = zones
        manager_ref = weakref.ref(model_manager)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        with patch.object(SecurityRuleModel, "__init__", easy_init):
            rule = SecurityRuleModel(
                source_users=["admin"],
                source_zones=["user_id_zone"],
                location="vsys1",
                rule_enabled=True,
                action="allow",
            )
        rules = [rule]
        check, settings = analyzer._check_user_id_rules_without_user_id_on_zone(rules)
        assert check.check_passed is True


class Test_check_new_apps_with_app_filter:
    @pytest.mark.integration
    @pytest.mark.none
    def test_skip_if_panorama(self, check_info):
        model_manager = ModelManager()
        model_manager.tree = MagicMock()
        model_manager.tree.panorama = True
        model_manager.tree.version = 8.0
        manager_ref = weakref.ref(model_manager)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        rules = []
        check, settings = analyzer._check_new_apps_with_app_filter(rules)
        assert (check, settings) == (None, None)

    @pytest.mark.integration
    @pytest.mark.passing
    def test_passing(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="intrazone-default",
                action="allow",
                applications=["filter-1"],
            )
        ]
        check, settings = analyzer._check_new_apps_with_app_filter(rules)
        assert settings == {}
        assert check.check_passed

    @pytest.mark.integration
    @pytest.mark.failing
    def test_failing(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-2",
                rule_name="intrazone-default",
                action="allow",
                applications=["filter-2"],
            )
        ]
        check, settings = analyzer._check_new_apps_with_app_filter(rules)
        assert settings == {}
        assert not check.check_passed


class Test_check_panw_known_malicious_ip_inbound_rule:
    @pytest.mark.integration
    @pytest.mark.passing
    def test_passing(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="malicious_inbound",
                action="deny",
                rule_enabled=True,
                source_addresses=["panw-known-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
            )
        ]
        check, settings = analyzer._check_panw_known_malicious_ip_inbound_rule(rules)
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_passed
        assert settings == {}

    @pytest.mark.integration
    @pytest.mark.failing
    def test_failing_incorrect_os(self, model_manager, check_info):
        manager_ref = weakref.ref(model_manager)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)

        # Fail condition: Model Manager with OS version 8.0 selected
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager,
                location="loc-1",
                rule_name="malicious_inbound",
                action="deny",
                rule_enabled=True,
                source_addresses=["panw-known-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
            )
        ]
        check, settings = analyzer._check_panw_known_malicious_ip_inbound_rule(rules)
        assert model_manager.tree.version < 8.1
        assert check is None
        assert settings is None

    @pytest.mark.integration
    @pytest.mark.failing
    def test_failing_incorrect_config(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)

        # Fail condition: Source address not set as 'Palo Alto Networks - Known malicious IP addresses'
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="malicious_inbound",
                action="deny",
                rule_enabled=True,
                source_addresses=[],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
            )
        ]
        check, settings = analyzer._check_panw_known_malicious_ip_inbound_rule(rules)
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert not check.check_passed
        assert settings == {}


class Test_check_panw_known_malicious_ip_outbound_rule:
    @pytest.mark.integration
    @pytest.mark.passing
    def test_passing(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="malicious_outbound",
                action="deny",
                rule_enabled=True,
                dest_addresses=["panw-known-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
            )
        ]
        check, settings = analyzer._check_panw_known_malicious_ip_outbound_rule(rules)
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_passed
        assert settings == {}

    @pytest.mark.integration
    @pytest.mark.failing
    def test_failing_incorrect_os(self, model_manager, check_info):
        manager_ref = weakref.ref(model_manager)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)

        # Fail condition: Model Manager with OS version 8.0 selected
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager,
                location="loc-1",
                rule_name="malicious_outbound",
                action="deny",
                rule_enabled=True,
                dest_addresses=["panw-known-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
            )
        ]
        check, settings = analyzer._check_panw_known_malicious_ip_outbound_rule(rules)
        assert model_manager.tree.version < 8.1
        assert check is None
        assert settings is None

    @pytest.mark.integration
    @pytest.mark.failing
    def test_failing_incorrect_config(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)

        # Fail condition: Destination address not set as 'Palo Alto Networks - Known malicious IP addresses'
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="malicious_outbound",
                action="deny",
                rule_enabled=True,
                dest_addresses=[],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
            )
        ]
        check, settings = analyzer._check_panw_known_malicious_ip_outbound_rule(rules)
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert not check.check_passed
        assert settings == {}


class Test_check_panw_known_high_risk_ip_inbound_rule:
    @pytest.mark.integration
    @pytest.mark.passing
    def test_passing_action_deny(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="highrisk_inbound",
                action="deny",
                rule_enabled=True,
                source_addresses=["panw-highrisk-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
            )
        ]

        check, settings = analyzer._check_panw_known_high_risk_ip_inbound_rule(rules)
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_id == 263
        assert check.check_passed
        assert settings == {}

    @pytest.mark.integration
    @pytest.mark.passing
    def test_passing_panorama(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="highrisk_inbound",
                action="deny",
                rule_enabled=True,
                source_addresses=["panw-highrisk-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
                rulebase="pre-rulebase",
            )
        ]

        # Explicitly setting it to be panaroma
        analyzer.objects.tree.panorama = True

        check, settings = analyzer._check_panw_known_high_risk_ip_inbound_rule(rules)
        assert analyzer.objects.tree.panorama is True
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_id == 263
        assert check.check_passed
        assert settings == {}

    @pytest.mark.integration
    @pytest.mark.passing
    def test_passing_action_allow(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="highrisk_inbound",
                action="allow",
                rule_enabled=True,
                source_addresses=["panw-highrisk-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
                profile_antivirus="default",
                profile_anti_spyware="strict",
                profile_vulnerability_protection="default",
                profile_url_filtering="default",
            )
        ]

        check, settings = analyzer._check_panw_known_high_risk_ip_inbound_rule(rules)
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_id == 263
        assert check.check_passed
        assert settings == {}

    @pytest.mark.integration
    @pytest.mark.failing
    def test_failing_incorrect_os(self, model_manager, check_info):
        manager_ref = weakref.ref(model_manager)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)

        # Fail condition: Model Manager with OS version 8.0 selected
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager,
                location="loc-1",
                rule_name="highrisk_inbound",
                rule_enabled=True,
            )
        ]

        check, settings = analyzer._check_panw_known_high_risk_ip_inbound_rule(rules)
        assert model_manager.tree.version < 8.1
        assert check is None
        assert settings is None

    @pytest.mark.integration
    @pytest.mark.failing
    def test_failing_incorrect_config(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)

        # Fail condition: Source address not set as 'Palo Alto Networks - High risk IP addresses'
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="highrisk_inbound",
                action="deny",
                rule_enabled=True,
                source_addresses=["any"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
            )
        ]

        check, settings = analyzer._check_panw_known_high_risk_ip_inbound_rule(rules)
        assert analyzer.objects.tree.panorama is False
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_id == 263
        assert not check.check_passed
        assert settings == {}

    @pytest.mark.integration
    @pytest.mark.failing
    def test_failing_incorrect_panoroma_config(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)

        # Fail condition: Rulebase is not pre-rulebase
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="highrisk_inbound",
                action="deny",
                rule_enabled=True,
                source_addresses=["panw-highrisk-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
                rulebase="post-rulebase",
            )
        ]

        # Explicitly setting it to be panaroma
        analyzer.objects.tree.panorama = True

        check, settings = analyzer._check_panw_known_high_risk_ip_inbound_rule(rules)
        assert analyzer.objects.tree.panorama is True
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_id == 263
        assert not check.check_passed
        assert settings == {}

    @pytest.mark.integration
    @pytest.mark.failing
    def test_failing_profile_not_configured(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)

        # Fail condition: Action allow but profiles not set.
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="highrisk_inbound",
                action="allow",
                rule_enabled=True,
                source_addresses=["panw-highrisk-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
            )
        ]

        check, settings = analyzer._check_panw_known_high_risk_ip_inbound_rule(rules)
        assert analyzer.objects.tree.panorama is False
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_id == 263
        assert not check.check_passed
        assert settings == {}


class Test_check_panw_known_high_risk_ip_outbound_rule:
    @pytest.mark.integration
    @pytest.mark.passing
    def test_passing_action_deny(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="highrisk_outbound",
                action="deny",
                rule_enabled=True,
                dest_addresses=["panw-highrisk-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
            )
        ]
        check, settings = analyzer._check_panw_known_high_risk_ip_outbound_rule(rules)
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_id == 264
        assert check.check_passed
        assert settings == {}

    @pytest.mark.integration
    @pytest.mark.passing
    def test_passing_action_allow(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="highrisk_outbound",
                action="allow",
                rule_enabled=True,
                dest_addresses=["panw-highrisk-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
                profile_antivirus="default",
                profile_anti_spyware="strict",
                profile_vulnerability_protection="default",
                profile_url_filtering="default",
            )
        ]
        check, settings = analyzer._check_panw_known_high_risk_ip_outbound_rule(rules)
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_id == 264
        assert check.check_passed
        assert settings == {}

    @pytest.mark.integration
    @pytest.mark.passing
    def test_passing_panorama(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="highrisk_outbound",
                action="deny",
                rule_enabled=True,
                dest_addresses=["panw-highrisk-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
                rulebase="pre-rulebase",
            )
        ]

        # Explicitly setting it to be panaroma
        analyzer.objects.tree.panorama = True

        check, settings = analyzer._check_panw_known_high_risk_ip_outbound_rule(rules)
        assert analyzer.objects.tree.panorama is True
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_id == 264
        assert check.check_passed
        assert settings == {}

    @pytest.mark.integration
    @pytest.mark.failing
    def test_failing_incorrect_os(self, model_manager, check_info):
        manager_ref = weakref.ref(model_manager)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)

        # Fail condition: Model Manager with OS version 8.0 selected
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager,
                location="loc-1",
                rule_name="highrisk_outbound",
                rule_enabled=True,
            )
        ]
        check, settings = analyzer._check_panw_known_high_risk_ip_outbound_rule(rules)
        assert model_manager.tree.version < 8.1
        assert check is None
        assert settings is None

    @pytest.mark.integration
    @pytest.mark.failing
    def test_failing_incorrect_config(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)

        # Fail condition: Destination address not set as 'Palo Alto Networks - High risk IP addresses'
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="highrisk_outbound",
                action="deny",
                rule_enabled=True,
                dest_addresses=["any"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
            )
        ]
        check, settings = analyzer._check_panw_known_high_risk_ip_outbound_rule(rules)
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_id == 264
        assert not check.check_passed
        assert settings == {}

    @pytest.mark.integration
    @pytest.mark.failing
    def test_failing_incorrect_panoroma_config(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)

        # Fail condition: Rulebase is not pre-rulebase
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="highrisk_outbound",
                action="deny",
                rule_enabled=True,
                dest_addresses=["panw-highrisk-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
                rulebase="post-rulebase",
            )
        ]

        # Explicitly setting it to be panaroma
        analyzer.objects.tree.panorama = True

        check, settings = analyzer._check_panw_known_high_risk_ip_outbound_rule(rules)
        assert analyzer.objects.tree.panorama is True
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_id == 264
        assert not check.check_passed
        assert settings == {}

    @pytest.mark.integration
    @pytest.mark.failing
    def test_failing_profile_not_configured(self, model_manager_2, check_info):
        manager_ref = weakref.ref(model_manager_2)
        analyzer = SecurityRulebaseAnalyzer(manager_ref, check_info)

        # Fail condition: Action allow but profiles not set.
        rules = [
            build_model(
                SecurityRuleModel,
                model_manager=model_manager_2,
                location="loc-1",
                rule_name="highrisk_outbound",
                action="allow",
                rule_enabled=True,
                dest_addresses=["panw-highrisk-ip-list"],
                log_end_enabled=True,
                log_forwarding_profile=["Log-FWD"],
            )
        ]
        check, settings = analyzer._check_panw_known_high_risk_ip_outbound_rule(rules)
        assert model_manager_2.tree.version >= 8.1
        assert isinstance(check, SecurityRuleWarning)
        assert check.check_id == 264
        assert not check.check_passed
        assert settings == {}
