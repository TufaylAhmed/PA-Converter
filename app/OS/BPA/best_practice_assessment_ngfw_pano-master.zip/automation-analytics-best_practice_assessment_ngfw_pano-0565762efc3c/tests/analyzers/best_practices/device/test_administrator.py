# -*- coding: utf-8 -*-
import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.device.administrator import AdministratorAnalyzer
from bpa.models.device.administrator import AdministratorModel
from bpa.models.device.authentication_profile import AuthenticationProfileModel
from bpa.models.device.server_profiles import (
    RadiusServerProfileModel,
    TacPlusServerProfileModel,
)
from bpa.models.model_set import ModelSet
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_other(model_manager):
        model_manager.get = MagicMock()
        model_manager.tree = MagicMock()

    return model_manager_factory(populate_other=populate_other)


@pytest.fixture
def model_manager_with_profiles(model_manager_factory):
    def populate_models(model_manager):
        # Sample authentication profiles
        a_ms = model_manager.model_set_lookup["authentication_profile"] = ModelSet()
        a_ms.add(
            build_model(
                AuthenticationProfileModel,
                model_manager,
                name="Auth-Prof-1",
                method="radius",
                server_profile="Radius-Good",
            )
        )
        a_ms.add(
            build_model(
                AuthenticationProfileModel,
                model_manager,
                name="Auth-Prof-2",
                method="radius",
                server_profile="Radius-Bad",
            )
        )
        a_ms.add(
            build_model(
                AuthenticationProfileModel,
                model_manager,
                name="Auth-Prof-3",
                method="tacplus",
                server_profile="Tacplus-Good",
            )
        )
        a_ms.add(
            build_model(
                AuthenticationProfileModel,
                model_manager,
                name="Auth-Prof-4",
                method="tacplus",
                server_profile="Tacplus-Bad",
            )
        )

        # Sample radius profiles
        r_ms = model_manager.model_set_lookup["radius_server_profile"] = ModelSet()
        r_ms.add(
            build_model(
                RadiusServerProfileModel,
                model_manager,
                name="Radius-Good",
                protocol="EAP-TTLS-with-PAP",
            )
        )
        r_ms.add(
            build_model(
                RadiusServerProfileModel,
                model_manager,
                name="Radius-Bad",
                protocol="BOGUS",
            )
        )

        # Sample tacacs+ profiles
        t_ms = model_manager.model_set_lookup["tac_plus_server_profile"] = ModelSet()
        t_ms.add(
            build_model(
                TacPlusServerProfileModel,
                model_manager,
                name="Tacplus-Good",
                protocol="CHAP",
            )
        )
        t_ms.add(
            build_model(
                TacPlusServerProfileModel,
                model_manager,
                name="Tacplus-Bad",
                protocol="BOGUS",
            )
        )

    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8.1

    return model_manager_factory(
        populate_models=populate_models, populate_tree=populate_tree
    )


@pytest.fixture
def make_admin(model_manager):
    """Helper factory for creating AuthenticationSequenceModel instances.

    https://docs.pytest.org/en/latest/fixture.html#factories-as-fixtures
    """

    defaults = {
        "name": "dummy",
        "role": "superuser",
        "password_profile": None,
        "authentication_profile": None,
        "template_name": None,
    }

    def _make_admin(**overrides):
        attrs = {**defaults, **overrides}
        manager_input = attrs.pop("model_manager", None) or model_manager
        return build_model(AdministratorModel, manager_input, **attrs)

    return _make_admin


@pytest.fixture
def make_admin_with_profiles(model_manager_with_profiles):
    def _make_admin(**overrides):
        return build_model(AdministratorModel, model_manager_with_profiles, **overrides)

    return _make_admin


@pytest.fixture
def admin_analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    return AdministratorAnalyzer(manager_ref, check_info)


@pytest.fixture
def admin_analyzer_with_profiles(model_manager_with_profiles, check_info):
    manager_ref = weakref.ref(model_manager_with_profiles)
    return AdministratorAnalyzer(manager_ref, check_info)


class Test_check_admin_password_profile:
    def test_with_no_admins(self, admin_analyzer, make_admin):
        assert (
            admin_analyzer._check_admin_password_profile(template_name=None, admins=[])
            is None
        )

    @pytest.mark.passing
    @pytest.mark.failing
    def test_with_admins(self, admin_analyzer, make_admin):
        assert (
            admin_analyzer._check_admin_password_profile(
                template_name=None, admins=[make_admin()]
            ).check_passed
            is False
        )
        assert (
            admin_analyzer._check_admin_password_profile(
                template_name=None, admins=[make_admin(password_profile="p1")]
            ).check_passed
            is True
        )
        assert (
            admin_analyzer._check_admin_password_profile(
                template_name=None, admins=[make_admin(authentication_profile="a1")]
            ).check_passed
            is True
        )


class Test_check_admin_auth_on_device:
    def test_no_local_admins(self, admin_analyzer, make_admin):
        assert (
            admin_analyzer._check_admin_auth_on_device(
                template_name=None, admins=[make_admin(authentication_profile="a1")]
            )
            is None
        )

    @pytest.mark.failing
    def test_invalid_min_pw_complexity(self, model_manager, check_info, make_admin):
        manager_ref = weakref.ref(model_manager)
        manager_ref().get().find().min_password_complexity.valid.return_value = False
        admin_analyzer = AdministratorAnalyzer(manager_ref, check_info)
        check = admin_analyzer._check_admin_auth_on_device(
            template_name=None, admins=[make_admin(authentication_profile=None)]
        )
        assert check.check_passed is False
        assert (
            check.check_message
            == "Minimum Password Complexity Settings are not configured correctly."
        )

    @pytest.mark.failing
    def test_no_pw_prof(self, admin_analyzer, make_admin):
        check = admin_analyzer._check_admin_auth_on_device(
            template_name=None,
            admins=[make_admin(authentication_profile=None, password_profile=None)],
        )
        assert check.check_passed is False
        assert (
            check.check_message
            == "The following local admins are not using a password profile: ***mmy."
        )

    @pytest.mark.failing
    def test_bad_change_period(self, model_manager, admin_analyzer, make_admin):
        manager_ref = weakref.ref(model_manager)
        # Mocking PasswordProfileModel's password_change_period
        manager_ref().get().find().password_change_period = "0"
        check = admin_analyzer._check_admin_auth_on_device(
            template_name=None,
            admins=[
                make_admin(
                    authentication_profile=None,
                    password_profile="p1",
                    model_manager=model_manager,
                )
            ],
        )
        assert check.check_passed is False
        assert (
            check.check_message
            == "The following local admins as using a password profile with a Required Password Change Period not set to 90 days: ***mmy."
        )

    @pytest.mark.xfail(reason="Failing this")
    @pytest.mark.passing
    def test_passing(self, model_manager, admin_analyzer, make_admin):
        manager_ref = weakref.ref(model_manager)
        # Mocking PasswordProfileModel's password_change_period
        manager_ref().get().find().password_change_period = "90"
        check = admin_analyzer._check_admin_auth_on_device(
            template_name=None,
            admins=[
                make_admin(
                    authentication_profile=None,
                    password_profile="p1",
                    model_manager=model_manager,
                )
            ],
        )
        assert check.check_passed is True
        assert check.check_type == "Warning"


class Test_check_admin_server_profile:
    @pytest.mark.note
    def test_none(self, admin_analyzer_with_profiles, make_admin_with_profiles):
        assert (
            admin_analyzer_with_profiles._check_admin_server_profile(
                template_name=None,
                admins=[
                    make_admin_with_profiles(authentication_profile="Auth-Prof-1"),
                    make_admin_with_profiles(authentication_profile="Auth-Prof-3"),
                ],
            )
            is None
        )

    @pytest.mark.note
    def test_caution(self, admin_analyzer_with_profiles, make_admin_with_profiles):
        assert (
            admin_analyzer_with_profiles._check_admin_server_profile(
                template_name=None,
                admins=[
                    make_admin_with_profiles(authentication_profile="Auth-Prof-2"),
                    make_admin_with_profiles(authentication_profile="Auth-Prof-3"),
                    make_admin_with_profiles(authentication_profile="Auth-Prof-4"),
                ],
            ).check_severity
            == "Caution"
        )
