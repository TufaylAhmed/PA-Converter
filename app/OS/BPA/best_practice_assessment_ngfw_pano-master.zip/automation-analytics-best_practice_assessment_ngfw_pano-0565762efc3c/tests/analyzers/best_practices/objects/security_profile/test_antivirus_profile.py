import weakref
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeNote
from bpa.analyzers.best_practices.objects.security_profile.antivirus_profile import (
    AntivirusProfileAnalyzer,
)
from bpa.models.objects.security_profile.antivirus_profile import (
    AntivirusProfileModel,
    AntivirusDecoder,
)
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_models(model_manager):
        model_manager.tree = MagicMock()

    return model_manager_factory(populate_models=populate_models)


@pytest.fixture
def antivirus_profile(model_manager):
    def _antivirus_profile(**overrides):
        return build_model(AntivirusProfileModel, model_manager, **overrides)

    return _antivirus_profile


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = AntivirusProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestAntivirusProfileAnalyzer:

    """check_threat_exceptions_note"""

    @pytest.mark.passing
    def test_check_threat_exceptions_passing(self, analyzer, antivirus_profile):
        assert (
            analyzer._check_threat_exceptions_note(
                antivirus_profile(threat_exceptions=[])
            )
            is None
        )

    @pytest.mark.failing
    def test_check_threat_exceptions_failing(self, analyzer, antivirus_profile):
        check_result = analyzer._check_threat_exceptions_note(
            antivirus_profile(threat_exceptions=["test_threat"])
        )
        assert isinstance(check_result, BestPracticeNote)
        assert check_result.check_severity == "Caution"

    """check_application_exceptions_note"""

    @pytest.mark.passing
    def test_check_application_exceptions_passing(self, analyzer, antivirus_profile):
        assert (
            analyzer._check_application_exceptions_note(
                antivirus_profile(application_exceptions=[])
            )
            is None
        )

    @pytest.mark.failing
    def test_check_application_exceptions_failing(self, analyzer, antivirus_profile):
        check_result = analyzer._check_application_exceptions_note(
            antivirus_profile(application_exceptions=["test_app"])
        )
        assert isinstance(check_result, BestPracticeNote)
        assert check_result.check_severity == "Caution"

    """check_decoders_action"""

    @pytest.mark.passing
    def test_check_decoders_action_passing(self, analyzer, antivirus_profile):
        assert (
            analyzer._check_decoders_action(
                antivirus_profile(
                    decoders=[
                        AntivirusDecoder(
                            name="smtp", action="drop", wildfire_action=""
                        ),
                        AntivirusDecoder(
                            name="smb", action="reset-both", wildfire_action=""
                        ),
                        AntivirusDecoder(
                            name="ftp", action="reset-client", wildfire_action=""
                        ),
                        AntivirusDecoder(
                            name="http", action="reset-server", wildfire_action=""
                        ),
                        AntivirusDecoder(
                            name="http2", action="reset-server", wildfire_action=""
                        ),
                    ]
                )
            ).check_passed
            is True
        )

    @pytest.mark.failing
    def test_check_decoders_action_failing(self, analyzer, antivirus_profile):
        assert (
            analyzer._check_decoders_action(
                antivirus_profile(
                    decoders=[
                        AntivirusDecoder(
                            name="smtp", action="not-passing-action", wildfire_action=""
                        ),
                        AntivirusDecoder(
                            name="smb", action="not-passing-action", wildfire_action=""
                        ),
                        AntivirusDecoder(
                            name="ftp", action="not-passing-action", wildfire_action=""
                        ),
                        AntivirusDecoder(
                            name="http", action="not-passing-action", wildfire_action=""
                        ),
                        AntivirusDecoder(
                            name="http2",
                            action="not-passing-action",
                            wildfire_action="",
                        ),
                    ]
                )
            ).check_passed
            is False
        )

    """check_decoders_wildfire_action"""

    @pytest.mark.passing
    def test_check_decoders_wildfire_action_passing(self, analyzer, antivirus_profile):

        assert (
            analyzer._check_decoders_wildfire_action(
                antivirus_profile(
                    decoders=[
                        AntivirusDecoder(
                            name="imap", action="reset-both", wildfire_action="alert"
                        ),
                        AntivirusDecoder(
                            name="pop3", action="drop", wildfire_action="alert"
                        ),
                        AntivirusDecoder(
                            name="ftp", action="reset-client", wildfire_action="drop"
                        ),
                    ]
                )
            ).check_passed
            is True
        )

    @pytest.mark.failing
    def test_check_decoders_wildfire_action_failing(self, analyzer, antivirus_profile):
        assert (
            analyzer._check_decoders_wildfire_action(
                antivirus_profile(
                    decoders=[
                        AntivirusDecoder(
                            name="ftp", action="reset-both", wildfire_action="alert"
                        ),
                        AntivirusDecoder(
                            name="http", action="drop", wildfire_action="alert"
                        ),
                        AntivirusDecoder(
                            name="smtp", action="reset-client", wildfire_action="alert"
                        ),
                    ]
                )
            ).check_passed
            is False
        )

    """check_packet_capture"""

    @pytest.mark.passing
    def test_check_packet_capture_passing(self, analyzer, antivirus_profile):

        assert isinstance(
            analyzer._check_packet_capture(
                antivirus_profile(packet_capture_enabled=True)
            ),
            BestPracticeNote,
        )

    @pytest.mark.failing
    def test_check_packet_capture_failing(self, analyzer, antivirus_profile):
        assert (
            analyzer._check_packet_capture(
                antivirus_profile(packet_capture_enabled=False)
            )
            is None
        )

    """check_reset_action_note"""

    @pytest.mark.passing
    def test_check_reset_action_note_passing(self, analyzer, antivirus_profile):
        check_result = analyzer._check_reset_action_note(
            antivirus_profile(
                decoders=[
                    AntivirusDecoder(
                        name="ftp", action="reset-both", wildfire_action="alert"
                    ),
                    AntivirusDecoder(
                        name="http", action="drop", wildfire_action="alert"
                    ),
                ]
            )
        )
        assert check_result is None

    @pytest.mark.failing
    def test_check_reset_action_note_failing(self, analyzer, antivirus_profile):
        check_result = analyzer._check_reset_action_note(
            antivirus_profile(
                decoders=[
                    AntivirusDecoder(
                        name="ftp", action="reset-both", wildfire_action="alert"
                    ),
                    AntivirusDecoder(
                        name="http", action="drop", wildfire_action="alert"
                    ),
                    AntivirusDecoder(
                        name="smtp", action="reset-client", wildfire_action="alert"
                    ),
                ]
            )
        )
        assert isinstance(check_result, BestPracticeNote)
        assert check_result.check_severity == "Info"
