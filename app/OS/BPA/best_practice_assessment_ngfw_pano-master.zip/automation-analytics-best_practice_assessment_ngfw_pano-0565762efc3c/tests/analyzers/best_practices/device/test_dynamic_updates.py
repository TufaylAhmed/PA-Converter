from unittest.mock import MagicMock
import weakref

import pendulum
import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeWarning, BestPracticeNote
from bpa.analyzers.best_practices.device.dynamic_updates import DynamicUpdatesAnalyzer
from bpa.models.device.dynamic_updates import DynamicUpdatesModel, UpdateType
from bpa.models.system import SystemInfo
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.ngfw = True
        model_manager.tree.version = 8.1

    def populate_other(model_manager):
        model_manager.system_info = SystemInfo()
        model_manager.system_time = pendulum.now()

    return model_manager_factory(
        populate_tree=populate_tree, populate_other=populate_other
    )


@pytest.fixture
def dynamic_updates_pass(model_manager):

    anti_virus = UpdateType(
        recurrence="hourly",
        action="download-and-install",
        sync_to_peer=True,
        threshold=0,
    )
    threats = UpdateType(
        recurrence="every-30-mins",
        action="download-and-install",
        sync_to_peer=True,
        threshold=30,
        new_app_threshold=8,
    )
    wildfire = UpdateType(
        recurrence="every-min", action="download-and-install", sync_to_peer=True
    )
    global_protect = UpdateType(
        recurrence="hourly", action="download-and-install", sync_to_peer=True
    )
    gp_clientless_vpn = UpdateType(
        recurrence="hourly", action="download-and-install", sync_to_peer=True
    )
    return build_model(
        DynamicUpdatesModel,
        model_manager,
        update_types={
            "anti-virus": anti_virus,
            "threats": threats,
            "wildfire": wildfire,
            "global-protect-datafile": global_protect,
            "global-protect-clientless-vpn": gp_clientless_vpn,
        },
        template_name=None,
    )


@pytest.fixture
def dynamic_updates_fail(model_manager):

    anti_virus = UpdateType(
        recurrence="daily", action="download", sync_to_peer=False, threshold=10
    )
    threats = UpdateType(
        recurrence="weekly",
        action="download",
        sync_to_peer=False,
        threshold=30,
        new_app_threshold=0,
    )
    wildfire = UpdateType(recurrence="daily", action="download", sync_to_peer=True)
    global_protect = UpdateType(
        recurrence="daily", action="download", sync_to_peer=True
    )
    gp_clientless_vpn = UpdateType(
        recurrence="daily", action="download", sync_to_peer=True
    )
    return build_model(
        DynamicUpdatesModel,
        model_manager,
        update_types={
            "anti-virus": anti_virus,
            "threats": threats,
            "wildfire": wildfire,
            "global-protect-datafile": global_protect,
            "global-protect-clientless-vpn": gp_clientless_vpn,
        },
        template_name=None,
    )


@pytest.fixture
def dynamic_updates(model_manager):
    def _dynamic_updates(**overrides):
        return build_model(DynamicUpdatesModel, model_manager, **overrides)

    return _dynamic_updates


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = DynamicUpdatesAnalyzer(manager_ref, check_info)
    return analyzer


class TestUserIdAnalyzer:
    """
    NOTE: For Dynamic Updates tests, please refer to the dynamic_updates_pass and
    dynamic_updates_fail fixtures above for the correect values.
    """

    """check_anti_virus"""

    @pytest.mark.passing
    def test_check_anti_virus_passing(self, analyzer, dynamic_updates_pass):
        assert analyzer._check_anti_virus(dynamic_updates_pass).check_passed

    @pytest.mark.failing
    def test_check_anti_virus_failing(self, analyzer, dynamic_updates_fail):
        assert not analyzer._check_anti_virus(dynamic_updates_fail).check_passed

    """check_anti_virus_note"""

    @pytest.mark.note
    def test_check_anti_virus_note(self, analyzer, dynamic_updates_pass):
        assert analyzer._check_anti_virus_note(dynamic_updates_pass)

    @pytest.mark.note
    def test_check_anti_virus_note_none(self, analyzer, dynamic_updates):
        assert not analyzer._check_anti_virus_note(
            dynamic_updates(update_types={"anti-virus": None})
        )

    """check_apps_threats"""

    @pytest.mark.passing
    def test_check_apps_threats_passing(self, analyzer, dynamic_updates_pass):
        assert analyzer._check_apps_threats(dynamic_updates_pass).check_passed

    @pytest.mark.failing
    def test_check_apps_threats_failing(self, analyzer, dynamic_updates_fail):
        assert not analyzer._check_apps_threats(dynamic_updates_fail).check_passed

    """check_apps_threats_note"""

    @pytest.mark.note
    def test_check_apps_threats_note(self, analyzer, dynamic_updates_pass):
        assert analyzer._check_apps_threats_note(dynamic_updates_pass)

    @pytest.mark.note
    def test_check_apps_threats_note_none(self, analyzer, dynamic_updates):
        assert not analyzer._check_apps_threats_note(
            dynamic_updates(update_types={"threats": None})
        )

    """check_wildfire"""

    @pytest.mark.passing
    def test_check_wildfire_passing(self, analyzer, dynamic_updates_pass):
        assert analyzer._check_wildfire(dynamic_updates_pass).check_passed

    @pytest.mark.failing
    def test_check_wildfire_failing(self, analyzer, dynamic_updates_fail):
        assert not analyzer._check_wildfire(dynamic_updates_fail).check_passed

    """check_global_protect"""

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_global_protect_passing(self, analyzer, dynamic_updates_pass):
        assert analyzer._check_global_protect(dynamic_updates_pass).check_passed

    @pytest.mark.integration
    @pytest.mark.failing
    def test_check_global_protect_failing(self, analyzer, dynamic_updates_fail):
        assert not analyzer._check_global_protect(dynamic_updates_fail).check_passed

    """check_gp_clientless_vpn"""

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_gp_clientless_vpn_passing(self, analyzer, dynamic_updates_pass):
        assert analyzer._check_gp_clientless_vpn(dynamic_updates_pass).check_passed

    @pytest.mark.integration
    @pytest.mark.failing
    def test_check_gp_clientless_vpn_failing(self, analyzer, dynamic_updates_fail):
        assert not analyzer._check_gp_clientless_vpn(dynamic_updates_fail).check_passed

    """check_apps_and_threats_app_id_threshold"""

    @pytest.mark.integration
    @pytest.mark.passing
    def test_check_apps_and_threats_app_id_threshold_passing(
        self, analyzer, dynamic_updates_pass
    ):
        assert analyzer._check_apps_and_threats_app_id_threshold(
            dynamic_updates_pass
        ).check_passed

    @pytest.mark.integration
    @pytest.mark.failing
    def test_check_apps_and_threats_app_id_threshold_failing(
        self, analyzer, dynamic_updates_fail
    ):
        assert not analyzer._check_apps_and_threats_app_id_threshold(
            dynamic_updates_fail
        ).check_passed


class Test_dynamic_updates_get_checks:
    def test_use_all_checks_when_not_ngfw(self, check_info):
        manager = MagicMock()
        manager().tree.ngfw = False
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        assert len(analyzer.get_checks()) == len(
            [_ for _ in dir(analyzer) if _.startswith("_check")]
        )

    @pytest.mark.parametrize(
        "target_license, target_checks",
        [
            ("WildFire License", {"_check_wildfire"}),
            (
                "Threat Prevention",
                {
                    "_check_anti_virus",
                    "_check_anti_virus_note",
                    "_check_apps_threats",
                    "_check_apps_threats_note",
                    "_check_apps_and_threats_app_id_threshold",
                },
            ),
        ],
    )
    def test_ngfw_wf_and_threat_checks(self, check_info, target_license, target_checks):
        manager = MagicMock()
        manager().tree.ngfw = True
        manager().license_info.has_active_license.side_effect = (
            lambda name: name == target_license
        )
        manager().license_info.has_active_gp_license.return_value = False
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        assert (
            len(target_checks - {check.__name__ for check in analyzer.get_checks()})
            == 0
        )

    @pytest.mark.parametrize(
        "active_gp_license, run_checks", [(True, True), (False, False)]
    )
    def test_ngfw_gp_checks(self, check_info, active_gp_license, run_checks):
        manager = MagicMock()
        manager().tree.ngfw = True
        manager().license_info.has_active_license.return_value = False
        manager().license_info.has_active_gp_license.return_value = active_gp_license
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        check_names = [_.__name__ for _ in analyzer.get_checks()]
        assert (
            all(
                _ in check_names
                for _ in ["_check_global_protect", "_check_gp_clientless_vpn"]
            )
            is run_checks
        )


class Test_check_anti_virus_content_note:
    def test_none_if_template(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        updates = MagicMock(template_name="temp1")
        assert analyzer._check_anti_virus_content_note(updates) is None

    def test_none_if_no_content_delta(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        analyzer.content_deltas = {}
        updates = MagicMock(template_name=None)
        assert analyzer._check_anti_virus_content_note(updates) is None

    def test_warning_threshold(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        analyzer.content_deltas = {"av-release-date": (86400 * 7) + 1}
        updates = MagicMock(template_name=None)
        check = analyzer._check_anti_virus_content_note(updates)
        assert isinstance(check, BestPracticeWarning)

    def test_note_threshold(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        analyzer.content_deltas = {"av-release-date": (86400 * 1) + 1}
        updates = MagicMock(template_name=None)
        check = analyzer._check_anti_virus_content_note(updates)
        assert isinstance(check, BestPracticeNote)

    def test_skip_threshold(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        analyzer.content_deltas = {"av-release-date": (86400 * 1) - 1}
        updates = MagicMock(template_name=None)
        check = analyzer._check_anti_virus_content_note(updates)
        assert check is None


class Test_check_apps_threats_content_note:
    def test_none_if_template(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        updates = MagicMock(template_name="temp1")
        assert analyzer._check_apps_threats_content_note(updates) is None

    def test_none_if_no_content_delta(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        analyzer.content_deltas = {}
        updates = MagicMock(template_name=None)
        assert analyzer._check_apps_threats_content_note(updates) is None

    def test_warning_threshold(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        analyzer.content_deltas = {"app-release-date": (86400 * 30) + 1}
        updates = MagicMock(template_name=None)
        check = analyzer._check_apps_threats_content_note(updates)
        assert isinstance(check, BestPracticeWarning)

    def test_note_threshold(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        analyzer.content_deltas = {"app-release-date": (86400 * 7) + 1}
        updates = MagicMock(template_name=None)
        check = analyzer._check_apps_threats_content_note(updates)
        assert isinstance(check, BestPracticeNote)

    def test_skip_threshold(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        analyzer.content_deltas = {"app-release-date": (86400 * 7) - 1}
        updates = MagicMock(template_name=None)
        check = analyzer._check_apps_threats_content_note(updates)
        assert check is None


class Test_check_wildfire_content_note:
    def test_none_if_template(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        updates = MagicMock(template_name="temp1")
        assert analyzer._check_wildfire_content_note(updates) is None

    def test_none_if_no_content_delta(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        analyzer.content_deltas = {}
        updates = MagicMock(template_name=None)
        assert analyzer._check_wildfire_content_note(updates) is None

    def test_warning_threshold(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        analyzer.content_deltas = {"wildfire-release-date": (86400 * 1) + 1}
        updates = MagicMock(template_name=None)
        check = analyzer._check_wildfire_content_note(updates)
        assert isinstance(check, BestPracticeWarning)

    def test_skip_threshold(self, check_info):
        manager = MagicMock()
        analyzer = DynamicUpdatesAnalyzer(manager, check_info)
        analyzer.content_deltas = {"wildfire-release-date": (86400 * 1) - 1}
        updates = MagicMock(template_name=None)
        check = analyzer._check_wildfire_content_note(updates)
        assert check is None
