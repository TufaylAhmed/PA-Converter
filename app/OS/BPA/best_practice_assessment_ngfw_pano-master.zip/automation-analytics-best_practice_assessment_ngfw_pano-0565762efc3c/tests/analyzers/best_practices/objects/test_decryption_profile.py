# -*- coding: utf-8 -*-
from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.objects.decryption_profile import (
    DecryptionProfileAnalyzer,
)
from bpa.models.objects.decryption_profile import (
    DecryptionProfileModel,
    SSLForwardProxy,
    SSLInboundInspection,
    SSLProtocolSettings,
    NoDecryption,
    SSHProxy,
)
from bpa.models.manager import ModelManager


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager = ModelManager()
        model_manager.tree = MagicMock()
        model_manager.tree.version = 8

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def model_instance(model_manager):
    prof = DecryptionProfileModel(
        location=None,
        model_manager=model_manager,
        name="Decryption Profile-BP",
        ssl_forward_proxy=SSLForwardProxy(
            block_expired_certificate=True,
            block_untrusted_issuer=True,
            block_unknown_cert=True,
            block_unsupported_version=True,
            block_unsupported_cipher=False,
            block_client_cert=True,
            block_if_no_resource=True,
            block_if_hsm_unavailable=True,
            strip_alpn=False,
        ),
        ssl_inbound_inspection=SSLInboundInspection(
            block_unsupported_version=True,
            block_unsupported_cipher=True,
            block_if_no_resource=False,
            block_if_hsm_unavailable=True,
        ),
        ssl_protocol_settings=SSLProtocolSettings(
            min_version="tls1-1",
            max_version="tls1-2",
            enc_algo_3des=True,
            enc_algo_rc4=True,
            enc_algo_aes_128_cbc=False,
            enc_algo_aes_256_cbc=True,
            enc_algo_aes_128_gcm=False,
            enc_algo_aes_256_gcm=False,
            auth_algo_sha1=True,
            auth_algo_md5=False,
            auth_algo_sha256=False,
            auth_algo_sha384=False,
            keyxchg_algo_rsa=True,
            keyxchg_algo_dhe=True,
            keyxchg_algo_ecdhe=True,
        ),
        no_decryption=NoDecryption(
            block_expired_certificate=True, block_untrusted_issuer=False
        ),
        ssh_proxy=SSHProxy(
            block_unsupported_version=False,
            block_unsupported_alg=True,
            block_ssh_errors=True,
            block_if_no_resource=False,
        ),
    )
    return prof


@pytest.mark.failing
def test_decryption_analyzer_failing(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    prof = model_instance
    analyzer = DecryptionProfileAnalyzer(manager_ref, check_info)
    assert not analyzer._check_ssl_forward_proxy(prof).check_passed
    assert not analyzer._check_ssl_inbound_inspection(prof).check_passed
    assert not analyzer._check_ssl_protocol_settings(prof).check_passed
    assert not analyzer._check_no_decryption(prof).check_passed
    assert not analyzer._check_ssh_proxy(prof).check_passed


@pytest.mark.passing
def test_decryption_analyzer_passing(model_instance, model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = DecryptionProfileAnalyzer(manager_ref, check_info)

    prof = model_instance
    prof.ssl_forward_proxy.block_unsupported_cipher = True
    prof.ssl_forward_proxy.block_if_no_resource = False
    prof.ssl_forward_proxy.block_if_hsm_unavailable = False
    assert analyzer._check_ssl_forward_proxy(prof).check_passed

    prof.ssl_inbound_inspection.block_if_hsm_unavailable = False
    assert analyzer._check_ssl_inbound_inspection(prof).check_passed

    prof.ssl_protocol_settings.auth_algo_md5 = False
    prof.ssl_protocol_settings.auth_algo_sha1 = False
    prof.ssl_protocol_settings.min_version = "tls1-2"
    prof.ssl_protocol_settings.max_version = "max"
    prof.ssl_protocol_settings.enc_algo_3des = False
    prof.ssl_protocol_settings.enc_algo_rc4 = False
    prof.ssl_protocol_settings.enc_algo_aes_128_cbc = True
    prof.ssl_protocol_settings.enc_algo_aes_128_gcm = True
    prof.ssl_protocol_settings.enc_algo_aes_256_gcm = True
    prof.ssl_protocol_settings.auth_algo_sha256 = True
    prof.ssl_protocol_settings.auth_algo_sha384 = True
    assert analyzer._check_ssl_protocol_settings(prof).check_passed

    prof.no_decryption.block_untrusted_issuer = True
    assert analyzer._check_no_decryption(prof).check_passed

    prof.ssh_proxy.block_unsupported_version = True
    prof.ssh_proxy.block_if_no_resource = True
    assert analyzer._check_ssh_proxy(prof).check_passed
