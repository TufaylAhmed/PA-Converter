import weakref

import pytest

from bpa.analyzers.best_practices.device.server_profiles import (
    SnmpTrapServerProfileAnalyzer,
)
from bpa.models.device.server_profiles import SnmpTrapServerProfileModel
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def snmp_trap_server_profile(model_manager):
    def _snmp_trap_server_profile(**overrides):
        return build_model(SnmpTrapServerProfileModel, model_manager, **overrides)

    return _snmp_trap_server_profile


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = SnmpTrapServerProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestSnmpServerProfileAnalyzer:

    """check_version"""

    @pytest.mark.passing
    def test_check_version_passing(self, analyzer, snmp_trap_server_profile):
        assert analyzer._check_version(
            snmp_trap_server_profile(version="V3")
        ).check_passed

    @pytest.mark.failing
    def test_check_version_failing(self, analyzer, snmp_trap_server_profile):
        assert not analyzer._check_version(
            snmp_trap_server_profile(version="v2c")
        ).check_passed

    """check_admin_password_profile"""

    @pytest.mark.passing
    def test_check_admin_password_profile_passing(
        self, analyzer, snmp_trap_server_profile
    ):
        assert analyzer._check_admin_password_profile(
            snmp_trap_server_profile(community="Internal")
        ).check_passed

    @pytest.mark.failing
    def test_check_admin_password_profile_failing(
        self, analyzer, snmp_trap_server_profile
    ):
        assert not analyzer._check_admin_password_profile(
            snmp_trap_server_profile(community="PUBLIC")
        ).check_passed
