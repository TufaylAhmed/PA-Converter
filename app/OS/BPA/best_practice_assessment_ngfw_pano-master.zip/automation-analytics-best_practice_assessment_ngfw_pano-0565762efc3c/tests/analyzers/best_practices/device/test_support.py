# -*- coding: utf-8 -*-
import datetime
import weakref

import pytest

from bpa.analyzers.best_practices.device.support import SupportAnalyzer
from bpa.analyzers.best_practices.manager import BestPracticesAnalyzerManager
from bpa.analyzers.best_practices.bp_check import BestPracticeNote
from bpa.models.license import License, LicenseInfo

from unittest.mock import Mock


check_info = BestPracticesAnalyzerManager.get_check_info()


class Test_check_support_license_note:
    @pytest.mark.none
    def test_skip_if_active_license(self):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.tree.version = 8.1
        lics = LicenseInfo()
        supp_lic = License(
            "Premium",
            "dummy",
            "123",
            datetime.date(2019, 5, 1),
            datetime.date(9999, 7, 1),
        )
        lics.add(supp_lic)
        model_manager.license_info = lics
        manager_ref = weakref.ref(model_manager)
        analyzer = SupportAnalyzer(manager_ref, check_info)
        check = analyzer._check_support_license_note()
        assert check is None

    @pytest.mark.none
    def test_skip_if_panorama(self):
        model_manager = Mock()
        model_manager.tree.panorama = True
        manager_ref = weakref.ref(model_manager)
        analyzer = SupportAnalyzer(manager_ref, check_info)
        check = analyzer._check_support_license_note()
        assert check is None

    @pytest.mark.none
    def test_note_if_no_active_license(self):
        model_manager = Mock()
        model_manager.tree.panorama = False
        model_manager.tree.version = 8.0
        model_manager.license_info = LicenseInfo()
        manager_ref = weakref.ref(model_manager)
        analyzer = SupportAnalyzer(manager_ref, check_info)
        check = analyzer._check_support_license_note()
        assert isinstance(check, BestPracticeNote)
