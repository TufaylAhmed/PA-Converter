# -*- coding: utf-8 -*-
from unittest.mock import MagicMock
import weakref

import pytest

from bpa.analyzers.best_practices.bp_check import BestPracticeNote
from bpa.analyzers.best_practices.objects.application_tag import ApplicationTagAnalyzer
from bpa.models.monitor.pdf_reports.user_activity_report import UserActivityReportModel
from bpa.models.objects.application_tag import ApplicationTagModel
from tests.utils.models.base import build_skeleton


@pytest.fixture
def model_manager(model_manager_factory):
    def populate_tree(model_manager):
        model_manager.tree = MagicMock()
        model_manager.tree.version = 7.1

    return model_manager_factory(populate_tree=populate_tree)


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    return ApplicationTagAnalyzer(manager_ref, check_info)


@pytest.mark.parametrize(
    "tags,expected",
    [
        ([], False),
        (["garbage", "tags", "here"], False),
        (["Sanctioned"], True),
        (["garbage", "tags", "here", "Sanctioned"], True),
    ],
)
def test_check_sanctioned_app(analyzer, tags, expected):
    apps = {"mail": build_skeleton(ApplicationTagModel, name="mail", tags=tags)}
    assert analyzer._check_sanctioned_app(apps).check_passed is expected


@pytest.mark.note
class Test_check_saas_report:
    def test_no_apps(self, analyzer):
        assert analyzer._check_saas_report(apps={}, reports={}) is None

    def test_apps_and_saas_report(self, analyzer):
        apps = {
            "mail": build_skeleton(
                ApplicationTagModel, name="mail", tags=["Sanctioned"]
            )
        }
        reports = {
            "saas": build_skeleton(
                UserActivityReportModel,
                name="saas",
                report_type="saas-application-usage-report",
            )
        }
        assert analyzer._check_saas_report(apps=apps, reports=reports) is None

    def test_apps_no_saas_report(self, analyzer):
        apps = {
            "mail": build_skeleton(
                ApplicationTagModel, name="mail", tags=["Sanctioned"]
            )
        }
        check = analyzer._check_saas_report(apps=apps, reports={})
        assert check is not None
        assert isinstance(check, BestPracticeNote)
