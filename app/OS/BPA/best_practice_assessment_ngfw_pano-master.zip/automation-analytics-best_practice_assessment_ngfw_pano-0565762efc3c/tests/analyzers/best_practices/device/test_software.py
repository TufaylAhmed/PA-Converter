# -*- coding: utf-8 -*-
import weakref
from datetime import date
from unittest.mock import MagicMock

import pytest

from bpa.analyzers.best_practices.device.software import SoftwareAnalyzer
from bpa.models.utils.software import EOL
from bpa.analyzers.best_practices.bp_check import BestPracticeWarning, BestPracticeNote


@pytest.fixture
def model_manager(model_manager_factory):

    return model_manager_factory()


def test_eol_version_none(model_manager, check_info):
    model_manager.tree = MagicMock(version=100.0)
    model_manager.is_eol = (False, "Unknown")
    manager_ref = weakref.ref(model_manager)
    analyzer = SoftwareAnalyzer(manager_ref, check_info)
    assert analyzer._check_version_eol() is None


@pytest.mark.note
def test_eol_version_note(model_manager, check_info):
    model_manager.tree = MagicMock(version=7.0)
    model_manager.is_eol = (True, EOL["7.0"])
    manager_ref = weakref.ref(model_manager)
    analyzer = SoftwareAnalyzer(manager_ref, check_info)
    check = analyzer._check_version_eol()
    assert check.check_type == "Note"
    assert check.check_severity == "Caution"


@pytest.mark.parametrize(
    "days_since_release,check_type,passing",
    [
        (179, BestPracticeWarning, True),
        (180, BestPracticeNote, None),
        (365, BestPracticeNote, None),
        (366, BestPracticeWarning, False),
    ],
)
def test_check_old_version_passing(
    monkeypatch, model_manager, check_info, days_since_release, check_type, passing
):
    def mockreturn(version, release_dates):
        assert isinstance(version, str)
        assert isinstance(release_dates, dict)
        return (date.today(), days_since_release)

    monkeypatch.setattr(
        "bpa.analyzers.best_practices.device.software.get_release_date_info", mockreturn
    )
    model_manager.tree = MagicMock(version=9.0, _version="9.0.0")
    model_manager.is_eol = (True, EOL["9.0"])
    model_manager.release_dates = {}
    manager_ref = weakref.ref(model_manager)
    analyzer = SoftwareAnalyzer(manager_ref, check_info)
    check = analyzer._check_old_version()
    assert isinstance(check, check_type)
    if type(check) == BestPracticeNote:
        assert check.check_severity == "Caution"
    else:
        assert check.check_passed == passing
