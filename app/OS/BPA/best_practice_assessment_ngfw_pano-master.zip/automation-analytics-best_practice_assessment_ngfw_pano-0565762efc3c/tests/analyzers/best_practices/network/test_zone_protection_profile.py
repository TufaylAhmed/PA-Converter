import weakref

import pytest

from bpa.analyzers.best_practices.network.zone_protection_profile import (
    ZoneProtectionProfileAnalyzer,
)
from bpa.models.network.zone_protection_profile import (
    ZoneProtectionProfileModel,
    ReconnaissanceProtection,
    FloodProtection,
    FloodProtectionFeature,
    PacketBasedAttackProtection,
    TcpDrop,
)
from tests.utils.models.base import build_model, build_skeleton


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def zone_protection_profile(model_manager):
    def _zone_protection_profile(**overrides):
        return build_model(ZoneProtectionProfileModel, model_manager, **overrides)

    return _zone_protection_profile


@pytest.fixture
def packet_based_attack_protection():
    def _packet_based_attack_protection(**overrides):
        return build_skeleton(PacketBasedAttackProtection, **overrides)

    return _packet_based_attack_protection


@pytest.fixture
def tcp_drop():
    def _tcp_drop(**overrides):
        return build_skeleton(TcpDrop, **overrides)

    return _tcp_drop


@pytest.fixture
def flood_protection():
    def _flood_protection(**overrides):
        return build_skeleton(FloodProtection, **overrides)

    return _flood_protection


@pytest.fixture
def flood_protection_feature():
    def _flood_protection_feature(**overrides):
        return build_skeleton(FloodProtectionFeature, **overrides)

    return _flood_protection_feature


@pytest.fixture
def reconnaissance_protection():
    def _reconnaissance_protection(**overrides):
        return build_skeleton(ReconnaissanceProtection, **overrides)

    return _reconnaissance_protection


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = ZoneProtectionProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestZoneProtectionProfileAnalyzer:

    """check_flood_protection"""

    @pytest.mark.passing
    def test_check_flood_protection_passing(
        self,
        analyzer,
        zone_protection_profile,
        flood_protection,
        flood_protection_feature,
    ):
        attrs = {"enabled": True, "alert": 10001, "activate": 10001, "maximum": 40001}
        assert analyzer._check_flood_protection(
            zone_protection_profile(
                flood_protection=flood_protection(
                    tcp_syn=flood_protection_feature(**attrs),
                    icmp=flood_protection_feature(**attrs),
                    icmp_v6=flood_protection_feature(**attrs),
                    other_ip=flood_protection_feature(**attrs),
                    udp=flood_protection_feature(**attrs),
                )
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_flood_protection_failing(
        self,
        analyzer,
        zone_protection_profile,
        flood_protection,
        flood_protection_feature,
    ):
        attrs = {"enabled": False, "alert": 10000, "activate": 10000, "maximum": 40000}
        assert not analyzer._check_flood_protection(
            zone_protection_profile(
                flood_protection=flood_protection(
                    tcp_syn=flood_protection_feature(**attrs),
                    icmp=flood_protection_feature(**attrs),
                    icmp_v6=flood_protection_feature(**attrs),
                    other_ip=flood_protection_feature(**attrs),
                    udp=flood_protection_feature(**attrs),
                )
            )
        ).check_passed

    """check_reconnaissance_protection"""

    @pytest.mark.passing
    def test_check_reconnaissance_protection_passing(
        self, analyzer, zone_protection_profile, reconnaissance_protection
    ):
        attrs = {
            "tcp_port_scan_enabled": True,
            "host_sweep_enabled": True,
            "udp_port_scan_enabled": True,
        }
        assert analyzer._check_reconnaissance_protection(
            zone_protection_profile(
                reconnaissance_protection=reconnaissance_protection(**attrs)
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_reconnaissance_protection_failing(
        self, analyzer, zone_protection_profile, reconnaissance_protection
    ):
        attrs = {
            "tcp_port_scan_enabled": False,
            "host_sweep_enabled": False,
            "udp_port_scan_enabled": False,
        }
        assert not analyzer._check_reconnaissance_protection(
            zone_protection_profile(
                reconnaissance_protection=reconnaissance_protection(**attrs)
            )
        ).check_passed

    """check_packet_based_attack_protection"""

    @pytest.mark.passing
    def test_check_packet_based_attack_protection_passing(
        self,
        analyzer,
        zone_protection_profile,
        packet_based_attack_protection,
        tcp_drop,
    ):
        attrs = {
            "mismatched_overlapping_tcp_segment": True,
            "tcp_syn_with_data": True,
            "tcp_synack_with_data": True,
            "strip_tcp_timestamp": True,
        }
        assert analyzer._check_packet_based_attack_protection(
            zone_protection_profile(
                packet_based_attack_protection=packet_based_attack_protection(
                    ip_option_drop_malformed=True, tcp_drop=tcp_drop(**attrs)
                )
            )
        ).check_passed

    @pytest.mark.failing
    def test_check_packet_based_attack_protection_failing(
        self,
        analyzer,
        zone_protection_profile,
        packet_based_attack_protection,
        tcp_drop,
    ):
        attrs = {
            "mismatched_overlapping_tcp_segment": False,
            "tcp_syn_with_data": False,
            "tcp_synack_with_data": False,
            "strip_tcp_timestamp": False,
        }
        assert not analyzer._check_packet_based_attack_protection(
            zone_protection_profile(
                packet_based_attack_protection=packet_based_attack_protection(
                    ip_option_drop_malformed=False, tcp_drop=tcp_drop(**attrs)
                )
            )
        ).check_passed
