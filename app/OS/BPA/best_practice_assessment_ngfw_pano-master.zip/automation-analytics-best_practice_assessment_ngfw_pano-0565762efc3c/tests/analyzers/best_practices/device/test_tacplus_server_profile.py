import weakref

import pytest

from bpa.analyzers.best_practices.device.server_profiles import (
    TacPlusServerProfileAnalyzer,
)
from bpa.models.device.server_profiles import TacPlusServerProfileModel
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def tac_plus_server_profile(model_manager):
    def _tac_plus_server_profile(**overrides):
        return build_model(TacPlusServerProfileModel, model_manager, **overrides)

    return _tac_plus_server_profile


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = TacPlusServerProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestTacPlusServerProfileAnalyzer:

    """check_protocol"""

    @pytest.mark.passing
    def test_check_protocol_passing(self, analyzer, tac_plus_server_profile):
        assert analyzer._check_protocol(
            tac_plus_server_profile(protocol="CHAP")
        ).check_passed

    @pytest.mark.failing
    def test_check_protocol_failing(self, analyzer, tac_plus_server_profile):
        assert not analyzer._check_protocol(
            tac_plus_server_profile(protocol="EAP-TTLS-with-PAP")
        ).check_passed
