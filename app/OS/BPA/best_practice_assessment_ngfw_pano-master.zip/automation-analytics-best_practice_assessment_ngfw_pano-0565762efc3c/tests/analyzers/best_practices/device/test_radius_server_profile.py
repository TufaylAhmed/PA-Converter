import weakref

import pytest

from bpa.analyzers.best_practices.device.server_profiles import (
    RadiusServerProfileAnalyzer,
)
from bpa.models.device.server_profiles import RadiusServerProfileModel
from tests.utils.models.base import build_model


@pytest.fixture
def model_manager(model_manager_factory):
    return model_manager_factory()


@pytest.fixture
def radius_server_profile(model_manager):
    def _radius_server_profile(**overrides):
        return build_model(RadiusServerProfileModel, model_manager, **overrides)

    return _radius_server_profile


@pytest.fixture
def analyzer(model_manager, check_info):
    manager_ref = weakref.ref(model_manager)
    analyzer = RadiusServerProfileAnalyzer(manager_ref, check_info)
    return analyzer


class TestRadiusServerProfileAnalyzer:

    """check_protocol"""

    @pytest.mark.passing
    def test_check_protocol_passing(self, analyzer, radius_server_profile):
        assert analyzer._check_protocol(
            radius_server_profile(protocol="EAP-TTLS-with-PAP")
        ).check_passed

    @pytest.mark.failing
    def test_check_protocol_failing(self, analyzer, radius_server_profile):
        assert not analyzer._check_protocol(
            radius_server_profile(protocol="CHAP")
        ).check_passed
