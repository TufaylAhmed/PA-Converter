import argparse
import cProfile
import logging
import pstats
import sys

from scripts.common import run_config


logging.basicConfig(level=logging.INFO, format="%(message)s")
LOG = logging.getLogger(__name__)


def parse_args():
    parser = argparse.ArgumentParser(description="Profile library with running config")
    parser.add_argument(
        "configuration",
        help="Configuration name to run against",
        type=str,
        action="store",
    )
    parser.add_argument(
        "-t",
        "--type",
        help="Fixture type to inspect",
        type=str,
        action="store",
        choices=("failed", "lab", "pulled"),
    )
    return vars(parser.parse_args())


def main():
    args = parse_args()
    config_id = args["configuration"]
    config_dir = args["type"] + "_configs"
    LOG.info("Start profiling...")
    pr = cProfile.Profile()
    pr.enable()
    run_config(config_id, config_dir)
    pr.disable()
    LOG.info("Done.")
    ps = pstats.Stats(pr, stream=sys.stdout).strip_dirs()
    ps.sort_stats("time", "name")
    ps.print_stats(25)


if __name__ == "__main__":
    main()
