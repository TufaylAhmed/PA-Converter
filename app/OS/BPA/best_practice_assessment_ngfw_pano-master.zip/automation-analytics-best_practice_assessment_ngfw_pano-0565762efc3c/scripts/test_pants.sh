#!/bin/bash
set -euo pipefail
docker build --rm -f dockerfiles/pants.Dockerfile -t cexp/ngfw:test-pants .
docker run --rm -t \
    -e PANTS_USER="$PANTS_USER" \
    -e PANTS_PASS="$PANTS_PASS" \
    -e PANTS_HOST="$PANTS_HOST" \
    -e PANTS_DB="$PANTS_DB" \
    -e MYSQL_USER="$MYSQL_USER" \
    -e MYSQL_PASSWORD="$MYSQL_PASSWORD" \
    -e MYSQL_HOST="$MYSQL_HOST" \
    cexp/ngfw:test-pants
