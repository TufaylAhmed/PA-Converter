import argparse
import logging
import os
import urllib3

from tests import pulled_path
from pants.utils import get_pants_ids, get_pants_file

# Disable HTTPS warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logging.basicConfig(level=logging.INFO, format="%(message)s")
LOG = logging.getLogger(__name__)


def parse_args():
    parser = argparse.ArgumentParser(description="Pull running config from PANTS")
    parser.add_argument(
        "identifiers",
        help="List of pants identifiers",
        type=int,
        nargs="+",
        action="store",
    )
    parser.add_argument(
        "--type",
        help="xml or tgz file type",
        type=str,
        choices=["xml", "tgz"],
        default="xml",
        action="store",
        required=False,
    )

    return vars(parser.parse_args())


def main():
    args = parse_args()
    unique_ids = set(args["identifiers"])

    LOG.info(f"Searching for {unique_ids}...")
    df = get_pants_ids()
    pull_df = df[df["pants_id"].isin(unique_ids)]

    if len(pull_df) == 0:
        LOG.warning(f"{unique_ids} not found in {len(df)} entries")
        return

    LOG.info("Starting downloads...")
    pull_base = os.path.basename(pulled_path)
    for row in pull_df.itertuples():
        dest_name = f'{row.pants_id}.{args["type"]}'
        dest_path = os.path.join(pulled_path, dest_name)
        if os.path.exists(dest_path):
            LOG.warn(f"{dest_name} already exists in {pull_base}")
            continue
        LOG.info(f"Downloading {dest_name} to {pull_base}...")
        if args["type"] == "xml":
            file_path = row.file_path
        else:
            file_path = row.tsf_path
        raw = get_pants_file(file_path)
        if raw is not None:
            with open(dest_path, "wb") as f:
                f.write(raw.read())


if __name__ == "__main__":
    main()
