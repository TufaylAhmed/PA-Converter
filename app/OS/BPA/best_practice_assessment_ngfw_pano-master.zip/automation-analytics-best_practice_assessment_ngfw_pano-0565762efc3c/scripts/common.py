import json
import logging
import os
import sys

from bpa.controller import Controller
from tests import fixt_path


LOG = logging.getLogger(__name__)


def run_config(config_id, config_dir):
    config_path = os.path.join(fixt_path, config_dir)
    xml_name = f"{config_id}.xml"
    xml_path = os.path.join(config_path, xml_name)
    try:
        controller = Controller.from_xml(xml_path)
    except OSError:
        LOG.warning(f"{config_id} does not exist at {os.path.basename(config_path)}")
        sys.exit(1)
    output = controller.publisher_manager.get("best_practices")
    data = json.loads(output)
    assert len(data) > 0, data
