# Scripts

These scripts should aid administrators and developers alike to troubleshoot library
issues in a systematic fashion.

## Python scripts

The following script use cases are provided:

- `scripts.debug_conf` for debugging library issues
- `scripts.profile_conf` for profiling library execution times
- `scripts.pull_conf` for pulling running config from PANTS for experiments

## Shell scripts

- `test_pants.sh` for testing the library against the full suite of PANTS configuration
- `test_unit.sh` for running the integration/unit tests against the library
