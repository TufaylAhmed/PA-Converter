# BPA

This package generates Best Practice and Adoption data for NGFW and Panorama devices.

A couple of folders that you might be interested in:

- `dockerfiles` - Dockerfile artifacts for Jenkins builds
- `docs` - Sphinx documentation for new developers
- `pants` - Utilities for invoking PANTS test
- `scripts` - Scripts for developers and Jenkins builds
- `tests` - For tests spanning from unit tests to end-to-end tests

---

## Install package

There are several options for installing the package.

### Bitbucket method

Install via HTTPS URL:

    pip install git+ssh://git@bitbucket.org/automation-analytics/best_practice_assessment_ngfw_pano.git

### Clone method

Enter the cloned repository:

    cd /path/to/best_practice_assessment_ngfw_pano

Direct installation works as follows:

    pip install .

Indirect installation works as follows:

    pip install -e .

Extra requirements can be installed to the package as well:

    pip install '.[mysql,sql]'

To inspect other extras, take a look at the `setup.py`.
