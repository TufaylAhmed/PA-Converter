How to create a Model
=====================

Models are `dataclass` instances that inherit from `BaseModel` or `SubModel`.

The models are partitioned by the tabs of the PAN-OS UI:

- `Monitor` matches and filters ingress and egress logs
- `Policies` enforces all kinds of firewall rules
- `Objects` defines prebuilt and custom entities for processing
- `Network` is used for configuring network setup
- `Device` is used for configuring PAN-OS device settings
- `Panorama` is used for configuring Panorama-specific settings

Adding a primary model
----------------------

Adding a new `BaseModel` instance involves the following steps:

1. Create a new dataclass that inherits from `BaseModel`
2. Determine the xpath attribute to parse from
3. Inspect the entry/entries from the xpath
4. Identify data that is needed from the entry/entries
5. Declare dataclass attribute for each piece of data in step 4
6. Implement `staticmethod` for attributes as `_get_<attribute_name>`
7. Add tests in the `tests` folder to verify that the model works

Adding a secondary model
------------------------

Adding a new `SubModel` instance involves the following steps:

1. Create a new dataclass that inherits from `SubModel`
2. Determine the xpath attribute to parse from
3. Inspect the entry/entries from the xpath
4. Identify data that is needed from the entry/entries
5. Declare dataclass attribute for each piece of data in step 4
6. Implement `classmethod` that returns an instance of the parsed data
7. Link the `SubModel` to the `SubModel` or `BaseModel` in question
8. Add tests in the `tests` folder to verify that the model works
