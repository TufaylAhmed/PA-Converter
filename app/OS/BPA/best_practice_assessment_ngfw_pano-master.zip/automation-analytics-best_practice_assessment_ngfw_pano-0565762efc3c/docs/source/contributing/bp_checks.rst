How to create a BP Check
========================

Best Practice Assessment checks are used to determine whether a customer
has configured their Panorama/firewalls devices optimally.

There are two primary ways to add a new Check ID.

Approach 1: Via file
--------------------

To add a new best practice check, update this file::

    analyzers/best_practices/check_config.json

and add a new check.

Example of BPA check ID 3::

    "3":
        {
            "check_id": 3,
            "check_name": "Description Populated",
            "check_type": "Warning"
        }

These check IDs will be hardcoded into the Analyzer classes::

    check_id = '3'
    check_attrs = self.check_info[check_id]
    return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

Approach 2: Via database
------------------------

These check IDs will also be used in the Customer Success Site Documentation (Django DB):

https://customersuccess.paloaltonetworks.com/admin/documentation/documentation/
