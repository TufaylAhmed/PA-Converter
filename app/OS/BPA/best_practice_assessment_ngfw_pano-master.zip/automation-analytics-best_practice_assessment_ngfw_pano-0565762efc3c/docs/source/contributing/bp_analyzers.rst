How to create a BP Analyzer
===========================

These analyzers help with analyzing best practice data.

The analyzers are partitioned by feature category (e.g. policies, objects, etc.).

Adding a new analyzer
---------------------

Adding a new `BestPracticesAnalyzer` instance involves the following steps:

1. Create a new class that inherits from `BestPracticesAnalyzer`
2. Add check info to check_info.json file for the new checks
3. Implement instance methods that start with `_check_<check_name>` and accepts a model instance. If the analyzer requires more complex logic, you will need to override the `get_results` method. The `check_<check_name>` can accept any arguments with this variant
4. Add tests in the `tests` folder to verify that the analyzer works
