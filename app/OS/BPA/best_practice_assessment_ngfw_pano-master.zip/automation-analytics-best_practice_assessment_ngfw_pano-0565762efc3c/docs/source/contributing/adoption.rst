How to create an Adoption Metric
================================

A metric falls into a couple categories:

- Rule metrics
- Profile metrics

Adding a new rule metric
------------------------

1. Ensure that `SecurityRuleModel` has the necessary attributes
2. Implement `_metric_{metric_name}` under `RuleMetrics` class
3. Add tests in the `tests` folder to verify that the metric works

Adding a new profile metric
---------------------------

1. Create a new class that inherits from AdoptionProfileMetric
2. Declare `profile_type` for given class
3. Implement `metric_key` and `bp_analyzer_key` if necessary
4. Implement `get_adoption_result`
5. Add tests in the `tests` folder to verify that the metric works
