How to create a Publisher
=========================

A publisher processes data and returns it as bytes.

They fall into the following categories:

- Excel spreadsheet
- HTML report
- Raw output

Adding a new Publisher
----------------------

1. Create a new class that inherits from BasePublisher
2. Determine whether it needs additional data (i.e. documentation, trending)
3. Add optional constructor parameters as necessary
4. Implement `process` routine
5. Implement `publish` routine
6. Add tests in the `tests` folder to verify that the publisher works
