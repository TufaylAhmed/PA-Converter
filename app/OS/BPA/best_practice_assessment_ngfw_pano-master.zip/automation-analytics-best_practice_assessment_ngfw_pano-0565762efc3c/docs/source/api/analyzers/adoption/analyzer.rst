Adoption Rule Analyzer
======================

Provide overview of `base_analyzer` module.

Source Code
-----------

.. automodule:: bpa.analyzers.adoption.base_analyzer
    :members:
