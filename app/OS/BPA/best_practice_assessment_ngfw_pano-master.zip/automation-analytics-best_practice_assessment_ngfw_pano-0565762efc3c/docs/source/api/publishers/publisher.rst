Base Publisher
==============

Here is an overview of `base_publisher` module.

Source Code
-----------

.. automodule:: bpa.publishers.base_publisher
    :members:
