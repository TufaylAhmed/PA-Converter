Model API
=========

.. toctree::
   :maxdepth: 2

   base_model
   sub_model
   manager
   template_stack
   mixins
   model_set

Here are the core APIs for parsing XML data.
