Publisher API
=============

.. toctree::
   :maxdepth: 2

   manager
   publisher

Here are the core APIs for publishing output.
