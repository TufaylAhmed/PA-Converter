Publisher Manager
=================

Here is an overview of `manager` module.

Source Code
-----------

.. automodule:: bpa.publishers.manager
    :members:
