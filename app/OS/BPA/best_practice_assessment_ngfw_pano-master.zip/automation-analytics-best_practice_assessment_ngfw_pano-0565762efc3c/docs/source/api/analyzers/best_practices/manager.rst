Best Practice Manager
=====================

Here is an overview of `manager` module.

Source Code
-----------

.. automodule:: bpa.analyzers.best_practices.manager
    :members:
