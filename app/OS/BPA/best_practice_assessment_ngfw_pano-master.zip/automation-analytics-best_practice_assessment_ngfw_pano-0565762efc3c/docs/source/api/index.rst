API Documentation
=================

.. toctree::
   :maxdepth: 2

   controller
   models/index
   analyzers/index
   publishers/index

Although there's a lot of code, here are the APIs that you need to know at an
absolute minimum in order to understand the codebase architecture.
