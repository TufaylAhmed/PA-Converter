Adoption Rule Result
====================

Provide overview of `rule_result` module.

Source Code
-----------

.. automodule:: bpa.analyzers.adoption.rule_result
    :members:
