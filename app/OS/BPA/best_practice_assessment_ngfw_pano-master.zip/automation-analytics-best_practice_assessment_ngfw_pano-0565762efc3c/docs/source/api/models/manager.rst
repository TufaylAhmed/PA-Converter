Model Manager
=============

Here is an overview of `manager` module.

Source Code
-----------

.. automodule:: bpa.models.manager
    :members:
