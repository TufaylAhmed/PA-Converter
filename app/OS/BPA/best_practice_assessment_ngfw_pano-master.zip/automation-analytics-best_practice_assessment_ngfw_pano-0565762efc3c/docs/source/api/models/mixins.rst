Model Mixins
============

Here is an overview of `mixins` module.

Source Code
-----------

.. automodule:: bpa.models.mixins
    :members:
