Best Practice Analyzer
======================

Here is an overview of `base_analyzer` module.

Source Code
-----------

.. automodule:: bpa.analyzers.best_practices.base_analyzer
    :members:
