Adoption Metric
===============

Provide overview of `base_metric` module.

Source Code
-----------

.. automodule:: bpa.analyzers.adoption.base_metric
    :members:
