Base Model
==========

Here is an overview of `base_model` module.

Source Code
-----------

.. automodule:: bpa.models.base_model
    :members:
