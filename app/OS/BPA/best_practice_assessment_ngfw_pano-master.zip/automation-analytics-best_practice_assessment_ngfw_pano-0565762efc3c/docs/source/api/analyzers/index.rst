Analyzer API
============

.. toctree::
   :maxdepth: 2

   best_practices/manager
   best_practices/analyzer
   best_practices/check
   best_practices/result
   adoption/manager
   adoption/analyzer
   adoption/metric
   adoption/result

Here are the core APIs for analyzing parsed data.
