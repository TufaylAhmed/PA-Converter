Best Practice Result
====================

Here is an overview of `bp_result` module.

Source Code
-----------

.. automodule:: bpa.analyzers.best_practices.bp_result
    :members:
