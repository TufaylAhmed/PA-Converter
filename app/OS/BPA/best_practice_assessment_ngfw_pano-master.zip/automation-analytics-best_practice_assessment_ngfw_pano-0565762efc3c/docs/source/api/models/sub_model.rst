Sub Model
==========

Here is an overview of `sub_model` module.

Source Code
-----------

.. automodule:: bpa.models.sub_model
    :members:
