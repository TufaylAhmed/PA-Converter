Adoption Analyzer Manager
=========================

Provide overview of `manager` module.

Source Code
-----------

.. automodule:: bpa.analyzers.adoption.manager
    :members:
