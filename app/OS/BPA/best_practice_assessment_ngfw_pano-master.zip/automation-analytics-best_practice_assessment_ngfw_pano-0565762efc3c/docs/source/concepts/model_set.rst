Model sets collect data
=======================

Design patterns that this component uses:

- https://sourcemaking.com/design_patterns/iterator
- https://sourcemaking.com/design_patterns/composite

Context
-------

`ModelSet` design borrows its influence from Django's `QuerySet` interface.
It has a `find` and `findall` API that helps with quick model lookups
and model filters respectively, much like the `get` and `filter`
operations of Django's `QuerySet`.

Implementation
--------------

A single `ModelSet` tends to get built up from the `ModelManager` code.
Something particularly nice about `ModelSet` is that it has `model_kls`
and `model_attrs` which helps with building model lookup signatures.

The `model_kls` is used heavily in `Analyzer` code that depends on
multiple models.

The `model_attrs` is used to validate fields that are used for
populating a particular `BaseModel` instance.
