PAN-OS ecosystem
================

PAN-OS is the operating system for Palo Alto Networks devices.

General PAN-OS explanations:
----------------------------

Here is some curated material from the team Confluence:

- Features on PAN device (https://automation-analytics.atlassian.net/wiki/spaces/BPA/pages/58654742/Features+on+PAN+device)
- Panorama vs NGFW (https://automation-analytics.atlassian.net/wiki/spaces/BPA/pages/57901061/Panorama+vs+NGFW)
- Anatomy of TS file (https://automation-analytics.atlassian.net/wiki/spaces/BPA/pages/57835548/Anatomy+of+TS+file)
- Adding a BP Check (https://automation-analytics.atlassian.net/wiki/spaces/BPA/pages/58785904/End-to-End+Adding+a+BP+Check)
- Lab on PAN devices (https://automation-analytics.atlassian.net/wiki/spaces/BPA/pages/57999364/Lab+on+PAN+devices)

Relevance
---------

The Best Practice Assessment is used to increase the security posture of PAN-OS
devices which include Next Gen Firewalls (NGFW) and Panorama devices.

Lab Devices
-----------

Here is a list of devices used for development and testing purposes:

https://automation-analytics.atlassian.net/wiki/spaces/DEV/pages/25624649/PAN-OS+Devices
