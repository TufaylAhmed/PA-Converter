Managers delegate work
======================

Design patterns that this component uses:

- https://sourcemaking.com/design_patterns/facade
- https://sourcemaking.com/design_patterns/mediator
- https://sourcemaking.com/design_patterns/proxy

Managers act as mediators between the dumb components that we have.
They also cache intermediate results for faster computation for
their successive phases.

ModelManager
------------

Its role is to pass data between `Model` instances and to provide the
controller a clear way to access `Model` data from other subsystems.
It often gets injected into other components as a weak reference.

BestPracticesAnalyzerManager
----------------------------

Its role is to retrieve results from `BestPracticeAnalyzer` instances and to pass
them off to the `Publisher` components.

AdoptionAnalyzerManager
-----------------------

Its role is to retrieve results from `AdoptionMetric` instances and to pass them off to
the `Publisher` components.

PublisherManager
----------------

Its role is to retrieve results from analyzer managers and convert them into output that
can be consumed by stakeholders and end users of this framework.
