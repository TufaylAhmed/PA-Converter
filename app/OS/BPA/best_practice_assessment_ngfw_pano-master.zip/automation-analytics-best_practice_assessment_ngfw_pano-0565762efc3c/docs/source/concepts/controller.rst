Controller as client API
========================

Design patterns that this component uses:

- https://sourcemaking.com/design_patterns/facade
- https://sourcemaking.com/design_patterns/mediator

It is the interface that orchestrates data retrieval and transfer
between multiple manager components.

Implementation
--------------

It is initialized with all possible managers. It can either parse a
Tech Support File or direct config as XML. Afterwards, the tree data
should be populated with the following metadata:

- XML ancestors
- XML descendants
- Device group hierarchy
- PAN-OS version
- Boolean flag for Panorama/NGFW

Some or all of this data is necessary for parsing `Model` information
and analyzing them.
