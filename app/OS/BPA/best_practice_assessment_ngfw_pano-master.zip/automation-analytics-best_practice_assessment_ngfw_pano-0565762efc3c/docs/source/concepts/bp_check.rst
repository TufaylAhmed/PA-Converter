BP checks assess config
=======================

Design patterns that this component uses:

- https://sourcemaking.com/design_patterns/factory_method

Context
-------

Checks are designed to guide customers into using PAN-OS features
that enhance the security of the following focus areas of the
PAN-OS user interface:

- Policies
- Network
- Objects
- Device

These have been vetted by product management and architects, so
the ideas are fairly established.

Implementation
--------------

Best Practice Checks all have an identifier, name and type. The message
attribute is optional. The base definition is an abstract class, so
it cannot be instatiated directly. Instead, one should use the
`get_check` class method from one of its subclasses to generate
the appropriate Best Practice Check.
