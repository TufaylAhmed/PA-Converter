Tutorials
=========

.. toctree::
   :maxdepth: 2

   xpath
   jira
   logging
   pytest

Tutorials will help with fundamentals and practical knowledge needed to contribute to the codebase.
