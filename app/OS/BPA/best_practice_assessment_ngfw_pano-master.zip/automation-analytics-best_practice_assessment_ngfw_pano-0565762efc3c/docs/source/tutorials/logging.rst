Quickstart on logging
=====================

Logging can help you develop a better understanding of the flow of a program and discover breaking points of a running program.

How to add logs
---------------

Here is how to add logs in a module::

    import logging
    LOG = logging.getLogger(__name__)
    LOG.debug('foo')
    LOG.info('bar')
    LOG.warning('something is on fire')
    LOG.error('the world is blowing up')
    LOG.critical('the universe is blowing up')

How to view logs selectively
----------------------------

Here is how to set the log visibility::

    import logging
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)
    LOG.debug('Debug logs do not show up')
    LOG.info('Info logs show up')
    LOG.critical('Critical logs show up')
