Quickstart for XPath
====================

XPath can be used to navigate through elements and attributes in an XML document.

Tools
-----

Tools to run XPath queries to see results: 

- `Sublime text`_ with `XPath plugin`_

.. _`Sublime text`: http://www.python.org
.. _`XPath plugin`: https://packagecontrol.io/packages/xpath

Syntax explained
----------------

https://www.w3schools.com/xml/xpath_intro.asp provides a brief overview of
XPath syntax. It is useful for learning enough XPath to get started.

https://msdn.microsoft.com/en-us/library/ms256471(v=vs.110).aspx provides a
comprehensive overview of XPath syntax. This is not necessary for getting up
to speed, but it's good to read at some point.

XPath for Python
----------------

The `lxml`_ library is heavily used within the code to parse XML.

.. _`lxml`: https://lxml.de/tutorial.html

Basic APIs
~~~~~~~~~~

Here is a quick summary of the basic APIs:

- `el.find(xpath)`: returns the Element
- `el.findtext(xpath, default=None)`: returns the text or a default value
- `el.get(xpath)`: returns an attribute of the node, else None
- `el.text`: returns the text of the element itself

XPath API
~~~~~~~~~

`el.xpath(xpath)` returns the following:

- True or False, when the XPath expression has a boolean result
- a float, when the XPath expression has a numeric result (integer or float)
- a 'smart' string (as described below), when the XPath expression has a string result.
- a list of items, when the XPath expression has a list as result.

    The items may include Elements (also comments and processing instructions),
    strings and tuples. Text nodes and attributes in the result are returned as
    'smart' string values. Namespace declarations are returned as tuples of
    strings: (prefix, URI).

XPath string results are 'smart' in that they provide a getparent() method that knows their origin:

- for attribute values, result.getparent() returns the Element that carries them. An example is //foo/@attribute, where the parent would be a foo Element.
- for the text() function (as in //text()), it returns the Element that contains the text or tail that was returned.

Example
-------

Here is how an XPath would be evaluated::

    xpath = '//foo/bar/entry'

    xml = '''
    <foo>
        <bar>
            <entry name="John">blah</entry>
            <entry name="Mary">blah</entry>
        </bar>
    </foo>
    '''

    result = [
        <entry name="John">blah</entry>,
        <entry name="Mary">blah</entry>,
    ]
