Quickstart for pytest
=====================

The pytest framework makes it easy to write small tests, yet scales to support
complex functional testing for applications and libraries.

https://docs.pytest.org/en/latest/

How to write a test
-------------------

An example of a function-based test::

    # test_inc.py
    def inc(x):
        return x + 1


    @pytest.mark.utils
    @pytest.mark.passing
    def test_inc_passing():
        assert inc(3) == 5

An example of a class-based test::

    # test_between_10_and_100.py
    def is_between_10_and_100(x):
        return 10 <= x <= 100


    @pytest.mark.utils
    class TestIsBetween10And100:

        @pytest.mark.failing
        def test_between_fail_less(self):
            assert not is_between_10_and_100(0)
            assert not is_between_10_and_100(9)

        @pytest.mark.failing
        def test_between_fail_greater(self):
            assert not is_between_10_and_100(101)
            assert not is_between_10_and_100(200)

        @pytest.mark.passing
        def test_between_pass(self):
            assert is_between_10_and_100(10)
            assert is_between_10_and_100(50)
            assert is_between_10_and_100(100)

Create fixtures
^^^^^^^^^^^^^^^

An example of a fixture being used by a test::

    # test_db_connection.py
    @pytest.fixture
    def db_connection():
        return PGClient(hostname='localhost', port=5432)


    def test_db_exists(db_connection):
        connection = db_connection.connect()
        assert connection.is_closed() is False

How to run a test
-----------------

There are many ways to run the tests.

**Note:** Remember to run tests from the base directory of the Git repository.

Run tests by files
^^^^^^^^^^^^^^^^^^

Here are some examples::

    pytest /path/to/test_inc.py
    pytest /path/to/test_between_10_and_100.py

Run tests by function/class names
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Here are some examples::

    pytest -k inc_passing
    pytest -k between_fail
    pytest -k TestIsBetween10And100
    pytest -k 'TestIsBetween10And100 and fail_greater'

Run tests by markers
^^^^^^^^^^^^^^^^^^^^

Here are some examples::

    pytest -m failing
    pytest -m passing
    pytest -m 'failing or passing'

To recall the markers::

    pytest --markers
