Quickstart for Jira
===================

The team uses Jira Cloud to keep track of project issues that come up.

Issue
-----

Example Jira Issue:
https://automation-analytics.atlassian.net/projects/BPA/issues/BPA-107

Terms found in above page:

- Type: Issue is either a New Feature, Enhancement or a Bug
- PAN-OS version: Issue only applies to listed version(s)
- Component: Defines where in codebase issue applies to
- Epic Link: Defines where in Best Practice Assessment UI issue applies
