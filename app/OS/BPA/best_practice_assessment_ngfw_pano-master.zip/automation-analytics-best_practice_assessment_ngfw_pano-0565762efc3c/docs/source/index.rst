.. Best Practice documentation master file, created by
   sphinx-quickstart on Wed Oct 17 17:19:16 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to BPA documentation!
=======================================

.. toctree::
   :maxdepth: 2

   api/index
   concepts/index
   contributing/index
   tutorials/index

The Best Practice Assessment framework empowers users to use their PAN-OS devices more
effectively. It consists of the following components:

- Controller runs managers of models, analyzers and publishers
- Models parse running config and other metadata
- Analyzers produce BPA and adoption results
- Publishers extract results and export them to HTML/XLSX/JSON

Contribute to the `docs` folder as much as you like. Every bit that you do
to help is greatly appreciated.
