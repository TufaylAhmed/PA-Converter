# Getting Started

Below are two workflows for getting started with documentation.

## Reading Docs

1. Run `pip install sphinx sphinx-rtd-theme`
2. Go to `docs`
3. Run `make html` or `make singlehtml` to build HTML docs
4. View docs in docs/build/html/index.html

## Writing Docs

1. Learn how to edit RST files
2. Go to docs
3. Edit the files in docs/source
4. Run `make html` or `make singlehtml` to rebuild HTML docs
5. Commit and push your changes
