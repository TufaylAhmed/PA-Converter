import weakref
import logging
from abc import ABCMeta, abstractmethod

from ..utils.common import common_key


LOG = logging.getLogger(__name__)


class BasePublisher(metaclass=ABCMeta):
    """Base publisher.

    Attributes:
        publisher_manager: Weak reference to PublisherManager instance.
        bp_manager: Weak reference to BestPracticeAnalyzerManager instance.
        adoption_manager: Weak reference to AdoptionAnalyzerManager instance.
    """

    def __init__(self, publisher_manager):
        LOG.debug(f"Initializing {self.__class__.__name__}")
        self.publisher_manager = weakref.ref(publisher_manager)
        self.bp_manager = publisher_manager.bp_manager
        self.adoption_manager = publisher_manager.adoption_manager
        self.register_publisher()

    def register_publisher(self):
        key = self.build_publisher_key()
        LOG.debug(f"Registering {self.__class__.__name__} with key {key}")
        self.publisher_manager().publisher_results_lookup[key] = self

    @abstractmethod
    def publish(self) -> bytes:
        """Publish results.

        Looks at the processed output and returns the result as a
        bytes object.

        Returns:
            Bytes data in the publisher format desired.
        """
        pass

    @abstractmethod
    def process(self):
        """Process results and stores them in publisher attributes."""
        pass

    @classmethod
    def build_publisher_key(cls) -> str:
        return common_key(cls)
