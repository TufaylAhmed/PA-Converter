# NOTE: Used as default choice for mapping schema
UNDEFINED = "Undefined"
