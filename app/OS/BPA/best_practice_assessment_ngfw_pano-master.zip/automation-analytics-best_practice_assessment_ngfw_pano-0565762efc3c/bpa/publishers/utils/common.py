from typing import Dict, List
import logging
from bpa.publishers.schemas.documentation import Documentation

LOG = logging.getLogger(__name__)


def docs_to_dict(docs: List[Documentation]) -> Dict[int, Documentation]:
    """Convert Documentation list to Documentation dictionary.

    Args:
        name: list of Documentation objects as input.

    Returns:
        a dictionary of Documentation objects, each with key as doc_id(int) and value as documentation object.
    """
    try:
        return {int(doc.doc_id): doc for doc in docs}
    except Exception as e:
        LOG.error(
            f"Error converting list of Documentation in docs_to_dict function {e}"
        )
        return {}


def divide(numerator, denominator):
    """Divides numerator by denominator. If denominator is 0, returns 0."""
    try:
        return numerator / denominator
    except ZeroDivisionError:
        return 0


def convert_list_of_str_to_str(docs: List[Dict]) -> List[Dict]:
    """ Helper function to change List of String to string. especially for Documentation dataclass """
    for d in docs:
        for key, value in d.items():
            if isinstance(value, list):
                if len(value) == 0:
                    d[key] = ""
                else:
                    d[key] = ",".join(value)
    return docs
