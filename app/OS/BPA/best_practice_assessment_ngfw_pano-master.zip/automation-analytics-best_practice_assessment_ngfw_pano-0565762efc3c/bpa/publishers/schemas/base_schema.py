from dataclasses import dataclass


@dataclass
class BaseSchema:
    """Base schema.

    NOTE: The motivation behind this schema is to enforce a data
    contract for any external data that comes into the BPA library.
    The library won't dictate how the data comes in, only that the data
    must come in a certain format.
    """

    @classmethod
    def from_dicts(cls, entries):
        return [cls(**entry) for entry in entries]

    @classmethod
    def from_df(cls, df):
        fields = [field for field in cls.__dataclass_fields__.keys()]
        entries = df[fields].to_dict("record")
        return [cls(**entry) for entry in entries]
