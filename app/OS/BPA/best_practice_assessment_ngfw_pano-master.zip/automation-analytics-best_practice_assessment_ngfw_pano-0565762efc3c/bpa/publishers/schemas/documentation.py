from datetime import datetime
from typing import List

from dataclasses import dataclass, asdict

from bpa.publishers.schemas.base_schema import BaseSchema


@dataclass
class Documentation(BaseSchema):
    """Documentation schema

    NOTE: The attributes are mostly copied from the Customer
    Success Site. Feel free to add/remove fields as the database
    schema changes.
    """

    doc_id: int
    top_nav: str
    left_nav: str
    title: str
    doc_type: str
    description: str
    rationale: str
    references: List[str]
    last_updated_date: datetime
    effort: str
    complexity: str
    active: bool
    capability_label: List[str]
    class_label: List[str]
    control_category: List[str]
    cscv6_control: List[str]
    cscv7_control: List[str]

    @property
    def as_dict(self):
        """ Helper function to return dictionary object of the class.
            for an example {'doc_id':3,'top_nav': 'policy',.....}"""
        return asdict(self)
