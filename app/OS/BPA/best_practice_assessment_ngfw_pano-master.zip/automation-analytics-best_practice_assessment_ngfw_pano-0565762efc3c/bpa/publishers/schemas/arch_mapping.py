import logging
from dataclasses import dataclass
from typing import Dict, List, Optional, Union

from bpa.publishers.constants import UNDEFINED


LOG = logging.getLogger(__name__)


@dataclass
class Mapping:
    """Mapping schema.

    NOTE: These are related to area of architecture mappings.
    These tend to get configured before running a HTML report
    and may be useful for other report use cases.
    """

    CHOICES = frozenset(
        (
            "Enterprise",
            "Perimeter",
            "Internet",
            "DMZ",
            "3rd Party/Vendor",
            "Internal Core",
            "Users",
            "IT Infrastructure",
            "Out-of-Band Management",
            "Remote Office/MPLS",
            "Mobility",
            "Remote Users/VPN",
            "Guest",
            "BYOD",
            "Datacenter",
            "Web-tier",
            "App-tier",
            "DB-tier",
            "PCI",
            "SCADA/ICS",
            "R&D",
            "Lab/Test",
            "Decommissioned/Not-in-use",
            UNDEFINED,
        )
    )

    DEFAULT_CHOICE = UNDEFINED

    location: str
    zone: str
    architecture: Optional[str] = UNDEFINED

    def __getitem__(self, key) -> str:
        return getattr(self, key)


class MappingSet:
    """Mapping set.

    NOTE: Used for collecting a list of Mapping instances
    and register them somehow to a singleton object.
    """

    def __init__(self, mappings: List[Union[Mapping, Dict]]):
        self._lookup = {}
        self.register_mapping(mappings)

    def register_mapping(self, mappings: List) -> None:
        for mapping in mappings:
            sig = (mapping["location"], mapping["zone"])
            if mapping["architecture"] not in Mapping.CHOICES:
                raise ValueError(
                    f"{mapping['architecture']} is not a valid architecture choice"
                )
            self._lookup[sig] = mapping["architecture"]

    def get(self, location, zone) -> str:
        if zone == "any":
            return "any"
        try:
            return self._lookup[(location, zone)]
        except KeyError:
            LOG.debug(f"Mapping with location={location} and zone={zone} not found")
            return Mapping.DEFAULT_CHOICE
