from dataclasses import dataclass

from bpa.publishers.schemas.base_schema import BaseSchema


@dataclass
class Snapshot(BaseSchema):
    """Snapshot schema.

    NOTE: Its impetus comes from the HTML report where there
    may be one or more previous snapshots of adoption data,
    and they can be fed in to help the customer realize trends
    in the way they configure PAN-OS devices.
    """

    pass
