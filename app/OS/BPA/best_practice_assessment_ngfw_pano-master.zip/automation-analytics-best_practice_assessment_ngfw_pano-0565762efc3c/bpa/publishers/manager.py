import logging
import weakref

from . import formats
from .base_publisher import BasePublisher
from ..utils.common import find_classes


LOG = logging.getLogger(__name__)


class PublisherManager:
    """Publisher manager.

    Attributes:
        bp_manager: Weak reference to BestPracticeAnalyzerManager instance.
        adoption_manager: Weak reference to AdoptionAnalyzerManager instance.
        publisher_lookup: Dictionary of Publisher classes.
        publisher_results_lookup: Dictionary of Publisher instances.
    """

    def __init__(self, adoption_manager):
        LOG.debug(f"{self.__class__.__name__} initializing")
        self.bp_manager = adoption_manager.bp_manager
        self.adoption_manager = weakref.ref(adoption_manager)
        self.publisher_lookup = self.find_publishers()
        self.publisher_results_lookup = {}

    def get_publisher(self, publisher_key: str):
        """Retrieve publisher instance from results lookup.

        Useful after invoking the get routine manually and/or
        checking whether the publisher has been processed already.

        Args:
            publisher_key: Use key to retrieve correct publisher.

        Returns:
            Publisher instance of a particular type.

        Raises:
            KeyError if publisher has not been processed yet.
        """
        return self.publisher_results_lookup[publisher_key]

    def is_processed(self, publisher_key: str):
        """Check if result was processed for publisher_key already.

        Args:
            publisher_key: Use key to check for publisher results.

        Returns:
            Boolean value - true or false.
        """
        return publisher_key in self.publisher_results_lookup

    def get(self, publisher_key, **kwargs):
        """Get publisher bytes.

        This will ask the bundler proxy to return results back
        to the controller component.

        Args:
            publisher_key: Use key to call correct publisher.

        Returns:
            Bytes of a given publisher.
        """
        if self.is_processed(publisher_key):
            return self.get_publisher(publisher_key).publish()
        publisher = self.publisher_lookup[publisher_key](self, **kwargs)
        publisher.process()
        return publisher.publish()

    @staticmethod
    def find_publishers():
        return find_classes(formats, BasePublisher, "build_publisher_key")
