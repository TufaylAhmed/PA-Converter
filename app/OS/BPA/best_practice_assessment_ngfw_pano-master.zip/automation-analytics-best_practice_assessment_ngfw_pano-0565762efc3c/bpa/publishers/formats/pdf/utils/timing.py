from datetime import datetime


def get_time(dt: datetime) -> str:
    """Return formatted time."""
    return dt.strftime("%b %d, %Y @ %I:%M:%S %p %Z")
