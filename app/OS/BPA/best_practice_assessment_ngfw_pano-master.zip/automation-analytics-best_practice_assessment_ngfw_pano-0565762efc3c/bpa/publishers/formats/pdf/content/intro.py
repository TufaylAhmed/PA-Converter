from typing import List

from reportlab.platypus import PageBreak, NextPageTemplate
from reportlab.platypus.flowables import Flowable

from bpa.publishers.formats.pdf.utils.content import build_internal_link


def front_cover(Story: List[Flowable]):
    """Build front cover."""
    Story.append(NextPageTemplate("Normal"))
    Story.append(PageBreak())


def start_point(Story: List[Flowable]):
    """Build automated TOC."""
    Story.append(build_internal_link("start"))
