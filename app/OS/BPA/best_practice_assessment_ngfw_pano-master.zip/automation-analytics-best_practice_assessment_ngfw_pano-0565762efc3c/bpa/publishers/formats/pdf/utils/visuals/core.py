import colorsys
from textwrap import wrap

import numpy as np
import pandas as pd
from matplotlib import cm, pyplot as plt
from matplotlib.patches import Circle, Wedge


# https://docs.python.org/3.7/library/colorsys.html
def get_color(val, target=100):
    ratio = val / target
    deg = ratio * 120
    return colorsys.hls_to_rgb(deg / 360, 0.68, 1)


# https://python-graph-gallery.com/2-horizontal-barplot/
# https://pandas.pydata.org/pandas-docs/version/0.23/generated/pandas.DataFrame.plot.barh.html
# https://stackoverflow.com/questions/6774086/why-is-my-xlabel-cut-off-in-my-matplotlib-plot
# https://stackoverflow.com/questions/38415774/ipython-get-access-to-current-figure
def bar_h(data, figsize=(8, 5), fontsize=11, title=None, wrapping=20):
    # Make fake dataset
    current, delta, labels = [], [], []
    for k in sorted(data):
        v = data[k]
        percent_ = v.get("percent")
        change_ = v.get("change")
        current.append(percent_)
        if change_:
            delta.append(change_)
        klabel = ""
        for line in wrap(k, wrapping):
            ktmp = line.rjust(wrapping) + "\n"
            klabel += ktmp
        klabel = klabel[:-1]
        labels.append(klabel)
    df = pd.DataFrame({"current": current}, index=labels)

    ax = df.plot.barh(figsize=figsize, fontsize=fontsize, title=title, legend=False)

    # Set larger label size
    # https://stackoverflow.com/questions/29766827/matplotlib-make-axis-ticks-label-for-dates-bold
    ax.yaxis.set_tick_params(labelsize=11)

    # Ensure x axis is hidden
    # https://stackoverflow.com/questions/40705614/hide-axis-label-only-not-entire-axis-in-pandas-plot
    x_axis = ax.axes.get_xaxis()
    x_axis.set_visible(False)

    # Set range from 0 to 100
    # https://matplotlib.org/api/_as_gen/matplotlib.axes.Axes.set_xlim.html
    # https://stackoverflow.com/questions/15858192/how-to-set-xlim-and-ylim-for-a-subplot-in-matplotlib
    ax.set_xlim([0, 100])

    # Hide all spines except for left
    # https://stackoverflow.com/questions/14908576/how-to-remove-frame-from-matplotlib-pyplot-figure-vs-matplotlib-figure-frame
    for k, spine in plt.gca().spines.items():
        if k != "left":
            spine.set_visible(False)

    fig = plt.gcf()
    rects = ax.patches

    for ix, rect in enumerate(rects):
        cur = current[ix]
        color = get_color(cur, target=100)
        rect.set_color(color)

        # Set text besides rectangle
        content = f"{cur}%"
        if delta:
            diff = delta[ix]
            content += f" / {diff}"
        yloc = rect.get_y() + rect.get_height() / 3
        ax.text(
            rect.get_x() + rect.get_width() + (min(4, len(content) * 0.5)),
            yloc,
            content,
            ha="left",
            fontdict={"size": fontsize},
        )
    plt.tight_layout()
    return fig


# https://pbpython.com/bullet-graph.html
def bulletgraph(
    data=None,
    axis_label=None,
    title=None,
    size=(8, 2),
    formatter=None,
    bar_color="black",
    show_pct=False,
):
    """Build out a bullet graph image.

    Args:
        data = List of labels, measures and targets
        axis_label = string describing x axis
        title = string title of plot
        size = tuple for plot size
        formatter = matplotlib formatter object for x axis
        bar_color = color string for the small bar

    Returns:
        A matplotlib figure.
    """
    # Determine the max value for adjusting the bar height
    # Dividing by 10 seems to work pretty well
    limits = [20, 40, 60, 80, 100]
    h = limits[-1] / 10

    N = 5
    W = 100 / N
    colors = [get_color(i * W) for i in range(N)]

    # Must be able to handle one or many data sets via multiple subplots
    if len(data) == 1:
        fig, ax = plt.subplots(figsize=size, sharex=True)
    else:
        fig, axarr = plt.subplots(len(data), figsize=size, sharex=True)

    # Add each bullet graph bar to a subplot
    for idx, item in enumerate(data):

        # Get the axis from the array of axes returned when the plot is created
        if len(data) > 1:
            ax = axarr[idx]

        # Formatting to get rid of extra marking clutter
        ax.set_aspect("equal")
        # ax.set_yticklabels([item["name"]])
        ax.set_yticks([])
        ax.spines["bottom"].set_visible(False)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["left"].set_visible(False)

        prev_limit = 0
        for idx2, lim in enumerate(limits):
            # Draw the bar
            limit_color = colors[idx2]
            to_show = [1]
            ax.barh(
                to_show, lim - prev_limit, left=prev_limit, height=h, color=limit_color
            )
            prev_limit = lim
        rects = ax.patches
        # The last item in the list is the value we're measuring
        # Draw the value we're measuring
        ax.barh([1], item["percent"], height=(h / 3), color=bar_color)

        # Show percentages and deltas
        if not show_pct:
            continue
        rect = rects[-1]
        height = rect.get_height()
        content = f'{item["percent"]}% / {item["change"]}'
        if item["percent"] < 5:
            offset = 1.5
        else:
            offset = min(4, len(content) * 0.5)
        ax.text(
            rect.get_x() + rect.get_width() + offset,
            0.1 * height,
            content,
            ha="left",
            color="white",
            bbox={"facecolor": "black", "alpha": 0.7},
            fontdict={"size": 8},
        )
    if formatter:
        ax.xaxis.set_major_formatter(formatter)
    if axis_label:
        ax.set_xlabel(axis_label)
    if title:
        fig.suptitle(title, fontsize=14)

    # Hide unused trailing ticks
    # https://stackoverflow.com/questions/13576805/matplotlib-hiding-specific-ticks-on-x-axis/13583251
    # https://www.mathworks.com/matlabcentral/answers/368590-how-to-find-next-number-divisible-by-n
    ax.set_xlim([0, 100])
    xticks = ax.xaxis.get_major_ticks()
    for tick in xticks:
        tick.label1.set_visible(False)

    # Hide xtick widths
    # https://stackoverflow.com/questions/29988241/python-hide-ticks-but-show-tick-labels
    ax.tick_params(which="both", width=0)

    fig.subplots_adjust(hspace=0)
    plt.tight_layout()
    return fig


# http://nicolasfauchereau.github.io/climatecode/posts/drawing-a-gauge-with-matplotlib/
def gauge(percent, figsize=(5, 2)):
    N = 5
    W = 100 / N
    colors = [get_color(i * W) for i in range(N)]

    # If colors is a string, we assume it's a matplotlib colormap
    # and we discretize in N discrete colors.
    if isinstance(colors, str):
        cmap = cm.get_cmap(colors, N)
        cmap = cmap(np.arange(N))
        print(colors)
    if isinstance(colors, list):
        if len(colors) == N:
            colors = colors[::-1]
        else:
            raise Exception(
                "\n\nnumber of colors {} not equal \
            to number of categories{}\n".format(
                    len(colors), N
                )
            )

    def degree_range(n):
        start = np.linspace(0, 180, n + 1, endpoint=True)[0:-1]
        end = np.linspace(0, 180, n + 1, endpoint=True)[1::]
        mid_points = start + ((end - start) / 2.0)
        return np.c_[start, end], mid_points

    # Begin plotting
    fig, ax = plt.subplots(figsize=figsize, sharex=True)
    ang_range, mid_points = degree_range(N)

    # Plot the sectors and the arcs
    patches = []
    hi = 0.15
    for ang, c in zip(ang_range, colors):
        # sectors
        patches.append(Wedge((0.0, 0.0), hi, *ang, facecolor="w", lw=2))
        # arcs
        patches.append(
            Wedge((0.0, 0.0), hi, *ang, width=0.10, facecolor=c, lw=2, alpha=0.5)
        )
    for p in patches:
        ax.add_patch(p)

    # Plot the arrow now
    mid = 180 - (180 * percent / 100)
    pointy_width = 0.008
    ax.arrow(
        0,
        0,
        0.1 * np.cos(np.radians(mid)),
        0.1 * np.sin(np.radians(mid)),
        width=pointy_width,
        head_width=pointy_width,
        head_length=hi / 10,
        fc="k",
        ec="k",
    )
    ax.add_patch(Circle((0, 0), radius=0.02, facecolor="k"))
    ax.add_patch(Circle((0, 0), radius=0.01, facecolor="w", zorder=11))

    # Remove frame and ticks
    # Make axis equal and tight
    ax.set_frame_on(False)
    ax.axes.set_xticks([])
    ax.axes.set_yticks([])
    ax.axis("equal")
    plt.tight_layout()
    return fig
