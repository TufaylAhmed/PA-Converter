import os
from typing import Tuple

from reportlab.platypus import BaseDocTemplate, Paragraph
from reportlab.platypus.flowables import Flowable

from bpa.publishers.formats.pdf import images_path
from bpa.publishers.formats.pdf.linkers.internal import InternalLinkImage


class CustomDocTemplate(BaseDocTemplate):
    """CustomDocTemplate handles TOC and bookmark logic.

    This subclass overrides the afterInit to cache the logo
    Flowable and its dimensions. It also overrides the afterFlowable
    to inject PDF bookmarks and notify the TOC that Heading1 and
    Heading2 objects are available.

    Attributes:
        logo: Flowable Image entity that is used for rendering the logo.
        logo_dim: Current dimensions of printed logo.
        _meta: Application metadata useful during processing.
        line_light: Light line width.
        line_medium: Medium line width.
        line_heavy: Medium line width.
        color_grey: Dark grey color as RGB tuple.
        color_white: White color as RGB tuple.
        color_sky_blue: Sky blue as RGB tuple.
        color_deep_sky_blue: Deep sky blue as RGB tuple.
        header_nav: An ordered list of tuples for header navigation.
    """

    def __init__(self, filename, **kw):
        super().__init__(filename, **kw)
        # Header navigation
        self.header_nav = []

    # Logo settings
    logo_path = os.path.join(images_path, "panw-white.png")
    logo_ratio = 1.3

    # Line width settings
    line_light = 0.3
    line_medium = 0.8
    line_heavy = 1

    # Color settings
    color_grey = (0.3, 0.3, 0.3)
    color_white = (1, 1, 1)
    color_sky_blue = (0, 0.6, 0.9)
    color_deep_sky_blue = (0, 0.5, 0.8)

    header_nav_mapping = {
        "BPA Summary": "#ch-bpa",
        "Adoption Summary": "#ch-adoption",
        "Decryption Summary": "#ch-decryption",
        "Appendix": "#ch-appendix",
    }

    # Start anchor
    start_contents = "Start content"
    start_anchor = "start"

    def __getitem__(self, key: str):
        """Retrieve one metadata entry."""
        return self._meta.get(key)

    def __setitem__(self, key: str, val):
        """Update one metadata entry."""
        self._meta[key] = val

    def updateMeta(self, **kwargs):
        """Custom entrypoint for inserting batch metadata."""
        self._meta = {**self._meta, **kwargs}

    def getLogoDimensions(self, logo_factor: float) -> Tuple[float, float]:
        """Custom routine for getting the dimensions of the PANW logo."""
        _logo_width = logo_factor * 400.0
        _logo_height = logo_factor * 225.0
        return (_logo_width, _logo_height)

    def afterInit(self):
        """Post-initialization hook."""
        _logo_width, _logo_height = self.getLogoDimensions(logo_factor=0.15)
        self.logo_dim = (_logo_width, _logo_height)
        self.logo = InternalLinkImage(
            self.logo_path,
            width=_logo_width,
            height=_logo_height,
            destination=self.start_anchor,
            contents=self.start_contents,
        )
        self._meta = {}

    def afterFlowable(self, flowable: Flowable):
        """Post-creation hook for Flowable instances."""
        if isinstance(flowable, Paragraph):
            style = flowable.style.name
            if style == "Heading1":
                chapter = flowable.getPlainText()
                key = "h1-%s" % self.seq.nextf("heading1")
                self.canv.bookmarkPage(key)
                self.canv.addOutlineEntry(chapter, key, level=0)
                self.notify("TOCEntry", (0, chapter, self.page, key))
            if style == "Heading2":
                chapter = flowable.getPlainText()
                key = "h2-%s" % self.seq.nextf("heading2")
                self.canv.bookmarkPage(key)
                self.canv.addOutlineEntry(chapter, key, level=1)
                self.notify("TOCEntry", (1, chapter, self.page, key))

    def set_headers_nav(self, label):
        """ Helper method to add headers nav dynamically. """
        self.header_nav.append((label, self.header_nav_mapping[label]))
