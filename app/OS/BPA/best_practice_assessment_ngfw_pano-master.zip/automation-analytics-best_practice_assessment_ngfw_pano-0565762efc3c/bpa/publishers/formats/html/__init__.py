import os


# Base path
base_path = os.path.dirname(os.path.realpath(__file__))

# Mapping data paths
map_definitions_path = os.path.join(base_path, "formatted_mapping_definitions.json")
