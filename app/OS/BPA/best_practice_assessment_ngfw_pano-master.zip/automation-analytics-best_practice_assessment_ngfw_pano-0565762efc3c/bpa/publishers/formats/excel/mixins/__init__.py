from bpa.publishers.formats.excel.constants import WIDTHS

from .category import CategoryMixin
from .doc import DocumentationMixin
from .mapping import MappingMixin
from .result import ResultMixin
from .summary import SummaryMixin


# NOTE: Add mixins here to extend FailedChecksPublisher
combine_list = (
    CategoryMixin,
    DocumentationMixin,
    MappingMixin,
    ResultMixin,
    SummaryMixin,
)


class CompositeMixin(*combine_list):
    """Combining multiple utilities together"""

    def set_column_widths(self, sheet_data, worksheet):
        """Set column widths for a given worksheet."""
        for index, column in enumerate(sheet_data.columns):
            width = WIDTHS.get(column)
            if width is None:
                try:
                    width = sheet_data[column].str.len().max() + 5
                except AttributeError:
                    width = 20
            worksheet.set_column(index, index, width)
