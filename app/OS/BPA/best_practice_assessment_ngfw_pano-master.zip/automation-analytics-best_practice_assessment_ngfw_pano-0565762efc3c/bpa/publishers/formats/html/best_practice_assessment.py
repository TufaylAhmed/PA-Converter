# -*- coding: utf-8 -*-
"""
Created on Tue Mar 07 11:25:57 2017

@author: anmendoza
"""
import datetime
import json
import weakref
from .common import encode_image
from os.path import dirname, join
from collections import defaultdict, OrderedDict
from typing import Any, Dict, Iterable, List, Set, Optional

from bpa.components.aggregate import (
    BPAChecksPassFail,
    BPAChange,
    BPChecksDescription,
    BPATrend,
    BPAChecksDocsMapping,
    BPASummary,
)
from bpa.components.data_models import BPAHistory

from bpa.publishers.formats.pdf.utils.data import get_csc_meta

from .adapters.bpa import BestPracticeAssessment


def get_object_categories() -> Set:
    return {
        "application_tags",
        "hip_profiles",
        "antispyware_profiles",
        "antivirus_profiles",
        "file_blocking_profiles",
        "url_filtering_profiles",
        "vuln_protection_profiles",
        "wildfire_profiles",
        "dos_protection_profiles",
        "log_forwarding_profiles",
        "decryption_profiles",
    }


def get_learn_more_urls() -> defaultdict:
    vals = [
        "general_settings",
        "authentication_settings",
        "logging_reporting_settings",
        "secure_communication_settings",
        "management_interface_settings",
        "minimum_password_complexity_settings",
        "services_settings",
        "content_id_settings",
        "wildfire_settings",
        "telemetry_settings",
        "session_settings",
        "administrators",
        "admin_roles",
        "auth_profiles",
        "auth_profiles_aggregate",
        "auth_sequences",
        "auth_sequences_aggregate",
        "user_id",
        "template",
        "log_setting_system",
        "log_setting_config",
        "snmptrap_server_profiles",
        "syslog_server_profiles",
        "ldap_server_profiles",
        "radius_server_profiles",
        "tac_plus_server_profiles",
        "software",
        "dynamic_updates",
        "high_availability",
    ]
    device = [f"template_{val}" for val in vals]
    device.extend([f"device_{val}" for val in vals])
    policies = [
        "app_override_rules",
        "captive_portal_rules",
        "decryption_rules",
        "decryption_rulebase",
        "dos_protection_rulebase",
        "policy_based_forwarding_rules",
        "security_rulebase",
    ]
    network = [
        "zones",
        "zone_protection_profiles",
        "gp_portals",
        "gp_gateways",
        "ipsec_crypto_profiles",
    ]
    lookup = {
        "policies": "https://docs.paloaltonetworks.com/best-practices/9-0/bpa-getting-started/evaluate-best-practice-configuration/review-best-practice-policy-configuration.html",
        "network": "https://docs.paloaltonetworks.com/best-practices/9-0/bpa-getting-started/evaluate-best-practice-configuration/review-best-practice-network-configuration.html",
        "device": "https://docs.paloaltonetworks.com/best-practices/9-0/bpa-getting-started/evaluate-best-practice-configuration/review-best-practice-device-and-panorama-management-configuration.html",
    }
    learn_more_urls = defaultdict(lambda: "#")
    for key, vals in zip(
        ["policies", "network", "device"], [policies, network, device]
    ):
        for val in vals:
            learn_more_urls[val] = lookup[key]
    return learn_more_urls


# def get_bpa_mappings(current_pass_fail_checks, docs):
#     """Reads mapping file and organizes the mappings by type and ID.
#
#     Returns:
#         A dictionary of dictionaries. The top level key specifies the mapping type and
#         the second level key provides the check ID. The value for each ID key is a list
#         of relevant mappings for that category.
#     """
#     collector = {}
#     mappings = pd.read_excel(map_xlsx_path)
#
#     records = [
#         {"ID": key, "pass": val["pass"], "fail": val["fail"]}
#         for key, val in current_pass_fail_checks.items()
#     ]
#     mapping_records = pd.merge(
#         mappings.fillna("N/A"), pd.DataFrame(records), how="left", on="ID"
#     )
#     docs_df = pd.DataFrame(docs, columns=["doc_id", "rationale"]).rename(
#         columns={"doc_id": "ID", "rationale": "Rationale"}
#     )
#     mapping_records = pd.merge(mapping_records, docs_df, how="left", on="ID").to_dict(
#         orient="records"
#     )
#     mappings.set_index("ID", inplace=True)
#     for col in ["Functionality / Capability", "Class", "Control Category"]:
#         collector[col] = mappings[col].dropna().str.strip().str.split(", ").to_dict()
#
#     # NOTE: Include checks with no CSC entries
#     csc_column = mappings["CSCv7 Controls"].astype(str).to_dict()
#     csc_collector = collector["CSC Controls"] = {}
#     for k, v in csc_column.items():
#         if v == "nan":
#             csc_collector[k] = []
#         else:
#             csc_collector[k] = [int(float(n)) for n in v.split(", ")]
#
#     return collector, mapping_records


# def get_pass_fail_checks(bpat_json):
#     """Count all passing and failing checks.
#
#     Args:
#         bpat_json: Flattened BPA JSON data
#
#     Returns:
#         A defaultdict where keys are checks IDs found in the BPA JSON data
#         and values are dictionaries of pass / fail counts.
#     """
#     checks = defaultdict(lambda: defaultdict(int))
#     for records in bpat_json.values():
#         for record in records:
#             for check in record["bp_check"]:
#                 if check["result"] in ["pass", "fail"]:
#                     checks[check["id"]][check["result"]] += 1
#     return checks


# def apply_mappings(checks, mappings):
#     """"""
#     collector = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
#     for category, id_lookup in mappings.items():
#         mapping_counts = defaultdict(lambda: defaultdict(int))
#         for bpa_id, mappings in id_lookup.items():
#             passing = checks[bpa_id]["pass"]
#             total = checks[bpa_id]["pass"] + checks[bpa_id]["fail"]
#             for mapping in mappings:
#                 mapping_counts[mapping]["passing"] += passing
#                 mapping_counts[mapping]["total"] += total
#         for mapping, counts in mapping_counts.items():
#             collector[category][mapping] = {**counts}
#             collector[category][mapping]["percent"] = round(
#                 divide(counts["passing"], counts["total"]) * 100
#             )
#     return collector


# def add_prior_summary_comparison(bpa_summary, prior_bpa_summary):
#     """"""
#     for category, mappings in bpa_summary.items():
#         for mapping, vals in mappings.items():
#             if prior_bpa_summary is None:
#                 bpa_summary[category][mapping]["change"] = "No change"
#             else:
#                 change = (
#                     bpa_summary[category][mapping]["percent"]
#                     - prior_bpa_summary[category][mapping]["percent"]
#                 )
#                 if change > 0:
#                     change_text = f"+{change}"
#                 elif change == 0:
#                     change_text = "No change"
#                 else:
#                     change_text = str(change)
#                 abs_change = abs(change)
#                 if abs_change != 0:
#                     if abs_change == 1:
#                         change_text = f"{change_text} pt"
#                     else:
#                         change_text = f"{change_text} pts"
#                 bpa_summary[category][mapping]["change"] = change_text


# def process_bpa_summary(
#     current_data, current_pass_fail_checks, prior_data, bpa_mappings
# ):
#     """"""
#     bpa_summary = apply_mappings(current_pass_fail_checks, bpa_mappings)
#     if prior_data is not None:
#         prior_pass_fail_checks = get_pass_fail_checks(prior_data)
#         prior_bpa_summary = apply_mappings(prior_pass_fail_checks, bpa_mappings)
#     else:
#         prior_bpa_summary = None
#     add_prior_summary_comparison(bpa_summary, prior_bpa_summary)
#
#     return bpa_summary


# def get_check_ids(bpat, attrib):
#     """Looks up all check IDs associated with a given attribute.
#
#     Args:
#         bpat: BestPracticeAssessment object instance
#         attrib: BestPracticeAssessment check attribute
#
#     Returns:
#         A tuple where the first item is the attribute check name and the
#         second item is a list of check IDs. "device" and "template" attribute
#         name prefixes are stripped from the attribute name since the documentation
#         for the checks themselves are the same.
#     """
#     if attrib == "security_rules":
#         try:
#             ids = {
#                 check.check_id
#                 for check in bpat.bp_manager().get("security_rule")[0].checks
#             }
#         except IndexError:
#             ids = set()
#     else:
#         ids = set(
#             itertools.chain.from_iterable(
#                 [
#                     [check.get("id", -1) for check in record["bp_check"]]
#                     for record in getattr(bpat, attrib)
#                 ]
#             )
#         )
#
#     return (
#         "_".join(x for x in attrib.split("_") if x not in ["device", "template"]),
#         ids,
#     )


# def get_documentation(bpat, docs):
#     """Get documentation data for each
#
#     Args:
#         bpat: BestPracticeAssessment object instance
#
#     Returns:
#         A dictionary where the keys are BestPracticeAssessment attributes
#         and the values are list of dictionaries of each relevant documentation check.
#     """
#
#     documentation_dict = defaultdict(set)
#     for attrib in get_attributes(bpat):
#         key, ids = get_check_ids(bpat, attrib)
#         if ids:
#             documentation_dict[key].update(ids)
#     collector = {}
#     for key, ids in documentation_dict.items():
#         collector[key] = [d for d in docs if d["doc_id"] in ids]
#     return collector


# def calculate_passing(record, include_keys):
#     """Calculates passing percentages by top nav categories.
#
#     Args:
#         record: dictionary of aggregated total and passing checks per category
#         include_keys: list of keys to include in returned passing percentages dictionary
#
#     Returns:
#         A dictionary of passing percentages by category
#     """
#     passing = dict()
#     for category in {
#         key.split("_")[0] for key in record.keys() if key not in include_keys
#     }:
#         passing[category] = round(
#             divide(
#                 record["{}_pass".format(category)], record["{}_total".format(category)]
#             )
#             * 100,
#             2,
#         )
#
#     passing.update({key: record[key] for key in include_keys})
#
#     return passing


# def aggregate_measures(records, include_dict=None, sep="."):
#     """Aggregate total and passing counts from Best Practice Assessment JSON.
#
#     Args:
#         records: flattened Best Practice Assessment JSON data
#         include_dict: dictionary to add to aggregated counts dictionary
#         sep: nested JSON key separator
#
#     Returns:
#         A dictionary of aggregated total and passing checks per
#         category (i.e. policies, objects, etc.)
#     """
#     totals = defaultdict(int)
#     warning_results = {"pass", "fail"}
#     for nav, items in records.items():
#         top_nav = nav.split(sep)[0]
#         totals[top_nav + "_pass"] += 0
#         totals[top_nav + "_total"] += 0
#         for record in items:
#             for check in record["bp_check"]:
#                 if check["result"] in warning_results:
#                     totals[top_nav + "_total"] += 1
#                 if check["result"] == "pass":
#                     totals[top_nav + "_pass"] += 1
#
#     if include_dict is not None:
#         totals.update(include_dict)
#
#     return totals


# def create_trend(bpa_history: OrderedDict, panorama: bool) -> List:
#     """Creates trending pass % metrics by top nav category.
#
#     Args:
#         tsf_generated_date: string representing the TSF generated datetime of current data.
#         serial_number: string representing the device serial number.
#         current_data: optional dictionary of the current data in flattened JSON structure
#
#     Returns:
#         A list of trend dictionary records
#     """
#     CATEGORIES = ["policies", "objects", "device", "network", "panorama"]
#     if not panorama:
#         CATEGORIES = CATEGORIES[:-1]
#     trend = []
#     for tsf_date, data in bpa_history.items():
#         agg_data = aggregate_measures(
#             flatten_json(data), include_dict={"tsf_generated_date": tsf_date}
#         )
#         not_configured = [cat for cat in CATEGORIES if agg_data[f"{cat}_total"] == 0]
#         passing_pcts = calculate_passing(
#             record=agg_data, include_keys=["tsf_generated_date"]
#         )
#         for nc in not_configured:
#             passing_pcts[nc] = "Not Configured"
#         trend.append(passing_pcts)
#     return trend


def get_attributes(bpat, additional_ignores=None):
    """Gets BestPracticeAssessment attributes allowed in HTML report.

    Args:
        bpat: BestPracticeAssessment object instance
        additional_ignores: list of additional attributes to exclude from returned list

    Returns:
        A list of BestPracticeAssessment object attributes to be included in HTML report
    """
    ignores = additional_ignores or []
    return list(bpat.result_attrs - {*ignores})


def get_security_rules(security_rule_records):
    """Creates JavaScript variable from security rule records.

    Args:
        security_rule_records: list of security rule dictionary records

    Returns:
        A string for the security_rules JavaScript variable.
    """

    check_replacements = {
        "pass": '<i class="fa fa-check pass" aria-hidden="true"></i>',
        "fail": '<i class="fa fa-times fail" aria-hidden="true"></i>',
        "exclude": '<i class="fa fa-window-minimize" aria-hidden="true"></i>',
    }

    record_lst = [
        {
            **record["configuration"],
            **{
                check["name"]: check_replacements[check["result"]]
                for check in record["bp_check"]
            },
        }
        for record in security_rule_records
    ]

    return "var security_rules = {};".format(json.dumps(record_lst))


def get_top_nav_badges(data):
    """Gets count of failed checks for each top nav category.

    Args:
        data: flattened BestPracticeAssessment JSON

    Returns:
        A dictionary where the keys are top nav categories and the values are counts of
        failed checks.
    """
    top_nav_badges = defaultdict(int)
    for attr, records in data.items():
        hierarchy = attr.split(".")
        top_nav_badges[hierarchy[0]] += sum(
            sum(1 for check in record["bp_check"] if check["result"] == "fail")
            for record in records
            if hierarchy[-1] != "security_rules"
        )

    return top_nav_badges


def get_left_nav_badges(bpat):
    """Get the count of failed checks per Best Practice Assessment attribute.

    Args:
        bpat: BestPracticeAssessment object instance

    Returns:
        A dictionary where keys are BestPracticeAssessment attributes
        and values are the count of failed checks.
    """

    return {
        attr: sum(
            sum(1 for check in record["bp_check"] if check["result"] == "fail")
            for record in getattr(bpat, attr)
            if attr != "security_rules"
        )
        for attr in get_attributes(bpat, additional_ignores=["security_rules"])
    }


def split_checks(checks):
    """Helper function to split checks between warning and notes.

    Args:
        checks: list of all bp_checks for a record

    Returns:
        A tuple where the first item is a list of checks and the second item
        is a list of notes.
    """
    warnings, notes = [], []
    for check in checks:
        if check["type"] == "warn":
            warnings.append(check)
        else:
            notes.append(check)
    return (warnings, notes)


def get_panel_type(checks):
    """Helper function to determine CSS class to apply to each panel in HTML report."""
    notes_found = False
    for check in checks:
        if check["result"] == "fail":
            return "panel-danger"
        elif check["type"] == "note":
            notes_found = True
    if notes_found:
        return "panel-warning"
    else:
        return "panel-default"


def modal_attr(attr):
    """Helper functionary to generate the corresponding modal id for a given
    check attribute in HTML report."""
    attr = [x for x in attr.split("_") if x not in ["device", "template"]]
    attr.append("modal")
    return "_".join(attr)


def isboolean(val):
    """Helper function to determine if value passed is a boolean."""
    return isinstance(val, bool)


def guess_col_length(val):
    """Helper function to determine number of Bootstrap columns to use for each
    configuration item in HTML report.
    """
    if isinstance(val, (bool, int, str, float)) or not val:
        return 4
    elif isinstance(val, list) and not isinstance(val[0], dict):
        return 4
    else:
        return 12


def add_to_dict(key, val, dictionary):
    """Adds a key/value pair to the front of a given dictionary."""
    return OrderedDict({key: val, **dictionary})


def all_dicts(collection: Iterable) -> bool:
    """Check if all items in collection are dictionaries"""
    return all(isinstance(item, dict) for item in collection)


def bad_val(val: Any) -> bool:
    return isinstance(val, weakref.ref)


def render_iterable(val: Iterable) -> str:
    return ", ".join(list(map(str, val)))


def get_options(val, attr, bpat) -> List:
    """Get unique record values for a given attribute in a
    BestPracticeAssessment object instance."""
    options = {
        record["configuration"].get(val)
        for record in getattr(bpat, attr)
        if record["configuration"].get(val) is not None
    }
    return sorted(options, key=str.lower)


def count_number_of_checks(attr, bpat, check_value) -> int:
    """ Initially count number of pass and fail bp check and return number. """
    all_cards = getattr(bpat, attr)
    result = 0
    for card in all_cards:
        bp_checks = card["bp_check"]
        for bp_check in bp_checks:
            if bp_check["type"] != "note" and bp_check["result"] == check_value:
                result += 1
    return result


def helper_func_for_get_check_names(result, bp_checks) -> List:
    """ Helper function to get check names."""
    for data in bp_checks:
        if data["type"] != "note" and data["name"] not in result:
            result.append(data["name"])
    return result


def get_check_names(attr, bpat) -> List:
    """ Retrieve all check names based on attr"""
    if not getattr(bpat, attr):
        return []
    else:
        result = []
        for check in getattr(bpat, attr):
            if isinstance(check["bp_check"], list):
                result = helper_func_for_get_check_names(result, check["bp_check"])
        return result


def get_bp_check_results(checks, match) -> Optional[bool]:
    """Helper function to determine CSS class to apply to each panel in HTML report."""
    notes_founds = False
    for check in checks:
        if check["result"] == match:
            return True
        elif check["type"] == "note":
            notes_founds = True
    if notes_founds:
        return None
    return False


def get_no_results_message(attr, version):
    """Gets the "no results message" for an attribute with no records."""
    if attr == "antivirus_profiles":
        return (
            "The device only has default Anti-Virus profiles and no custom profiles configured "
            'to run the Best Practices against. The "default" profile DOES NOT align to '
            "Best Practice."
        )
    elif attr == "antispyware_profiles":
        message = [
            'The device only has "default" and "strict" predefined Anti-Spyware profiles '
            "and no custom profiles configured to run the Best Practices against. "
            'The "default" profile does not align to Best Practice.'
        ]
        if version == 7.1:
            message.append(
                'The "strict" profile is good enough per Anti-Spyware Best Practice, '
                "but its DNS Sinkhole configuration does not have sinkhole IP configured, "
                'nor is the action set to Sinkhole. Since the "strict" profile is predefined, '
                "it can only be edited via cloning which creates a custom profile that the "
                "Best Practice Assessment can check for automatically."
            )
        elif version == 8:
            message.append(
                'The "strict" profile aligns to Best Practice for Anti-Spyware. '
                'The "strict" DNS Sinkhole IP is preconfigured to 72.5.65.111, which is good, '
                'but the action is set to "block" compared to the recommended '
                'action of "sinkhole".'
            )
        return " ".join(message)
    elif attr == "vuln_protection_profiles":
        return (
            'The device only has "default" and "strict" Vulnerability Protection profiles and no '
            'custom profiles configured to run the Best Practices against. The "default" profile '
            'DOES NOT align to Best Practice, whereas the "strict" profile DOES align to '
            "Best Practice."
        )
    elif attr == "url_filtering_profiles":
        return (
            'The device only has the "default" URL Filtering profile and no custom profiles '
            'configured to run the Best Practices against. The "default" profile DOES NOT '
            "align to Best Practice."
        )
    elif attr == "file_blocking_profiles":
        if version <= 7.1:
            return (
                "The device has no predefined or custom File Blocking profiles to run the "
                "Best Practices against."
            )
        elif version == 8:
            return (
                "The device has no custom File Blocking profiles configured, but "
                'there are two predefined profiles: "basic file blocking" and '
                '"strict file blocking". The "strict file blocking" profile aligns '
                'to Best Practice. The "strict file blocking" is configured to block both '
                'PE and Flash file types, whereas the "basic file blocking" is only configured '
                "to block PE file types."
            )
    elif attr == "wildfire_profiles":
        return (
            'The device only has the predefined "default" WildFire profile and no '
            'custom profiles configured to run the Best Practices against. The "default" profile '
            "DOES align to Best Practice."
        )
    elif attr == "dos_protection_profiles":
        return (
            "The device has no default or custom DoS Protection profiles "
            "configured to run the Best Practices against."
        )
    elif attr == "dos_protection_rulebase":
        return (
            "No DoS protection rules configured. "
            "DoS Protection rules are added to protect individual servers or systems and each DoS rule "
            "should be custom configured to the server capacity and requirements."
        )
    else:
        return False


def get_no_data_img(attr):
    """
    generate image when no config found.
    Args:
        attr: name of left_nav page to be displayed as message

    Returns: message and image to display.

    """
    TEMPLATE_DIR = join(dirname(__file__), "templates")
    IMAGE_DIR = join(TEMPLATE_DIR, "img")
    data = {"image": encode_image("no_data.png", IMAGE_DIR)}
    message = "Current configuration does not have {} configured".format(
        " ".join(attr.split("_")).title()
    )
    return message, data["image"]


def calculate_security_rules_passing_colspan(
    panoroma, is_rule_usage_info_available
) -> int:
    """This dynamically calculates the col span for the passing footer for BPA > Policies > Security
    security rule table
    """
    passing_colspan = 2
    if panoroma:
        # Since there will be 2 additional columns
        passing_colspan += 2
    if is_rule_usage_info_available:
        # Since there will be one additional column
        passing_colspan += 1
    return passing_colspan


def get_checks_per_csc(bpa_csc_mapping):
    """Reorganizes CSC Mapping data to get count of checks per CSC"""
    collector = defaultdict(int)
    for controls in bpa_csc_mapping.values():
        for csc in controls:
            collector[csc] += 1
    return collector


def package_html(
    bpat: BestPracticeAssessment, device_info: Dict, bpa_history: BPAHistory
) -> Dict:
    """Create Best Practice Assessment HTML report

    Args:
        bpat: BestPracticeAssessment object
        device_info: dictionary with data for device info tab
        bpa_history: Assessment history retrieved from db

    Returns:
        A dictionary of Best Practice Assessment context variables to be used in template.
    """

    # Add data from latest BPA into history
    bpa_history.add_assessment(
        tsf_generation_date=device_info["Tech Support File Generated Date"],
        latest_bpa=bpat,
    )

    # latest/current bpa data in flattened json format
    current_data = bpa_history.latest_bpa_flattened_json

    # Getting how many checks passed or failed in the new
    bpa_checks_pass_fail = BPAChecksPassFail.get_counts(
        bpat_flattened_json=bpa_history.latest_bpa_flattened_json
    )

    # Creating a Summary of the prior BPA data
    prior_data = bpa_history.get_previous_assessment(
        current_tsf_generation_date=bpa_history.current_tsf_generation_date
    )
    old_bpa_checks_pass_fail = {}
    if prior_data:
        old_bpa_checks_pass_fail = BPAChecksPassFail.get_counts(
            bpat_flattened_json=prior_data
        )

    # Getting an aggregate of the passes and failures mapped to the bp doc
    mapped_records = BPAChecksDocsMapping.map_checks_to_docs(
        current_pass_fail_checks=bpa_checks_pass_fail,
        previous_pass_fail_checks=old_bpa_checks_pass_fail,
        bpa_docs=bpat.bp_manager().model_manager().documentation,
    )

    formatted_mapped_records = None
    bpa_summary = None
    checks_per_csc = None
    sorted_csc_keys = None
    csc_metadata = None
    # added this lines to handle no data display message.
    if mapped_records is not None:
        formatted_mapped_records = mapped_records.format_data_util()

        # Creating a BPA Summary
        summarization_data = mapped_records.extract_summarization_data()

        bpa_summary = BPASummary.from_mappings(
            pass_fail_checks=bpa_checks_pass_fail, summarization_data=summarization_data
        )

        if prior_data is not None:
            prior_bpa_summary = BPASummary.from_mappings(
                pass_fail_checks=old_bpa_checks_pass_fail,
                summarization_data=summarization_data,
            )
        else:
            prior_bpa_summary = None

        # Comparing current summary with the summary of the prior BPA to calculate the amount of change.
        BPAChange(bpa_summary=bpa_summary).compare_change(
            compare_against=prior_bpa_summary
        )

        checks_per_csc = get_checks_per_csc(summarization_data["CSC Controls"])
        csc_metadata = {int(k.split(" ")[-1]): v for k, v in get_csc_meta().items()}
        csc_metadata = {k: v for k, v in csc_metadata.items() if checks_per_csc[k] > 0}
        sorted_csc_keys = [
            k
            for k in sorted(checks_per_csc.keys())
            if checks_per_csc[k] > 0 and k in csc_metadata
        ]

    data = {
        "bpa_mapping_records": formatted_mapped_records
        if formatted_mapped_records
        else None,
        "split_checks": split_checks,
        "get_panel_type": get_panel_type,
        "isboolean": isboolean,
        "guess_col_length": guess_col_length,
        "add_to_dict": add_to_dict,
        "all_dicts": all_dicts,
        "bad_val": bad_val,
        "render_iterable": render_iterable,
        "modal_attr": modal_attr,
        "get_options": get_options,
        "get_no_results_message": get_no_results_message,
        "get_no_data_img": get_no_data_img,
        "count_number_of_checks": count_number_of_checks,
        "get_check_names": get_check_names,
        "get_bp_check_results": get_bp_check_results,
        "is_multi_vsys": bpat.is_multi_vsys,
        "object_categories": get_object_categories(),
        "learn_more_urls": get_learn_more_urls(),
        "display_attrs": get_attributes(bpat, ["security_rules", "security_rulebase"]),
        "report_generated": datetime.datetime.today().strftime("%Y-%m-%d %H:%M:%S"),
        "device_info": device_info,
        "modals": BPChecksDescription().get(bpat=bpat),
        "security_rules": get_security_rules(bpat.security_rules),
        "badges": {**get_top_nav_badges(current_data), **get_left_nav_badges(bpat)},
        "bpa_metrics": ["policies", "objects", "network", "device"],
        "bpa_summary": bpa_summary.data if bpa_summary else None,
        "checks_per_csc": checks_per_csc if checks_per_csc else None,
        "sorted_csc_keys": sorted_csc_keys if sorted_csc_keys else None,
        "csc_metadata": csc_metadata if csc_metadata else None,
        "mapping_definitions": None
        if not all([csc_metadata, checks_per_csc, sorted_csc_keys])
        else True,
        "decryption_profile_used": any(
            rule["configuration"]["decryption_profile"] != "None"
            for rule in bpat.decryption_rules
        ),
        "security_rules_passing_colspan": calculate_security_rules_passing_colspan,
    }
    data["bpa_trend"] = BPATrend().create_trend(bpa_history, bpat.panorama)
    if bpat.panorama:
        data["bpa_metrics"].append("panorama")

    return data
