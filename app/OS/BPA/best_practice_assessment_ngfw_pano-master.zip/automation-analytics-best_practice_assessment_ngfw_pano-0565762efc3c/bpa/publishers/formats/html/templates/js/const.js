// Use this file to define any JavaScript constants to be used in other modules

const panorama = {{ json_dumps(panorama) }};
const version = {{ version }};