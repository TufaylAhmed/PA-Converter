// JavaScript for Heatmap Report

const heatmap_values = {{ heatmap_values }};
const heatmap_raw_values = {{ heatmap_raw_values }}
const areas_of_architecture_length = {{areas_of_architecture}}.length;
const content_update_age = {{ json_dumps(content_update_age) }};

// enable Bootstrap 3 Tooltips
//https://getbootstrap.com/docs/3.3/javascript/#tooltips
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})


$(document).ready(function(){
  let thresholds = {
    'app-release-date': [30, 7],
    'av-release-date': [7, 1],
    // WF only has one threshold to check, so using Infinity as a placeholder
    'wildfire-release-date': [1, Infinity],
  }

  for (let item in content_update_age) {
    let days_old = content_update_age[item]/60/60/24;
    let threshold_1 = thresholds[item][0],
        threshold_2 = thresholds[item][1];
    if (days_old > threshold_1) {
      $(`li[data-info-item="${item}"]`).css("color", "red");
    } else if (days_old > threshold_2) {
      $(`li[data-info-item="${item}"]`).css("color", "orange");
    }
  }
});


// Highlight if PAN-OS software version is End-of-Life
const is_eol = {{ json_dumps(is_eol) }};
$(document).ready(function(){
  if (is_eol[0] === true) {
    $('li[data-info-item="sw-version"]').append('[End-of-Life Software]').css("color", "red");
  }
});


// ensure all percentage metrics are rounded to 1 decimal place
function format_measures(row) {
  // leave the counts as whole numbers
  for (let metric of display_measures.slice(3)) {
    row[metric] = row[metric].toFixed(1)
  }
}


let metrics = [
  {'name': 'Total Rule Count', 'numerator': 'total_rule_count'},
  {'name': 'Allow Rule Count', 'numerator': 'allow_rule_count'},
  {'name': 'Deny Rule Count', 'numerator': 'deny_rule_count'},
  {'name': 'WildFire Adoption %', 'numerator': 'wildfire_enabled', 'denominator': 'allow_rule_count'},
  {'name': 'Anti-Spyware Adoption %', 'numerator': 'antispyware_enabled', 'denominator': 'allow_rule_count'},
  {'name': 'DNS Sinkhole Adoption %', 'numerator': 'dns_sinkhole_enabled', 'denominator': 'allow_rule_count'},
  {'name': 'Anti-Virus Adoption %', 'numerator': 'antivirus_enabled', 'denominator': 'allow_rule_count'},
  {'name': 'Vulnerability Protection Adoption %', 'numerator': 'vulnerability_enabled', 'denominator': 'allow_rule_count'},
  {'name': 'URL-Filtering Adoption %', 'numerator': 'url_filtering_enabled', 'denominator': 'allow_rule_count'},
  {'name': 'Credential Theft Adoption %', 'numerator': 'credential_theft_enabled', 'denominator': 'allow_rule_count'},
  {'name': 'File-Blocking Adoption %', 'numerator': 'file_blocking_enabled', 'denominator': 'allow_rule_count'},
  {'name': 'Data-Filtering Adoption %', 'numerator': 'data_filtering_enabled', 'denominator': 'allow_rule_count'},
  {'name': 'User ID Adoption %', 'numerator': 'user_id_enabled', 'denominator': 'allow_rule_count'},
  {'name': 'App ID Adoption %', 'numerator': 'app_id_enabled', 'denominator': 'allow_rule_count'},
  {'name': 'Service / Port Adoption %', 'numerator': 'service_port_configured', 'denominator': 'allow_rule_count'},
  {'name': 'Logging Adoption %', 'numerator': 'log_end', 'denominator': 'total_rule_count'},
  {'name': 'Log Forwarding Adoption %', 'numerator': 'log_forwarding_enabled', 'denominator': 'total_rule_count'},
  {'name': 'Zone Protection Profile Adoption %', 'numerator': 'zone_protection_profile_enabled', 'denominator': 'total_rule_count'},
];
if (version < 8) {
  metrics.splice(9, 1)
}

function get_strict_targets() {
    return [
    'wildfire_enabled',
    'antispyware_enabled',
    'dns_sinkhole_enabled',
    'antivirus_enabled',
    'vulnerability_enabled',
    'url_filtering_enabled',
    'credential_theft_enabled',
    'file_blocking_enabled',
  ]
}

function get_strict_metrics(record) {
  let targets = get_strict_targets()

  if (targets.includes(record['numerator'])) {
    record['numerator'] = record['numerator'] + '_strict'
  }

  return record
}

// Trending Tab Functions
$('#trend-bp-mode-radio input').click(function(){
    const init_industry_average_available = {{1 if industry_average else 0}}
    if ($('input:checked').val() == "adoption"){
        $('.trend-adoption_mode').removeClass('hidden');
        $('.trend-bp_mode').addClass('hidden');
        if (init_industry_average_available == 1){
            $('#heatmap_trend_table').addClass('trend_with_industry');
        }
    } else {
        $('.trend-adoption_mode').addClass('hidden');
        $('.trend-bp_mode').removeClass('hidden');
        $('#heatmap_trend_table').removeClass('trend_with_industry');
    }
});

// these are the only measures we will display on the heatmap tables
let display_measures =  metrics.map(record => record['name']);

// builds sql query based on provided dimensions / measures
function build_sql_query(dimensions, measures) {
  // using slice to remove the trailing ', '
  let measures_sql = measures.reduce(
    function (accumulator, metric) {
      if (metric['name'].slice(-5) === 'Count') {
        return accumulator + `SUM(${metric['numerator']}) as \`${metric['name']}\`, `
      } else {
        return accumulator + `IFNULL(ROUND((SUM(${metric['numerator']}) / SUM(${metric['denominator']})) * 100, 1), 0) as \`${metric['name']}\`, `
      }
    },
    ''
  ).slice(0, -2);

  if (Array.isArray(dimensions)) {
    let dimensions_sql = dimensions.map(dim => `\`${dim}\``).join();
    return `SELECT ${dimensions_sql}, ${measures_sql} FROM ? GROUP BY ${dimensions_sql}`
  } else {
    return `SELECT ${measures_sql} FROM ?`
  }
}

// Build query to group heatmap values
function build_grouping_sql_query(summation_fields, group_by=['dest_area_of_architecture', 'dest_zone', 'device_group', 'source_area_of_architecture', 'source_zone', 'tags', 'target']) {
  // using slice to remove the trailing ', '
  let measures_sql = summation_fields.reduce(
    function (accumulator, metric) {
        return accumulator + `IFNULL(ROUND((SUM(${metric})), 1), 0) as \`${metric}\`, `
    },
    ''
  ).slice(0, -2);

  let dimensions_sql = group_by.map(dim => `\`${dim}\``).join();
  return `SELECT ${dimensions_sql}, ${measures_sql} FROM ? GROUP BY ${dimensions_sql}`
}

// queries provided dataset and returns formatted heatmap data
function get_heatmap_data(dimensions, measures, data) {
  if (data.length === 0) {
    return [];
  }
  let result = alasql(build_sql_query(dimensions, measures), [data]);
  result.forEach(format_measures);
  return result;
}

// groups provided data set to how heatmap_values is setup
function group_heatmap_data(summation_fields, data) {
  if (data.length === 0) {
    return [];
  }
  let result = alasql(build_grouping_sql_query(summation_fields=summation_fields), [data]);
  return result;
}

// Create aggregated views for each heatmap
if (panorama) {
  var dg_heatmap_table = get_heatmap_data(['device_group'], metrics, heatmap_values);
}
var tags_heatmap_table = get_heatmap_data(['tags'], metrics, heatmap_values);
var sn_vsys_heatmap_table = get_heatmap_data(['target'], metrics, heatmap_values);
var zone_heatmap_table = get_heatmap_data(['source_zone','dest_zone'], metrics, heatmap_values);;
var arch_heatmap_table = get_heatmap_data(['source_area_of_architecture','dest_area_of_architecture'], metrics, heatmap_values);;
var grand_totals = get_heatmap_data(null, metrics, heatmap_values);


//insert tfoot into tables
function addFooterTotals(table_id, grand_total_data){
  if (grand_total_data.length === 0) {
    return;
  }

  // use slice to remove the #
  var table = document.getElementById(table_id.slice(1)); 
  
  if (_.isEmpty(table.getElementsByTagName('tfoot'))) { 
    // if footer does not already exist in the DOM, create the HTML
    var footer_cells = _.map(display_measures, function(col){ return '<th>'+grand_total_data[0][col]+'</th>' }).join('');

    //zone heatmap has an extra column, so need to change the colspan of first cell
    if (table_id === '#zone_heatmap_table' || table_id === '#arch_heatmap_table') { 
      first_cell = '<th colspan="2"><strong>Grand Total:</strong></th>';
    }
    else {
      first_cell = '<th><strong>Grand Total:</strong></th>';
    }

    var footer = document.createElement('tfoot');
    footer.innerHTML = '<tr>' + first_cell + footer_cells + '</tr>';
    table.appendChild(footer);
  }
  else {
    // if footer already exists, iterate through and update the values
    var new_footer_vals = ['Grand Total'].concat(_.map(display_measures, function(col){ return grand_total_data[0][col] }));
    var footer_cells = $(table_id).DataTable().table().footer().querySelectorAll('th');
    for (var i = new_footer_vals.length - 1; i >= 0; i--) {
      footer_cells[i].textContent = new_footer_vals[i]
    }
  }
}


//initialize grand totals on all heatmaps
let heatmap_ids = [
  '#dg_heatmap_table', 
  '#tags_heatmap_table', 
  '#sn_vsys_heatmap_table', 
  '#zone_heatmap_table',
  '#arch_heatmap_table'
];
if (!panorama) {
  heatmap_ids.splice(0, 1);
}
for (var i = heatmap_ids.length - 1; i >= 0; i--) {
  addFooterTotals( heatmap_ids[i], grand_totals );
}


// Apply conditional formatting
function applyConditionalFormatting(table_id, is_panorama=null) {
  //determine which rows need the conditional formatting applied (zone heatmap has an extra column)
  let td_start = 6;
  let selector = '';

  if (table_id==='#heatmap_trend_table'){
    //  Do not apply conditional formatting to rule counts or metric titles

    // As of BPA 180 the number of rule counts will be dynamic dependent on if device is a panorama
    if (is_panorama == true) {
      selector = 'table#heatmap_trend_table tr:nth-child(n+6) td:nth-child(n+2)';
    } else {
      selector = 'table#heatmap_trend_table tr:nth-child(n+5) td:nth-child(n+2)';
    }
  } else {
    if (table_id === '#tags_heatmap_table' || table_id === '#sn_vsys_heatmap_table' || table_id === '#dg_heatmap_table') {
      td_start = 5;
    }
    selector = `table${table_id} tbody td:nth-child(n+${td_start}), table[data-id="${table_id}"] tfoot th:nth-child(n+5)`;
  }

  $(selector).each(
    function() { //only apply to columns 5 through 15
      let val = parseFloat($(this).text());

      if (isNaN(val) || val === 0) {
          //if value is 0, we don't want to apply conditional formatting
          $(this).css('background-color', '');
      } else {
          //coerce val to float between 0 and 1
          val = Math.min(val, 100)/100

          //generate the background color
          var hue = (val*120).toString(10);

          //hsl = hue, saturation, and lightness
          var color = ["hsl(",hue,",100%,68%)"].join("");

          $(this).css('background-color', color);
      }
    }
  );

}

applyConditionalFormatting('#heatmap_trend_table', {{panorama | lower}});


{% if panorama %}
// Initialize device group heatmap datatable
$('#dg_heatmap_table').DataTable( {
  "columnDefs": [{ "title":"Device Group", "name":"device_group", "data":"device_group", "targets":0, "type":"string" }].concat(
    _.map(display_measures, function(value, index){ return { "title":value, "name":value, "data":value, "targets":index+1, "type":"num" }; }) ),
  "data": dg_heatmap_table,
  "scrollX": true,
  "scrollY": 600,
  "scrollCollapse": true, //reduce height if there are only a few rows
  "paging": true,
  "pageLength": 50,
  "lengthChange": false, //disable user page display toggle
  "deferRender": true,
  "processing": true,
  "order": [[1,'desc']], //sort based on total rule count
  "initComplete": function( settings, json ) {
    applyConditionalFormatting('#dg_heatmap_table');
  },
  "language": {
      "emptyTable": "Filter(s) yielded no results"
    },
  dom: 'frtiBp',
  buttons: [
        {
            extend: 'csv',
            text: 'Export Data'
        }
    ]
} );
{% endif %}

// Initialize tags heatmap datatable
$('#tags_heatmap_table').DataTable( {
  "columnDefs": [{ "title":"Tags", "name":"tags", "data":"tags", "targets":0, "type":"string" }].concat(
    _.map(display_measures, function(value, index){ return { "title":value, "name":value, "data":value, "targets":index+1, "type":"num" }; }) ),
  "data": tags_heatmap_table,
  "scrollX": true,
  "scrollY": 600,
  "scrollCollapse": true, //reduce height if there are only a few rows
  "paging": true,
  "pageLength": 50,
  "lengthChange": false,
  "deferRender": true,
  "processing": true,
  "order": [[1,'desc']], //sort based on total rule count
  "initComplete": function( settings, json ) {
    applyConditionalFormatting('#tags_heatmap_table');
  },
  "language": {
      "emptyTable": "Filter(s) yielded no results"
    },
  dom: 'frtiBp',
  buttons: [
        {
            extend: 'csv',
            text: 'Export Data'
        }
    ]
} );

// Initialize sn_vsys heatmap datatable
$('#sn_vsys_heatmap_table').DataTable( {
  "columnDefs": [{ "title":"Target Devices", "name":"target", "data":"target", "targets":0, "type":"string" }].concat(
    _.map(display_measures, function(value, index){ return { "title":value, "name":value, "data":value, "targets":index+1, "type":"num" }; }) ),
  "data": sn_vsys_heatmap_table,
  "scrollX": true,
  "scrollY": 600,
  "scrollCollapse": true, //reduce height if there are only a few rows
  "paging": true,
  "pageLength": 50,
  "lengthChange": false,
  "deferRender": true,
  "processing": true,
  "order": [[1,'desc']], //sort based on total rule count
  "initComplete": function( settings, json ) {
    applyConditionalFormatting('#sn_vsys_heatmap_table');
  },
  "language": {
      "emptyTable": "Filter(s) yielded no results"
    },
  dom: 'frtiBp',
  buttons: [
        {
            extend: 'csv',
            text: 'Export Data'
        }
    ]
} );

// Initialize zones heatmap datatable
$('#zone_heatmap_table').DataTable( {
  "columnDefs": [{ "title":"Source Zone", "name":"source_zone", "data":"source_zone", "targets":0, "type":"string" }, { "title":"Destination Zone", "name":"dest_zone", "data":"dest_zone", "targets":1, "type":"string" }].concat(
    _.map(display_measures, function(value, index){ return { "title":value, "name":value, "data":value, "targets":index+2, "type":"num" }; }) ),
  "data": zone_heatmap_table,
  "scrollX": true,
  "scrollY": 600,
  "scrollCollapse": true, //reduce height if there are only a few rows
  "paging": true,
  "pageLength": 50,
  "lengthChange": false,
  "deferRender": true,
  "processing": true,
  "order": [[2,'desc']], //sort based on total rule count
  "initComplete": function( settings, json ) {
    applyConditionalFormatting('#zone_heatmap_table');
  },
  "language": {
      "emptyTable": "Filter(s) yielded no results"
    },
  dom: 'frtiBp',
  buttons: [
        {
            extend: 'csv',
            text: 'Export Data'
        }
    ]
} );


// Initialize area of architecture heatmap datatable
$('#arch_heatmap_table').DataTable( {
  "columnDefs": [{ "title":"Source Area of Architecture", "name":"source_area_of_architecture", "data":"source_area_of_architecture", "targets":0, "type":"string" }, { "title":"Destination Area of Architecture", "name":"dest_area_of_architecture", "data":"dest_area_of_architecture", "targets":1, "type":"string" }].concat(
    _.map(display_measures, function(value, index){ return { "title":value, "name":value, "data":value, "targets":index+2, "type":"num" }; }) ),
  "data": arch_heatmap_table,
  "scrollX": true,
  "scrollY": 600,
  "scrollCollapse": true, //reduce height if there are only a few rows
  "paging": true,
  "pageLength": 50,
  "lengthChange": false,
  "deferRender": true,
  "processing": true,
  "order": [[2,'desc']], //sort based on total rule count
  "initComplete": function( settings, json ) {
    applyConditionalFormatting('#arch_heatmap_table');
  },
  "language": {
      "emptyTable": "Filter(s) yielded no results"
    },
  dom: 'frtiBp',
  buttons: [
        {
            extend: 'csv',
            text: 'Export Data'
        }
    ]
} );

//Apply conditional formatting to heatmap tables whenever they are re-drawn
$('#tags_heatmap_table, #sn_vsys_heatmap_table, #dg_heatmap_table, #zone_heatmap_table, #arch_heatmap_table').on( 'draw.dt', function () {
    applyConditionalFormatting('#'+$(this).attr('id'));
} );



function titleCase(str) {
  str = str.toLowerCase().split('_');
  for (var i = 0; i < str.length; i++) {
    str[i] = str[i].charAt(0).toUpperCase() + str[i].slice(1); 
  }
  return str.join(' ');
}
// Initialize the Rule Details DataTable
const rules_values = {{ rules_values }};
let rule_detail_columns = {{ rule_detail_columns }};


let strict_lookups = {
  'wildfire_profile_name': 'wildfire_enabled_strict',
  'url_filtering_profile_name': 'url_filtering_enabled_strict',
  'av_profile_name': 'antivirus_enabled_strict',
  'spyware_profile_name': 'antispyware_enabled_strict',
  'vuln_profile_name': 'vulnerability_enabled_strict',
  'file_blocking_profile_name': 'file_blocking_enabled_strict',
};

var table = $('#rule_table').DataTable( {
  "columnDefs": _.map(rule_detail_columns, function(value, index){ return { "title":titleCase(value), "name":value, "data":value, "targets":index }; }),
  "scrollX": true,
  "scrollY": 600,
  "scrollCollapse": true, //reduce height if there are only a few rows
  "paging": true,
  "pageLength": 50,
  "lengthChange": false,
  "data": rules_values,
  "deferRender": true,
  "processing": true, //show processing message when user is sorting
  "search": {
      "regex": true
    },
  "language": {
    "emptyTable": "Filter(s) yielded no results"
  },
  dom: 'frtiBp',
  buttons: [
    {
      extend: 'csv',
      text: 'Export Data'
    }
  ],
  // "createdRow": function( row, data, dataIndex ) {
  //   // highlight profile names that do not pass strict check
  //   _.forEach(strict_lookups, function(strict_metric, profile_name) {
  //     if (data[strict_metric] === 'no' && data[profile_name] !== 'none') {
  //       let target_index = rule_detail_columns.indexOf(profile_name);
  //       $('td', row).eq(target_index).addClass('fail');
  //     }
  //   });
  // }
});

//shift the rule details search bar to the left
$('#rule_table_wrapper > div:nth-child(1) > div:nth-child(1)').remove();
$('#rule_table_filter > label').addClass('pull-left');

let column_values = {{ column_values }};
var showData = changeHeaderValueForTarget(rules_values);

displayPageInfoText(showData);


function generateColumnWithData(){

//For option values provided in the column_values variable, convert to a concatenated string and append to relevant select tag
var provided_options = Object.keys(column_values);
for (var i = provided_options.length - 1; i >= 0; i--) {
    // create the concatenated string of HTML option tags
    var option_string = _.map(column_values[provided_options[i]], function(val){ return '<option value="'+val+'">'+val+'</option>' }).join('');
    // this assumes that the name attribute of the select tag matches the key provided in column_values
    $(`select.use-col-vals[name='${provided_options[i]}']`).append( option_string );

}
}
generateColumnWithData()

// Apply the bootstrap-select library to our filters 
var column_filters = $('select.col-filter');
column_filters.selectpicker({
  liveSearch: true,
  actionsBox: true,
  selectedTextFormat: "count > 1",
});

// made a function to display placeholder
function changeHeaderValueForTarget(data){
    let all_targets = [];
    for (d in data){
      all_targets.push(data[d]["target"]);
    }
    let firewalls = [];
    let unique_firewalls = all_targets.forEach(function(item)
    {
        if (item !== "NO_TARGET")
        {
            let new_item = item.split(":");
            if (!firewalls.includes(new_item[0]))
                {
                    firewalls.push(new_item[0]);
                }
         }
    }
    )
    return ' targeting ' + firewalls.length.toString() + ' firewalls';
}

// Add event handler to clear filters on rule details tab
$('button.clear-filter').click(
  function() {
    //target all of the dropdowns within the same "well" area as the button
    $(this).parents('div.well').find('.col-filter').selectpicker('deselectAll');
    // Redraw the table with original dataset
    renderAllRows(rules_values);
  }
);


// Add event handler to clear filters on heatmap tabs
$('button.heatmap-clear-filter').click(
  function() {
    let table = $( $(this).data('table') );

    //since we're clearing the filters, just re-use the original dataset
    let original_data = eval( $(this).data('table').slice(1) );
    addFooterTotals($(this).data('table'), grand_totals);
    table.DataTable().clear().rows.add(original_data).draw();

    // target all of the filters within the same "well" area as the button
    let filter_well = $(this).parents('div.well');
    filter_well.find('.col-filter').selectpicker('deselectAll');
    filter_well.find('input.strict').prop("checked", false);
    filter_well.find('input.strict-rule-hit').prop("checked", false);
  }
);

// Collect selected filter values
function collect_filters(filter_button) {
  let filters = {};
  //target all of the dropdowns within the same "well" area
  $(filter_button).parents('div.well').find('select.col-filter').each(
    function() {
      let selected_options = $(this).val(); //returns all selected options in array

      // If no options are selected or all options are selected, do not use to filter
      if (selected_options == null || selected_options.length === 0 || selected_options.length === $(this).children('option').length) {
        return true;
      } else {
        // name of select tag should align with column names in our dataset
        let name = $(this).attr('name');
        filters[name] = selected_options;
      }
    }
  );
  return filters;
}
// maaping all bp check results for objects -> security profiles tab
const bpCheckMappings = {
  'av_profile_name':['antivirus_profile_threat_exceptions_bp_check','antivirus_profile_application_exceptions_bp_check','antivirus_profile_decoder_actions_bp_check','antivirus_profile_decoder_wildfire_actions_bp_check','antivirus_profile_packet_capture_bp_check','reset-client_/_reset-server_actions_bp_check_for_av','unused_security_profile_bp_check_for_av'],
  'wildfire_profile_name':['wildfire_profile_file_types_bp_check','unused_security_profile_bp_check_for_wildfire'],
  'file_blocking_profile_name':['file_blocking_strict_profile_bp_check','unused_security_profile_bp_check_for_file_blocking'],
  'spyware_profile_name':['anti_spyware_profile_threat_exceptions_bp_check','botnet_configuration_bp_check','dns_sinkhole_bp_check','passive_dns_monitoring_bp_check','anti-spyware_strict_profile_bp_check','anti-spyware_low/informational_profile_bp_check','reset-client_/_reset-server_actions_bp_check_for_spyware','unused_security_profile_bp_check_for_spyware'],
  'url_filtering_profile_name':['url_profile_known_bad_categories_bp_check','log_container_page_bp_check','url_filtering_profile_allow_categories_bp_check','credential_theft_bp_check','credential_phishing_mode_bp_check','unused_security_profile_bp_check_for_url_filtering'],
  'vuln_profile_name':['vulnerability_protection_profile_threat_exceptions_bp_check','vulnerability_protection_strict_profile_bp_check','vulnerability_protection_low/informational_profile_bp_check','reset-client_/_reset-server_actions_bp_check_for_vuln','unused_security_profile_bp_check_for_vuln']
};

// Use alasql to query rules_values data based on selected filters
function filter_rule_detail(filters) {
  let where_clause = [];
  if (_.isEmpty(filters)) {
    where_clause.push(1)
  } else {
    if (_.has(filters, 'source_area_of_architecture')) {
      filters.source_area_of_architecture.push('any')
    }
    if (_.has(filters, 'dest_area_of_architecture')) {
      filters.dest_area_of_architecture.push('any')
    }
    if (_.has(filters, 'traffic_hit_days')) {
        if (filters.traffic_hit_days.includes("yes")){
            filters.traffic_hit_days = ["^[1-9]\\d*$"]
        } else if (filters.traffic_hit_days.includes("90-days")){
            filters.traffic_hit_days = ["^[1-9]$|^[1-8][0-9]$|^90$"]
        } else if (filters.traffic_hit_days.includes("no")){
            filters.traffic_hit_days = ["^-1$"]
        }
    }
    // handle scenario when only security_profile_verdict is selected. In that case needs to pass whole data
    if (Object.keys(filters).length === 1 && _.has(filters,'security_profile_verdict')){
      let securityProfileVerdictResult = securityProfileVerdictFilter(filters,rules_values);
      return securityProfileVerdictResult;
    }
    for (const [filter_name, values] of Object.entries(filters)) {
      if(filter_name !== 'security_profile_verdict'){
        let column_name = `\`${filter_name}\``;
        let values_regex = values.join('|');
        where_clause.push(`(${column_name}) REGEXP "${values_regex}"`)
      }

    }
  }

  // redraw table with filtered data
  let query = `SELECT * FROM ? WHERE ${where_clause.join(' AND ')}`;
  let data = alasql(query, [rules_values]);
  // handle scenario when security_profile_verdict is selected along with other filters and data is null.
  // in that case no need to call function for security_profile_verdict.
  if (data.length === 0){
    return data;
  }
  if (_.has(filters,'security_profile_verdict')){
    let securityProfileVerdictResult = securityProfileVerdictFilter(filters,data);
    return securityProfileVerdictResult;
  }

  return data;
}

function securityProfileVerdictFilter(filters,data){

      // see if any filters from my bp_check_mappings.key has been selected or not.
      // if selected then only care about those else care about all bp_checks
      // handle note scenario. note name can be note(caution) also. treat both same way.
      let selectedFilters = [];

      // need to know if av or spyware or anything else has been selected or not.
      // handled above description here.
      for (const [key, value] of Object.entries(filters)) {
        if (_.indexOf(Object.keys(bpCheckMappings),key) != -1){
            selectedFilters.push(key);
        }
      }
      let where_clause = [];
      if (selectedFilters.length != 0){
        // handle where av or spyware or anything else is selected along with security_profile_verdict.
        // for ex antivirus_profile == 'name' and security_profile_verdict == 'pass'
        const filteredObj = _.pick(bpCheckMappings, selectedFilters)
        for (const [key, value] of Object.entries(filteredObj)) {
          value.forEach(function (item, index) {
            filters[item] = filters.security_profile_verdict;
          });
          // deleting key to maintain sql query
          delete filters[key];
        }
        // deleting key to maintain sql query
        delete filters.security_profile_verdict;
      }
      // handle scenario when only security_profile_verdict is selected.
      else{
        for (const [key, value] of Object.entries(bpCheckMappings)) {
          value.forEach(function (item, index) {
            filters[item] = filters.security_profile_verdict;
          });
        }
        // deleting key to maintain sql query
        delete filters.security_profile_verdict;
      }
      // making sql queries with filter values.
      for (const [filter_name, values] of Object.entries(filters)) {
        let column_name = `\`${filter_name}\``;
        let values_regex = values.join('|');
        where_clause.push(`(${column_name}) REGEXP "${values_regex}"`)
    }
      let query = `SELECT * FROM ? WHERE ${where_clause.join(' OR ')}`;
      let filteredData = alasql(query, [data]);
      return filteredData;

}

function renderAllRows(allData){
 let displayNewShowData = changeHeaderValueForTarget(allData);
 $('#rule_table').DataTable().clear().rows.add(allData).draw();
 displayPageInfoText(displayNewShowData);


}

function displayPageInfoText(inputString){
  let pageInfoDataNew = $('#rule_table_info').text().replace("entries","policies")
  $('#rule_table_info').text(pageInfoDataNew + inputString );
}

//Add event handler to rule filter apply button
$('button.rule-filter').click(
  function() {
    let filters = collect_filters(this);
    let allData = filter_rule_detail(filters);
    renderAllRows(allData);
  }
);

// Returns TRUE if AT LEAST ONE of the row values is present in the filter values
function passes_includes_filter(row_values, filter_values) {
  return row_values.some(val => filter_match_any(val, filter_values));
}

// Returns TRUE if ALL of the filter values are present in the row values
// AND ALL of the row values are present in the filter values
function passes_exact_filter(row_values, filter_values) {
  if (row_values[0] == 'any' && filter_values.length == areas_of_architecture_length) {
    return true
  } else {
      return is_every_array1_value_in_array2(row_values, filter_values) &&
        is_every_array1_value_in_array2(filter_values, row_values);
    }
}

// Returns TRUE if every_array1 value is in array2
function is_every_array1_value_in_array2(array1, array2) {
  return array1.every(value => filter_match_any(value, array2));
}

// Returns TRUE if 'value' is equal to 'any' or 'value' is in array_values
// note: 'any' is equal to [Perimeter, Internet, DMZ, 3rd Party, ..., ..., PCI, SCADA/ICS] and represents all values
function filter_match_any(value, array_values) {
  if (value == 'any') {
    return true
  } else {
      return _.includes(array_values, value)
    }
}

// Returns TRUE if (value is equal to 'any' AND array_values is equal to total areas of architecture) OR value IN array
function filter_match_only(value, array_values) {
  if (value == 'any' && array_values.length == areas_of_architecture_length) {
    return true
  } else {
      return _.includes(array_values, value)
    }
}

// returns true if ALL of the row values are present in the filter values
// note: filter_values can have extra values not present in row values
function passes_only_filter(row_values, filter_values) {
  return row_values.every(val => filter_match_only(val, filter_values));
}


// applies selected filters to a row of heatmap_values
// expects a context object with a 'type' string and
// 'filters' object where values are arrays
function apply_filters(row) {
  let keep = true;
  let passes_filter = null;

  if (this.type === 'includes') {
    passes_filter = passes_includes_filter;
  } else if (this.type === 'exact') {
    passes_filter = passes_exact_filter;
  } else {
    passes_filter = passes_only_filter;
  }

  for (const col in this.filters) {
    let row_values = row[col].split(', ');
    let filter_values = this.filters[col];
    if (! passes_filter(row_values, filter_values)) {
      keep = false;
      break;
    }
  }

  return keep;
}


//Add event handler to heatmap filter apply buttons
$('button.heatmap-filter').click(
  function() {
    var table = $( $(this).data('table') );
    let dimensions = table.data('index').split(',');
    let filters = collect_filters(this);
    let filter_well = $(this).parents('div.well');

    let filter_type = 'includes';
    if (filter_well.find('input.exact').prop( "checked")) {
      filter_type = 'exact';
    } else if (filter_well.find('input.only').prop( "checked")) {
      filter_type = 'only';
    }

    let context = {'type': filter_type, 'filters': filters};

    let filtered_data = heatmap_values

    // create a deep copy of metrics to avoid overwriting the original numerator values
    // let measures = [...metrics];
    let measures = _.cloneDeep(metrics);

    // If enable traffic hit rules check box is checked then further filter the data to only have the
    // rows with traffic hitting i.e traffic_hit not equal 0
    let strict_rule_hit_enabled = filter_well.find('input.strict-rule-hit').prop("checked");
    if (strict_rule_hit_enabled) {

      // This filtering will need to be done on the raw data and then regrouped as heatmap_values is a grouped data
      // and does not have individual itemized rules
      filtered_data = heatmap_raw_values.filter((row) => row["traffic_hit_within_time_frame"] != 0);

      // We need to get a list of regular + strict measures to sum up all numerical columns
      let strict_targets = get_strict_targets().map(target => target + "_strict")
      let all_measures =  measures.map(measure => measure["numerator"]).concat(strict_targets);

      filtered_data = group_heatmap_data(all_measures, filtered_data)
    }

    filtered_data = filtered_data.filter(apply_filters, context);

    table.DataTable().clear();

    if (filtered_data.length !== 0) {
      let strict_enabled = filter_well.find('input.strict').prop("checked");
      if (strict_enabled) {
        measures.map(get_strict_metrics)
      }
      let filtered_heatmap = get_heatmap_data(dimensions, measures, filtered_data);
      table.DataTable().rows.add(filtered_heatmap);
    }

    // update the footer grand totals to use the filtered data
    let footer_data = get_heatmap_data(null, measures, filtered_data);
    addFooterTotals($(this).data('table'), footer_data)

    table.DataTable().draw();
  }
);

//resize the multiselect buttons by adding bootstrap class
$('button.multiselect').addClass('btn-sm');

// Unbind default datatables search functionality
let rule_table_input = $("div#rule_table_filter input");
rule_table_input.unbind();
// Change search functionality to apply global regex filter on Enter key press
rule_table_input.keyup( function (e) {
    if (e.keyCode == 13) { // 13 represents the enter key
        $('#rule_table').DataTable().search(
            $(this).val(),
            regex=true,
            smart=false
        ).draw();
    }
});






//////////////////////////////
// Adoption Summary logic starts here
//////////////////////////////
{% if industry_average %}
const industry_average = {{ json_dumps(industry_average) }};
{% else %}
const industry_average = [];
{% endif %}

const levels = ["WildFire", "Anti-Virus", "Anti-Spyware", "DNS Sinkhole", "Vulnerability Protection", "URL-Filtering", "Credential Theft", "File-Blocking", "Data-Filtering"];
if (version < 8) {
  levels.splice(6, 1);
  chart_labels = levels.slice(0);
} else {
  chart_labels = levels.slice(0);
  chart_labels[6] = 'Credential Phishing Prevention';
}
const overall_data = [];
const bp_data = [];
const industry_data = [];

let strict_measures = _.cloneDeep(metrics);
strict_measures.map(get_strict_metrics)
let strict_totals = get_heatmap_data(null, strict_measures, heatmap_values);

for (let metric of levels) {
  key = `${metric} Adoption %`;
  overall_data.push(_.get(grand_totals, `[0][${key}]`, '0.0'));
  // No BP Mode for Data-Filtering
  if (metric != 'Data-Filtering') {
    bp_data.push(_.get(strict_totals, `[0][${key}]`, '0.0'));
  }
  industry_data.push(industry_average[key]);
}

const heatmap_summary = {{ json_dumps(heatmap_summary) }};

function getBarChartOptions(metric_deltas) {
  return {
    scales: {
        yAxes: [{
            ticks: {
                beginAtZero:true
            },
            gridLines: {
                display: false,
            }
        }],
        xAxes: [{
            gridLines: {
                display: false,
                drawBorder: false,
            },
            ticks: {
                // Include a dollar sign in the ticks
                callback: function(value, index, values) {
                    return null;
                },
                max: 100,
                min: 0,
            },
        }],
    },
    title: {
        display: true,
        // text: 'Overall Adoption'
    },
    legend: {
        display: false,
    },
    layout: {
        padding: {
            // left: 50,
            // right: 0,
            top: -40,
            bottom: -50,
        }
    },
    plugins: {
        datalabels: {
            anchor: function(context) {
                return context.dataset.data[context.dataIndex] <= 35 ? 'end' : 'center';
            },
            align: function(context) {
                return context.dataset.data[context.dataIndex] <= 35 ? 'end' : 'center';
            },
           //  display: function(context) {
           //    return context.dataset.data[context.dataIndex] !== 0;
           // },
           formatter: function(value, context) {
            if (context.dataset.data[context.dataIndex] != '') {
              if (metric_deltas === undefined) {
                return context.dataset.data[context.dataIndex] + '%';
              } else {
                return context.dataset.data[context.dataIndex] + '% (' + metric_deltas[context.dataIndex] + ')';
              }
            }
          }
      }
   },
};
}

let overall_colors = []
for(var i = 0; i < overall_data.length; i++){
   overall_colors[i] = get_color(round5(overall_data[i]));
}

let industry_colors = []
for(var i = 0; i < industry_data.length; i++){
   industry_colors[i] = get_color(round5(industry_data[i]));
}

let bp_colors = []
for(var i = 0; i < bp_data.length; i++){
   bp_colors[i] = get_color(round5(bp_data[i]));
}



var overall_ctx = document.getElementById("overall_chart").getContext('2d');
var overall_chart = new Chart(overall_ctx, {
    type: 'horizontalBar',
    data: {
        labels: chart_labels,
        datasets: [{
            data: overall_data,
            backgroundColor: overall_colors,
            borderWidth: 1
        }]
    },
    options: getBarChartOptions(_.map(heatmap_summary["overall_adoption"], x => x["change"])),
});
// overall_chart.config.options.title.text = 'Overall Adoption';
// overall_chart.update();

{% if industry_average %}
var industry_ctx = document.getElementById("industry_chart").getContext('2d');
var industry_chart = new Chart(industry_ctx, {
    type: 'horizontalBar',
    data: {
        labels: chart_labels,
        datasets: [{
            data: industry_data,
            backgroundColor: industry_colors,
            borderWidth: 1
        }]
    },
    options: getBarChartOptions(),
});
// industry_chart.config.options.title.text = 'Industry Average';
// industry_chart.update();
{% endif %}


bp_levels = chart_labels.slice(0);
bp_levels[_.findLastIndex(bp_levels)] = '';
var bp_ctx = document.getElementById("bp_chart").getContext('2d');
var bp_chart = new Chart(bp_ctx, {
    type: 'horizontalBar',
    data: {
        labels: bp_levels,
        datasets: [{
            data: bp_data,
            backgroundColor: bp_colors,
            borderWidth: 1
        }]
    },
    options: getBarChartOptions(),
});
// bp_chart.config.options.title.text = 'Best Practice Adoption';
// bp_chart.update();



var opts = {
  angle: 0.15, // The span of the gauge arc
  lineWidth: 0.44, // The line thickness
  radiusScale: 1, // Relative radius
  pointer: {
    length: 0.6, // // Relative to gauge radius
    strokeWidth: 0.035, // The thickness
    color: '#000000' // Fill color
  },
  limitMax: false,     // If false, max value increases automatically if value > maxValue
  limitMin: false,     // If true, the min value of the gauge will be fixed
  // colorStart: '#6FADCF',   // Colors
  // colorStop: '#8FC0DA',    // just experiment with them
  strokeColor: '#E0E0E0',  // to see which ones work best for you
  generateGradient: true,
  highDpiSupport: true,     // High resolution support
  percentColors: [[0.0, "#FF4C38" ], [0.50, "#FFFF38"], [1.0, "#38FF38"]],
};

const gauge_mapping = {
  'app-id': 'APP-ID',
  'user-id': 'User-ID',
  'service-port': 'Service / Port',
  'logging': 'Logging',
  'log-fwd': 'Log Forwarding',
  'zone-protect': 'Zone Protection Profile',
};
for (const [id, metric] of _.toPairs(gauge_mapping)) {
  let target = document.getElementById(id); // your canvas element
  let gauge = new Gauge(target).setOptions(opts); // create sexy gauge!
  gauge.maxValue = 100; // set max gauge value
  gauge.setMinValue(0);  // Prefer setter over gauge.minValue = 0
  gauge.animationSpeed = 20; // set animation speed (32 is default value)
  let gauge_value = heatmap_summary['overall_adoption'][metric]['percent'];
  let change = heatmap_summary['overall_adoption'][metric]['change'];
  let label = `${gauge_value}% <span class="pct-change">(${change})</span>`;
  document.getElementById(`${id}-val`).innerHTML = label; // set the gauge label
  gauge.set(gauge_value); // set actual value
}

// Hide loading message once script is finished processing
$('#loading').hide();
