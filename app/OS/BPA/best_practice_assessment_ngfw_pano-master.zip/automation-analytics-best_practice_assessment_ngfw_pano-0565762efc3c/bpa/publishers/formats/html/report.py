from typing import Dict, Optional

from bpa.publishers.base_publisher import BasePublisher
from bpa.publishers.schemas.arch_mapping import MappingSet

from .adapters.xml_config import XMLConfig
from .html import package_html


class ReportPublisher(BasePublisher):
    """Publishes HTML output"""

    def __init__(
        self,
        publisher_manager,
        arch_mappings: Optional[MappingSet] = None,
        industry_attrs: Optional[Dict] = None,
    ):
        super().__init__(publisher_manager)
        self.arch_mappings = arch_mappings or MappingSet(mappings=[])
        self.industry_attrs = industry_attrs or {}

    def process(self):
        self.xml_config = XMLConfig(
            self.publisher_manager, self.arch_mappings, self.industry_attrs
        )
        self.html, self.summary_data = package_html(self.xml_config)

    def publish(self) -> bytes:
        return self.html.encode()
