from functools import wraps
from typing import Callable, Dict, List

from matplotlib import pyplot as plt
from reportlab.platypus import TableStyle

from bpa.publishers.formats.pdf.constants import DEFAULT_LEFT_PADDING
from bpa.publishers.formats.pdf.utils.content import build_p, build_space, NoSplitTable
from bpa.publishers.formats.pdf.utils.visuals.vector import build_svg
from bpa.publishers.formats.pdf.utils.visuals.core import bulletgraph


def get_percent(percent: int) -> str:
    """Get string representation of percent."""
    return f"<span size=9>{percent}%&nbsp</span>"


def get_delta(content: str) -> str:
    """Get string representation of delta color."""
    color = "grey"
    if content.startswith("+"):
        color = "green"
    if content.startswith("-"):
        color = "red"
    return f'<span color="{color}">{content}</span>'


def fake_meta(key: str) -> Dict:
    """Fake metadata builder for mocking purposes."""
    content = ". ".join(["Lorem ipsum blah blah blah"] * 5) + "."
    return {"description": content, "title": "Title provided here"}


def bullet_graphs(f):
    """Decorator for building out bullet graphs."""

    @wraps(f)
    def wrapper(
        Story: List,
        data: Dict,
        ordering: Callable = None,
        metabuild: Callable = fake_meta,
        lpad: int = DEFAULT_LEFT_PADDING,
    ):
        ix = 0
        for k in sorted(data.keys(), key=ordering):
            data_to_plot2 = [{"name": k, **data[k]}]

            # Step 1: Build bullet image
            fig = bulletgraph(data_to_plot2)

            # Step 2: Build table for title-chart-description
            tbl = f(k, fig, data, lpad, metabuild)

            # Step 3: Add table to story
            Story.append(tbl)

            # NOTE: Only add space between graphs
            if ix < len(data) - 1:
                Story.append(build_space())

            plt.close()

            ix += 1

    return wrapper


@bullet_graphs
def write_bullet_one_col(key, fig, data, metabuild, lpad):
    """Write bullet graphs in a 1-column format."""
    img = build_svg(fig)
    n = 150
    cw = [n * 2.305]
    rh = [n * 0.1, n * 0.1, n * 0.25, n * 0.25]
    chart_style = TableStyle(
        [
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, 0), "BOTTOM"),
            ("VALIGN", (0, 1), (-1, 1), "BOTTOM"),
            ("VALIGN", (0, 2), (-1, 2), "MIDDLE"),
            ("VALIGN", (0, 3), (-1, 3), "TOP"),
        ]
    )
    entry = data[key]
    cur = entry.get("percent")
    delta = entry.get("change")
    content = get_percent(cur)
    if delta:
        content += f" {get_delta(delta)}"
    metadata = metabuild(key)
    d_para = build_p(content, font_size=7, halign="CENTER")
    k_para = build_p(key, font_size=9, halign="CENTER")
    l_para = build_p(metadata.get("description", "N/A"), halign="CENTER")
    return NoSplitTable(
        [[k_para], [d_para], [img], [l_para]],
        colWidths=cw,
        rowHeights=rh,
        style=chart_style,
    )


@bullet_graphs
def write_bullet_three_col(key, fig, data, metabuild, lpad):
    """Write bullet graphs in a 3-column format."""
    img = build_svg(fig, scaling_factor=0.20)
    n = 150
    cw = [n * 0.3, n * 2.0, n * 0.8]
    rh = [n * 0.1, n * 0.375]
    chart_style = TableStyle(
        [("VALIGN", (0, 0), (-1, 0), "BOTTOM"), ("VALIGN", (0, 1), (-1, 1), "TOP")]
    )
    entry = data[key]
    cur = entry.get("percent")
    delta = entry.get("change")
    content = get_percent(cur)
    if delta:
        content += f" {get_delta(delta)}"
    metadata = metabuild(key)
    t_para = build_p(metadata.get("title", "N/A"), font_size=9, halign="CENTER")
    d_para = build_p(content, font_size=7, halign="CENTER")
    k_para = build_p(key, font_size=9, halign="CENTER")
    l_para = build_p(metadata.get("description", "N/A"), halign="CENTER")
    return NoSplitTable(
        [[None, t_para, d_para], [k_para, l_para, img]],
        colWidths=cw,
        rowHeights=rh,
        style=chart_style,
    )
