import pandas as pd

from bpa.publishers.formats.excel.constants import (
    DOC_COLUMNS,
    TABLE_STYLE_LIGHT,
    TEXT_REMEDIATION_MINUTES,
)


class DocumentationMixin:
    """Documentation processing utilities"""

    # NOTE: Entrypoint for parsing data
    def parse_documentation(self):
        """Store and format documentation pandas dataframe"""
        cleaned_docs = []
        for key, val in sorted(self.docs_map.items()):
            if type(val.references) is list:
                cleaned_reference = "\n".join(val.references)
            else:
                cleaned_reference = val.references
            cleaned_docs.append(
                {
                    "ID": key,
                    "Section": val.top_nav,
                    "Sub Section": val.left_nav,
                    "Type": val.doc_type,
                    "Title": val.title,
                    "Description": val.description,
                    "Rationale": val.rationale,
                    "Complexity": val.complexity,
                    TEXT_REMEDIATION_MINUTES: int(val.effort),
                    "References": cleaned_reference,
                }
            )
        sheet_data = pd.DataFrame(cleaned_docs, columns=DOC_COLUMNS)
        sheet_data.fillna("", inplace=True)
        sheet_data.dropna(axis="columns", how="all", inplace=True)
        self.docs_df = sheet_data

    # NOTE: Entrypoint for writing data
    def write_documentation(self):
        """Write Documentation to an excel object"""
        # Step 1: Create worksheet in workbook
        docs_sheet = self.workbook.add_worksheet("Documentation")
        docs_sheet.add_table(
            first_row=0,
            first_col=0,
            last_row=self.docs_df.shape[0],
            last_col=(self.docs_df.shape[1] - 1),
            options={
                "columns": [{"header": col} for col in self.docs_df.columns],
                "data": self.docs_df.values,
                "style": TABLE_STYLE_LIGHT,
                "name": "Documentation",
            },
        )

        # Step 2: Decorate created worksheet
        self.set_column_widths(self.docs_df, docs_sheet)
