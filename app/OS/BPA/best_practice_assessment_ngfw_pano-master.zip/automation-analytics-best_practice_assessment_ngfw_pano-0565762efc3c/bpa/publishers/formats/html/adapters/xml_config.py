from typing import List

from bpa.models.utils.software import get_release_date_info

from .bpa import BestPracticeAssessment
from .heatmap import SecurityPolicyCapabilityAdoption


class XMLConfig:
    """docstring for XML_Config"""

    def __init__(self, report_publisher, arch_mappings, industry_attrs):
        model_manager = report_publisher().bp_manager().model_manager()
        self.model_manager = model_manager
        self.serial_number = model_manager.system_info.get("serial")
        self.serial_numbers = model_manager.system_info.all_serial_numbers
        self.system_info = model_manager.system_info.copy()
        self.content_update_age = model_manager.system_info.get_content_deltas(
            model_manager.system_time
        )
        self.license_info = model_manager.license_info.to_json()
        self.version = model_manager.tree.version
        self.is_eol = model_manager.is_eol
        self.panorama = model_manager.tree.panorama
        self.managed_device_count = self.model_manager.metadata.managed_device_count
        self.zone_mappings = self.get_zone_mappings(arch_mappings)
        self.heatmap = SecurityPolicyCapabilityAdoption(report_publisher, arch_mappings)
        self.bpa = BestPracticeAssessment(report_publisher)
        self.sw_version_class = self.get_sw_version_class()
        self.__dict__.update(**industry_attrs)

    def get_sw_version_class(self) -> str:
        """Helper for injecting into Jinja template"""
        try:
            _, days_since_release = get_release_date_info(
                self.model_manager.tree._version, self.model_manager.release_dates
            )
        except TypeError:
            return ""
        if days_since_release < 180:
            return ""
        elif days_since_release < 365:
            return "warning"
        else:
            return "danger"
        return days_since_release

    def get_zone_mappings(self, arch_mappings) -> List:
        mappings = []
        for sig, arch in arch_mappings._lookup.items():
            _map = {"area_of_architecture": arch}
            _map["vsys"], _map["zone"] = sig
            mappings.append(_map)
        return mappings
