import pandas as pd


class MappingMixin:
    """Mapping processing utilities"""

    def parse_mapping(self, docs_map):
        self.mapping_df_docs = pd.DataFrame(docs_map)
        self.mapping_df_docs.set_index("doc_id", inplace=True)
