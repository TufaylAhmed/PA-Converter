from typing import Callable, List

from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, Spacer, Table
from reportlab.platypus.flowables import Flowable

from bpa.publishers.formats.pdf.constants import (
    NORM_STYLE,
    H1_STYLE,
    H2_STYLE,
    TITLE_STYLE,
)


class NoSplitTable(Table):
    def split(self, availWidth, availHeight):
        """Always avoid row splits."""
        return []


def build_text_settings() -> Callable:
    """Return callable for building Paragraph instances."""
    default = {
        "font_size": None,
        "font_color": None,
        "base_style": NORM_STYLE,
        "halign": "LEFT",
    }

    def buildable(content, **overrides) -> Paragraph:
        settings = {**default, **overrides}
        _size, _color = "", ""
        if settings["font_size"]:
            _size = f'size={settings["font_size"]}'
        if settings["font_color"]:
            _color = f'color="{settings["font_color"]}"'
        _all = " ".join([_size, _color])
        pre = f'<para align={settings["halign"]}><font {_all}>'
        post = "</font></para>"
        return Paragraph(pre + content + post, settings["base_style"])

    return buildable


def build_text(content: str, **overrides) -> Paragraph:
    """Build text with overrides."""
    return build_text_settings()(content, **overrides)


def build_text_simple(content: str, base_style: ParagraphStyle) -> Paragraph:
    """Build text with only base style."""
    return Paragraph(content, base_style)


def build_p(content: str, **overrides) -> Paragraph:
    """Build Normal paragraph."""
    return build_text(content, **overrides)


def build_h1(content: str, **overrides) -> Paragraph:
    """Build Heading1 paragraph."""
    return build_text(content, base_style=H1_STYLE, **overrides)


def build_h2(content: str, **overrides) -> Paragraph:
    """Build Heading2 paragraph."""
    return build_text(content, base_style=H2_STYLE, **overrides)


def build_title(content: str) -> Paragraph:
    """Build Title paragraph."""
    return build_text_simple(content, base_style=TITLE_STYLE)


def build_space(space_size: int = 12) -> Spacer:
    """Build Spacer."""
    return Spacer(width=1, height=space_size)


def build_link(content: str, uri: str, **overrides) -> Paragraph:
    """Build <link> content with URI."""
    link_content = f'<link href="{uri}">{content}</link>'
    return build_p(link_content, **overrides)


def build_internal_link(uri: str) -> Paragraph:
    """Build internal <a> reference."""
    return build_p(f'<a name="{uri}" />')


def build_sample(count: int = 4) -> List[Flowable]:
    """Build a list of sample paragraphs."""
    if count == 0:
        return []
    result = []
    hello = " ".join(["Hello world is just another language." for _ in range(20)])
    result.append(build_p(hello))
    for _ in range(1, count):
        result.append(build_space())
        result.append(build_p(hello))
    return result


def build_line(count: int = 5):
    """Build a simple paragraph with cruft."""
    content = ". ".join(["Lorem ipsum blah blah blah"] * count) + "."
    return build_p(content, font_size=7)
