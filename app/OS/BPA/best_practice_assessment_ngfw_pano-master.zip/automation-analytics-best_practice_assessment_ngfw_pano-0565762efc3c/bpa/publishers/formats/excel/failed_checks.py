from collections import defaultdict
from io import BytesIO

import xlsxwriter

from bpa.publishers.base_publisher import BasePublisher
from bpa.publishers.utils.common import docs_to_dict, convert_list_of_str_to_str
from .constants import FONT_BLUE
from .mixins import CompositeMixin


class FailedChecksPublisher(BasePublisher, CompositeMixin):
    """Publishes XLSX output.

    Attributes:
        output: Output for publisher.
        workbook: Excel workbook.
        link_format: Link formatting construct.
        combined_data: Data for each category.
        docs_map: Dictionary with Documentation data.
        docs_df: Pandas DataFrame with Documentation data.
        mapping_df: Mapping DataFrame.
        grand_total: Grand total sums from combined data.
        check_doc_location: Check documentation locations.
    """

    def __init__(self, publisher_manager):
        super().__init__(publisher_manager)

        # I/O data
        self.output = BytesIO()
        self.workbook = xlsxwriter.Workbook(
            self.output, options={"nan_inf_to_errors": True, "strings_to_urls": False}
        )
        self.link_format = self.workbook.add_format(
            {"underline": 1, "font_color": FONT_BLUE}
        )
        documentation = self.bp_manager().model_manager().documentation
        if documentation:
            # Optional data
            self.docs_map = docs_to_dict(documentation)
        else:
            self.docs_map = None
        # Processed data
        self.combined_data = defaultdict(list)
        self.docs_df = None
        self.mapping_df = None

        # Workbook data
        self.grand_total = {}
        self.check_doc_location = {}

    def process(self):
        """Process data"""
        above_version_8 = self.bp_manager().model_manager().tree.version >= 8.0
        if self.docs_map:
            # Step 1: Build documentation DataFrame
            self.parse_documentation()

            # Step 2: Build mapping DataFrame
            docs = convert_list_of_str_to_str(
                [d.as_dict for d in self.bp_manager().model_manager().documentation]
            )
            self.parse_mapping(docs)

        # Step 3: Build combined data from BP results
        results_by_category = self.bp_manager().get_all_by_category()
        for category in results_by_category:
            for analyzer in results_by_category[category]:
                for result in results_by_category[category][analyzer]:
                    if above_version_8 and analyzer == "captive_portal_rule":
                        analyzer = "authentication"
                    # if not self.docs_map:
                    #     return
                    self.parse_bp_result(result, category, analyzer)

        # Step 4: Write workbook
        self.write_summary()
        self.write_worksheets()
        if self.docs_map:
            self.write_documentation()
        self.workbook.close()

    def publish(self) -> bytes:
        """Publish data"""
        return self.output.getvalue()
