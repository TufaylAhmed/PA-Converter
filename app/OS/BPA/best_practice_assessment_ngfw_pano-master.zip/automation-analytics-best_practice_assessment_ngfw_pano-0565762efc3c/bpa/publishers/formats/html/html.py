# -*- coding: utf-8 -*-
from os import linesep
from os.path import dirname, join
import json
from collections import OrderedDict
from jinja2 import FileSystemLoader, Environment

from bpa import __version__ as bpa_version

from .common import encode_font, encode_image
from .best_practice_assessment import package_html as bpa_vars
from .security_policy_capability_adoption import package_html as heatmap_vars
from bpa.components.data_retrieval import HeatMapBPAHistoricalData


def render_from_template(directory, template_name, **kwargs):
    """Helper function to quick load Jinja2 templates."""
    loader = FileSystemLoader(directory)
    env = Environment(loader=loader)
    template = env.get_template(template_name)
    return template.render(**kwargs)


def package_html(xml_config, **kwargs):
    """Create Best Practice Assessment HTML report

    Args:
        bpat: BestPracticeAssessment object
        info: dictionary with data for device info tab
        kwargs: dictionary of all keyword arguments for package_html function in security_policy_capability_adoption module

    Returns:
        A string of the combined HTML and all related assets
    """
    heatmap_history, bpa_history = HeatMapBPAHistoricalData.get(
        serial_numbers=xml_config.serial_numbers
    )
    heatmap_history.set_is_panorama(xml_config.panorama)
    device_info = xml_config.system_info.copy()
    bpat = xml_config.bpa

    TEMPLATE_DIR = join(dirname(__file__), "templates")
    IMAGE_DIR = join(TEMPLATE_DIR, "img")

    data = {
        "bpat": bpat,
        "panorama": xml_config.panorama,
        "json_dumps": json.dumps,
        "version": xml_config.version,
        "sw_version_class": xml_config.sw_version_class,
        "title": "Best Practice Assessment for {}".format(
            "Panorama" if xml_config.panorama else "NGFW"
        ),
        "css": linesep.join(
            encode_font(css, TEMPLATE_DIR)
            for css in [
                "font-awesome.min.css",
                "bootstrap.min.css",
                "datatables.min.css",
                "bootstrap-select.min.css",
                "ie10-viewport-bug-workaround.css",
                "common.css",
                "bpa.css",
                "heatmap.css",
            ]
        ),
        "images": {
            image: encode_image(image, IMAGE_DIR)
            for image in ["favicon.png", "logo.png", "logo_small.png", "no_data.png"]
        },
        "release_version": bpa_version,
        "rule_usage_info_available": xml_config.model_manager.rule_usage_info.is_available,
    }

    context = {
        **data,
        **bpa_vars(bpat, device_info, bpa_history),
        **heatmap_vars(xml_config, heatmap_history),
    }

    html = render_from_template(
        directory=TEMPLATE_DIR, template_name="template.html", **context
    )

    summary = OrderedDict(
        {
            "adoption_summary": context["heatmap_summary"],
            "best_practice_summary": context["bpa_summary"],
        }
    )

    return html, summary
