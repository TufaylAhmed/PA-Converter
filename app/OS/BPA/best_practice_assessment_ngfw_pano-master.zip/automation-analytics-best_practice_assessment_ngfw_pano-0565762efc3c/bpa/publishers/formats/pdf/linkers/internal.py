from reportlab.platypus import Image


class InternalLinkImage(Image):
    """Image with internal link."""

    def __init__(self, *args, **kwargs):
        self.contents = kwargs.pop("contents", None)
        self.destination = kwargs.pop("destination", None)
        super().__init__(*args, **kwargs)

    def drawOn(self, canvas, x, y, _sW=0):
        if self.contents and self.destination:
            x1 = self._hAlignAdjust(x, _sW)
            y1 = y
            x2 = x1 + self._width
            y2 = y1 + self._height
            canvas.linkAbsolute(
                contents=self.contents,
                destinationname=self.destination,
                Rect=(x1, y1, x2, y2),
                Border="[0 0 0]",
            )
        super().drawOn(canvas, x, y, _sW)
