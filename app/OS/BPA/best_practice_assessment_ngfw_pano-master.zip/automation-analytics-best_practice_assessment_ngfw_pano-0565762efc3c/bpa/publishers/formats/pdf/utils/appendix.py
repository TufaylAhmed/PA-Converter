from typing import List

from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle
from reportlab.platypus.flowables import Flowable

from bpa.publishers.formats.pdf.utils.content import build_p
from bpa.publishers.formats.pdf.utils.data import get_appendix


def write_appendix(Story: List[Flowable], ltitle: str, rtitle: str, apptype: str):
    c_para = build_p(ltitle, font_size=9)
    d_para = build_p(rtitle, font_size=9)
    n = 150
    cw = [n * 0.6, n * 2.2]
    chart_style = TableStyle(
        [
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.black),
            ("BOX", (0, 0), (-1, -1), 0.25, colors.black),
        ]
    )
    tdata = [[c_para, d_para]]
    for item in get_appendix(apptype):
        tdata.append([build_p(item["name"]), build_p(item["definition"])])
    tbl = Table(tdata, colWidths=cw, style=chart_style)
    Story.append(tbl)
