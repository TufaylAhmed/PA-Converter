from copy import deepcopy
from typing import Any, Dict, List

from reportlab.platypus import PageBreak
from reportlab.platypus.flowables import Flowable

from bpa.publishers.formats.pdf.utils.appendix import write_appendix
from bpa.publishers.formats.pdf.utils.content import (
    build_internal_link,
    build_p,
    build_h1,
    build_h2,
    build_space,
)
from bpa.publishers.formats.pdf.utils.data import get_metabuild
from bpa.publishers.formats.pdf.utils.decryption import write_decryption
from bpa.publishers.formats.pdf.utils.visuals.bar import write_bar_one_col
from bpa.publishers.formats.pdf.utils.visuals.gauge import (
    write_gauge_one_col,
    write_gauge_three_col,
)


# https://stackoverflow.com/questions/14703310/how-can-i-get-a-python-decorator-to-run-after-the-decorated-function-has-complet?answertab=votes#tab-top
def register_header_nav(label):
    """ Helper decorator to call setter function to set header nav value after generating data. """

    def decorator_func(func):
        def wrapper_func(**kwargs):
            # Invoke the wrapped function first
            set_headers_nav = kwargs.pop("set_headers_nav")
            retval = func(**kwargs)
            set_headers_nav(label)
            return retval

        return wrapper_func

    return decorator_func


@register_header_nav(label="BPA Summary")
def chapter_bpa(Story: List[Flowable], data: Dict[str, Any]):
    """Build Chapter 1 content."""
    Story.append(build_internal_link("ch-bpa"))
    Story.append(build_h1("BPA Summary", halign="CENTER"))

    classes = data["Class"]
    controls = data["CSC Controls"]
    categories = data["Control Category"]
    capabilities = data["Functionality / Capability"]

    # NOTE: Capability bar chart
    Story.append(build_h2("Capability Summary"))
    data = {**capabilities}
    link = "https://www.microsoftpressstore.com/articles/article.aspx?p=2201319"
    capability_txt = (
        "Security controls are safeguards or countermeasures put into place "
        "to reduce overall risk. Additional information available at "
        f'<a color="blue" href="{link}">{link}</a>.'
    )
    write_bar_one_col(Story, data, capability_txt, figsize=(10, 4.5), wrapping=25)
    Story.append(build_space())

    # NOTE: Category bar chart
    Story.append(build_h2("NIST Security Controls"))
    data = {**categories}
    link = "https://nvd.nist.gov/800-53/Rev4"
    category_txt = (
        "Security controls and assessment procedures for federal information "
        "systems and organizations. Additional information available at "
        f'<a color="blue" href="{link}">NIST Security Controls</a>.'
    )
    write_bar_one_col(Story, data, category_txt, figsize=(10, 6))
    Story.append(PageBreak())

    # NOTE: Class gauge chart
    Story.append(build_h2("Class Summary"))
    data = {**classes}
    metabuild = get_metabuild("class")
    write_gauge_one_col(Story, data, metabuild=metabuild)
    Story.append(PageBreak())

    def csc_key(val):
        return int(val.split(" ")[-1])

    # NOTE: Control gauge chart
    Story.append(build_h2("CIS Critical Security Control Summary"))
    Story.append(build_space())
    data = {}
    for control_ in controls:
        data[f"CSC {control_}"] = controls[control_]
    metabuild = get_metabuild("csc")
    write_gauge_three_col(Story, data, ordering=csc_key, metabuild=metabuild)
    Story.append(PageBreak())


@register_header_nav(label="Adoption Summary")
def chapter_adoption(Story: List[Flowable], data: Dict[str, Any]):
    """Build Chapter 2 content."""
    Story.append(build_internal_link("ch-adoption"))
    Story.append(build_h1("Adoption Summary", halign="CENTER"))

    overall = data["overall_adoption"]
    best_practices = data["best_practice_mode_adoption"]

    # NOTE: Industry data might not be present
    industry = data.get("industry_adoption", None)

    # Adoption sets
    app_user_adoption = {"APP-ID", "User-ID", "Service / Port"}
    log_zone_adoption = {"Logging", "Log Forwarding", "Zone Protection Profile"}
    okeys = set(overall.keys())
    bkeys = set(best_practices.keys())

    # NOTE: Change depending on existence of industry data
    if industry:
        ikeys = set(industry.keys())
        common_adoption = okeys.intersection(ikeys).intersection(bkeys)
    else:
        common_adoption = okeys.intersection(bkeys)

    # TODO: Determine why industry keys are not the same
    special_keys = ["Credential Phishing Prevention"]
    for key in special_keys:
        if key in okeys and key in bkeys:
            common_adoption.add(key)

    # NOTE: Overall bar chart
    Story.append(build_h2("Overall Adoption"))
    data = {k: overall[k] for k in common_adoption}
    overall_text = (
        "This is the Heatmap results showing percentage of Adoption for all "
        "Security profiles applied on a firewall or Panorama."
    )
    write_bar_one_col(Story, data, overall_text, figsize=(10, 5))
    Story.append(build_space())

    # NOTE: Industry bar chart
    if industry:
        # NOTE: Sanitize any invalid data before processing graphs
        data = {}
        for common_key in common_adoption:
            common_val = deepcopy(industry.get(common_key, {}))
            if not isinstance(common_val.get("percent"), (int, float)):
                common_val["percent"] = 0
            data[common_key] = common_val
        industry_name = industry["Industry"]
        Story.append(build_h2(f"{industry_name} Adoption"))
        industry_text = (
            "Industry Average results show how your area of business or industry "
            "is adopting security profiles on their firewall or Panorama. Industry "
            "Average data is obtained from the total Tech Support Files uploaded "
            "to Customer Success Tools. Only the Average % on Adoption Is stored "
            "for providing the industry average guidance."
        )
        write_bar_one_col(Story, data, industry_text, figsize=(10, 5))
    Story.append(PageBreak())

    # NOTE: BP mode bar chart
    Story.append(build_h2("BP Mode Adoption"))
    data = {k: best_practices[k] for k in common_adoption}
    bp_mode_text = (
        "Best Practice Mode results show the effectiveness of the Security Profile "
        "Adoption. Results indicate how the security profiles adhere to Best "
        "Practice and provide the percentage of those security profiles "
        "adopting Best Practices."
    )
    write_bar_one_col(Story, data, bp_mode_text, figsize=(10, 6))
    Story.append(PageBreak())

    # NOTE: Application & User Control Adoption gauge chart
    Story.append(build_h2("Application & User Control Adoption"))
    data = {k: overall[k] for k in app_user_adoption}
    metabuild = get_metabuild("app_user")
    write_gauge_one_col(Story, data, metabuild=metabuild)
    Story.append(PageBreak())

    # NOTE: Logging & Zone Protection Adoption gauge chart
    Story.append(build_h2("Logging & Zone Protection Adoption"))
    data = {}
    data = {k: overall[k] for k in log_zone_adoption}
    metabuild = get_metabuild("log_zone")
    write_gauge_one_col(Story, data, metabuild=metabuild)
    Story.append(PageBreak())


@register_header_nav(label="Decryption Summary")
def chapter_decryption(Story: List[Flowable], data: Dict[str, Any]):
    """Build Chapter 3 content."""
    Story.append(build_internal_link("ch-decryption"))
    Story.append(build_h1("Decryption Summary", halign="CENTER"))

    decryption = data["decryption_summary"]
    exempted = decryption.pop("URL Categories Exempted")

    # NOTE: Check mark table
    data = {**decryption}
    write_decryption(Story, data)
    Story.append(build_space())

    # NOTE: Categories exempted
    etext = "None" if not exempted else exempted
    econtent = f"URL Categories Exempted: {etext}"
    Story.append(build_p(econtent))
    Story.append(build_space())
    category_text = (
        "URL predefined and custom categories that are being exempted "
        "from Decryption. This may be due to company policies such as "
        "compliance, privacy and other standards."
    )
    Story.append(build_p(category_text))
    Story.append(PageBreak())


@register_header_nav(label="Appendix")
def chapter_appendix(Story: List[Flowable]):
    """Build Chapter 4 content."""
    Story.append(build_internal_link("ch-appendix"))
    Story.append(build_h1("Appendix", halign="CENTER"))

    # NOTE: Capability appendix
    Story.append(build_h2("Appendix - Capability"))
    write_appendix(Story, "Capability", "Definition", "cap")
    Story.append(PageBreak())

    # NOTE: NIST Security Controls appendix
    Story.append(build_h2("Appendix - NIST Security Controls"))
    write_appendix(Story, "NIST Security Controls", "Definition", "ctl")

    # NOTE: Prior BPA Comparison appendix
    Story.append(build_h2("Appendix - Prior BPA Comparison"))
    write_appendix(Story, "Comparison", "Definition", "bpa")
