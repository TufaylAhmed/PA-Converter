import json
import logging
import weakref

from bpa.models.default_value import DefaultValue
from bpa.publishers.base_publisher import BasePublisher


LOG = logging.getLogger(__name__)


class BestPracticesEncoder(json.JSONEncoder):
    """Custom encoder used before rendering Best Practices output"""

    weakref_count = 0

    def default(self, obj):
        """Handles BestPracticeResult attributes recursively"""
        if hasattr(obj, "__dataclass_fields__"):
            return {
                k: getattr(obj, k)
                for k in obj.__dataclass_fields__.keys()
                if k not in {"model_manager"}
            }
        elif isinstance(obj, set):
            return list(obj)
        elif isinstance(obj, DefaultValue):
            return obj.value
        elif isinstance(obj, weakref.ReferenceType):
            self.weakref_count += 1
            return None
        return json.JSONEncoder.default(self, obj)


class BestPracticesPublisher(BasePublisher):
    """Publishes JSON output"""

    def process(self):
        self.output = self.bp_manager().get_all_by_category()

    def publish(self) -> bytes:
        content = json.dumps(self.output, cls=BestPracticesEncoder)
        if BestPracticesEncoder.weakref_count > 0:
            LOG.warning(
                f"{BestPracticesEncoder.weakref_count} weakref found in BP results"
            )
        return bytes(content, encoding="utf-8")
