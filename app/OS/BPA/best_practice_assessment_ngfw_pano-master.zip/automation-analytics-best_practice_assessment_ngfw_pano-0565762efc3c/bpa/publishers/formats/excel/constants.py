# Special values
TEXT_NOT_APPLICABLE = "N/A"
TEXT_EMPTY = ""

# Column values
TEXT_CHECK_ID = "Check ID"
TEXT_CHECK_NAME = "Check Name"
TEXT_CSC_6 = "Critical Security Controls v6"
TEXT_CSC_7 = "Critical Security Controls v7"
TEXT_CAP_SUMMARY = "Capability Summary"
TEXT_CTL_CATEGORY = "Control Category"
TEXT_REMEDIATION_MINUTES = "Remediation Effort (Minutes)"
TEXT_REMEDIATION_EIGHT_HOURS = "Remediation Effort (8 Hour Work Days)"
TEXT_TEMPLATE = "Template Name"

# Category settings
CATEGORY_COLUMNS = (
    "Feature",
    "Location",
    TEXT_TEMPLATE,
    "Name",
    TEXT_CHECK_ID,
    TEXT_CHECK_NAME,
    "Message",
    "Complexity",
    TEXT_REMEDIATION_MINUTES,
    TEXT_CSC_6,
    TEXT_CSC_7,
    TEXT_CAP_SUMMARY,
    TEXT_CTL_CATEGORY,
    "Class",
)
CATEGORY_CATEGORIES = ("policies", "objects", "network", "device", "panorama")

# Documentation settings
DOC_COLUMNS = (
    "ID",
    "Section",
    "Sub Section",
    "Type",
    "Title",
    "Description",
    "Rationale",
    "Complexity",
    TEXT_REMEDIATION_MINUTES,
    "References",
)

# Status values
STATUS_NOT_STARTED = "Not Started"
STATUS_IN_PROGRESS = "In Progress"
STATUS_RESOLVED = "Resolved"
STATUS_PLANNED = "Planned"
STATUS_NOT_APPLICABLE = "Not Applicable"
PROGRESS_OPTIONS = [
    STATUS_NOT_STARTED,
    STATUS_IN_PROGRESS,
    STATUS_RESOLVED,
    STATUS_PLANNED,
    STATUS_NOT_APPLICABLE,
]

# Color values
BG_BLUE = "#4F80BD"
FONT_WHITE = "white"
FONT_BLUE = "blue"

# Table settings
TABLE_STYLE_LIGHT = "Table Style Light 9"

# Width settings
WIDTHS = {
    "Message": 50,
    "Title": 50,
    "Description": 50,
    "Notes": 50,
    "Rationale": 50,
    "References": 50,
    "ID": 5,
    TEXT_CHECK_ID: 10,
    TEXT_REMEDIATION_EIGHT_HOURS: 40,
    TEXT_CSC_6: 30,
    TEXT_CSC_7: 30,
    TEXT_CAP_SUMMARY: 30,
    "Class": 30,
}
