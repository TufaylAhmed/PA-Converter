import logging
from collections import defaultdict
from dataclasses import asdict
from typing import Dict, Union

from bpa.analyzers.best_practices.bp_result import BestPracticeResult

from bpa.analyzers.best_practices.bp_check import BestPracticeNote, BestPracticeWarning


LOG = logging.getLogger(__name__)


class BestPracticeAssessment:
    """docstring for BestPracticeAssessment"""

    normal_attrs = {
        # network
        "network": {
            "zone": "zones",
            "zone_protection_profile": "zone_protection_profiles",
            "global_protect_portal": "gp_portals",
            "global_protect_gateway": "gp_gateways",
            "gre_tunnel": "gre_tunnels",
            "ip_sec_crypto_profile": "ipsec_crypto_profiles",
            "interface_management_profile": "interface_management_profiles",
        },
        # objects
        "objects": {
            "application_filter": "application_filters",
            "application_tag": "application_tags",
            "hip_profile": "hip_profiles",
            "anti_spyware_profile": "antispyware_profiles",
            "antivirus_profile": "antivirus_profiles",
            "file_blocking_profile": "file_blocking_profiles",
            "url_filtering_profile": "url_filtering_profiles",
            "vulnerability_protection_profile": "vuln_protection_profiles",
            "wildfire_analysis_profile": "wildfire_profiles",
            "dos_protection_profile": "dos_protection_profiles",
            "log_forwarding_profile": "log_forwarding_profiles",
            "decryption_profile": "decryption_profiles",
        },
        # policies
        "policies": {
            "app_override": "app_override_rules",
            "captive_portal_rule": "captive_portal_rules",
            "tunnel_inspection": "tunnel_inspections",
            "decryption_rule": "decryption_rules",
            "decryption_rulebase": "decryption_rulebase",
            "dos_protection_rule": "dos_protection_rules",
            "policy_based_forwarding_rule": "policy_based_forwarding_rules",
            "security_rulebase": "security_rulebase",
        },
    }

    split_attrs = {
        # device
        "device_setup_general": "general_settings",
        "device_setup_authentication": "authentication_settings",
        "device_setup_logging_reporting": "logging_reporting_settings",
        "device_setup_secure_communication": "secure_communication_settings",
        "device_setup_management_interface": "management_interface_settings",
        "device_setup_min_password_complexity": "minimum_password_complexity_settings",
        "device_setup_policy_rulebase": "policy_rulebase",
        "device_setup_services": "services_settings",
        "device_setup_content_id": "content_id_settings",
        "device_setup_wildfire": "wildfire_settings",
        "device_setup_telemetry": "telemetry_settings",
        "device_setup_session": "session_settings",
        "administrator": "administrators",
        "admin_role": "admin_roles",
        "authentication_profile": "auth_profiles",
        "authentication_profiles": "auth_profiles_aggregate",
        "authentication_sequence": "auth_sequences",
        "authentication_sequences": "auth_sequences_aggregate",
        "user_id": "user_id",
        "virtual_system": "virtual_systems",
        "template": "template",
        "certificate": "certificate",
        "scheduled_config_export": "scheduled_config_export",
        "log_settings_system": "log_setting_system",
        "log_settings_config": "log_setting_config",
        "snmp_trap_server_profile": "snmptrap_server_profiles",
        "syslog_server_profile": "syslog_server_profiles",
        "ldap_server_profile": "ldap_server_profiles",
        "radius_server_profile": "radius_server_profiles",
        "tac_plus_server_profile": "tac_plus_server_profiles",
        "software": "software",
        "dynamic_updates": "dynamic_updates",
        "high_availability": "high_availability",
        "license": "license",
        "support": "support",
    }

    def __init__(self, report_publisher):
        self.json_keys = defaultdict(set)
        self.bp_manager = report_publisher().bp_manager
        self.panorama = self.bp_manager().model_manager().tree.panorama
        self.is_multi_vsys = len(self.bp_manager().model_manager().tree.vsys_names) > 1
        self.result_attrs = set()
        self._json = None
        self.set_normal_attrs()
        self.set_split_attrs()
        self.set_security_rules()

    def process_result(self, check) -> str:
        if check.check_excluded:
            return "exclude"
        return "pass" if check.check_passed else "fail"

    def set_security_rules(self):
        rules = []
        model_set = self.bp_manager().model_manager().get("security_rule")
        name_map = {
            "Description Populated": "Description Populated",
            "Source/Destination = any/any": "Source/Destination = any/any",
            "Service != any": "Service = any",
            "Application != any": "Application != any",
            "APP-ID with Service": "APP-ID with Service",
            "Log at Start of Session": "Not Logging at Start of Session",
            "Log Forwarding": "Log Forwarding",
            "Expired Non-Recurring Schedules": "Expired Non-Recurring Schedules",
            "Disable Server Response Inspection": "Disable Server Response Inspection",
        }

        for result in self.bp_manager().get("security_rule"):
            sig = {
                "rule_name": result.configuration["rule_name"],
                "location": result.configuration["location"],
            }
            rule = model_set.find(**sig)
            row = {
                "configuration": {
                    "vsys": rule.location,
                    "rule_name": rule.rule_name,
                    "rulebase": rule.rulebase,
                    "rule_enabled": rule.rule_enabled,
                },
                "bp_check": [],
            }

            _traffic_hit = result.configuration.get("traffic_hit")
            if _traffic_hit is not None:
                row["configuration"].update({"traffic_hit": _traffic_hit})
            for check in result.checks:
                row["bp_check"].append(
                    {
                        "id": check.check_id,
                        "name": name_map[check.check_name],
                        "result": self.process_result(check),
                    }
                )
            rules.append(row)
        self.security_rules = rules
        self.result_attrs.add("security_rules")
        self.json_keys["policies"].add("security_rules")

    def set_normal_attrs(self):
        bp_manager = self.bp_manager()
        for category, mappings in self.normal_attrs.items():
            for analyzer_key, attr in mappings.items():
                results = bp_manager.get(analyzer_key)
                self.register_attr(attr)
                if attr == "security_rulebase":
                    check_cache: Dict = {}
                    sec_rulbase_analyzer = bp_manager.analyzer_instance_lookup[
                        analyzer_key
                    ]
                    for (
                        location,
                        cache_lookup,
                    ) in sec_rulbase_analyzer.cache_lookups.items():
                        configuration = {"vsys": location}
                        try:
                            bp_check = check_cache[cache_lookup]
                        except KeyError:
                            checks, _ = sec_rulbase_analyzer.cache[cache_lookup]
                            bp_check = [self.convert_check(check) for check in checks]
                            check_cache[cache_lookup] = bp_check
                        record = {"configuration": configuration, "bp_check": bp_check}
                        self.add(attr, record)
                        self.json_keys[category].add(attr)
                else:
                    for result in results:
                        record = self.to_record(result)
                        self.add(attr, record)
                        self.json_keys[category].add(attr)

    def set_split_attrs(self):
        bp_manager = self.bp_manager()
        if not self.panorama:
            _prefix = "device"
            _category = "device"

        for analyzer_key, attr in self.split_attrs.items():
            results = bp_manager.get(analyzer_key)
            self.register_attr(f"device_{attr}")
            self.register_attr(f"template_{attr}")
            for result in results:
                record = self.to_record(result)
                prefix = locals().get("_prefix") or self.get_prefix(result)
                category = locals().get("_category") or self.get_category(prefix)
                split_attr = f"{prefix}_{attr}"
                self.add(split_attr, record)
                self.json_keys[category].add(split_attr)

    def register_attr(self, attr):
        setattr(self, attr, [])
        self.result_attrs.add(attr)

    def get_prefix(self, result: BestPracticeResult) -> str:
        if result.configuration.get("template_name") is None:
            return "device"
        return "template"

    def get_category(self, prefix: str) -> str:
        if prefix == "device":
            return "panorama"
        return "device"

    def add(self, attr: str, record: Dict) -> None:
        getattr(self, attr).append(record)

    def convert_check(
        self, check: Union[BestPracticeWarning, BestPracticeNote]
    ) -> Dict:
        """Modify check to work with legacy:
            BP_Check = namedtuple('BP_Check', ['id', 'name', 'type', 'result', 'message'])
        """
        converted = asdict(check)
        keys = list(converted.keys())
        for key in keys:
            new_key = key.replace("check_", "")
            converted[new_key] = converted.pop(key)

        try:
            if check.check_passed is not None:
                del converted["passed"]
                if check.check_passed:
                    converted["result"] = "pass"
                else:
                    converted["result"] = "fail"
            else:
                converted["result"] = ""
        except AttributeError:
            converted["result"] = ""

        try:
            if check.check_severity == "Caution":
                converted["result"] = "warning"
        except AttributeError:
            pass

        if converted["message"] is None:
            converted["message"] = ""

        if isinstance(check, BestPracticeNote):
            converted["type"] = "note"
        else:
            converted["type"] = "warn"

        return converted

    def convert_configuration(self, config: Dict) -> Dict:
        converted = {}
        for key, val in config.items():
            if key == "template_name" and val is None:
                continue
            elif key == "location":
                converted["vsys"] = val
            else:
                converted[key] = val

        return converted

    def to_record(self, result: BestPracticeResult) -> Dict:
        record = asdict(result)
        del record["warnings"]
        del record["notes"]
        record["bp_check"] = [self.convert_check(check) for check in result.checks]
        record["configuration"] = self.convert_configuration(
            record.pop("configuration")
        )
        return record

    def json(self) -> Dict:
        if self._json is not None:
            return self._json
        data = defaultdict(dict)
        for category, attrs in self.json_keys.items():
            for attr in attrs:
                data[category][attr] = getattr(self, attr)
        self._json = data
        return data
