# -*- coding: utf-8 -*-
import base64
import logging
import re
from collections import OrderedDict
from os.path import basename, join

LOG = logging.getLogger(__name__)


def encode_font(filename, file_path):
    """Parses CSS for references to fonts and replaces them with data URIs

    Searches for any matches between url()s in the CSS.
    For example, url('../fonts/lato-latin-ext.woff2') format('woff2')
    would return '../fonts/lato-latin-ext.woff2' as a match.

    This function assumes that all font references are to local files.

    Args:
        css_content: string of css filename
        file_path: string of the file path to the template directory

    Returns:
        A string of CSS with the fonts embedded as data URIs
    """
    with open(join(file_path, "css", filename)) as css:
        css_content = css.read()

    media_types = {
        "eot": "application/octet-stream",
        "svg": "image/svg+xml",
        "ttf": "application/octet-stream",
        "woff": "application/font-woff",
        "woff2": "application/octet-stream",
        "otf": "application/octet-stream",
    }

    for font_path in re.findall(r"url\((.*?)\)", css_content):
        # determine media type
        for font_type in media_types.keys():
            if font_type in font_path:
                media_type = media_types[font_type]
                break

        # Build path to the font file
        # Remove unnecessary pieces of the URL (e.g. query strings)
        # url('../fonts/fontawesome-webfont.eot?v=4.7.0')
        delimiters = ["?", "#", "'"]
        clean_path = re.split(
            "|".join(map(re.escape, delimiters)), basename(font_path)
        )[0]
        clean_path = join(file_path, "fonts", clean_path)

        data = base64.b64encode(open(clean_path, "rb").read()).decode("utf-8")
        data = "data:{media_type};base64,{data}".format(
            media_type=media_type, data=data
        )

        css_content = css_content.replace(font_path, data)

    return css_content


def encode_image(filename, file_path):
    """Encodes images into Data URIs.

    Args:
        filename: name of the targeted file
        file_path: path to directory containing the targeted file

    Returns:
        A string representing the Data URI
    """
    mediatypes = {"png": "image/png", "ico": "image/x-icon"}

    data_uri = "data:{mediatype};base64,{data}".format(
        mediatype=mediatypes[filename.split(".")[-1]],
        data=base64.b64encode(open(join(file_path, filename), "rb").read()).decode(
            "utf-8"
        ),
    )

    return data_uri


def reverse_order(od: OrderedDict) -> OrderedDict:
    """Reverses order for an OrderedDict."""
    return OrderedDict(reversed(list(od.items())))
