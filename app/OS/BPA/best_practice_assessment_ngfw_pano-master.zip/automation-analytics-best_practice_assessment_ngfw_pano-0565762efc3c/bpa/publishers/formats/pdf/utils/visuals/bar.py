from typing import Dict, List

from matplotlib import pyplot as plt
from reportlab.platypus import TableStyle

from bpa.publishers.formats.pdf.constants import DEFAULT_LEFT_PADDING
from bpa.publishers.formats.pdf.utils.content import build_p, NoSplitTable
from bpa.publishers.formats.pdf.utils.visuals.core import bar_h
from bpa.publishers.formats.pdf.utils.visuals.vector import build_svg


def write_bar_one_col(
    Story: List, data: Dict, text: str, lpad: int = DEFAULT_LEFT_PADDING, **options
):
    fig = bar_h(data, **options)
    img = build_svg(fig)
    para = build_p(text)
    chart_style = TableStyle(
        [("VALIGN", (0, -1), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, 0), lpad)]
    )
    table = NoSplitTable([[img], [para]], style=chart_style)
    Story.append(table)
    plt.close()
