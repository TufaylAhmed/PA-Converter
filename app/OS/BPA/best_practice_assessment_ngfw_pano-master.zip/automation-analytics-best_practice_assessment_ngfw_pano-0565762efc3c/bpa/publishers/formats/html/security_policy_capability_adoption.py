# -*- coding: utf-8 -*-
"""
Created on Fri Jan 06 11:50:19 2017

@author: anmendoza
"""
import datetime
import json
from collections import OrderedDict, defaultdict
from os import getenv
from typing import Dict, List

import pandas as pd

from bpa.components.aggregate import (
    # OverallAdoption,
    HeatMapTrend,
    AdoptionAnalysis,
)
from bpa.components.constant import AdoptionMetrics
from bpa.components.data_models import HeatMapHistory
from bpa.publishers.schemas.arch_mapping import Mapping

# from bpa.publishers.utils.common import divide
from . import map_definitions_path


# def add_strict_checks(rule_json, raw_data_json, valid_security_profiles) -> Tuple[str]:
#     """Adds *enabled_strict* metrics to the rules_json and raw_data_json.
#
#     Creating a DataFrame from valid_security_profiles creates a wide, sparse dataset for joining into
#     rule_json based on the device group / security profile name combination.
#     """
#     rule_json = pd.DataFrame(rule_json)
#     if rule_json.empty:
#         return "[]", "[]"
#
#     targets = [
#         ("wildfire_profile_name", "wildfire_enabled_strict"),
#         ("url_filtering_profile_name", "url_filtering_enabled_strict"),
#         ("av_profile_name", "antivirus_enabled_strict"),
#         ("spyware_profile_name", "antispyware_enabled_strict"),
#         ("vuln_profile_name", "vulnerability_enabled_strict"),
#         ("file_blocking_profile_name", "file_blocking_enabled_strict"),
#     ]
#
#     # ensure that device group and target profile names are included as columns before creating tmp_df
#     cols = [t[0] for t in targets]
#     cols.append("device_group")
#     valid_security_profiles = pd.concat(
#         [pd.DataFrame(columns=cols), pd.DataFrame(valid_security_profiles)]
#     )
#     valid_security_profiles["strict"] = "yes"
#
#     DF_LENGTH = len(rule_json)
#     for joining_column, strict_metric in targets:
#         tmp_df = (
#             valid_security_profiles[["device_group", joining_column, "strict"]]
#             .dropna()
#             .drop_duplicates()
#         )
#         tmp_df.rename(columns={"strict": strict_metric}, inplace=True)
#         rule_json = pd.merge(
#             rule_json, tmp_df, how="left", on=["device_group", joining_column]
#         )
#         assert DF_LENGTH == len(rule_json)
#     rule_json.fillna("no", inplace=True)
#     rule_json["dns_sinkhole_enabled_strict"] = rule_json["dns_sinkhole_enabled"]
#     if "credential_theft_enabled" in rule_json.columns:
#         rule_json["credential_theft_enabled_strict"] = rule_json[
#             "credential_theft_enabled"
#         ]
#
#     # return rule_json.to_json(orient='records')
#     enabled_allow_rules = rule_json[
#         (rule_json["rule_enabled"] == "yes") & (rule_json["action"] == "allow")
#     ]
#     enabled_allow_rules.replace(["yes", "no"], [1, 0], inplace=True)
#     dimensions = [
#         "device_group",
#         "target",
#         "tags",
#         "source_zone",
#         "dest_zone",
#         "source_area_of_architecture",
#         "dest_area_of_architecture",
#     ]
#
#     measures = [target[1] for target in targets] + ["dns_sinkhole_enabled_strict"]
#     if "credential_theft_enabled_strict" in rule_json.columns:
#         measures.append("credential_theft_enabled_strict")
#
#     if enabled_allow_rules.empty:
#         enabled_allow_measures = pd.DataFrame(columns=[*dimensions, *measures])
#     else:
#         enabled_allow_measures = enabled_allow_rules.groupby(
#             dimensions, as_index=False
#         )[measures].sum()
#
#     raw_data_json = pd.DataFrame(raw_data_json)
#     raw_data_json = pd.merge(
#         raw_data_json, enabled_allow_measures, how="left", on=dimensions
#     )
#     raw_data_json.fillna(0, inplace=True)
#
#     return rule_json.to_json(orient="records"), raw_data_json.to_json(orient="records")


# def get_formula(metric: str, strict: bool = False) -> Tuple[str]:
#     """"""
#     FORMULAS = {
#         "WildFire": ("wildfire_enabled", "allow_rule_count"),
#         "Anti-Spyware": ("antispyware_enabled", "allow_rule_count"),
#         "Anti-Virus": ("antivirus_enabled", "allow_rule_count"),
#         "Vulnerability Protection": ("vulnerability_enabled", "allow_rule_count"),
#         "File-Blocking": ("file_blocking_enabled", "allow_rule_count"),
#         "Data-Filtering": ("data_filtering_enabled", "allow_rule_count"),
#         "URL-Filtering": ("url_filtering_enabled", "allow_rule_count"),
#         "Credential Phishing Prevention": (
#             "credential_theft_enabled",
#             "allow_rule_count",
#         ),
#         "DNS Sinkhole": ("dns_sinkhole_enabled", "allow_rule_count"),
#         "APP-ID": ("app_id_enabled", "allow_rule_count"),
#         "User-ID": ("user_id_enabled", "allow_rule_count"),
#         "Service / Port": ("service_port_configured", "allow_rule_count"),
#         "Logging": ("log_end", "total_rule_count"),
#         "Log Forwarding": ("log_forwarding_enabled", "total_rule_count"),
#         "Zone Protection Profile": (
#             "zone_protection_profile_enabled",
#             "allow_rule_count",
#         ),
#     }
#     numerator, denominator = FORMULAS[metric]
#     numerator = f"{numerator}_strict" if strict else numerator
#     return numerator, denominator


# def flatten_heatmap_values(heatmap_values: List) -> Dict:
#     """"""
#     return pd.DataFrame(heatmap_values).select_dtypes(include="number").sum().to_dict()


# def aggregate_measures(data, version=None, **kwargs):
#     """Aggregates recordset by summing specified measures.
#
#     Args:
#         data: Heatmap data for a device
#         version: Optional device PAN-OS version
#         kwargs: Any extra values to add to the returned dictionary
#
#     Returns:
#         A dictionary of aggregated measures
#     """
#     agg_measures = pd.DataFrame(data).select_dtypes(include="number").sum().to_dict()
#
#     metric_defs = [
#         ("Allow Rule Count", "allow_rule_count"),
#         ("Total Rule Count", "total_rule_count"),
#         ("Deny Rule Count", "deny_rule_count"),
#         ("WildFire Adoption %", "wildfire_enabled", "allow_rule_count"),
#         ("Anti-Spyware Adoption %", "antispyware_enabled", "allow_rule_count"),
#         ("Anti-Virus Adoption %", "antivirus_enabled", "allow_rule_count"),
#         (
#             "Vulnerability Protection Adoption %",
#             "vulnerability_enabled",
#             "allow_rule_count",
#         ),
#         ("File-Blocking Adoption %", "file_blocking_enabled", "allow_rule_count"),
#         ("Data-Filtering Adoption %", "data_filtering_enabled", "allow_rule_count"),
#         ("URL-Filtering Adoption %", "url_filtering_enabled", "allow_rule_count"),
#         ("Credential Theft Adoption %", "credential_theft_enabled", "allow_rule_count"),
#         ("DNS Sinkhole Adoption %", "dns_sinkhole_enabled", "allow_rule_count"),
#         ("App ID Adoption %", "app_id_enabled", "allow_rule_count"),
#         ("User ID Adoption %", "user_id_enabled", "allow_rule_count"),
#         ("Logging Adoption %", "log_end", "total_rule_count"),
#         ("Service / Port Adoption %", "service_port_configured", "allow_rule_count"),
#         ("Log Forwarding Adoption %", "log_forwarding_enabled", "total_rule_count"),
#         (
#             "Zone Protection Profile Adoption %",
#             "zone_protection_profile_enabled",
#             "allow_rule_count",
#         ),
#     ]
#
#     metrics = {}
#     for metric, val in metric_defs[:3]:
#         try:
#             metrics[metric] = int(agg_measures[val])
#         except KeyError:
#             metrics[metric] = 0
#
#     for metric, numerator, denominator in metric_defs[3:]:
#         try:
#             metrics[metric] = round(
#                 float((agg_measures[numerator] / agg_measures[denominator]) * 100), 1
#             )
#         except ZeroDivisionError:
#             metrics[metric] = 0
#         except KeyError:
#             # credential_theft_enabled will be missing for older history data and devices not running PAN-OS 8.0+
#             # version will be missing for industry average data
#             if (
#                 numerator == "credential_theft_enabled"
#                 and version is not None
#                 and version < 8
#             ):
#                 metrics[metric] = "PAN-OS < 8.0"
#             else:
#                 metrics[metric] = "N/A"
#
#     metrics.update(kwargs)
#
#     return metrics


# def get_device_trend(heatmap_history: HeatMapHistory) -> List:
#     """Query the database for the heatmap history of a given serial number.
#
#     Ignore history of the current TSF if it has previously been saved to the database.
#     If the same Tech Support File has been used multiple times, only show data from the
#     last time a report was generated.
#
#     Args:
#         serial_number: string of serial_number to query
#         current_tsf_generated_date: string of current tsf date
#
#     Returns:
#         A list of dictionaries representing the history recordset.
#     """
#     trend = []
#     for tsf_date, record in heatmap_history.historical_data.items():
#         trend.append(
#             OverallAdoption(data=record["data"]).calculate_percentage(
#                 version=panos_major_version(record["panos_version"]),
#                 tsf_generated_date=tsf_date,
#             )
#             # aggregate_measures(
#             #     record["data"],
#             #     panos_major_version(record["panos_version"]),
#             #     tsf_generated_date=tsf_date,
#             # )
#         )
#     return trend


# def to_pct(num: float) -> float:
#     """Format number as a percent"""
#     return round((num * 100), 1)


# def get_pct_change(current_pct: float, prior_pct: float) -> str:
#     """Calculates point change between two percentages."""
#     delta = round(current_pct - prior_pct)
#     if delta == 0:
#         return "No change"
#     label = "pt" if abs(delta) == 1 else "pts"
#     prefix = "+" if delta > 0 else ""
#     return f"{prefix}{delta} {label}"


def get_inactive_license_warnings(xml_config) -> defaultdict:
    """Collect warnings to display above adoption heatmaps.

    NOTE: Only applies to NGFWs
    """
    warnings = defaultdict(bool)
    if not xml_config.panorama:
        for license in [
            "WildFire License",
            "Threat Prevention",
            "PAN-DB URL Filtering",
        ]:
            warnings[
                license
            ] = not xml_config.model_manager.license_info.has_active_license(license)
    return warnings


def process_heatmap_summary(
    current_data, prior_data, industry_average, decryption_reporting, decryption_rules
) -> Dict:
    """Generates adoption summary data"""
    # ORDER = [
    #     "WildFire",
    #     "Anti-Virus",
    #     "Anti-Spyware",
    #     "DNS Sinkhole",
    #     "Vulnerability Protection",
    #     "URL-Filtering",
    #     "Credential Phishing Prevention",  # TODO Ask Sam
    #     "File-Blocking",
    #     "Data-Filtering",
    #     "User-ID",
    #     "APP-ID",
    #     "Service / Port",
    #     "Logging",
    #     "Log Forwarding",
    #     "Zone Protection Profile",
    # ]
    # if int(current_data["panos_version"][0]) < 8:
    #     ORDER.remove("Credential Phishing Prevention")
    #
    # heatmap_summary = OrderedDict()
    #
    # current = flatten_heatmap_values(current_data.pop("data"))
    # prior = (
    #     flatten_heatmap_values(prior_data.pop("data")) if prior_data is not None else {}
    # )
    #
    # overall_adoption = OrderedDict()
    # best_practice_mode_adoption = OrderedDict()
    # bp_ignores = {
    #     "Data-Filtering",
    #     "User-ID",
    #     "APP-ID",
    #     "Service / Port",
    #     "Logging",
    #     "Log Forwarding",
    #     "Zone Protection Profile",
    # }
    # for col in ORDER:
    #     numerator, denominator = get_formula(col)
    #     try:
    #         current_pct = to_pct(divide(current[numerator], current[denominator]))
    #     except KeyError:
    #         current_pct = 0.0
    #     overall_adoption[col] = {"percent": current_pct}
    #     try:
    #         prior_pct = to_pct(divide(prior[numerator], prior[denominator]))
    #     except KeyError:
    #         overall_adoption[col]["change"] = "No change"
    #     else:
    #         overall_adoption[col]["change"] = get_pct_change(current_pct, prior_pct)
    #     if col not in bp_ignores:
    #         numerator, denominator = get_formula(col, strict=True)
    #         try:
    #             best_practice_mode_adoption[col] = {
    #                 "percent": to_pct(divide(current[numerator], current[denominator]))
    #             }
    #         except KeyError:
    #             best_practice_mode_adoption[col] = {"percent": 0.0}

    current_data_adoption_analysis = AdoptionAnalysis(
        analysis_data=current_data.pop("data")
    )
    if prior_data is not None:
        prior_data_adoption_analysis = AdoptionAnalysis(
            analysis_data=prior_data.pop("data")
        )
        prior_data_adoption_analysis.calculate_adoption_percentage(
            version=prior_data.get("panos_version", None)
        )

    else:
        prior_data_adoption_analysis = None

    overall_adoption = OrderedDict()
    best_practice_mode_adoption = OrderedDict()

    # Process:
    # Step 1. excluding all the default values calculate_adoption_percentage uses which would result in an empty list
    # Step 2. then including only the BP Mode metrics
    # Step 3. Doing a shallow copy for safety
    _best_practice_mode_adoption = current_data_adoption_analysis.calculate_adoption_percentage(
        version=current_data["panos_version"][0],
        include_metrics=AdoptionMetrics.get_bp_mode_metrics(only_strict=True),
        exclude_metrics=AdoptionMetrics.get_adoption_metrics(),
    ).copy()

    _overall_adoption_pct = current_data_adoption_analysis.calculate_adoption_percentage(
        version=current_data["panos_version"][0]
    )
    _overall_adoption_change = AdoptionAnalysis.calculate_adoption_change(
        current_data_analysis=current_data_adoption_analysis,
        prior_data_analysis=prior_data_adoption_analysis,
    )

    # # Adapt to existing html format
    # custom_mapping = {
    #     AdoptionMetrics.WILD_FIRE_ADOPTION: "WildFire",
    #     AdoptionMetrics.ANTI_VIRUS_ADOPTION: "Anti-Virus",
    #     AdoptionMetrics.ANTI_SPYWARE_ADOPTION: "Anti-Spyware",
    #     AdoptionMetrics.DNS_SINKHOLE_ADOPTION: "DNS Sinkhole",
    #     AdoptionMetrics.VULNERABILITY_PROTECTION_ADOPTION: "Vulnerability Protection",
    #     AdoptionMetrics.URL_FILTERING_ADOPTION: "URL-Filtering",
    #     AdoptionMetrics.CREDENTIAL_THEFT_ADOPTION: "Credential Phishing Prevention",  # TODO Ask Sam for standard
    #     AdoptionMetrics.FILE_BLOCKING_ADOPTION: "File-Blocking",
    #     AdoptionMetrics.DATA_FILTERING_ADOPTION: "Data-Filtering",
    #     AdoptionMetrics.USER_ID_ADOPTION: "User-ID",
    #     AdoptionMetrics.APP_ID_ADOPTION: "APP-ID",
    #     AdoptionMetrics.SERVICE_PORT_ADOPTION: "Service / Port",
    #     AdoptionMetrics.LOGGING_ADOPTION: "Logging",
    #     AdoptionMetrics.LOG_FORWARDING_ADOPTION: "Log Forwarding",
    #     AdoptionMetrics.ZONE_PROTECTION_PROFILE_ADOPTION: "Zone Protection Profile",
    # }

    # Adapt to existing html format
    expected_html_order = OrderedDict(
        {
            "WildFire": AdoptionMetrics.WILD_FIRE_ADOPTION,
            "Anti-Virus": AdoptionMetrics.ANTI_VIRUS_ADOPTION,
            "Anti-Spyware": AdoptionMetrics.ANTI_SPYWARE_ADOPTION,
            "DNS Sinkhole": AdoptionMetrics.DNS_SINKHOLE_ADOPTION,
            "Vulnerability Protection": AdoptionMetrics.VULNERABILITY_PROTECTION_ADOPTION,
            "URL-Filtering": AdoptionMetrics.URL_FILTERING_ADOPTION,
            "Credential Phishing Prevention": AdoptionMetrics.CREDENTIAL_THEFT_ADOPTION,
            "File-Blocking": AdoptionMetrics.FILE_BLOCKING_ADOPTION,
            "Data-Filtering": AdoptionMetrics.DATA_FILTERING_ADOPTION,
            "User-ID": AdoptionMetrics.USER_ID_ADOPTION,
            "APP-ID": AdoptionMetrics.APP_ID_ADOPTION,
            "Service / Port": AdoptionMetrics.SERVICE_PORT_ADOPTION,
            "Logging": AdoptionMetrics.LOGGING_ADOPTION,
            "Log Forwarding": AdoptionMetrics.LOG_FORWARDING_ADOPTION,
            "Zone Protection Profile": AdoptionMetrics.ZONE_PROTECTION_PROFILE_ADOPTION,
        }
    )

    for html_label, metric_name in expected_html_order.items():
        try:
            # Keys from _best_practice_mode_adoption dict will have ' Strict' at the end of the metric name since
            # they are BP mode metrics
            best_practice_mode_adoption[html_label] = {
                "percent": _best_practice_mode_adoption[f"{metric_name} Strict"]
            }
        except KeyError:
            pass

        try:
            overall_adoption[html_label] = {
                "percent": _overall_adoption_pct[metric_name],
                "change": _overall_adoption_change[metric_name],
            }
        except KeyError:
            pass

    heatmap_summary = OrderedDict()
    heatmap_summary["overall_adoption"] = overall_adoption
    heatmap_summary["best_practice_mode_adoption"] = best_practice_mode_adoption

    if industry_average is not None:
        industry_adoption = OrderedDict(
            {"Industry": industry_average["sfdc_account_industry"]}
        )
        # ignores = {
        #     "User-ID",
        #     "APP-ID",
        #     "Service / Port",
        #     "Logging",
        #     "Log Forwarding",
        #     "Zone Protection Profile",
        # }
        # for metric in AdoptionMetrics.get_adoption_metrics():
        #     # Adding to adapt to the format required by the html
        #     col = custom_mapping.get(metric, metric)
        #
        #     if col not in ignores:
        #         val = (
        #             "Credential Theft"
        #             if col == "Credential Phishing Prevention"
        #             else col
        #         )
        #         industry_adoption[col] = {
        #             # "percent": industry_average[f"{val} Adoption %"]
        #             "percent": industry_average[f"{val} Adoption"]
        #         }

        industry_ignores_metrics = AdoptionMetrics.get_industry_ignores_metrics()
        for html_label, metric_name in expected_html_order.items():
            if metric_name not in industry_ignores_metrics:
                try:
                    industry_adoption[html_label] = {
                        "percent": industry_average[f"{metric_name} %"]
                    }
                except KeyError:
                    # This is due to Credential Theft not in versions < 8
                    continue

        heatmap_summary["industry_adoption"] = industry_adoption

    decryption_summary = OrderedDict(
        {
            "SSL Forward Proxy": "ssl-forward-proxy" in decryption_reporting["decrypt"],
            "SSL Inbound Inspection": "ssl-inbound-inspection"
            in decryption_reporting["decrypt"],
            "SSH Proxy": "ssh-proxy" in decryption_reporting["decrypt"],
            "Decryption Profile Used": any(
                rule["configuration"]["decryption_profile"] != "None"
                for rule in decryption_rules
            ),
            "URL Categories Exempted": ", ".join(decryption_reporting["no-decrypt"]),
        }
    )
    heatmap_summary["decryption_summary"] = decryption_summary

    return heatmap_summary


def group_mappings(zone_mapping: List) -> List:
    """Groups common mappings for the same zone."""
    mapping_df = pd.DataFrame(
        zone_mapping, columns=["zone", "vsys", "area_of_architecture"]
    )
    return (
        mapping_df.groupby(["zone", "area_of_architecture"])["vsys"]
        .apply(lambda x: ", ".join(x))
        .reset_index()
        .to_dict(orient="records")
    )


def package_html(xml_config, heatmap_history: HeatMapHistory) -> Dict:
    """ Packages heatmap HTML file

    Args:
        panorama: boolean
        info: dict containing a device_info dict, dep_dynamic_update list of dicts, and
        dynamic_update list of dicts
        ts_generated_date: datetime object
        raw_data_json: string representing a JavaScript variable of the heatmap values
        rule_json: string representing a JavaScript variable of the rule detail values
        column_json: string representing a JavaScript variable of the unique values for each column
        of the rule details dataset
        rule_detail_columns: string representing a JavaScript variable of the columns present in
        the rule_json object
        industry: string representing the SFDC industry
        decryption_reporting: dictionary for creating decryption reporting note on heatmap summary
        disable_industry_comparison: boolean flag indicating whether to include industry benchmarks

    Returns:
        A string of the combined HTML and all related assets
    """
    # TODO - Refactor this so BPA and CSS pull from same source
    mapping_definitions = json.load(open(map_definitions_path))

    heatmap_trending_metrics = ["Serial"]
    heatmap_trending_metrics.extend(
        AdoptionMetrics.get_panorama_specific_metrics(is_panorama=xml_config.panorama)
    )
    heatmap_trending_metrics.extend(AdoptionMetrics.get_count_metrics())
    heatmap_trending_metrics.extend(AdoptionMetrics.get_adoption_metrics(suffix=" %"))

    heatmap_trending_bp_mode_metrics = AdoptionMetrics.get_bp_mode_metrics(
        suffix=" %", only_strict=True
    )

    data = {
        "license_info": xml_config.license_info,
        "zone_mapping": group_mappings(xml_config.zone_mappings),
        "rule_detail_columns": xml_config.heatmap.rule_detail_columns,
        "decryption_reporting": xml_config.heatmap.decryption_reporting,
        "definitions": mapping_definitions,
        "metrics": heatmap_trending_metrics,
        "bp_mode_metrics": list(
            map(lambda x: x.replace(" Strict", ""), heatmap_trending_bp_mode_metrics)
        ),
        "areas_of_architecture": list(Mapping.CHOICES),
        "heatmap_values": xml_config.heatmap.heatmap_values,
        "heatmap_raw_values": xml_config.heatmap.heatmap_raw_values,
        "rules_values": xml_config.heatmap.rules_values,
        "column_values": xml_config.heatmap.column_json,
        "content_update_age": xml_config.content_update_age,
        "is_eol": xml_config.is_eol,
        "inactive_license_warnings": get_inactive_license_warnings(xml_config),
    }

    # moves "any" to start of filters
    column_values_json = data["column_values"]
    column_values = json.loads(column_values_json)
    for filter in column_values:
        if "any" in column_values[filter]:
            column_values[filter].remove("any")
            column_values[filter].insert(0, "any")
    new_column_values_json = json.dumps(column_values)
    data["column_values"] = new_column_values_json

    # current_data = {
    #     "data": xml_config.heatmap.heatmap_values,
    #     "panos_version": str(xml_config.version),
    # }
    tsf_date = xml_config.system_info["Tech Support File Generated Date"]

    device_info = xml_config.system_info.copy()
    device_info["serial_number"] = device_info.pop("serial")

    heatmap_history.add_heatmap(
        tsf_generation_date=tsf_date,
        pan_os_version=str(xml_config.version),
        heatmap_data=xml_config.heatmap.heatmap_values,
        serial_number=device_info["serial_number"],
        managed_device_count=xml_config.managed_device_count,
    )
    data["managed_firewalls"] = {
        "managed_devices": xml_config.managed_device_count,
        "device_groups_with_security_policies_enabled": str(
            len(
                xml_config.model_manager.get(
                    "security_rule"
                ).device_group_with_policies_configured_for_security_rule(
                    excluded_shared=True
                )
            )
        ),
    }
    # heatmap_history empty OrderedDict() at this point
    # heatmap_history[tsf_date] = current_data
    # heatmap_history = OrderedDict(sorted(heatmap_history.items()))

    data["generated_date"] = datetime.datetime.now().strftime("%B %d, %Y at %H:%M:%S")
    data["ts_generated_date"] = datetime.datetime.strptime(
        tsf_date, "%Y-%m-%d %H:%M:%S"
    ).strftime("%B %d, %Y at %H:%M:%S")

    # 'Trend' related to Heatmap -> Trending
    data["trend"] = HeatMapTrend.generate(heatmap_history)

    data["industry"] = xml_config.model_manager.industry_info.industry_name
    del device_info["Tech Support File Generated Date"]
    data["info"] = {
        "device_info": device_info,
        "dynamic_update": xml_config.heatmap.update_schedules,
        "dep_dynamic_update": xml_config.heatmap.deployment_update_schedules,
    }

    if xml_config.version < 8:
        # device has no data where running on PAN-OS 8.0+, so we can exclude from trend table
        data["metrics"].remove("Credential Theft Adoption %")

    DOCKER = bool(getenv("DOCKER"))
    if not DOCKER and not getattr(xml_config, "disable_industry_comparison", False):
        industry_sum = xml_config.model_manager.industry_info.industry_sum
        if industry_sum is not None and data["industry"] != "Other":
            adoption_analysis = AdoptionAnalysis(analysis_data=[industry_sum.as_dict])

            # Need to add Suffix as it hard coded into the HTML.
            # In future refactor avoid using % symbol
            calculated_metrics = adoption_analysis.calculate_adoption_percentage(
                include_metrics=adoption_analysis.adoption_metrics.get_bp_mode_metrics(),
                key_suffix=" %",
            )

            # Adding industry info to the metrics
            calculated_metrics["sfdc_account_industry"] = data["industry"]

            data["industry_average"] = calculated_metrics
        else:
            data["industry_average"] = None

    # prior_data = get_prior_history(heatmap_history, tsf_date)
    prior_data = heatmap_history.get_previous_heatmap(tsf_generation_date=tsf_date)

    data["heatmap_summary"] = process_heatmap_summary(
        heatmap_history.latest_heatmap_json,
        prior_data,
        data.get("industry_average"),
        xml_config.heatmap.decryption_reporting,
        xml_config.bpa.decryption_rules,
    )
    return data
