from bpa.analyzers.best_practices.bp_check import (
    BestPracticeWarning,
    SecurityRuleWarning,
)
from bpa.publishers.formats.excel.constants import (
    TEXT_NOT_APPLICABLE,
    TEXT_REMEDIATION_MINUTES,
    TEXT_CSC_6,
    TEXT_CSC_7,
    TEXT_CAP_SUMMARY,
    TEXT_CTL_CATEGORY,
    TEXT_CHECK_ID,
    TEXT_CHECK_NAME,
    TEXT_TEMPLATE,
)


class ResultMixin:
    """BestPracticeResult processing utilities"""

    # NOTE: Entrypoint for parsing data
    def parse_bp_result(self, result, category, analyzer):
        """Parse Best Practice Result"""
        config = {"Name": ""}
        for key, val in result.configuration.items():
            if key in {"name", "rule_name"}:
                config["Name"] = val
            if key == "location":
                config["Location"] = val
            if key == "template_name":
                config[TEXT_TEMPLATE] = val
        for check in result.checks:
            parsed_check = self.parse_bp_check(result, check, category, analyzer)
            if parsed_check is not None:
                self.combined_data[category].append({**config, **parsed_check})

    def parse_bp_check(self, result, check, category, analyzer):
        """Parse Best Practice Check"""
        if not isinstance(check, BestPracticeWarning):
            return
        if check.check_passed:
            return
        if isinstance(check, SecurityRuleWarning) and check.check_excluded:
            return
        check_key = int(check.check_id)
        check_details = {
            TEXT_CHECK_ID: check_key,
            TEXT_CHECK_NAME: check.check_name,
            "Message": check.check_message,
        }
        check_docs = self.docs_map.get(check_key) if self.docs_map else None
        doc_details = {}
        doc_details["Complexity"] = (
            check_docs.complexity if check_docs else TEXT_NOT_APPLICABLE
        )
        doc_details["Feature"] = (
            " > ".join([category.title(), *check_docs.left_nav.split(" - ")])
            if check_docs
            else " > ".join([category.title(), analyzer.replace("_", " ").title()])
        )
        doc_details[TEXT_REMEDIATION_MINUTES] = (
            int(check_docs.effort) if check_docs else TEXT_NOT_APPLICABLE
        )
        try:
            mapping_docs = (
                self.mapping_df_docs.loc[check_key].to_dict() if self.docs_map else None
            )
        except KeyError:
            mapping_docs = None
        doc_details[TEXT_CSC_6] = (
            mapping_docs["cscv6_control"] if mapping_docs else TEXT_NOT_APPLICABLE
        )
        doc_details[TEXT_CSC_7] = (
            mapping_docs["cscv7_control"] if mapping_docs else TEXT_NOT_APPLICABLE
        )
        doc_details[TEXT_CAP_SUMMARY] = (
            mapping_docs["capability_label"] if mapping_docs else TEXT_NOT_APPLICABLE
        )
        doc_details[TEXT_CTL_CATEGORY] = (
            mapping_docs["control_category"] if mapping_docs else TEXT_NOT_APPLICABLE
        )
        doc_details["Class"] = (
            mapping_docs["class_label"] if mapping_docs else TEXT_NOT_APPLICABLE
        )
        return {**check_details, **doc_details}
