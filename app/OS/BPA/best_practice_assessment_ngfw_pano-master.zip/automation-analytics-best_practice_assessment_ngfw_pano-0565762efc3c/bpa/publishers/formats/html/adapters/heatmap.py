import json
from collections import defaultdict
from dataclasses import asdict
from typing import Dict, List
from functools import reduce
import pandas as pd
from bpa.analyzers.best_practices.bp_check import BestPracticeNote


# TODO - create rule_values and heatmap_values in single iteration to avoid unnecessary looping


class SecurityPolicyCapabilityAdoption:
    _rule_detail_columns = (
        "device_group",
        "target",
        "source_area_of_architecture",
        "dest_area_of_architecture",
        "rulename",
        "tags",
        "service",
        "url_categories",
        "rulebase",
        "source_zone",
        "source_user",
        "dest_zone",
        "source_addresses",
        "dest_addresses",
        "application",
        "action",
        "rule_enabled",
        "wildfire_enabled",
        "file_blocking_enabled",
        "antivirus_enabled",
        "antispyware_enabled",
        "dns_sinkhole_enabled",
        "vulnerability_enabled",
        "url_filtering_enabled",
        "credential_theft_enabled",
        "data_filtering_enabled",
        "app_id_enabled",
        "user_id_enabled",
        "service_port_configured",
        "zone_protection_profile_enabled",
        "profile_used",
        "profile_group_used",
        "profile_group_name",
        # anti-virus profile columns
        "av_profile_name",
        "antivirus_profile_threat_exceptions_bp_check",
        "antivirus_profile_application_exceptions_bp_check",
        "antivirus_profile_decoder_actions_bp_check",
        "antivirus_profile_decoder_wildfire_actions_bp_check",
        "antivirus_profile_packet_capture_bp_check",
        "reset-client_/_reset-server_actions_bp_check_for_av",
        ####### NOTE ######
        # SAM - As we can see that unused_security_profile_bp_check_for_vuln(same for av,spyware,url_filtering,file_blocking and wildfire) BP check applies on profiles when it is not applied on a policy.
        # If it is not applied on policy I do not think we even need to show it. Because it will always be Not-Applicable as it never matches to any rule.
        # JENIL - kept code commented so that in future if we need we can just uncomment it.
        ####### END #######
        # "unused_security_profile_bp_check_for_av",
        # vuln protection columns
        "vuln_profile_name",
        "vulnerability_protection_profile_threat_exceptions_bp_check",
        "vulnerability_protection_strict_profile_bp_check",
        "vulnerability_protection_low/informational_profile_bp_check",
        "reset-client_/_reset-server_actions_bp_check_for_vp",
        # "unused_security_profile_bp_check_for_vuln",
        # anti spyware columns
        "spyware_profile_name",
        "anti_spyware_profile_threat_exceptions_bp_check",
        "botnet_configuration_bp_check",
        "dns_sinkhole_bp_check",
        "passive_dns_monitoring_bp_check",
        "anti-spyware_strict_profile_bp_check",
        "anti-spyware_low/informational_profile_bp_check",
        "reset-client_/_reset-server_actions_bp_check_for_as",
        # "unused_security_profile_bp_check_for_spyware",
        # url filtering columns
        "url_filtering_profile_name",
        "url_profile_known_bad_categories_bp_check",
        "log_container_page_bp_check",
        "url_filtering_profile_allow_categories_bp_check",
        "credential_theft_bp_check",
        "credential_phishing_mode_bp_check",
        # "unused_security_profile_bp_check_for_url_filtering",
        # file blocking columns
        "file_blocking_profile_name",
        "file_blocking_strict_profile_bp_check",
        # "unused_security_profile_bp_check_for_file_blocking",
        "data_filtering_profile_name",
        # wildfire columns
        "wildfire_profile_name",
        "wildfire_profile_file_types_bp_check",
        # "unused_security_profile_bp_check_for_wildfire",
        "log_end",
        "log_start",
        "log_forwarding_profile",
    )

    def __init__(self, report_publsiher, arch_mappings):
        self.arch_mappings = arch_mappings
        self.adoption_manager = report_publsiher().adoption_manager
        self.model_manager = self.adoption_manager().model_manager
        self.panorama = self.model_manager().tree.panorama
        self.version = self.model_manager().tree.version

        self.update_schedules = self.get_local_update_schedules()
        self.deployment_update_schedules = self.get_deployment_update_schedules()
        self.decryption_reporting = self.get_decryption_reporting()
        self._column_json = defaultdict(set)
        self._heatmap_raw_values = list()
        self.heatmap_values = self.set_heatmap_values()

    @property
    def column_json(self):
        class SetEncoder(json.JSONEncoder):
            def default(self, obj):
                if isinstance(obj, set):
                    return sorted(list(obj), key=str.casefold)
                return json.JSONEncoder.default(self, obj)

        return json.dumps(self._column_json, cls=SetEncoder)

    @property
    def rule_detail_columns(self):
        """"""
        rule_detail_columns = list(self._rule_detail_columns)
        if not self.panorama:
            rule_detail_columns = [
                x for x in rule_detail_columns if x not in ["device_group", "rulebase"]
            ]
        if self.version < 8:
            rule_detail_columns = [
                x for x in rule_detail_columns if x != "credential_theft_enabled"
            ]
        if self.model_manager().rule_usage_info.is_available:
            # These columns need to be between rulename and tags.
            rulename_index = rule_detail_columns.index("rulename")
            insertion_index = rulename_index + 1

            # Using slicing to stick to non mutation theme of this function
            rule_detail_columns = (
                rule_detail_columns[:insertion_index]
                + ["rule_hit_count", "rule_last_hit"]
                + rule_detail_columns[insertion_index:]
            )
        return rule_detail_columns

    @property
    def rules_values(self) -> List[Dict]:
        """Detailed heatmap data"""
        _model_manager = self.model_manager()
        model_set = _model_manager.get("security_rule")
        data = []

        bp_checks_result = self.get_all_bp_checks()

        for result in self.adoption_manager().get():
            sig = {
                "rule_name": result.configuration["rule_name"],
                "location": result.configuration["location"],
            }
            rule = model_set.find(**sig)
            row = {
                "target": ", ".join(rule.targets or ["NO_TARGET"]),
                "source_area_of_architecture": self.get_architectures(
                    rule.location, rule.source_zones
                ),
                "dest_area_of_architecture": self.get_architectures(
                    rule.location, rule.dest_zones
                ),
                "device_group": rule.location,
                "rulename": rule.rule_name,
                "rule_uuid": rule.rule_uuid,
                "rulebase": rule.rulebase,
                "action": rule.action,
                "rule_enabled": rule.rule_enabled,
                "application": ", ".join(rule.applications),
                "service": ", ".join(rule.services),
                "url_categories": ", ".join(rule.url_categories),
                "tags": ", ".join(rule.tags or ["NO_TAG"]),
                "source_user": ", ".join(rule.source_users),
                "source_zone": ", ".join(rule.source_zones),
                "dest_zone": ", ".join(rule.dest_zones),
                "profile_group_name": rule.profile_group,
                #################
                ###### URL Filtering ######
                #################
                "url_filtering_profile_name": rule.profile_url_filtering,
                "url_profile_known_bad_categories_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["url_filtering_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="url_profile_known_bad_categories_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_url_filtering}",
                ),
                "log_container_page_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["url_filtering_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="log_container_page_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_url_filtering}",
                ),
                "url_filtering_profile_allow_categories_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["url_filtering_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="url_filtering_profile_allow_categories_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_url_filtering}",
                ),
                "credential_theft_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["url_filtering_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="credential_theft_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_url_filtering}",
                ),
                "credential_phishing_mode_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["url_filtering_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="credential_phishing_mode_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_url_filtering}",
                ),
                # "unused_security_profile_bp_check_for_url_filtering": self.map_vsys(
                #     bp_checks_result=bp_checks_result["url_filtering_profile"],
                #     model_manager_ref=_model_manager,
                #     bp_check_name="unused_security_profile_bp_check_for_url_filtering",
                #     location_and_profile_name=f"{rule.location},{rule.profile_url_filtering}",
                # ),
                #################
                ###### Vulnerability Protection ######
                #################
                "vuln_profile_name": rule.profile_vulnerability_protection,
                "vulnerability_protection_profile_threat_exceptions_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result[
                        "vulnerability_protection_profile"
                    ],
                    model_manager_ref=_model_manager,
                    bp_check_name="vulnerability_protection_profile_threat_exceptions_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_vulnerability_protection}",
                ),
                "vulnerability_protection_strict_profile_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result[
                        "vulnerability_protection_profile"
                    ],
                    model_manager_ref=_model_manager,
                    bp_check_name="vulnerability_protection_strict_profile_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_vulnerability_protection}",
                ),
                "vulnerability_protection_low/informational_profile_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result[
                        "vulnerability_protection_profile"
                    ],
                    model_manager_ref=_model_manager,
                    bp_check_name="vulnerability_protection_low/informational_profile_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_vulnerability_protection}",
                ),
                "reset-client_/_reset-server_actions_bp_check_for_vp": self.map_vsys(
                    bp_checks_result=bp_checks_result[
                        "vulnerability_protection_profile"
                    ],
                    model_manager_ref=_model_manager,
                    bp_check_name="reset-client_/_reset-server_actions_bp_check_for_vp",
                    location_and_profile_name=f"{rule.location},{rule.profile_vulnerability_protection}",
                ),
                # "unused_security_profile_bp_check_for_vuln": self.map_vsys(
                #     bp_checks_result=bp_checks_result[
                #         "vulnerability_protection_profile"
                #     ],
                #     model_manager_ref=_model_manager,
                #     bp_check_name="unused_security_profile_bp_check_for_vuln",
                #     location_and_profile_name=f"{rule.location},{rule.profile_vulnerability_protection}",
                # ),
                #################
                ###### Wildfire ######
                #################
                "wildfire_profile_name": rule.profile_wildfire_analysis,
                "wildfire_profile_file_types_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["wildfire_analysis_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="wildfire_profile_file_types_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_wildfire_analysis}",
                ),
                # "unused_security_profile_bp_check_for_wildfire": self.map_vsys(
                #     bp_checks_result=bp_checks_result["wildfire_analysis_profile"],
                #     model_manager_ref=_model_manager,
                #     bp_check_name="unused_security_profile_bp_check_for_wildfire",
                #     location_and_profile_name=f"{rule.location},{rule.profile_wildfire_analysis}",
                # ),
                #################
                ###### Anti-virus ######
                #################
                "av_profile_name": rule.profile_antivirus,
                "antivirus_profile_threat_exceptions_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["antivirus_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="antivirus_profile_threat_exceptions_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_antivirus}",
                ),
                "antivirus_profile_application_exceptions_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["antivirus_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="antivirus_profile_application_exceptions_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_antivirus}",
                ),
                "antivirus_profile_decoder_actions_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["antivirus_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="antivirus_profile_decoder_actions_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_antivirus}",
                ),
                "antivirus_profile_decoder_wildfire_actions_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["antivirus_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="antivirus_profile_decoder_wildfire_actions_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_antivirus}",
                ),
                "antivirus_profile_packet_capture_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["antivirus_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="antivirus_profile_packet_capture_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_antivirus}",
                ),
                "reset-client_/_reset-server_actions_bp_check_for_av": self.map_vsys(
                    bp_checks_result=bp_checks_result["antivirus_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="reset-client_/_reset-server_actions_bp_check_for_av",
                    location_and_profile_name=f"{rule.location},{rule.profile_antivirus}",
                ),
                # "unused_security_profile_bp_check_for_av": self.map_vsys(
                #     bp_checks_result=bp_checks_result["antivirus_profile"],
                #     model_manager_ref=_model_manager,
                #     bp_check_name="unused_security_profile_bp_check_for_av",
                #     location_and_profile_name=f"{rule.location},{rule.profile_antivirus}",
                # ),
                #################
                ###### Anti-spyware ######
                #################
                "spyware_profile_name": rule.profile_anti_spyware,
                "anti_spyware_profile_threat_exceptions_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["anti_spyware_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="anti_spyware_profile_threat_exceptions_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_anti_spyware}",
                ),
                "botnet_configuration_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["anti_spyware_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="botnet_configuration_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_anti_spyware}",
                ),
                "dns_sinkhole_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["anti_spyware_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="dns_sinkhole_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_anti_spyware}",
                ),
                "passive_dns_monitoring_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["anti_spyware_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="passive_dns_monitoring_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_anti_spyware}",
                ),
                "anti-spyware_strict_profile_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["anti_spyware_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="anti-spyware_strict_profile_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_anti_spyware}",
                ),
                "anti-spyware_low/informational_profile_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["anti_spyware_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="anti-spyware_low/informational_profile_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_anti_spyware}",
                ),
                "reset-client_/_reset-server_actions_bp_check_for_as": self.map_vsys(
                    bp_checks_result=bp_checks_result["anti_spyware_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="reset-client_/_reset-server_actions_bp_check_for_as",
                    location_and_profile_name=f"{rule.location},{rule.profile_anti_spyware}",
                ),
                # "unused_security_profile_bp_check_for_spyware": self.map_vsys(
                #     bp_checks_result=bp_checks_result["anti_spyware_profile"],
                #     model_manager_ref=_model_manager,
                #     bp_check_name="unused_security_profile_bp_check_for_spyware",
                #     location_and_profile_name=f"{rule.location},{rule.profile_anti_spyware}",
                # ),
                #################
                ###### Data Filtering ######
                #################
                "data_filtering_profile_name": rule.profile_data_filtering,
                #################
                ###### File Blocking ######
                #################
                "file_blocking_profile_name": rule.profile_file_blocking,
                "file_blocking_strict_profile_bp_check": self.map_vsys(
                    bp_checks_result=bp_checks_result["file_blocking_profile"],
                    model_manager_ref=_model_manager,
                    bp_check_name="file_blocking_strict_profile_bp_check",
                    location_and_profile_name=f"{rule.location},{rule.profile_file_blocking}",
                ),
                # "unused_security_profile_bp_check_for_file_blocking": self.map_vsys(
                #     bp_checks_result=bp_checks_result["file_blocking_profile"],
                #     model_manager_ref=_model_manager,
                #     bp_check_name="unused_security_profile_bp_check_for_file_blocking",
                #     location_and_profile_name=f"{rule.location},{rule.profile_file_blocking}",
                # ),
                #################
                ###### Log Forwarding ######
                #################
                "log_forwarding_profile": rule.log_forwarding_profile,
                "description": rule.description,
                "source_addresses": rule.address_configured("source"),
                "dest_addresses": rule.address_configured("dest"),
                "file_blocking_enabled": result.metrics.get(
                    "file_blocking_profile_enabled", 0
                ),
                "log_forwarding_enabled": result.metrics.get(
                    "log_forwarding_enabled", 0
                ),
                "service_port_configured": result.metrics.get(
                    "service_port_configured", 0
                ),
                "dns_sinkhole_enabled": result.metrics.get("dns_sinkhole_enabled", 0),
                "url_filtering_enabled": result.metrics.get(
                    "url_filtering_profile_enabled", 0
                ),
                "vulnerability_enabled": result.metrics.get(
                    "vulnerability_protection_profile_enabled", 0
                ),
                "wildfire_enabled": result.metrics.get(
                    "wildfire_analysis_profile_enabled", 0
                ),
                "user_id_enabled": result.metrics.get("user_id_enabled", 0),
                "zone_protection_profile_enabled": result.metrics.get(
                    "zone_protection_profile_enabled", 0
                ),
                "log_start": result.metrics.get("log_start", 0),
                "log_end": result.metrics.get("log_end", 0),
                "data_filtering_enabled": result.metrics.get(
                    "data_filtering_profile_enabled", 0
                ),
                "profile_used": result.metrics.get("profile_used", 0),
                "profile_group_used": result.metrics.get("profile_group_used", 0),
                "antispyware_enabled": result.metrics.get(
                    "anti_spyware_profile_enabled", 0
                ),
                "antivirus_enabled": result.metrics.get("antivirus_profile_enabled", 0),
                "app_id_enabled": result.metrics.get("app_id_enabled", 0),
                "wildfire_enabled_strict": result.metrics.get(
                    "wildfire_analysis_profile_enabled_bp_mode", 0
                ),
                "url_filtering_enabled_strict": result.metrics.get(
                    "url_filtering_profile_enabled_bp_mode", 0
                ),
                "antivirus_enabled_strict": result.metrics.get(
                    "antivirus_profile_enabled_bp_mode", 0
                ),
                "antispyware_enabled_strict": result.metrics.get(
                    "anti_spyware_profile_enabled_bp_mode", 0
                ),
                "vulnerability_enabled_strict": result.metrics.get(
                    "vulnerability_protection_profile_enabled_bp_mode", 0
                ),
                "file_blocking_enabled_strict": result.metrics.get(
                    "file_blocking_profile_enabled_bp_mode", 0
                ),
                "dns_sinkhole_enabled_strict": result.metrics.get(
                    "dns_sinkhole_enabled_bp_mode", 0
                ),
            }
            if self.version >= 8:
                row.update(
                    {
                        "credential_theft_enabled": result.metrics.get(
                            "credential_theft_enabled", 0
                        ),
                        "credential_theft_enabled_strict": result.metrics.get(
                            "credential_theft_enabled_bp_mode", 0
                        ),
                    }
                )
            rule_usage = _model_manager.rule_usage_info.get(row["rule_uuid"])
            if rule_usage:
                row.update(
                    {
                        "traffic_hit_days": str(
                            rule_usage.traffic_hit_days(
                                _model_manager.system_info[
                                    "Tech Support File Generated Date"
                                ]
                            )
                        ),
                        "rule_hit_count": str(rule_usage.hit_count),
                        "rule_last_hit": rule_usage.last_hit_str,
                    }
                )
            data.append(row)
        df = pd.DataFrame(data)
        df.replace(
            {1: "yes", 0: "no", True: "yes", False: "no", None: "none"}, inplace=True
        )
        for column in df.columns:
            vals = set(df[column].unique()) - {""}
            if vals == {"yes", "no"}:
                continue
            for val in vals:
                self._column_json[column].update(val.split(", "))
        return df.to_dict(orient="records")

    @property
    def heatmap_raw_values(self) -> List[Dict]:
        """Populate heat map values"""

        if self._heatmap_raw_values:
            return self._heatmap_raw_values

        legacy_map = {
            # new_attr: legacy_attr
            "total_rule_count": "total_rule_count",
            "allow_rule_count": "allow_rule_count",
            "deny_rule_count": "deny_rule_count",
            "anti_spyware_profile_enabled": "antispyware_enabled",
            "antivirus_profile_enabled": "antivirus_enabled",
            "app_id_enabled": "app_id_enabled",
            "data_filtering_profile_enabled": "data_filtering_enabled",
            "dns_sinkhole_enabled": "dns_sinkhole_enabled",
            "file_blocking_profile_enabled": "file_blocking_enabled",
            "log_end": "log_end",
            "log_forwarding_enabled": "log_forwarding_enabled",
            "service_port_configured": "service_port_configured",
            "url_filtering_profile_enabled": "url_filtering_enabled",
            "user_id_enabled": "user_id_enabled",
            "vulnerability_protection_profile_enabled": "vulnerability_enabled",
            "wildfire_analysis_profile_enabled": "wildfire_enabled",
            "zone_protection_profile_enabled": "zone_protection_profile_enabled",
            "wildfire_analysis_profile_enabled_bp_mode": "wildfire_enabled_strict",
            "url_filtering_profile_enabled_bp_mode": "url_filtering_enabled_strict",
            "antivirus_profile_enabled_bp_mode": "antivirus_enabled_strict",
            "anti_spyware_profile_enabled_bp_mode": "antispyware_enabled_strict",
            "vulnerability_protection_profile_enabled_bp_mode": "vulnerability_enabled_strict",
            "file_blocking_profile_enabled_bp_mode": "file_blocking_enabled_strict",
            "dns_sinkhole_enabled_bp_mode": "dns_sinkhole_enabled_strict",
        }
        if self.version >= 8:
            legacy_map.update(
                {
                    "credential_theft_enabled": "credential_theft_enabled",
                    "credential_theft_enabled_bp_mode": "credential_theft_enabled_strict",
                }
            )
        _model_manager = self.model_manager()
        model_set = _model_manager.get("security_rule")
        data = []
        for result in self.adoption_manager().get():
            sig = {
                "rule_name": result.configuration["rule_name"],
                "location": result.configuration["location"],
            }
            rule = model_set.find(**sig)
            row = {}
            row["source_zone"] = ", ".join(result.configuration["source_zones"])
            row["dest_zone"] = ", ".join(result.configuration["dest_zones"])
            row["device_group"] = result.configuration["location"]
            row["source_area_of_architecture"] = self.get_architectures(
                rule.location, rule.source_zones
            )
            row["dest_area_of_architecture"] = self.get_architectures(
                rule.location, rule.dest_zones
            )
            row["tags"] = ", ".join(rule.tags or ["NO_TAG"])
            row["target"] = ", ".join(rule.targets or ["none"])

            for metric, legacy_attr in legacy_map.items():
                row[legacy_attr] = result.metrics.get(metric, 0)

            rule_usage = _model_manager.rule_usage_info.get(rule.rule_uuid)
            if rule_usage:
                row["traffic_hit_within_time_frame"] = int(
                    rule_usage.calculate_traffic_hit_within_time_frame(
                        tsf_generated_date=_model_manager.system_info[
                            "Tech Support File Generated Date"
                        ]
                    )
                )
            data.append(row)
        self._heatmap_raw_values = data
        return self._heatmap_raw_values

    def set_heatmap_values(self) -> List[Dict]:
        """Aggregate heatmap data"""

        df = pd.DataFrame(self.heatmap_raw_values)

        # NOTE: Possible that no security rules are present
        if df.empty is True:
            return []
        dimensions = list(df.dtypes[df.dtypes == object].index)
        grouped = df.groupby(dimensions).sum().reset_index()
        grouped = grouped[grouped["total_rule_count"] > 0]
        return grouped.to_dict(orient="records")

    def get_architectures(self, location: str, zones: List) -> str:
        archs = set()
        for zone in zones:
            archs.add(self.arch_mappings.get(location, zone))
        return ", ".join(archs)

    def get_decryption_reporting(self) -> Dict:
        """Collect decryption policy attributes for note on heatmap summary page.

        For policies with action of 'decrypt', collect the count of rules by type.
        For policies with action of 'no-decrypt', collect the categories.
        """
        decryption_policies = self.model_manager().get("decryption_rule")
        decryption_reporting = {
            "rule_count": len(decryption_policies),
            "decrypt": defaultdict(int),
            "no-decrypt": set(),
        }
        for policy in decryption_policies:
            if policy.action == "decrypt":
                decryption_reporting["decrypt"][policy.rule_type] += 1
            else:  # no-decrypt
                decryption_reporting["no-decrypt"].update(policy.categories)
        if "any" in decryption_reporting["no-decrypt"]:
            decryption_reporting["no-decrypt"].remove("any")
        return decryption_reporting

    def get_deployment_update_schedules(self) -> List[Dict]:
        """Parses deployment update schedules."""
        schedules = []
        if not self.model_manager().tree.panorama:
            return schedules

        for update in self.model_manager().get("device_deployment_dynamic_updates"):
            schedules.append({"name": update.name, **asdict(update.schedule)})

        return schedules

    def get_local_update_schedules(self) -> List[Dict]:
        """Parses local update schedules."""
        schedules = []

        local_dynamic_updates = (
            self.model_manager().get("dynamic_updates").find(template_name=None)
        )
        if local_dynamic_updates is None:
            return schedules

        for update_name, update_data in local_dynamic_updates.update_types.items():
            if update_data is None:
                continue
            info = {
                "type": update_name,
                "recurrence": update_data.recurrence,
                "action": update_data.action,
            }
            schedules.append(info)

        return schedules

    def convert_check_name(self, name):
        #  helper function to convert all names in format wanted to map
        return f"{'_'.join(name.split(' ')).lower()}_bp_check"

    def deep_get(self, dictionary, keys, default=None):
        # helper function to fetch data from nested dictionary.
        # https://stackoverflow.com/questions/25833613/python-safe-method-to-get-value-of-nested-dictionary
        def _reducer(d, key):
            if isinstance(d, dict):
                return d.get(key, default)
            return default

        return reduce(_reducer, keys, dictionary)

    def map_vsys(
        self,
        bp_checks_result,
        model_manager_ref,
        bp_check_name,
        location_and_profile_name,
    ):
        # helper function to map vsys with bp result for display.
        location, card_profile = location_and_profile_name.split(",")
        if card_profile == "None":
            # handle scenarios where (vsys1,None) has been passed. Here profile is None so could not fetch data
            return None
        # needs to convert all element of ancestors to string since vsys1 was element unicode result.
        ancestors = list(map(str, model_manager_ref.tree.ancestors[location]))
        test = bp_checks_result.get(location_and_profile_name, "location_not_found")
        if test == "location_not_found":
            ancestors.remove(location)
            for val in ancestors:
                new_location_and_profile_name = f"{val},{card_profile}"
                result = self.calculate_result(
                    bp_checks_result=bp_checks_result,
                    location_and_profile_name=new_location_and_profile_name,
                    bp_check_name=bp_check_name,
                )
                if result:
                    return result
        else:
            result = self.calculate_result(
                bp_checks_result=bp_checks_result,
                location_and_profile_name=location_and_profile_name,
                bp_check_name=bp_check_name,
            )
            if result:
                return result
        return "Not Applicable"

    def calculate_result(
        self, bp_checks_result, location_and_profile_name, bp_check_name
    ):
        # helper function for map_vsys to fetch result
        result = self.deep_get(
            bp_checks_result, [location_and_profile_name, bp_check_name], default=False,
        )
        if result:
            return result
        else:
            return False

    def get_all_bp_checks(self):
        # fetch all bp check results for objects -> security profiles tab
        mapping = {
            "antivirus_profile": "av",
            "anti_spyware_profile": "spyware",
            "vulnerability_protection_profile": "vuln",
            "url_filtering_profile": "url_filtering",
            "file_blocking_profile": "file_blocking",
            "wildfire_analysis_profile": "wildfire",
            "dos_protection_profile": "dos_protection",
        }
        bp_manager_analyzer_lookup = (
            self.adoption_manager().bp_manager().analyzer_results_lookup
        )

        result = {}
        for profile_name, profile_mapping in mapping.items():
            data = bp_manager_analyzer_lookup[profile_name]
            result[profile_name] = {}
            for bp_check_result in data:
                result[profile_name][
                    f'{bp_check_result.configuration["location"]},{bp_check_result.configuration["name"]}'
                ] = {}
                checks = bp_check_result.checks
                for check in checks:
                    if isinstance(check, BestPracticeNote):
                        if check.check_id == 206 or check.check_id == 221:
                            result[profile_name][
                                f'{bp_check_result.configuration["location"]},{bp_check_result.configuration["name"]}'
                            ][
                                f"{self.convert_check_name(check.check_name)}_for_{profile_mapping}"
                            ] = f"note{f'(warning)' if check.check_severity != 'Info' else ''}"
                        else:
                            result[profile_name][
                                f'{bp_check_result.configuration["location"]},{bp_check_result.configuration["name"]}'
                            ][
                                self.convert_check_name(check.check_name)
                            ] = f"note{f'(warning)' if check.check_severity != 'Info' else ''}"
                    else:
                        result[profile_name][
                            f'{bp_check_result.configuration["location"]},{bp_check_result.configuration["name"]}'
                        ][self.convert_check_name(check.check_name)] = (
                            "pass" if check.check_passed else "fail"
                        )
        return result
