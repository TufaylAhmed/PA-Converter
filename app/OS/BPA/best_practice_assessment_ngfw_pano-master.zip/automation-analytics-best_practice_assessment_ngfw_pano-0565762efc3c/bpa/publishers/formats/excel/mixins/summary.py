import numpy as np
import pandas as pd

from bpa.publishers.formats.excel.constants import (
    CATEGORY_COLUMNS,
    BG_BLUE,
    FONT_WHITE,
    TABLE_STYLE_LIGHT,
    TEXT_REMEDIATION_EIGHT_HOURS,
    TEXT_REMEDIATION_MINUTES,
)


class SummaryMixin:
    """Summary processing utilities"""

    # NOTE: Entrypoint for writing data
    def write_summary(self):
        """Store Summary pandas dataframe"""
        # Step 1: Build worksheet data
        total_summary = pd.DataFrame()
        for sheet in self.combined_data.keys():
            sheet_data = pd.DataFrame(
                self.combined_data[sheet], columns=CATEGORY_COLUMNS
            )
            sheet_data = sheet_data.fillna("")
            sheet_data[TEXT_REMEDIATION_MINUTES] = pd.to_numeric(
                sheet_data[TEXT_REMEDIATION_MINUTES], errors="coerce"
            )
            summary = (
                sheet_data.groupby("Feature")
                .agg({TEXT_REMEDIATION_MINUTES: np.sum, "Complexity": len})
                .reset_index()
            )
            summary[TEXT_REMEDIATION_EIGHT_HOURS] = (
                summary[TEXT_REMEDIATION_MINUTES] / 480
            )
            summary.drop(TEXT_REMEDIATION_MINUTES, axis=1, inplace=True)
            summary.rename(columns={"Complexity": "Failed Checks"}, inplace=True)
            # summary.rename(columns={"Control Category": "NIST Security Controls"}, inplace=True)
            summary = summary.round(2)
            total_summary = total_summary.append(summary)

        self.grand_total["Grand Total Label"] = "Total"
        self.grand_total["Failed Checks Total"] = "=SUBTOTAL(9, Summary[Failed Checks])"
        self.grand_total[
            "Remediation Total"
        ] = "=SUBTOTAL(9, Summary[Remediation Effort (8 Hour Work Days)])"
        self.grand_total["Grand Total Row Number"] = total_summary.shape[0] + 1

        total_summary.dropna(axis="columns", how="all", inplace=True)

        # Step 2: Create worksheet in workbook
        summary_sheet = self.workbook.add_worksheet("Summary")
        summary_sheet.add_table(
            first_row=0,
            first_col=0,
            last_row=total_summary.shape[0],
            last_col=(total_summary.shape[1] - 1),
            options={
                "columns": [{"header": col} for col in total_summary.columns],
                "data": total_summary.values,
                "style": TABLE_STYLE_LIGHT,
                "name": "Summary",
            },
        )

        # Step 3: Decorate created worksheet
        self.write_grand_total_summary(summary_sheet)
        self.set_column_widths(total_summary, summary_sheet)

    def write_grand_total_summary(self, summary_sheet):
        """Writes totals row which should be last row in Summary Worksheet, applies formatting also."""
        cell_format = self.workbook.add_format(
            {"bold": True, "font_color": FONT_WHITE, "bg_color": BG_BLUE}
        )
        summary_sheet.write(
            self.grand_total["Grand Total Row Number"],
            0,
            self.grand_total["Grand Total Label"],
            cell_format,
        )
        summary_sheet.write(
            self.grand_total["Grand Total Row Number"],
            1,
            self.grand_total["Failed Checks Total"],
            cell_format,
        )
        summary_sheet.write(
            self.grand_total["Grand Total Row Number"],
            2,
            self.grand_total["Remediation Total"],
            cell_format,
        )
