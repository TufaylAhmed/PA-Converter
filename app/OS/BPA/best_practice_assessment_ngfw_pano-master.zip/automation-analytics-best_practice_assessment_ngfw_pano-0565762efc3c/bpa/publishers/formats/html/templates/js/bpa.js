// JavaScript for Best Practice Assessment Report

// Apply conditional formatting to BPA-specific tables
function bpa_conditional_formatting() {
  $('table#bpa_trend_table tr td:not(:first-child), #bpa_mapping_table tr td:nth-last-child(2), #bpa_mapping_table tfoot th:nth-last-child(2), #bpa_mapping_table tr td:nth-last-child(3), #bpa_mapping_table tfoot th:nth-last-child(3)').each(function() {
    var val = $(this).text();
   
    if (isNaN(val) || val === "-") {
        //we don't want the header text to have conditional formatting applied,
        // so clear out any conditional formatting
        $(this).css('background-color', '');
    }
    else {
        //if it's a valid number, coerce to float for conditional formatting
        val = parseFloat(val);
        //coerce val to float between 0 and 1
        val = Math.min(val, 100)/100
        //generate the background color
        var hue = (val*120).toString(10);
        //hsl = hue, saturation, and lightness
        var color = ["hsl(",hue,",100%,68%)"].join("");
        $(this).css('background-color', color);

    }
  });
}

bpa_conditional_formatting();

//Apply conditional formatting to BPA mapping definitions table whenever it is re-drawn
$('#bpa_mapping_table').on( 'draw.dt', function () {
    bpa_conditional_formatting();
});


// Change table columns depending on whether Panorama or NGFW
let columnDefs = [
  { "title":"Device Group", "name":"vsys", "data":"vsys", "type":"string", "width": '12em' },
  { "title":"Rule Name", "name":"rule_name", "data":"rule_name", "type":"string", "width": '18em' },
  { "title":"Rulebase", "name":"rulebase", "data":"rulebase", "type":"string" },
  { "title":"Rule Enabled", "name":"rule_enabled", "data":"rule_enabled", "type":"string" },
  { "title":"Description Populated", "name":"description_populated", "data":"Description Populated", "type":"string" },
  { "title":"Source/Destination != any/any", "name":"source_dest_any_any", "data":"Source/Destination = any/any", "type":"string" },
  { "title":"Service != any", "name":"service_any", "data":"Service = any", "type":"string" },
  { "title":"Application != any", "name":"application_any", "data":"Application != any", "type":"string" },
  { "title":"APP-ID with Service", "name":"app_id_service", "data":"APP-ID with Service", "type":"string" },
  { "title":"Not Logging at Start of Session", "name":"not_logging_at_start_of_session", "data":"Not Logging at Start of Session", "type":"string" },
  { "title":"Log Forwarding", "name":"log_forwarding", "data":"Log Forwarding", "type":"string" },
  { "title":"Expired Non-Recurring Schedules", "name":"expired_non_recurring_schedules", "data":"Expired Non-Recurring Schedules", "type":"string" },
  { "title":"Disable Server Response Inspection", "name":"disable_server_response_inspection", "data":"Disable Server Response Inspection", "type":"string" }
]
if ({{rule_usage_info_available | tojson }}) {
  // IMP: Adding to list before removing otherwise index position to add after removal will get messy
  columnDefs.splice(4, 0,
    {"title":"Traffic Hit Rule", "name":"traffic_hit", "data":"traffic_hit", "type":"string"});
}
if (!panorama) {
  columnDefs.splice(2, 1); // remove Rulebase
  columnDefs.splice(0, 1); // remove Device Group
}
// set the targets values based on new index
for (var i = columnDefs.length - 1; i >= 0; i--) {
  columnDefs[i]['targets'] = i
}

// Cache the rules table
var security_rules_table = $('table#security_rules_table');

// Function to format exported data
var buttonCommon = {
    exportOptions: {
        format: {
            body: function ( data, row, column, node ) {
                if (data == '<i class="fa fa-times fail" aria-hidden="true"></i>') {
                  return 'fail';
                }else if (data == '<i class="fa fa-check pass" aria-hidden="true"></i>') {
                  return 'pass';
                } else if (data == '<i class="fa fa-window-minimize" aria-hidden="true"></i>'){
                  return '-';
                }else {
                  return data;
                }
            }
        }
    }
};

{{ security_rules }}

// Initialize generic data tables
$('table.datatable').DataTable({
  "scrollY":250,
  "paging": false,
  "lengthChange": false,
  "info": false,
});

// Initialize Security Rule Checks DataTable
security_rules_table.DataTable({
  "columnDefs": columnDefs,
  "data": security_rules,
  "scrollX": true,
  "scrollY":500,
  "scrollCollapse": true, //reduce height if there are only a few rows
  "paging": true,
  "pageLength": 50,
  "lengthChange": false, //disable user page display toggle
  "deferRender": true,
  "processing": true,
  "dom": '<"pull-left"f>rtiB<"pull-left"p>',
  "buttons": [
        $.extend( true, {}, buttonCommon, {
                    extend: 'csv',
                    text: 'Export Data'
                } ),
    ],
  // add footer subtotals for Security Rule Checks
  "footerCallback": function ( row, data, start, end, display ) {
    var api = this.api(), data;
    // looping through the last 9 columns of the table
		for (var col_ix = -9; col_ix < 0; col_ix++) {
      // using the selector-modifier to get the filtered dataset  (so footer totals will change when filtered)
      // https://datatables.net/reference/type/selector-modifier
			let dataset = api.column( col_ix, { search: 'applied' } ).data();
      let numerator = 0, denominator = 0;
      // looping through all rows in the column
      for (var row_ix = dataset.length - 1; row_ix >= 0; row_ix--) {
        if (dataset[row_ix] === '<i class="fa fa-check pass" aria-hidden="true"></i>') {
          numerator++, denominator++;
        } else if (dataset[row_ix] === '<i class="fa fa-times fail" aria-hidden="true"></i>') {
          denominator++;
        }
      }
      // update the HTML
      if (denominator !== 0) {
        let pass = ((numerator / denominator) * 100);
        pass = _.floor(pass, 1);
        $( api.column( col_ix ).footer() ).html(pass + '%');
      }
		}
	},
});


// Apply the bootstrap-select library to our filters
var column_filters = $('.bpa-report select.col-filter');
column_filters.selectpicker({
  liveSearch: true,
  actionsBox: true,
  selectedTextFormat: "count > 1"
});

// If panorama device, programatically load device group values into filter
if (panorama){
  // collect unique values from the datatable column
  let device_group_values = security_rules_table.DataTable().column('vsys:name').data().unique();

  let vsys_filter = $('.bpa-report select[name="vsys"]');
  vsys_filter.append(device_group_values.map(x => `<option value="${x}">${x}</option>`).join(''));

  // force a refresh of the UI after adding the options
  vsys_filter.selectpicker('refresh');
}

// Add event handler to clear filters on rule details tab
$('.bpa-report button.clear-filter').click(
  function() {
    security_rules_table.DataTable().columns().search('').draw();
    $(this).parents('div.well').find('.col-filter').selectpicker('deselectAll');
  }
);

// Add event handler to rule filter apply button
$('.bpa-report button.rule-filter').click(function() {
    //target all of the dropdowns within the card
    $(this).parents('div.well').find('select.col-filter').each(function() {
        // filter name should match datatable column name from columnDefs
        var name = $(this).attr('name');

        //returns all selected options in array
        var selected_options = $(this).val();

        // only proceed on filters with options selected
        if (selected_options != null && selected_options.length !== 0 && selected_options.length !== $(this).children('option').length) {
            let query = selected_options.join('|');
            security_rules_table.DataTable().column(name+':name').search(query, regex=true, smart=false);
        }
    });
    security_rules_table.DataTable().draw();
});

// Add event handler for pass / fail checks, card-filter and card-filter-for-lock.
$('select.card-filter-for-pass-fail, select.card-filter, select.card-filter-for-check').change(function( event ) {
  // get all filterable cards.
  var filterable_cards = $('div#main_content div:visible[id] div.panel:has(span[data-filter])');

  // used store key,value pair of selected filters.
  var filters = {};

  // get id of current page
  var id_of_page = $('div#main_content div:visible[id]').attr('id');

  // iterate over device group and template to get selected value.
  $(this).closest('div.row').find('select.card-filter').each(function() {
    if ($(this).attr('name') === 'vsys_filter') {
      var target_selector = 'vsys';
    }else{
      var target_selector = 'template';
    }
    filters[target_selector] = $(this).val();
  });

  // iterate over bp checks drop down and get selected value.
  $(this).closest('div.row').find('select.card-filter-for-check').each(function() {
    filters['checkname'] = $(this).val();
  });

  // iterate over cehck result drop down and get selected value.
  $(this).closest('div.row').find('select.card-filter-for-pass-fail').each(function() {
    filters['checkresult'] = $(this).val();
  });

   // init variable to count pass and fail values.
  let pass_count = 0;
  let fail_count = 0;

  // iterate over each card.
  filterable_cards.each(function() {
  var show = true; // Start by assuming that the card can be shown

  // temp variable to store checkname and bp result
  var best_practice_check_all = filters['checkname'] === 'all';

  // store bp check results for ex. key = check_name and value = pass or fail.
  var check_mapping = {};

  // get all bp check results objects.
  var mapping_target = $(this).find('i[data-' + 'checkname' + ']');

  // iterate over all bp check objects and store key value pair.
  for (var check in mapping_target.toArray()){
    let check_data = mapping_target[check];
    check_mapping[check_data.dataset.checkname] = check_data.classList[check_data.classList.length - 1];
  }


 // vsys is there or not
 if (filters['vsys'] != 'all' && filters['vsys'] !== $(this).find('span[data-vsys]').data('vsys')){
  show = false;

 }

 // template is there or not
 if (filters['template'] != 'all' && filters['template'] != $(this).find('span[data-template]').data('template')){
  show = false;
 }

 // bp check is there or not
 if (filters['checkname'] != 'all'){
    if (!Object.keys(check_mapping).includes(filters['checkname'])){
      show = false;
    }
 }

 // count logic
 if (show){
    if (best_practice_check_all){
        let total_count = _.countBy(Object.values(check_mapping));
        pass_count += total_count['pass'] || 0;
        fail_count += total_count['fail'] || 0;
  }
  else{
     if (check_mapping[filters['checkname']] === 'fail')
        {
            fail_count += 1;
        }
     else if (check_mapping[filters['checkname']] === 'pass')
        {
            pass_count += 1;
        }
  }
 }

  // pass-fail is there or not
 if (filters['checkresult'] != 'all'){
    if (filters['checkname'] != 'all'){
        if (check_mapping[filters['checkname']] !== filters['checkresult']){
          show = false;
        }
      }

    else if ( ['False','None'].includes($(this).find('span[data-'+filters['checkresult']+']').data(filters['checkresult'])))
    {
      show = false;
    }

 }
  if (show) {
    $(this).show();
  } else {
    $(this).hide();
  }

});
$('span#'+id_of_page+'_pass_sub').html(pass_count);
$('span#'+id_of_page+'_fail_sub').html(fail_count);
});




/////////////////////////////////////////
// JavaScript for BPA Summary view
/////////////////////////////////////////
let bpa_summary = {{ json_dumps(bpa_summary) }};

const bpa_mapping_records = {{ json_dumps(bpa_mapping_records) }};
let bpa_mapping_table = $('#bpa_mapping_table').DataTable( {
        data: bpa_mapping_records,
        columns: [
            { data: "ID" },
            { data: "Title" },
            { data: "Top Nav" },
            { data: "Left Nav" },
            { data: "Rationale", visible: false },
            { title: "Capability", data: "Functionality / Capability" },
            { data: "Class" },
            { data: "Control Category" },
            { title: "CSC Controls", data: "CSCv7 Controls" },
            { // Logic for Passing Checks here
              data: null,
              name: "Passing Occurrence",
               // Use the full data source object for the renderer's source
              // Display NaN values in a nicer way by modifying render logic
              // https://datatables.net/reference/option/columns.render
              render: function ( data, type, row, meta ) {
                let pass_cnt = data['current_pass']
                let total_cnt = data['current_pass'] + data['current_fail']
                if (isNaN(pass_cnt)) {
                  return '-';
                } else {
                  return pass_cnt + " out of " + total_cnt;
                }
              }
            },
            { // Logic for Previous Passing % here
              data: null,
              name: "Previous Passing %",
               // Use the full data source object for the renderer's source
              // Display NaN values in a nicer way by modifying render logic
              // https://datatables.net/reference/option/columns.render
              render: function ( data, type, row, meta ) {
                let pct = _.round((data['previous_pass'] / (data['previous_pass'] + data['previous_fail'])) * 100, 1);
                if (isNaN(pct)) {
                  return '-';
                } else {
                  return pct;
                }
              }
            },
            { // Logic for Passing % here
              data: null,
              name: "Current Passing %",
               // Use the full data source object for the renderer's source
              // Display NaN values in a nicer way by modifying render logic
              // https://datatables.net/reference/option/columns.render
              render: function ( data, type, row, meta ) {
                let pct = _.round((data['current_pass'] / (data['current_pass'] + data['current_fail'])) * 100, 1);
                if (isNaN(pct)) {
                  return '-';
                } else {
                  return pct;
                }
              }
            },
            {data:null,
            name: "Difference",
            // Display NaN values in a nicer way by modifying render logic
              // https://datatables.net/reference/option/columns.render
              render: function ( data, type, row, meta ) {

                let current_pct = _.round((data['current_pass'] / (data['current_pass'] + data['current_fail'])) * 100, 1);
                let previous_pct = _.round((data['previous_pass'] / (data['previous_pass'] + data['previous_fail'])) * 100, 1);
                // when calculating for first time previous values will be None so display '-'
                if (isNaN(previous_pct))
                {
                    return '-';
                }
                // count difference and display upto 2 decimals.
                let difference = _.round(current_pct - previous_pct, 2);
                if (difference > 0.00)
                {
                  return '+ '+difference;
                }
                else if (difference === 0.00)
                {
                  return 0;
                }
                else
                {
                     // Added this line to add space between '-' sign and number.
                    difference = Math.abs(difference);
                    return '- '+difference;
                }
              }
            }
        ],
        dom: 'lftiBpr',
        buttons: [
          {
              extend: 'csv',
              text: 'Export Mappings'
          }
        ],
        "initComplete": function( settings, json ) {
          applyConditionalFormatting('#dg_heatmap_table');
        },
       // https://datatables.net/examples/advanced_init/footer_callback.html
        "footerCallback": function ( row, data, start, end, display ) {
            // get the filtered data
            // https://datatables.net/reference/type/selector-modifier
            let filtered_data = _.values(this.api().rows({filter: 'applied'}).data());
            let previous_pct = count_percentage(filtered_data,'previous_pass','previous_fail');
            let current_pct = count_percentage(filtered_data,'current_pass','current_fail');
            $(this.api().column(10).footer()).text(previous_pct);
            $(this.api().column(11).footer()).text(current_pct);
            // when calculating for first time previous value is None.
            if (isNaN(previous_pct))
            {
                 $(this.api().column(12).footer()).text('-');
            }
            else
            {

                let difference = _.round(current_pct - previous_pct, 2);
                if (difference > 0.00)
                {
                    $(this.api().column(12).footer()).text('+ '+difference);
                }
                else if (difference === 0.00)
                {
                  return $(this.api().column(12).footer()).text(0);
                }
                else
                {

                    difference = Math.abs(difference);
                    $(this.api().column(12).footer()).text('- '+difference);
                }
            }
        },
    } );

function count_percentage(filtered_data,target_pass,target_fail)
{
    // aggregate the metrics
    let pass = 0;
    let fail = 0;
    for (let record of filtered_data) {
      pass += (record[target_pass] || 0);
      fail += (record[target_fail] || 0);
    }

    // calculate the percent
    let pct = _.round(pass / (pass + fail) * 100, 1) || '-';
    return pct;
}
// Fix column widths when first opening left nav
$('a[data-id="bpa_mapping_definitions"]').click(function(){
  bpa_mapping_table.columns.adjust();
});

$('#bpa_mapping_clear_button').click(function(){
  bpa_mapping_table.clear().rows.add(bpa_mapping_records).draw();
  $(this).parents('div.well').find('.col-filter').selectpicker('deselectAll');
});

$('#bpa_mapping_filter_button').click(function(){
  let data = _.cloneDeep(bpa_mapping_records);
  $(this).parents('div.well').find('select.col-filter').each(function() {
        // filter name should match datatable column name from columnDefs
        // returns all selected options in array
        let selected_options = $(this).val();
        if (! _.isEmpty(selected_options)) {
          let name = $(this).attr('name');
          if (name != 'CSC Controls') {
            data = _.filter(data, function(record) {
              return ! _.isEmpty(
                _.intersection(
                  record[name].split(', '),
                  selected_options
                )
              );
            });
          } else {
            data = _.filter(data, function(record) {
              // TODO: Automate record attribute naming
              let record_cscs = String(record["CSCv7 Controls"]).split(", ").map(
                csc => String(Math.floor(csc)
              ));
              return ! _.isEmpty(
                _.intersection(
                  record_cscs,
                  selected_options
                )
              );
            });
          }
        }
  });
  bpa_mapping_table.clear().rows.add(data).draw();
});

function get_color(pct) {
  let val = parseFloat(pct);

  // transform to a value between 0 and 1
  val = Math.min(val, 100)/100

  //generate the background color
  let hue = (val*120).toString(10);

  //hsl = hue, saturation, and lightness
  let color = ["hsl(",hue,",100%,68%)"].join("");

  return color;
}


// handle bug encountered in Chart.js
// charts turn black on hover if the value used to generate a HSL value from get_color
// is not a multiple of 5
// https://stackoverflow.com/a/46339121/614770
function round5(x) { return x%5<3 ? (x%5===0 ? x : Math.floor(x/5)*5) : Math.ceil(x/5)*5 }


function init_chart(chart_id, bar_values, metric_deltas, labels, tooltips) {
  let colors = []
  for(var i = 0; i < bar_values.length; i++){
     colors[i] = get_color(round5(bar_values[i]));
  }

  let ctx = document.getElementById(chart_id).getContext('2d');
  let options = {
      scales: {
          yAxes: [{
              ticks: {
                  beginAtZero:true
              },
              gridLines: {
                  display: false,
              },
              maxBarThickness: 50,
          }],
          xAxes: [{
              gridLines: {
                  display: false,
                  drawBorder: false,
              },
              ticks: {
                  // remove x axis ticks
                  callback: function(value, index, values) {
                      return null;
                  },
                  max: 100,
                  min: 0,
              },
          }],
      },
      title: {
          display: false,
      },
      legend: {
          display: false,
      },
      layout: {
          padding: {
              top: -40,
              bottom: -50,
          }
      },
      tooltips: {
          callbacks: {},
      },
      plugins: {
          datalabels: {
              // set anchor and alignment positions based on value
              anchor: function(context) {
                  return context.dataset.data[context.dataIndex] <= 35 ? 'end' : 'center';
              },
              align: function(context) {
                  return context.dataset.data[context.dataIndex] <= 35 ? 'end' : 'center';
              },
             // add % and metric change values to label
             formatter: function(value, context) {
              return context.dataset.data[context.dataIndex] + '% (' + metric_deltas[context.dataIndex] + ')';
              }
        }
     },
  };

  if (tooltips !== undefined) {
    // add check information to tooltip
    options['tooltips'].callbacks.afterLabel = function(tooltipItem, data) {
      return tooltips[tooltipItem.index] + ' checks';
    }
  }

  let chart = new Chart(ctx, {
      type: 'horizontalBar',
      data: {
          labels: labels,
          datasets: [{
              data: bar_values,
              backgroundColor: colors,
              borderWidth: 1
          }]
      },
      options: options,
  });
}


// init Functionality / Capability chart
//const func_capability_labels = [];
//const func_capability_data = [];
//const func_capability_change = [];
//const func_capability_tooltip_data = [];
//if (bpa_summary){
//  for (const [label, values] of _.toPairs(bpa_summary['Functionality / Capability'])) {
//  func_capability_data.push(values['percent']);
//  func_capability_change.push(values['change']);
//  func_capability_tooltip_data.push(`(${values['passing']}/${values['total']})`)
//  func_capability_labels.push(label);
//}
//init_chart("func-capability-chart", func_capability_data, func_capability_change, func_capability_labels, func_capability_tooltip_data);
//
//}



//////////////
// Gauge logic

const gauge_options = {
  angle: 0.15, // The span of the gauge arc
  lineWidth: 0.44, // The line thickness
  radiusScale: 1, // Relative radius
  pointer: {
    length: 0.6, // // Relative to gauge radius
    strokeWidth: 0.035, // The thickness
    color: '#000000' // Fill color
  },
  limitMax: false,     // If false, max value increases automatically if value > maxValue
  limitMin: false,     // If true, the min value of the gauge will be fixed
  // colorStart: '#6FADCF',   // Colors
  // colorStop: '#8FC0DA',    // just experiment with them
  strokeColor: '#E0E0E0',  // to see which ones work best for you
  generateGradient: true,
  highDpiSupport: true,     // High resolution support
  percentColors: [[0.0, "#FF4C38" ], [0.50, "#FFFF38"], [1.0, "#38FF38"]],
};

function init_gauge(gauge_id, value, label_id = `${gauge_id}-val`) {
  let target = document.getElementById(gauge_id); // your canvas element
  // handle a bug with gauge.js where canvas width and height are 0 when hidden by bootstrap
  // https://github.com/bernii/gauge.js/issues/149
  target.width = 120;
  target.height = 85;
  let gauge = new Gauge(target).setOptions(gauge_options); // create sexy gauge!
  gauge.maxValue = 100; // set max gauge value
  gauge.setMinValue(0);  // Prefer setter over gauge.minValue = 0
  gauge.animationSpeed = 20; // set animation speed (32 is default value)
  gauge.setTextField(document.getElementById(label_id));
  gauge.set(value); // set actual value
}


// init Control Category Summary chart and init Functionality / Capability chart
const control_category_data = [];
const control_category_change = [];
const control_category_labels = [];
const control_category_tooltip_data = [];
const func_capability_labels = [];
const func_capability_data = [];
const func_capability_change = [];
const func_capability_tooltip_data = [];
if (bpa_summary)
{
  for (const [category, values] of _.toPairs(bpa_summary['Control Category'])) {
  control_category_data.push(values['percent']);
  control_category_change.push(values['change']);
  control_category_tooltip_data.push(`(${values['passing']}/${values['total']})`)
  control_category_labels.push(category);
}
  for (const [label, values] of _.toPairs(bpa_summary['Functionality / Capability'])) {
  func_capability_data.push(values['percent']);
  func_capability_change.push(values['change']);
  func_capability_tooltip_data.push(`(${values['passing']}/${values['total']})`)
  func_capability_labels.push(label);
}
init_chart("func-capability-chart", func_capability_data, func_capability_change, func_capability_labels, func_capability_tooltip_data);
init_chart("nist_security_controls_chart", control_category_data, control_category_change, control_category_labels, control_category_tooltip_data);

}


let bpa_gauges_loaded = false;
function load_bpa_gauges() {
  if (bpa_summary){
    if (bpa_gauges_loaded == false) {
    // init Class Summary gauges
    for (const gauge_id of ['technical', 'operational', 'management']) {
      let gauge_value = bpa_summary["Class"][_.startCase(gauge_id)]['percent'];
      init_gauge(gauge_id, gauge_value)
    }

    // init CIS Critical Security Controls gauges
    for (const csc of {{ json_dumps(sorted_csc_keys) }}) {
      let gauge_id = `csc-${csc}-gauge`
      let label_id = `csc-${csc}-val`
      let gauge_value = bpa_summary["CSC Controls"][csc]['percent'];
      init_gauge(gauge_id, gauge_value, label_id);
    }
  }
    bpa_gauges_loaded = true;
  }
}



// add conditional formatting to percent change values
$('span.pct-change').each(
  function(){
    if (_.startsWith($(this).text(), '(-')) {
      $(this).addClass('check-fail');
    } else if (_.startsWith($(this).text(), '(+')) {
      $(this).addClass('check-pass');
    }
  }
);

