import pandas as pd

from bpa.publishers.formats.excel.constants import (
    CATEGORY_CATEGORIES,
    CATEGORY_COLUMNS,
    TEXT_EMPTY,
    PROGRESS_OPTIONS,
    STATUS_NOT_STARTED,
    TABLE_STYLE_LIGHT,
    TEXT_CHECK_ID,
    TEXT_TEMPLATE,
)


class CategoryMixin:
    """Category processing utilities"""

    # NOTE: Entrypoint for writing data
    def write_worksheets(self):
        """Store and format category data as pandas dataframe then convert to excel"""
        for sheet_key in CATEGORY_CATEGORIES:
            self.write_worksheet(sheet_key)

    def write_worksheet(self, sheet_key):
        if sheet_key not in self.combined_data.keys():
            return

        # Step 1: Build worksheet data
        sheet_data = pd.DataFrame(
            self.combined_data[sheet_key], columns=self.get_columns(sheet_key)
        )
        sheet_data.rename(
            columns={"Control Category": "NIST Security Controls"}, inplace=True
        )
        sheet_data = sheet_data.fillna(TEXT_EMPTY)
        sheet_data.dropna(axis="columns", how="all", inplace=True)
        sheet_data["Status"] = STATUS_NOT_STARTED
        sheet_data["Notes"] = TEXT_EMPTY

        # Step 2: Create worksheet in workbook
        worksheet = self.workbook.add_worksheet(sheet_key.capitalize())
        worksheet.add_table(
            first_row=0,
            first_col=0,
            last_row=sheet_data.shape[0],
            last_col=(sheet_data.shape[1] - 1),
            options={
                "columns": [{"header": col} for col in sheet_data.columns],
                "data": sheet_data.values,
                "style": TABLE_STYLE_LIGHT,
                "name": sheet_key.capitalize(),
            },
        )

        # Step 3: Decorate created worksheet
        self.add_data_validation(sheet_data, worksheet)
        if self.docs_map and len(self.docs_map) > 0:
            self.add_check_links(sheet_data, worksheet)
        self.set_column_widths(sheet_data, worksheet)

    def get_columns(self, sheet_key):
        """Get applicable columns for worksheet."""
        new_columns = list(CATEGORY_COLUMNS)
        if sheet_key in {"policies", "objects", "panorama"}:
            new_columns.remove(TEXT_TEMPLATE)
        elif sheet_key in {"device", "network"}:
            if self.bp_manager().model_manager().tree.ngfw:
                new_columns.remove(TEXT_TEMPLATE)
        if sheet_key == "panorama":
            new_columns.remove("Location")
        return new_columns

    def add_data_validation(self, sheet_data, worksheet):
        """Add data validation to *Status* column of a given worksheet."""
        target_column = sheet_data.columns.get_loc("Status")
        worksheet.data_validation(
            first_row=1,
            first_col=target_column,
            last_row=sheet_data.shape[0],
            last_col=target_column,
            options={
                "validate": "list",
                "source": PROGRESS_OPTIONS,
                "error_title": "Invalid Status!",
                "error_message": "You must choose from one of the given statuses.",
            },
        )

    def add_check_links(self, sheet_data, worksheet):
        """Link Check IDs in a given worksheet to the related row in the Documentation worksheet.

        Data in the Documentation worksheet is sorted by ID in ascending order, so we can link to
        the row in the Documentation worksheet with index of Check ID + 1.

        Args:
            sheet_data: pandas dataframe
            worksheet: xlsxwriter worksheet object
        """
        self.build_link_locations(self.docs_df, sheet_data)
        self.get_documentation_url(sheet_data, worksheet)

    def build_link_locations(self, doc_worksheet, sheet_data):
        """Build Check ID links map from a given worksheet to the related row in the Documentation worksheet.

        This dictionary has keys of Check IDs and values are the row in the Documentation worksheet
        that Check ID's documentation is located.

        Args:
            doc_worksheet: pandas dataframe of Documentation data
            sheet_data: pandas dataframe
        """
        for check_index, check_row in sheet_data.iterrows():
            try:
                if check_row[TEXT_CHECK_ID] not in self.check_doc_location:
                    check_id = str(check_row[TEXT_CHECK_ID])
                    if check_id.isdigit():
                        doc_row = (
                            doc_worksheet.query("ID == %s" % check_id).index[0] + 1
                        )
                        self.check_doc_location[check_row[TEXT_CHECK_ID]] = doc_row
            except IndexError:  # Docs don't exist for this Check ID
                pass

    def get_documentation_url(self, sheet_data, worksheet):
        """Get Documentation URLs to link to Check IDS

        This function actualy writes the URL links for linking a Worksheet's Check ID to
        the correct row of the Documentation worksheet.

        Args:
            sheet_data: pandas dataframe
            worksheet: xlsxwriter worksheet object
        """
        target_column = sheet_data.columns.get_loc(TEXT_CHECK_ID)
        for index, check_id in sheet_data[TEXT_CHECK_ID].iteritems():
            try:
                doc_sheet_row = self.check_doc_location[check_id]
            # When local documentation DB not in-sync with production documentation DB, you get key errors, just skip (continue)
            except KeyError:
                continue
            target_row = index + 1
            worksheet.write_url(
                row=target_row,
                col=target_column,
                url="internal:Documentation!A{}".format(doc_sheet_row + 1),
                tip="View Documentation",
            )
            # Need to re-write the cell as a number to avoid *Number Stored as Text* error
            worksheet.write_number(
                row=target_row,
                col=target_column,
                number=check_id,
                cell_format=self.link_format,
            )
