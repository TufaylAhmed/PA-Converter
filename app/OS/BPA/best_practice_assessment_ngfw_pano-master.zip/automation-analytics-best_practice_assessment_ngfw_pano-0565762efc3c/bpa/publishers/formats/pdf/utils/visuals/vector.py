import os
from tempfile import NamedTemporaryFile

from svglib.svglib import svg2rlg


# https://www.blog.pythonlibrary.org/2018/04/12/adding-svg-files-in-reportlab/
def scale_img(drawing, scaling_factor: float):
    """Scale reportlab Drawing object with same aspect ratio."""
    scaling_x = scaling_y = scaling_factor
    drawing.width = drawing.minWidth() * scaling_x
    drawing.height = drawing.height * scaling_y
    drawing.scale(scaling_x, scaling_y)
    return drawing


# https://stackoverflow.com/questions/6416782/what-is-namedtemporaryfile-useful-for-on-windows
# https://codeyarns.com/2015/07/29/how-to-remove-padding-around-plot-in-matplotlib/
def build_svg(fig, scaling_factor: float = 0.6):
    """Build and return SVG image as reportlab Drawing object."""
    temp = NamedTemporaryFile(delete=False)
    fig.savefig(
        fname=temp.name,
        format="svg",
        transparent=True,
        bbox_inches="tight",
        pad_inches=0,
    )
    img = scale_img(svg2rlg(temp.name), scaling_factor=scaling_factor)
    temp.close()
    os.remove(temp.name)
    return img
