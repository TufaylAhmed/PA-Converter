import json

from dataclasses import asdict

from bpa.publishers.base_publisher import BasePublisher


class AdoptionPublisher(BasePublisher):
    """Publishes JSON output"""

    def __init__(self, publisher_manager):
        super().__init__(publisher_manager)

    def process(self):
        self.output = []
        rule_results = self.adoption_manager().get()
        for rule_result in rule_results:
            self.output.append(asdict(rule_result))

    def publish(self) -> bytes:
        return bytes(json.dumps(self.output), encoding="utf-8")
