from reportlab.platypus import Image


class ExternalLinkImage(Image):
    """Image with external link."""

    def __init__(self, *args, **kwargs):
        self.hyperlink = kwargs.pop("hyperlink", None)
        super().__init__(*args, **kwargs)

    def drawOn(self, canvas, x, y, _sW=0):
        if self.hyperlink:
            x1 = self._hAlignAdjust(x, _sW)
            y1 = y
            x2 = x1 + self._width
            y2 = y1 + self._height
            canvas.linkURL(
                url=self.hyperlink,
                rect=(x1, y1, x2, y2),
                thickness=0,
                relative=1,
                kind="URI",
            )
        super().drawOn(canvas, x, y, _sW)
