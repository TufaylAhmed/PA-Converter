import os


# Establish core directories
pkg_path = os.path.abspath(os.path.dirname(__file__))
fonts_path = os.path.join(pkg_path, "fonts")
images_path = os.path.join(pkg_path, "images")
data_path = os.path.join(pkg_path, "data")
sample_json_path = os.path.join(data_path, "sample_summary.json")
