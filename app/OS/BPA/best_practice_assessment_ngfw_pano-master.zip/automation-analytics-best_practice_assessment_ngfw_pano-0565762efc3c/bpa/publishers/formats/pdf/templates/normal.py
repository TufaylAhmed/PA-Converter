from reportlab.lib.units import inch
from reportlab.platypus import BaseDocTemplate, Paragraph, PageTemplate, Frame

from bpa.publishers.formats.pdf.constants import FONT_LATO_REGULAR
from bpa.publishers.formats.pdf.utils.content import build_link


class NormalTemplate(PageTemplate):
    """Define normal frame"""

    def __init__(self, id: str, doc: BaseDocTemplate):
        _dx, _dy = doc.leftMargin, doc.bottomMargin
        _dw, _dh = doc.width, doc.height
        frame = Frame(_dx, _dy, _dw, _dh, id=id)
        super().__init__(id=id, frames=[frame], onPage=NormalProcessor())


class NormalProcessor:
    """Process normal layout"""

    def __init__(self):
        self.baseOffset = None

    @staticmethod
    def get_line_width(p: Paragraph) -> float:
        """Return line width of first line."""
        return p.getActualLineWidths0()[0]

    def handle_background(self, canvas, doc: BaseDocTemplate):
        """Handle header and footer background."""
        width, height = doc.pagesize
        canvas.setLineWidth(doc.line_light)
        canvas.setStrokeColorRGB(*doc.color_grey)
        canvas.setFillColorRGB(*doc.color_grey)
        canvas.rect(0, height - 50, width, 50, fill=1)
        canvas.setStrokeColorRGB(*doc.color_grey)
        canvas.setFillColorRGB(*doc.color_grey)
        canvas.rect(0, 0, width, 50, fill=1)

    def handle_header_logo(self, canvas, doc: BaseDocTemplate):
        """Handle header logo."""
        width, height = doc.pagesize
        doc.logo.wrap(width, height)
        doc.logo.drawOn(canvas, 10, height - 42)

    def handle_header_line(self, canvas, doc: BaseDocTemplate):
        """Handle header line."""
        width, height = doc.pagesize
        canvas.setLineWidth(doc.line_heavy)
        canvas.setStrokeColorRGB(*doc.color_white)
        line_hi = height - 15
        line_lo = height - 35
        canvas.line(self.baseOffset, line_hi, self.baseOffset, line_lo)

    def handle_header_nav(self, canvas, doc: BaseDocTemplate):
        """Handle header navigation."""
        width, height = doc.pagesize
        canvas.setLineWidth(doc.line_medium)
        canvas.setStrokeColorRGB(*doc.color_white)
        link_offset = doc.leftMargin + doc.width * 0.29
        text_offset = height - 33
        line_hi = height - 23
        line_lo = height - 33

        # NOTE: Re-configure if link text changes
        _t_offset = 103.0
        _l_offset = None

        # NOTE: Draws nav links one-by-one, recording width of previous link
        # in order to render current link at a new starting position.
        _appendix = doc.header_nav[-1][0]
        for content, uri in doc.header_nav:
            link = build_link(content=content, uri=uri, font_size=8, font_color="white")
            link.wrap(width, height)
            link.drawOn(canvas, link_offset + _t_offset, text_offset)
            if content == _appendix:
                continue
            _l_offset = _t_offset + self.get_line_width(link) + 5
            canvas.line(
                link_offset + _l_offset, line_hi, link_offset + _l_offset, line_lo
            )
            _t_offset = _l_offset + 5

    def handle_header_text(self, canvas, doc: BaseDocTemplate):
        """Handle header text."""
        width, height = doc.pagesize
        canvas.setFillColorRGB(*doc.color_white)
        canvas.setFont(FONT_LATO_REGULAR, 12)
        canvas.drawString(self.baseOffset + 10, height - 30, doc["title"])

    def handle_footer_text(self, canvas, doc: BaseDocTemplate):
        """Handle footer text."""
        width, height = doc.pagesize
        canvas.setFillColorRGB(*doc.color_white)
        canvas.setFont(FONT_LATO_REGULAR, 7)
        _f_start = 35
        _f_left = 15

        content = {
            "version": f'Version: {doc["version"]}',
            "device": f'Device: {doc["device"]}',
            "prepared": f'Generated On: {doc["time"]}',
            "page": f"Page {str(canvas.getPageNumber()).zfill(2)}",
        }

        canvas.drawString(_f_left, _f_start, content["prepared"])
        canvas.drawString(_f_left, _f_start - 10, content["device"])
        canvas.drawString(_f_left, _f_start - 20, content["version"])
        canvas.drawRightString(doc.width + 1.35 * inch, _f_start, content["page"])

    def store_dimensions(self, doc: BaseDocTemplate):
        """Store cross-cutting dimension info."""
        self.baseOffset = doc.leftMargin + 7

    def __call__(self, canvas, doc: BaseDocTemplate):
        """Establish header and footer contexts."""
        canvas.saveState()
        self.store_dimensions(doc)
        self.handle_background(canvas, doc)
        self.handle_header_logo(canvas, doc)
        self.handle_header_line(canvas, doc)
        self.handle_header_nav(canvas, doc)
        self.handle_header_text(canvas, doc)
        self.handle_footer_text(canvas, doc)
        canvas.restoreState()
