from copy import deepcopy
from datetime import datetime
from io import BytesIO

import pytz
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch

from bpa import __version__ as bpa_version
from bpa.models.utils.masking import mask_general
from bpa.publishers.base_publisher import BasePublisher
from bpa.publishers.formats.pdf.content import chapters, intro
from bpa.publishers.formats.pdf.templates.document import CustomDocTemplate
from bpa.publishers.formats.pdf.templates.front import FrontCoverTemplate
from bpa.publishers.formats.pdf.templates.normal import NormalTemplate
from bpa.publishers.formats.pdf.utils.timing import get_time


class ExecutiveSummaryPublisher(BasePublisher):
    """Publishes PDF output.

    Attributes:
        serial_number: Serial number.
        system_info: System information.
        license_info: License information.
        summary_data: Summary data.
        arch_mappings: Architecture mappings.
        industry_attrs: Industry attributes.
    """

    def _init_params(self, **kwargs):
        self.serial_number = kwargs.get("serial_number")
        self.system_info = kwargs.get("system_info")
        self.license_info = kwargs.get("license_info")
        self.summary_data = kwargs.get("summary_data")
        self.arch_mappings = kwargs.get("arch_mappings")
        self.industry_attrs = kwargs.get("industry_attrs")

    def __init__(self, publisher_manager, **kwargs):
        """Initialization logic.

        NOTE: Other sub-systems may interact directly with this publisher.
        Hence the kwargs parameter. In those cases, the publisher_manager
        should be set to None as it would not be useful.
        """
        self.output = BytesIO()

        if publisher_manager:
            model_manager = publisher_manager.bp_manager().model_manager()
        else:
            model_manager = None

        self._init_params(**kwargs)

        if self.serial_number is None and model_manager:
            self.serial_number = model_manager.system_info.get("serial")

        if self.system_info is None and model_manager:
            self.system_info = model_manager.system_info.copy()

        if self.license_info is None and model_manager:
            self.license_info = model_manager.license_info.to_json()

        self.publisher_manager = publisher_manager

    def process(self):
        """Process data."""
        doc = CustomDocTemplate(
            self.output,
            pagesize=letter,
            rightMargin=inch,
            leftMargin=inch,
            topMargin=inch,
            bottomMargin=inch,
        )

        # Create data collector
        Story = []

        # Build front cover and TOC
        intro.front_cover(Story)
        intro.start_point(Story)

        # make this as first step so that get headers dynamically.
        # Retrieve summary data
        # TODO: Refactor the code so that the summary data is not coming from another publisher
        content = self.summary_data
        if content is None:
            pub_mgr = self.publisher_manager
            pub_mgr.get(
                "report",
                arch_mappings=self.arch_mappings,
                industry_attrs=self.industry_attrs,
            )
            content = pub_mgr.get_publisher("report").summary_data

        content_copy = deepcopy(content)
        bp = content_copy["best_practice_summary"]
        adoption = content_copy["adoption_summary"]

        # Build content for each chapter
        if bp is not None:
            chapters.chapter_bpa(
                Story=Story, data=bp, set_headers_nav=doc.set_headers_nav
            )
        chapters.chapter_adoption(
            Story=Story, data=adoption, set_headers_nav=doc.set_headers_nav
        )
        chapters.chapter_decryption(
            Story=Story, data=adoption, set_headers_nav=doc.set_headers_nav
        )
        chapters.chapter_appendix(Story=Story, set_headers_nav=doc.set_headers_nav)

        # Build context for document instance
        utc_now = pytz.utc.localize(datetime.utcnow())
        pst_now = utc_now.astimezone(pytz.timezone("America/Los_Angeles"))
        masked_serial = mask_general(self.serial_number)
        doc.updateMeta(
            title="BPA Executive Summary",
            version=bpa_version,
            device=f'{self.system_info["hostname"]} ({masked_serial})',
            time=get_time(pst_now),
        )

        # Build page templates
        ntemplate = NormalTemplate(id="Normal", doc=doc)
        ftemplate = FrontCoverTemplate(id="Cover", doc=doc)
        doc.addPageTemplates([ftemplate, ntemplate])

        # Save file contents to bytes
        doc.multiBuild(Story)

    def publish(self):
        """Publish data."""
        return self.output.getvalue()
