import json
import os
from typing import Callable, Dict, List

from bpa.publishers.formats.pdf import data_path


def get_metabuild(metatype: str) -> Callable:
    """Build a metadata helper."""
    metapath = os.path.join(data_path, f"{metatype}_meta.json")
    with open(metapath, "r") as f:
        metadata = json.load(f)

    def metabuild(key):
        return metadata.get(key)

    return metabuild


def get_appendix(apptype: str) -> List[Dict]:
    """Retrieve appendix data."""
    apppath = os.path.join(data_path, f"{apptype}_appendix.json")
    with open(apppath, "r") as f:
        appdata = json.load(f)
    return appdata


def get_decryption() -> Dict:
    """Retrieve decryption data."""
    decpath = os.path.join(data_path, "decrypt_meta.json")
    with open(decpath, "r") as f:
        decdata = json.load(f)
    return decdata


def get_csc_meta() -> Dict:
    """Simple edge case where get_metabuild is not enough."""
    metapath = os.path.join(data_path, f"csc_meta.json")
    with open(metapath, "r") as f:
        return json.load(f)
