# HTML generation

This is where all the HTML output is being generated.

## Notes

Some noteworthy points:

`templates/` holds the HTML templates for rendering.

1. `best_practice_assessment.py` renders BPA-specific logic
2. `security_policy_capability_adotpion.py` renders SPCA-specific logic
3. `html.py` combines the two together using `template.html`

Common utilities exist to assist with encoding and other concerns.
