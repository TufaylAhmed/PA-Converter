// this object is responsible for maintaining state
const state = {
	'active_report': 'heatmap-report',
	'heatmap-report': {
		'active_top_nav': 'info',
		'active_left_nav': 'heatmap_left_nav',
	},
	'bpa-report': {
		'active_top_nav': 'info',
		'active_left_nav': 'info_left_nav',
	},
};

// controls which report is visible
$('.report-toggle').click(
	function() {
		let current_report = $(this).data('current-report');
		let next_report = current_report == 'heatmap-report' ? 'bpa-report' : 'heatmap-report';
		$(`.${current_report}`).addClass('hidden');
		$(`.${next_report}`).removeClass('hidden');
		state.active_report = next_report;
		if (next_report == 'bpa-report') {
			load_bpa_gauges()
		}
	}
);

// show info left nav by default
var bpa_current_active = 'info_left_nav';


// controls which options are shown on the left nav
function show_left_nav(top_nav){
	// hide current center content
	$('.bpa-report div#' + $('#' + bpa_current_active + ' li.active').children('a').data('id')).hide();

	// hide the currently active left nav
	$('.bpa-report ul#' + bpa_current_active).hide();

	// un-hide the selected left nav
	bpa_current_active = top_nav + '_left_nav';
	$('.bpa-report ul#' + bpa_current_active).show();

	// load center content for active left nav option
  var center_content_id = $('.bpa-report #' + bpa_current_active + ' li.active').children('a').data('id');
	$('.bpa-report div#' + center_content_id).show();
	
  // bootstrap fix - redraw datatables when switching to tab
  if ( center_content_id == 'security_rulebase' ){
		$('table#security_rules_table, table.datatable').DataTable().columns.adjust().draw();
	}

};

// top nav event handler
$('a.top-nav-option').click(
	function() {
		let active_report = state.active_report;
		let active_top_nav = state[active_report].active_top_nav;
		let next_top_nav = $(this).data('top-nav');

	    // remove active class from current top nav
	    $(`a.top-nav-option[data-top-nav="${active_top_nav}"]`).parents('li').removeClass('active');

	    // add active class to selected top nav
	    $(this).parents('li').addClass('active');

	    //update state
	    state[active_report].active_top_nav = next_top_nav;

	    if (active_report == 'bpa-report') {
	    	// show the new left nav options for BPA
    		show_left_nav($(this).attr('id'));
	    } else {
	    	// update center content
		    $(`.heatmap-report div#${active_top_nav}`).addClass('hidden');
		    $(`.heatmap-report div#${next_top_nav}`).removeClass('hidden');
	    }

	    //fix for rendering datatables (column alignments) in bootstrap tabs
	    $.fn.dataTable.tables( {visible: true, api: true} ).columns.adjust();

	}
);


// BPA left nav event handler
$('.bpa-report#left_nav a').click(function() {

	var active_left_nav = $('.bpa-report #' + bpa_current_active + ' li.active');

	// remove active from current left nav
	active_left_nav.removeClass('active');

	// hide currently visible content
	$('.bpa-report div#' + active_left_nav.children('a').data('id')).hide();

	// // add active to newly selected left nav
	$(this).parents('li').addClass('active');

	// show new center content
	$('.bpa-report div#' + $(this).data('id')).show();
	
  // bootstrap fix - redraw datatables when switching to tab
  if ( $(this).data('id') == 'security_rulebase' ){
		$('table#security_rules_table').DataTable().columns.adjust().draw();
	}

});


// Heatmap left nav event handler
let current_adoption_nav = 'adoption_summary'
$('.heatmap-report a.left_nav_option').click(
  function() {
    let clicked_id = $(this).data('id');
    if (current_adoption_nav != clicked_id) {
      $(`div#${current_adoption_nav}`).hide();
      $(`div#${clicked_id}`).show();
      current_adoption_nav = clicked_id;
      $(this).parents('li').siblings('li').removeClass('active');
      $(this).parents('li').addClass('active');
    }
  }
);
