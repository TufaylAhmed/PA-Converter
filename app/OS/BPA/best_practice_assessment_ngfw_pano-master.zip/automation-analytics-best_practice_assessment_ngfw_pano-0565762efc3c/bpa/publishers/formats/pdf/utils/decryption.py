import os
from typing import List, Dict

from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle, Image
from reportlab.platypus.flowables import Flowable

from bpa.publishers.formats.pdf import images_path
from bpa.publishers.formats.pdf.utils.content import build_p
from bpa.publishers.formats.pdf.utils.data import get_decryption


def write_decryption(Story: List[Flowable], data: Dict):
    n = 150
    cw = [n * 0.65, n * 1.7, n * 0.5]
    chart_style = TableStyle(
        [
            ("ALIGN", (-1, 0), (-1, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.black),
            ("BOX", (0, 0), (-1, -1), 0.25, colors.black),
        ]
    )
    tdata = []
    decdata = get_decryption()
    w = h = 16
    check_img = Image(os.path.join(images_path, "check.png"), width=w, height=h)
    cross_img = Image(os.path.join(images_path, "cross.png"), width=w, height=h)
    for k, v in data.items():
        k_para = build_p(k)
        c_img = check_img if v is True else cross_img
        c_para = build_p(
            "Configured" if v is True else "Not configured",
            halign="CENTER",
            font_size=7,
        )
        nsty = TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER")])
        ntbl = Table([[c_img], [c_para]], style=nsty)
        d_para = build_p(decdata[k]["description"])
        tdata.append([k_para, d_para, ntbl])
    tbl = Table(tdata, cw, style=chart_style)
    Story.append(tbl)
