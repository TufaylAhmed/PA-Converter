from reportlab.lib.units import inch
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Image

from bpa.publishers.formats.pdf.constants import FONT_LATO_REGULAR


class FrontCoverTemplate(PageTemplate):
    """Define front cover frame"""

    def __init__(self, id: str, doc: BaseDocTemplate):
        _dx, _dy = inch, doc.width - 2 * inch
        _dw, _dh = 3 * inch, doc.height - 518
        frame = Frame(_dx, _dy, _dw, _dh, id=id)
        super().__init__(id=id, frames=[frame], onPage=FrontCoverProcessor())


class FrontCoverProcessor:
    """Process front cover layout"""

    def __call__(self, canvas, doc: BaseDocTemplate):
        canvas.saveState()

        width, height = doc.pagesize

        # Fill the whole background
        canvas.setStrokeColorRGB(*doc.color_grey)
        canvas.setFillColorRGB(*doc.color_grey)
        canvas.rect(0, 0, width, height, fill=1)

        # Draw title
        canvas.setFillColorRGB(*doc.color_white)
        canvas.setFont(FONT_LATO_REGULAR, 30)
        title_offset = 0.6 * height
        title_left = width / 2
        canvas.drawCentredString(title_left, title_offset, doc["title"])

        # Draw contextual data
        canvas.setFont(FONT_LATO_REGULAR, 12)

        content = {
            "version": f'Version: {doc["version"]}',
            "device": f'Device: {doc["device"]}',
            "time": f'Generated On: {doc["time"]}',
        }

        canvas.drawCentredString(title_left, title_offset - 50, content["time"])
        canvas.drawCentredString(title_left, title_offset - 70, content["device"])
        canvas.drawCentredString(title_left, title_offset - 90, content["version"])

        # Draw logo
        _logo_width, _logo_height = doc.getLogoDimensions(logo_factor=0.3)
        logo = Image(doc.logo_path, width=_logo_width, height=_logo_height)
        logo.wrap(width, height)
        logo.drawOn(canvas, 20, height - 80)

        # Draw footer
        canvas.setFont(FONT_LATO_REGULAR, 10)
        canvas.setStrokeColorRGB(*doc.color_white)
        canvas.line(inch, 120, width - inch, 120)
        canvas.drawString(inch, 100, "Palo Alto Networks")
        canvas.drawString(inch, 100 - 12, "3000 Tannery Way")
        canvas.drawString(inch, 100 - 24, "Santa Clara, CA")

        canvas.restoreState()
