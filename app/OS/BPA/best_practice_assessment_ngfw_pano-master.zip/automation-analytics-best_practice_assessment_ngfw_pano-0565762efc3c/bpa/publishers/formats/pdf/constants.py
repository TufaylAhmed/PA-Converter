import os

from reportlab.lib.enums import TA_JUSTIFY
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

from bpa.publishers.formats.pdf import fonts_path


# Register regular font
FONT_LATO_REGULAR = "Lato-Regular"
FONT_LATO_REGULAR_PATH = os.path.join(fonts_path, f"{FONT_LATO_REGULAR}.ttf")
pdfmetrics.registerFont(TTFont(FONT_LATO_REGULAR, FONT_LATO_REGULAR_PATH))

# Register bold font
FONT_LATO_BOLD = "Lato-Bold"
FONT_LATO_BOLD_PATH = os.path.join(fonts_path, f"{FONT_LATO_BOLD}.ttf")
pdfmetrics.registerFont(TTFont(FONT_LATO_BOLD, FONT_LATO_BOLD_PATH))

# Register light font
FONT_LATO_LIGHT = "Lato-Light"
FONT_LATO_LIGHT_PATH = os.path.join(fonts_path, f"{FONT_LATO_LIGHT}.ttf")
pdfmetrics.registerFont(TTFont(FONT_LATO_LIGHT, FONT_LATO_LIGHT_PATH))

# Base styles
STYLES = getSampleStyleSheet()
STYLES.add(ParagraphStyle(name="Justify", alignment=TA_JUSTIFY))

# Overwrite common styles
NORM_STYLE = STYLES["Normal"]
NORM_STYLE.fontSize = 8
TITLE_STYLE = STYLES["Title"]
TITLE_STYLE.fontSize = 18
for style in (NORM_STYLE, TITLE_STYLE):
    style.fontName = FONT_LATO_REGULAR

# Overwrite heading styles
H1_STYLE = STYLES["Heading1"]
H1_STYLE.fontSize = 12
H2_STYLE = STYLES["Heading2"]
H2_STYLE.fontSize = 10
for style in (H1_STYLE, H2_STYLE):
    style.fontName = FONT_LATO_BOLD

# Default left padding
DEFAULT_LEFT_PADDING = 6
