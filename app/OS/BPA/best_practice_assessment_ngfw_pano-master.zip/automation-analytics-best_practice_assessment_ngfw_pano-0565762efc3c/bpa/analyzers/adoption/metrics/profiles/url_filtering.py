from bpa.models.objects.security_profile.url_filtering_profile import (
    UrlFilteringProfileModel,
)
from bpa.analyzers.adoption.metrics.profiles.common import AdoptionProfileMetric
from bpa.analyzers.adoption.metrics.profiles.mixins import BPResultMixin


class UrlFilteringProfileMetric(AdoptionProfileMetric, BPResultMixin):
    """UrlFilteringProfileMetric DOES have BP Mode"""

    profile_type = UrlFilteringProfileModel.build_model_key()

    def get_adoption_result(self):
        if self.rule.action == "allow" and self.profile is not None:
            return 1
        return 0

    def get_bp_mode_result(self) -> int:
        """All checks EXCEPT for check #207 need to pass for URL Filtering BP Mode.

        Check #207 is used for Credential Theft BP Mode.
        """
        if self.profile is not None:
            if not self.profile_used:
                return 0
            result = self.get_bp_analyzer()
            if result is None:
                return 0
            verdicts = set()
            for check in result.warnings:
                if check.check_id != 207:
                    verdicts.add(check.check_passed)
            return 1 if verdicts == {True} else 0
        return 0
