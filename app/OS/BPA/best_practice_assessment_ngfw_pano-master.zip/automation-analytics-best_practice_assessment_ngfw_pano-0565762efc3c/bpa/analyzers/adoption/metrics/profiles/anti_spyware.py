from bpa.models.objects.security_profile.anti_spyware_profile import (
    AntiSpywareProfileModel,
)
from bpa.analyzers.adoption.metrics.profiles.common import AdoptionProfileMetric
from bpa.analyzers.adoption.metrics.profiles.mixins import BPResultMixin


class AntiSpywareProfileMetric(AdoptionProfileMetric, BPResultMixin):
    """AntiSpywareProfileMetric DOES have BP Mode"""

    profile_type = AntiSpywareProfileModel.build_model_key()

    def get_adoption_result(self) -> int:
        if (
            self.rule.action == "allow"
            and self.profile is not None
            and len(self.profile.rules) > 0
        ):
            return 1
        return 0

    def get_bp_mode_result(self) -> int:
        """All checks EXCEPT for check #38 need to pass for AS BP Mode.

        Check #38 is used for DNS Sinkhole BP Mode.
        """
        if self.profile is not None:
            if not self.profile_used:
                return 0
            result = self.get_bp_analyzer()
            if result is None:
                return 0
            verdicts = set()
            for check in result.warnings:
                if check.check_id != 38:
                    verdicts.add(check.check_passed)
            return 1 if verdicts == {True} else 0
        return 0
