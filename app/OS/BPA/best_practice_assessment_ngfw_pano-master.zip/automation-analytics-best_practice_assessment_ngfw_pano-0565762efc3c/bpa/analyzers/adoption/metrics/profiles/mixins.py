import logging


LOG = logging.getLogger(__name__)


class BPResultMixin:
    """Best Practice result mixin.

    NOTE: Used in the context of an AdoptionProfileMetric
    subclass. The most important piece of this mixin class
    is that it introduces the BP Mode result, which is separate
    from the Adoption result.

    NOTE: Since it's used as part of the AdoptionProfileMetric
    instance, it will also share the same attributes as that
    class.
    """

    @property
    def bp_analyzer_key(self) -> str:
        """Get Best Practice Analyzer key.

        NOTE: Used for lookup of a given BP Analyzer that gets "joined"
        with this metric to enable BP Mode aggregates.

        Returns:
            BP Analyzer key as string representation.
        """
        return self.profile_type

    def get_bp_analyzer(self):
        if self.profile is not None:
            try:
                cache = self.adoption_manager().bp_mode_cache[self.profile.__class__]
            except KeyError:
                LOG.debug(f"Seeding bp_mode_cache with {self.bp_analyzer_key} results")
                cache = {}
                for result in self.bp_manager().get(self.bp_analyzer_key):
                    sig = (
                        result.configuration["location"],
                        result.configuration["name"],
                    )
                    cache[sig] = result
                self.adoption_manager().bp_mode_cache[self.profile.__class__] = cache

            try:
                return cache[(self.profile.location, self.profile.name)]
            except KeyError:
                raise ValueError(
                    (
                        f"No BP Result found for {self.bp_analyzer_key} with "
                        f"name={self.profile.name} and location={self.profile.location}"
                    )
                )

        raise ValueError(
            f"Cannot get BP Result when {self.profile.__class__.__name__} is None"
        )

    def get_bp_mode_result(self) -> int:
        if self.profile is not None:
            if not self.profile_used:
                return 0
            result = self.get_bp_analyzer()
            if result is None:
                return 0
            all_checks_passing = all(check.check_passed for check in result.warnings)
            return 1 if all_checks_passing else 0
        else:
            return 0

    @property
    def profile_used(self):
        sig = (self.profile.location, self.profile.name, self.profile.build_model_key())
        rules_using_profile = len(
            self.profile.objects.get("security_rule").sec_profiles_with_allow_rules[sig]
        )
        return rules_using_profile > 0
