from bpa.models.objects.security_profile.url_filtering_profile import (
    UrlFilteringProfileModel,
)
from bpa.analyzers.adoption.metrics.profiles.common import AdoptionProfileMetric
from bpa.analyzers.adoption.metrics.profiles.mixins import BPResultMixin


class CredentialTheftProfileMetric(AdoptionProfileMetric, BPResultMixin):
    """CredentialTheftProfileMetric DOES have BP Mode"""

    profile_type = UrlFilteringProfileModel.build_model_key()

    @property
    def metric_key(self) -> str:
        return "credential_theft"

    def get_adoption_result(self) -> int:
        if self.rule.action != "allow":
            return 0
        if self.profile is None:
            return 0
        if self.profile.credential_enforcement is None:
            return 0
        if self.profile.credential_enforcement.mode == "disabled":
            return 0
        for action in ["alert", "block", "continue"]:
            if self.profile.credential_enforcement.categories[action]:
                return 1
        else:
            return 0

    def get_bp_mode_result(self) -> int:
        """Only check #207 needs to pass for Credential Theft BP Mode."""
        if self.profile is not None:
            if not self.profile_used:
                return 0
            result = self.get_bp_analyzer()
            if result is None:
                return 0
            for check in result.warnings:
                if check.check_id == 207:
                    return 1 if check.check_passed else 0
        return 0
