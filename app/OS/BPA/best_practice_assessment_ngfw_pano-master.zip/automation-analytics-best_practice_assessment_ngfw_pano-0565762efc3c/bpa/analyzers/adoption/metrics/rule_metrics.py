from typing import Dict

from bpa.analyzers.adoption.base_metric import AdoptionMetric
from bpa.models.constants import NONE_LOWER


class RuleMetrics(AdoptionMetric):
    """Adoption Metric > RuleMetrics

    NOTE: Instead of making multiple classes, multiple _metric_
    routines were implemented instead since most of these metrics
    only need the SecurityRuleModel instance and nothing else.
    """

    # TODO: Automate zero-ing out these fields
    DISABLED_RULE_METRICS = {
        "total_rule_count": 0,
        "allow_rule_count": 0,
        "deny_rule_count": 0,
        "rule_enabled": 0,
        "user_id_enabled": 0,
        "app_id_enabled": 0,
        "service_port_configured": 0,
        "log_end": 0,
        "log_start": 0,
        "profile_group_used": 0,
        "profile_used": 0,
        "log_forwarding_enabled": 0,
        "zone_protection_profile_enabled": 0,
    }

    METRIC_PREFIX = "_metric_"

    def _metric_user_id_enabled(self) -> int:
        source_users = set(self.rule.source_users) - {"any", "unknown"}
        return 1 if source_users and self.rule.action == "allow" else 0

    def _metric_app_id_enabled(self) -> int:
        applications = set(self.rule.applications) - {"any"}
        return 1 if applications and self.rule.action == "allow" else 0

    def _metric_service_port_configured(self) -> int:
        services = set(self.rule.services) - {"any"}
        return 1 if services and self.rule.action == "allow" else 0

    def _metric_log_start(self) -> int:
        return 1 if self.rule.log_start_enabled else 0

    def _metric_log_end(self) -> int:
        return 1 if self.rule.log_end_enabled else 0

    def _metric_log_forwarding_enabled(self) -> int:
        return 1 if self.rule.log_forwarding_profile != NONE_LOWER else 0

    def _metric_zone_protection_profile_enabled(self) -> int:
        source_zones = set(self.rule.source_zones) - {"any"}
        if source_zones:
            # TODO: Sync with Samshodh on how to handle zone search from security rule on Panorama (i.e. how to handle template / location)
            zpp_used = any(
                zone.zone_protection_profile is not None
                for zone in self.rule.objects.get("zone")
                if zone.name in source_zones
            )
            return 1 if zpp_used else 0
        else:
            return 0

    def _add_rule_counts(self, results) -> None:
        results["total_rule_count"] = 1
        results["rule_enabled"] = 1
        if self.rule.action == "allow":
            results["allow_rule_count"] = 1
            results["deny_rule_count"] = 0
        else:
            results["allow_rule_count"] = 0
            results["deny_rule_count"] = 1

    def _add_profile_settings(self, results) -> None:
        if self.rule.profile_group is not None:
            results["profile_group_used"] = 1
            results["profile_used"] = 0
        else:
            results["profile_group_used"] = 0
            results["profile_used"] = 1

    def get_results(self) -> Dict:
        """Get results for all rule-based metrics."""
        if not self.rule.rule_enabled:
            return self.DISABLED_RULE_METRICS

        def sanitize(attr):
            return attr.replace(self.METRIC_PREFIX, "")

        results = {}
        metrics = (
            (sanitize(attr), getattr(self, attr))
            for attr in dir(self)
            if attr.startswith(self.METRIC_PREFIX)
        )
        for metric_key, metric in metrics:
            results[metric_key] = metric()
        self._add_rule_counts(results)
        self._add_profile_settings(results)
        return results
