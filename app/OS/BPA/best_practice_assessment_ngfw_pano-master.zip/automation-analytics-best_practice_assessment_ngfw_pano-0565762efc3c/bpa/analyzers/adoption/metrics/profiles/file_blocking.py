from bpa.models.objects.security_profile.file_blocking_profile import (
    FileBlockingProfileModel,
)
from bpa.analyzers.adoption.metrics.profiles.common import AdoptionProfileMetric
from bpa.analyzers.adoption.metrics.profiles.mixins import BPResultMixin


class FileBlockingProfileMetric(AdoptionProfileMetric, BPResultMixin):
    """FileBlockingProfileMetric DOES have BP Mode"""

    profile_type = FileBlockingProfileModel.build_model_key()

    def get_adoption_result(self) -> int:
        if (
            self.rule.action == "allow"
            and self.profile is not None
            and len(self.profile.rules) > 0
        ):
            return 1
        return 0
