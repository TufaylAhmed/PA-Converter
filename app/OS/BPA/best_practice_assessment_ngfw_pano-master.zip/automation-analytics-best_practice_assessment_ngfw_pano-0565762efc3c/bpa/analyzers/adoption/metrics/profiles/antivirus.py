from bpa.models.objects.security_profile.antivirus_profile import AntivirusProfileModel
from bpa.analyzers.adoption.metrics.profiles.common import AdoptionProfileMetric
from bpa.analyzers.adoption.metrics.profiles.mixins import BPResultMixin


class AntivirusProfileMetric(AdoptionProfileMetric, BPResultMixin):
    """AntivirusProfileModel DOES have BP Mode"""

    profile_type = AntivirusProfileModel.build_model_key()

    def get_adoption_result(self) -> int:
        if (
            self.rule.action == "allow"
            and self.profile is not None
            and len(self.profile.decoders) > 0
        ):
            return 1
        return 0
