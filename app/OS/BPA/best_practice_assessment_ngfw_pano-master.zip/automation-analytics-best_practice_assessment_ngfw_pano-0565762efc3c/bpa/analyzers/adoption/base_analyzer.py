import weakref
from typing import List

from .rule_result import AdoptionRuleResult


class AdoptionRuleAnalyzer:
    """Adoption Rule Analyzer.

    This analyzer looks at security rules checks if each rule has the
    following facts:

    - Object profiles configured
    - Object profile groups configured
    - App ID
    - User ID
    - etc.

    These facts get compiled into metric counts and aggregate higher
    up the chain at the Manager level.

    Attributes:
        rule: SecurityRuleModel instance.
        model_manager: Weak reference to ModelManager instance.
        bp_manager: Weak reference to BestPracticeAnalyzerManager.
        adoption_manager: Weak reference to AdoptionAnalyzerManager.
        metrics: List of AdoptionCheck instances to iterate against.
    """

    def __init__(self, rule, metrics: List, adoption_manager):
        self.rule = rule
        self.model_manager = adoption_manager.model_manager
        self.bp_manager = adoption_manager.bp_manager
        self.adoption_manager = weakref.ref(adoption_manager)
        self.metrics = metrics

    @property
    def objects(self):
        """Helper to call the model_manager weakref."""
        return self.model_manager()

    def get_rule_result(self, run_metrics: bool = True) -> AdoptionRuleResult:
        """Returns rule result.

        For a given SecurityRuleModel, run all routines for each metric
        that was registered in the AdoptionRuleAnalyzer
        and return a processed result.

        Returns:
            AdoptionRuleResult instance.
        """
        attrs = {"metrics": {}, "configuration": self.rule.to_dict()}
        if run_metrics:
            results = {}
            for metric in self.metrics:
                results.update(metric(self.rule, self.adoption_manager).get_results())
            attrs["metrics"] = results
        return AdoptionRuleResult(**attrs)
