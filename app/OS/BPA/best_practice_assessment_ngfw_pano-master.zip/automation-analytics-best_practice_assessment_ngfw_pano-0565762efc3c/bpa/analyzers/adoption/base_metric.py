import weakref
from abc import ABCMeta
from typing import Dict

from .metrics.profiles.mixins import BPResultMixin


class AdoptionMetric(metaclass=ABCMeta):
    """Adoption metric.

    A single unit of metric. The primary API that gets invoked
    by the AdoptionRuleAnalyzer is get_results. The get_results
    can be overwritten to fill custom cases, but bear in mind
    that the metric_key and get_adoption_result still need
    to be overwritten.

    Attributes:
        rule: SecurityRuleModel instance.
    """

    def __init__(self, rule, adoption_manager: weakref.ReferenceType):
        self.rule = rule
        self.adoption_manager = adoption_manager

    def get_results(self) -> Dict:
        """Get results for given metric.

        Results come in the form of a simple enable and a BP enable
        flag (0 or 1). Both are identified by _enabled and
        _enabled_bp_mode respectively.

        Returns:
            A dictionary with one or two results. One for simple, one for BP.
        """
        results = {}
        results[f"{self.metric_key}_enabled"] = self.get_adoption_result()
        if isinstance(self, BPResultMixin):
            if results[f"{self.metric_key}_enabled"] == 1:
                results[
                    f"{self.metric_key}_enabled_bp_mode"
                ] = self.get_bp_mode_result()
            else:
                results[f"{self.metric_key}_enabled_bp_mode"] = 0
        return results
