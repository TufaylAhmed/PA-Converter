import logging
import weakref
from typing import List

from bpa.analyzers.adoption import metrics
from bpa.analyzers.adoption.base_analyzer import AdoptionRuleAnalyzer
from bpa.analyzers.adoption.base_metric import AdoptionMetric
from bpa.utils.common import find_classes


LOG = logging.getLogger(__name__)


class AdoptionAnalyzerManager:
    """Adoption Analyzer Manager.

    Attributes:
        model_manager: ModelManager instance.
        bp_manager: BestPracticesAnalyzerManager instance.
        bp_mode_cache: BP Mode cache for BPResultMixin to populate.
        results: List of rule results for each security rule processed.
        results_attempted: Flag to determine whether results were computed.
    """

    def __init__(self, bp_manager):
        LOG.debug(f"{self.__class__.__name__} initializing")
        self.bp_manager = weakref.ref(bp_manager)
        self.model_manager = bp_manager.model_manager
        self.bp_mode_cache = {}
        self.results = []
        self.results_attempted = False

    def find_metrics(self) -> List:
        metrics_dict = find_classes(metrics, AdoptionMetric, "default")
        if self.model_manager().tree.version < 8:
            del metrics_dict["CredentialTheftProfileMetric"]
        return list(metrics_dict.values())

    def get(self) -> List:
        LOG.debug("Retrieving all metric results")
        if self.results_attempted is True:
            return self.results
        metrics = self.find_metrics()
        for rule in self.model_manager().get("security_rule"):
            analyzer = AdoptionRuleAnalyzer(rule, metrics, self)
            result = analyzer.get_rule_result(run_metrics=rule.rule_enabled)
            self.results.append(result)
        if len(self.results) == 0:
            LOG.warning(f"No results were retrieved from {self.__class__.__name__}")
        self.results_attempted = True
        return self.results
