from typing import Dict

from dataclasses import dataclass


@dataclass
class AdoptionRuleResult:
    """Collects metrics for rule adoption.

    Attributes:
        configuration: Metadata for rule name, location and other attributes.
        metrics: Mapping of metric names to metric outputs.
    """

    configuration: Dict
    metrics: Dict
