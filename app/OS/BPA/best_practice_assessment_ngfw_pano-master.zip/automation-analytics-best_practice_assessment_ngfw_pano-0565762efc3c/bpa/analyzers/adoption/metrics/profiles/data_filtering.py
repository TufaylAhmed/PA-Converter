from bpa.models.objects.security_profile.data_filtering_profile import (
    DataFilteringProfileModel,
)
from bpa.analyzers.adoption.metrics.profiles.common import AdoptionProfileMetric


class DataFilteringProfileMetric(AdoptionProfileMetric):
    """DataFilteringProfileMetric does NOT have BP Mode"""

    profile_type = DataFilteringProfileModel.build_model_key()

    def get_adoption_result(self) -> int:
        if (
            self.rule.action == "allow"
            and self.profile is not None
            and len(self.profile.rules) > 0
        ):
            return 1
        return 0
