from bpa.models.objects.security_profile.wildfire_analysis_profile import (
    WildfireAnalysisProfileModel,
)
from bpa.analyzers.adoption.metrics.profiles.common import AdoptionProfileMetric
from bpa.analyzers.adoption.metrics.profiles.mixins import BPResultMixin


class WildfireAnalysisProfileMetric(AdoptionProfileMetric, BPResultMixin):
    """WildfireAnalysisProfileMetric DOES have BP Mode"""

    profile_type = WildfireAnalysisProfileModel.build_model_key()

    def get_adoption_result(self):
        if (
            self.rule.action == "allow"
            and self.profile is not None
            and len(self.profile.rules) > 0
        ):
            return 1
        return 0
