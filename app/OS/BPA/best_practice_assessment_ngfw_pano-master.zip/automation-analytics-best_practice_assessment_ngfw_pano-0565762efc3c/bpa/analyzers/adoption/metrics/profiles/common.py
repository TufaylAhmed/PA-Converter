import weakref
from abc import ABCMeta

from bpa.analyzers.adoption.base_metric import AdoptionMetric
from bpa.models.utils.searching import get_object_from_ancestors


class AdoptionProfileMetric(AdoptionMetric, metaclass=ABCMeta):
    """Adoption Metric > Adoption Profile Metric

    Attributes:
        rule: Instance of the SecurityRuleModel.
        profile: Optional instance of SecurityProfileModel retrieved from ancestors.
        bp_manager: Weak reference to BestPracticeAnalyzerManager instance.
        model_manager: Weak reference to ModelManager instance.
    """

    profile_type = None

    @property
    def metric_key(self) -> str:
        """Return metric key.

        Returns:
            Metric key as string representation.
        """
        return self.profile_type

    @property
    def profile_attr(self) -> str:
        """Return profile attribute in SecurityRuleModel.

        NOTE: Any diff between the SecurityProfileModel key must be
        updated in the SecurityRuleModel to maintain consistency at this
        phase.
        """
        return f'profile_{self.profile_type.replace("_profile", "")}'

    def __init__(self, rule, adoption_manager: weakref.ReferenceType):
        super().__init__(rule, adoption_manager)
        self.bp_manager = adoption_manager().bp_manager
        profile_ms = rule.objects.get(self.profile_type)
        profile_name = getattr(rule, self.profile_attr)
        if profile_name is None:
            self.profile = None
            return
        self.profile = get_object_from_ancestors(
            rule.objects, rule.location, profile_ms, name=profile_name
        )
