from bpa.models.objects.security_profile.anti_spyware_profile import (
    AntiSpywareProfileModel,
)
from bpa.analyzers.adoption.metrics.profiles.common import AdoptionProfileMetric
from bpa.analyzers.adoption.metrics.profiles.mixins import BPResultMixin


class DnsSinkholeProfileMetric(AdoptionProfileMetric, BPResultMixin):
    """DnsSinkholeProfileMetric DOES have BP Mode"""

    profile_type = AntiSpywareProfileModel.build_model_key()

    @property
    def metric_key(self) -> str:
        return "dns_sinkhole"

    def get_adoption_result(self) -> int:
        if (
            self.rule.action == "allow"
            and self.profile is not None
            and self.profile.dns_sinkhole is True
        ):
            return 1
        return 0

    def get_bp_mode_result(self) -> int:
        """Only check #38 needs to pass for DNS Sinkhole BP Mode."""
        if self.profile is not None:
            if not self.profile_used:
                return 0
            result = self.get_bp_analyzer()
            if result is None:
                return 0
            for check in result.warnings:
                if check.check_id == 38:
                    return 1 if check.check_passed else 0
        return 0
