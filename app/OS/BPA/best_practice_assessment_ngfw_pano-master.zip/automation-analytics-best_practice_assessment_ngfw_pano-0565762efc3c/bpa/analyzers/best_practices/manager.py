import json
import logging
import os
import weakref
from collections import defaultdict
from typing import Dict, List

from ...utils.common import find_classes
from .. import best_practices
from .base_analyzer import BestPracticesAnalyzer


LOG = logging.getLogger(__name__)


class BestPracticesAnalyzerManager:
    """Best Practices Analyzer Manager.

    Attributes:
        model_manager: ModelManager instance.
        analyzer_lookup: Dictionary of BestPracticeAnalyzer classes.
        analyzer_results_lookup: [analyzer] -> [r1, r2, ...]
        analyzer_results_by_categories: [category][analyzer] -> [r1, r2, ...]
        analyzer_results_by_categories_asdict: [category][analyzer] -> [{}, {}, ...]
        check_info: Check information as dictionary.
    """

    def __init__(self, model_manager):
        LOG.debug(f"{self.__class__.__name__} initializing")
        self.model_manager = weakref.ref(model_manager)
        self.analyzer_instance_lookup = {}
        self.analyzer_lookup = self.find_analyzers()
        self.analyzer_results_lookup = {}
        self.analyzer_results_by_categories = defaultdict(dict)
        self.check_info = self.get_check_info()

    @classmethod
    def get_check_info(cls) -> Dict:
        """Get check information from JSON file"""
        with open(os.path.join(os.path.dirname(__file__), "check_config.json")) as f:
            check_info = json.load(f)
        return check_info

    @staticmethod
    def analyzer_results_by_template(results):
        """Search for null template_name in analyzer results."""
        with_template_null = []
        with_template_exists = []
        for result in results:
            # NOTE: Assume that every device model has template_name
            if result.configuration.get("template_name") is None:
                with_template_null.append(result)
            else:
                with_template_exists.append(result)
        return with_template_null, with_template_exists

    def _register_results(self, name) -> List:
        """Register and get analyzer results dynamically.

        Provides a convenient public API for getting results from
        specific analyzers. The BestPracticesAnalyzerManager can
        then be seen as a cache that gets computed whenever data
        is needed.
        """
        try:
            TargetClass = self.analyzer_lookup[name]
        except KeyError:
            raise AttributeError(f"No class found for analyzing {name}")
        analyzer = TargetClass(self.model_manager, self.check_info)
        self.analyzer_instance_lookup[name] = analyzer
        results = self.analyzer_results_lookup[name] = analyzer.get_results()

        folder_name = TargetClass.folder()

        def store_results(category, name, results):
            """Store results in two formats."""
            self.analyzer_results_by_categories[category][name] = results

        # NOTE: Handle panorama corner cases in device folder
        if folder_name == "device" and self.model_manager().tree.panorama is True:
            with_template = self.analyzer_results_by_template(results)
            with_template_null, with_template_exists = with_template
            if len(with_template_null) > 0:
                store_results("panorama", name, with_template_null)
            store_results(folder_name, name, with_template_exists)
        else:
            store_results(folder_name, name, results)

        return results

    def get(self, requested_analyzer) -> List:
        """Lazily retrieve analyzer results from BestPracticesAnalyzerManager."""
        LOG.debug(f"Retrieving results from {requested_analyzer}")
        return self._register_results(requested_analyzer)

    def run_all(self):
        """Run all analyzers in lookup dictionary.

        NOTE: This must be run before retrieving any results.
        Otherwise, the analyzer results will not be present when
        retrieving the data.
        """
        for key in self.analyzer_lookup.keys():
            self.get(key)

    def get_all(self):
        """Get all results executed so far."""
        self.run_all()
        return self.analyzer_results_lookup

    def get_all_by_category(self):
        """Get all results executed so far by category."""
        self.run_all()
        return self.analyzer_results_by_categories

    @staticmethod
    def find_analyzers() -> Dict:
        return find_classes(best_practices, BestPracticesAnalyzer, "build_analyzer_key")
