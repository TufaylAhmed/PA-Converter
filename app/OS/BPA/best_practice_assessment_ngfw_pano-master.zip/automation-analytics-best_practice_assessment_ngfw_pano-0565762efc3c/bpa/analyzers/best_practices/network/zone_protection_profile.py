from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning
from ....models.network.zone_protection_profile import ZoneProtectionProfileModel


class ZoneProtectionProfileAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > ZoneProtectionProfileAnalyzer"""

    def get_configuration(self, model):
        model_dict = model.to_dict()
        flood_protection = []
        for key in model_dict["flood_protection"].keys():
            named_value = {"Name": key}
            value = model_dict["flood_protection"][key]
            named_value.update(value)
            flood_protection.append(named_value)
        model_dict["flood_protection"] = flood_protection
        model_dict["applied_on_zones"] = [
            _.name
            for _ in self.get_models("zone").findall(
                zone_protection_profile=model.name, template_name=model.template_name
            )
        ]
        return model_dict

    def _check_flood_protection(
        self, profile: ZoneProtectionProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["85"]
        display_dict = {
            "tcp_syn": "SYN",
            "icmp": "ICMP",
            "icmp_v6": "ICMPv6",
            "other_ip": "Other IP",
            "udp": "UDP",
        }
        default_vals = (10000, 10000, 40000)

        not_enabled_fails = []
        default_value_fails = []
        for flood_type, checks in profile.flood_protection.to_dict().items():
            # check if not enabled
            if not checks["enabled"]:
                not_enabled_fails.append(display_dict[flood_type])
            # check if using any default alues
            if any(
                (default, provided)
                for (default, provided) in zip(
                    default_vals,
                    (checks["alert"], checks["activate"], checks["maximum"]),
                )
                if default == provided
            ):
                default_value_fails.append(display_dict[flood_type])

        warn_message_lst = []
        if not_enabled_fails:
            warn_message_lst.append(
                "Flood Protection > {} should be enabled".format(
                    " / ".join(not_enabled_fails)
                )
            )
        if default_value_fails:
            warn_message_lst.append(
                "Flood Protection > {} should NOT use default values (10000,10000,40000)".format(
                    " / ".join(default_value_fails)
                )
            )

        if warn_message_lst:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message=" AND ".join(warn_message_lst)
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_reconnaissance_protection(
        self, profile: ZoneProtectionProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["86"]
        warn_message_lst = []
        display_dict = {
            "tcp_port_scan_enabled": "TCP Port Scan",
            "host_sweep_enabled": "Host Sweep",
            "udp_port_scan_enabled": "UDP Port Scan",
        }

        for scan_type, enabled in profile.reconnaissance_protection.flags.items():
            if not enabled:
                warn_message_lst.append(display_dict[scan_type])

        if warn_message_lst:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="Reconnaissance Protection > {} should be enabled".format(
                    " / ".join(warn_message_lst)
                )
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_packet_based_attack_protection(
        self, profile: ZoneProtectionProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["87"]
        errors = []

        if not profile.packet_based_attack_protection.ip_option_drop_malformed:
            errors.append("IP Option Drop Malformed should be enabled.")

        for (
            setting,
            enabled,
        ) in profile.packet_based_attack_protection.tcp_drop.to_dict().items():
            if not enabled:
                errors.append(
                    "TCP Drop {} should be enabled.".format(
                        " ".join(x.title() for x in setting.split("_"))
                    )
                )

        if errors:
            return BestPracticeWarning.get_check(
                **check_attrs, check_passed=False, check_message=" ".join(errors)
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
