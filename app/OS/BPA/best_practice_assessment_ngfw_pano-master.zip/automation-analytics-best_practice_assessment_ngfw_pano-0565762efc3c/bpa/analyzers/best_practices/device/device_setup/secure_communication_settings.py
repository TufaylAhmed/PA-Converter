import logging
from typing import List, Optional, Union

from ...bp_check import BestPracticeNote, BestPracticeWarning
from ...bp_result import BestPracticeResult
from .common import DeviceSetupAnalyzer


LOG = logging.getLogger(__name__)


class SecureCommunicationSettingsAnalyzer(DeviceSetupAnalyzer):
    """BestPracticesAnalyzer > DeviceSetupAnalyzer > SecureCommunicationSettingsAnalyzer"""

    target_attr = "secure_comm"

    @classmethod
    def build_analyzer_key(cls) -> str:
        return "device_setup_secure_communication"

    def valid_cert_profile(
        self, cert_profile: Optional[str], template_name: str
    ) -> bool:
        if cert_profile is None:
            return False
        obj = self.get_models("certificate_profile").find(
            name=cert_profile, template_name=template_name
        )
        return obj.use_crl is True and obj.use_ocsp is True

    def _check_server_communication(
        self, secure_comms, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["224"]
        server = secure_comms.server

        if server.ssl_tls_service_profile is None:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="SSL/TLS Service Profile should be configured",
            )
        if not self.valid_cert_profile(
            server.certificate_profile, device_setup.template_name
        ):
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="Certificate Profile should be configured using CRL and OCSP",
            )
        if not server.allow_custom_certificate_only:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="Allow Custom Certificate Only setting should be configured",
            )

        return BestPracticeWarning.passing(**check_attrs)

    def _check_client_communication(
        self, secure_comms, device_setup
    ) -> Union[BestPracticeNote, BestPracticeWarning]:
        check_attrs = self.check_info["223"]
        client = secure_comms.client

        if client.certificate_type == "predefined":
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to configure "Local" or "SCEP" Certificate Type',
            )
        if client.certificate_type == "local" and client.certificate is None:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to configure a certificate when Certificate Type is Local",
            )
        if client.certificate_type == "scep" and client.scep_profile is None:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to configure a SCEP Profile when Certificate Type is SCEP",
            )
        if not self.valid_cert_profile(
            client.certificate_profile, device_setup.template_name
        ):
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to configure a Certificate Profile using CRL and OCSP",
            )

        enabled_options, disabled_options = (
            client.customize_communication.enabled_disabled_options()
        )
        if not disabled_options:
            return BestPracticeWarning.passing(**check_attrs)
        elif enabled_options:
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message=f'The following Customize Communication options should be enabled: {", ".join(disabled_options)}',
            )
        else:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="All Customize Communication options should be enabled",
            )

    def get_checks(self) -> List:
        """Get list of checks

        NOTES:
        PAN-OS == 8.0:
            Secure Communication Settings was nested within Panorama Settings and only includes
            Secure SERVER Communication for Panorama devices and Secure CLIENT Communication for NGFWs
        PAN-OS >= 8.1:
            Secure Communication Settings is a standalone feature and includes both
            Secure SERVER Communication and Secure CLIENT Communication for Panorama devices and
            Secure CLIENT Communication for NGFWs
        """

        if self.objects.tree.ngfw:
            return [self._check_client_communication]
        else:  # Panorama
            checks = [self._check_server_communication]
            if self.objects.tree.version >= 8.1:
                checks.append(self._check_client_communication)
            return checks

    def get_results(self) -> List[BestPracticeResult]:
        """Secure Communication Settings only applies PAN-OS 8.0+"""
        results = []
        if self.objects.tree.version < 8:
            return results
        for device_setup in self.get_models("device_setup"):
            if (
                device_setup.panorama is not None
                and not device_setup.panorama.panorama_servers
            ):
                LOG.debug(
                    f"Skipping result for {self.__class__.__name__} because there are no Panorama Servers "
                    f"on DeviceSetupModel with template_name={device_setup.template_name}."
                )
                continue
            target_model = device_setup.secure_comm
            configuration = {
                **target_model.to_dict(),
                "template_name": device_setup.template_name,
            }
            checks = []
            for method in self.get_checks():
                check = method(target_model, device_setup)
                if check is not None:
                    checks.append(check)
            results.append(BestPracticeResult(configuration, checks))
        return results
