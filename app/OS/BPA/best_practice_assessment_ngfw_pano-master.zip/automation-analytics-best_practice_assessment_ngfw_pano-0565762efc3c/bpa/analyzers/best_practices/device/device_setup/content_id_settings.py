import logging
from typing import List, Optional

from ...bp_check import BestPracticeNote, BestPracticeWarning
from ...bp_result import BestPracticeResult
from .common import DeviceSetupAnalyzer


LOG = logging.getLogger(__name__)


class ContentIDSettingsAnalyzer(DeviceSetupAnalyzer):
    """BestPracticesAnalyzer > DeviceSetupAnalyzer > ContentIDSettingsAnalyzer"""

    target_attr = "content_id"

    @classmethod
    def build_analyzer_key(cls) -> str:
        return "device_setup_content_id"

    def get_results(self) -> List[BestPracticeResult]:
        """Get list of results

        NOTE: Content-ID Settings checks only apply to NGFWs and device templates.
        """
        results = super().get_results()
        if self.objects.tree.panorama:
            results = [
                result
                for result in results
                if result.configuration["template_name"] is not None
            ]
        return results

    def _check_use_x_forwarded_for_enabled_note(
        self, content_id_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if not content_id_settings.use_x_forwarded_for_enabled:
            check_attrs = self.check_info["107"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message='If proxy is configured, it is recommended to enable "Use X-Forwarded-For Header in User ID"',
            )

    def _check_strip_x_forwarded_for_enabled_note(
        self, content_id_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if not content_id_settings.strip_x_forwarded_for_enabled:
            check_attrs = self.check_info["108"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message='If proxy is configured, it is recommended to enable "Strip X-Forwarded-For Header"',
            )

    def _check_allow_forwarding_decrypted_content_warn(
        self, content_id_settings, device_setup
    ) -> Optional[BestPracticeWarning]:
        if self.objects.tree.ngfw:
            check_attrs = self.check_info["203"]
            if content_id_settings.vsys_not_forwarding_decrypted_content:
                message = (
                    "The following vsys are not configured to allow forwarding of decrypted content: "
                    f'{", ".join(content_id_settings.vsys_not_forwarding_decrypted_content)}. '
                    "In a multi-vsys environment, this is configured in Device > Virtual Systems."
                )
                return BestPracticeWarning(
                    **check_attrs, check_passed=False, check_message=message
                )
            return BestPracticeWarning.passing(**check_attrs)

    def _check_exceed_tcp_queue_disabled_warn(
        self, content_id_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["215"]
        if content_id_settings.exceed_tcp_queue_enabled:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to disable "Forward Segments Exceeding TCP Content Inspection Queue"',
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_exceed_udp_queue_disabled_warn(
        self, content_id_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["216"]
        if content_id_settings.exceed_udp_queue_enabled:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to disable "Forward Datagrams Exceeding UDP Content Inspection Queue"',
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_exceed_appID_queue_disabled_warn(
        self, content_id_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["217"]
        if content_id_settings.exceed_appID_queue_enabled:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to disable "Forward Segments Exceeding TCP APP-ID Inspection Queue"',
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_http_partial_enabled(
        self, content_id_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["229"]
        if content_id_settings.http_partial_enabled:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message=f'It is recommended to disable "{content_id_settings.http_partial_name}"',
            )
        return BestPracticeWarning.passing(**check_attrs)
