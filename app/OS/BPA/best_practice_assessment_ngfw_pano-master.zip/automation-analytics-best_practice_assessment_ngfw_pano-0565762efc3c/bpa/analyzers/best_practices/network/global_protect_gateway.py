import logging
from typing import List

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning
from ..bp_result import BestPracticeResult
from ....models.network.global_protect import GlobalProtectGatewayModel
from ....models.constants import NONE
from ....models.utils.searching import get_object_from_ancestors


LOG = logging.getLogger(__name__)


class GlobalProtectGatewayAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > GlobalProtectGatewayAnalyzer"""

    def _check_ssl_tls_service_profile_min_version(
        self, gateway: GlobalProtectGatewayModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["76"]
        fail_check = BestPracticeWarning.get_check(**check_attrs, check_passed=False)
        if gateway.ssl_tls_service_profile == NONE:
            fail_check.check_message = "The SSL/TLS Service Profile is not configured"
            return fail_check

        ms = self.get_models("ssl_tls_service_profile")
        profile = get_object_from_ancestors(
            self.objects,
            gateway.location,
            ms,
            template_name=gateway.template_name,
            name=gateway.ssl_tls_service_profile,
        )

        # TODO: Sync with Samshodh on whether gateway is truly corrupt
        if profile is None:
            fail_check.check_message = (
                "Corrupt reference to SSL/TLS Service Profile: "
                f"{gateway.ssl_tls_service_profile} @ {gateway.location}"
            )
            return fail_check

        if profile.min_version != "tls1-2":
            fail_check.check_message = (
                "The SSL/TLS Service Profile you are using ({}) has a Min Version "
            )
            "other than TLSv1.2".format(gateway.ssl_tls_service_profile)
            return fail_check

        return BestPracticeWarning.passing(**check_attrs)

    def _check_certificate_profile(
        self, gateway: GlobalProtectGatewayModel
    ) -> BestPracticeWarning:
        """Two ways for check to pass:

        1) GP Gateway > Authentication Tab > Client Authentication > Authentication Profiles all have Authentication Type of Radius or SAML
        2) GP Gateway > Authentication Tab > Client Authentication > Configured with auth profile of any type
            AND Certificate Profile is configured.
        """
        check_attrs = self.check_info["77"]
        if gateway.certificate_profile != NONE:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
        if not gateway.auth_clients:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to utilize a Certificate Profile or have all "
                "Client Authentication configs use Radius or SAML for authentication",
            )

        bad_clients = []
        for client in gateway.auth_clients:
            auth_prof = get_object_from_ancestors(
                self.objects,
                gateway.location,
                self.get_models("authentication_profile"),
                template_name=gateway.template_name,
                name=client.auth_profile,
            )
            if auth_prof is not None and not auth_prof.using_radius_saml():
                bad_clients.append(client.name)

        if bad_clients:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="The following Client Authentication configs are not "
                f'configured to use Radius or SAML: {", ".join(bad_clients)}',
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_access_routes(
        self, gateway: GlobalProtectGatewayModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["78"]
        missing_routes = []
        for agent_config in gateway.agent_configs:
            if not any(
                route in agent_config.access_routes for route in ("0.0.0.0/0", "::/0")
            ):
                missing_routes.append(agent_config.name)

        if missing_routes:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="Please update the following agents so that their access routes "
                'include "0.0.0.0/0" and/or "::/0": {}'.format(
                    ", ".join(missing_routes)
                ),
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_replay_attack_detection(
        self, gateway: GlobalProtectGatewayModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["79"]
        fail_check = BestPracticeWarning.get_check(**check_attrs, check_passed=False)
        if gateway.tunnel_mode_enabled:
            tunnel_ms = self.get_models("global_protect_site_to_site_tunnel_settings")
            tunnel_settings = tunnel_ms.find(
                template_name=gateway.template_name, name=gateway.name + "-S"
            )

            if tunnel_settings is None:
                fail_check.check_message = "Tunnel configuration is missing"
                return fail_check

            if not tunnel_settings.replay_attack_detection_enabled:
                fail_check.check_message = (
                    "It is recommended to enable Replay Attack Detection when "
                    "Tunnel Configuration is enabled"
                )
                return fail_check
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_tunnel_monitoring(
        self, gateway: GlobalProtectGatewayModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["80"]
        fail_check = BestPracticeWarning.get_check(**check_attrs, check_passed=False)
        if gateway.tunnel_mode_enabled:
            tunnel_ms = self.get_models("global_protect_site_to_site_tunnel_settings")
            tunnel_settings = tunnel_ms.find(
                template_name=gateway.template_name, name=gateway.name + "-S"
            )

            if tunnel_settings is None:
                fail_check.check_message = "Tunnel configuration is missing"
                return fail_check

            if not tunnel_settings.tunnel_monitoring_enabled:
                fail_check.check_message = (
                    "It is recommended to enable Tunnel Monitoring when "
                    "Tunnel Configuration is enabled"
                )
                return fail_check
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def get_results(self) -> List[BestPracticeResult]:
        """Overrides base_analyzer get_results to include configuration for other dataclasses used in configuration"""
        results = []

        for gateway in self.get_models("global_protect_gateway"):
            tunnel_ms = self.get_models("global_protect_site_to_site_tunnel_settings")
            tunnel_settings = tunnel_ms.find(
                template_name=gateway.template_name, name=gateway.name + "-S"
            )
            if tunnel_settings is None:
                tunnel_configuration_enabled = False
                replay_attack_detection_enabled = False
                tunnel_monitoring_enabled = False
            else:
                tunnel_monitoring_enabled = tunnel_settings.tunnel_monitoring_enabled
                replay_attack_detection_enabled = (
                    tunnel_settings.replay_attack_detection_enabled
                )
                tunnel_configuration_enabled = True

            profile = self.get_models("ssl_tls_service_profile").find(
                template_name=gateway.template_name,
                location=gateway.location,
                name=gateway.ssl_tls_service_profile,
            )
            if profile is None:
                ssl_tls_service_profile_min_version = NONE
            else:
                ssl_tls_service_profile_min_version = profile.min_version

            configuration = {
                **gateway.to_dict(),
                "tunnel_configuration_enabled": tunnel_configuration_enabled,
                "replay_attack_detection_enabled": replay_attack_detection_enabled,
                "tunnel_monitoring_enabled": tunnel_monitoring_enabled,
                "ssl_tls_service_profile_min_version": ssl_tls_service_profile_min_version,
            }
            checks = []
            for method in self.get_checks():
                check = method(gateway)
                if check is not None:
                    checks.append(check)
            results.append(BestPracticeResult(configuration, checks))

        return results
