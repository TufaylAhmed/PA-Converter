import logging
from typing import List, Optional, Union

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote
from ....models.device.dynamic_updates import DynamicUpdatesModel


LOG = logging.getLogger(__name__)


class DynamicUpdatesAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > DynamicUpdatesAnalyzer"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.content_deltas = self.objects.system_info.get_content_deltas(
            self.objects.system_time
        )

    def _check_anti_virus(self, updates: DynamicUpdatesModel) -> BestPracticeWarning:
        check_attrs = self.check_info["188"]
        if updates.update_types["anti-virus"] is None:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="AV update is not configured.",
            )

        message_lst = []
        if updates.update_types["anti-virus"].recurrence != "hourly":
            message_lst.append("AV update recurrence is not set to hourly.")
        if updates.update_types["anti-virus"].action != "download-and-install":
            message_lst.append('AV update action is not set to "download-and-install".')
        if updates.update_types["anti-virus"].threshold != 0:
            message_lst.append("AV update should not have a threshold configured.")

        if message_lst:
            return BestPracticeWarning.get_check(
                **check_attrs, check_passed=False, check_message=" ".join(message_lst)
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_anti_virus_note(
        self, updates: DynamicUpdatesModel
    ) -> Optional[BestPracticeNote]:
        check_attrs = self.check_info["191"]
        if (
            updates.update_types["anti-virus"]
            and updates.update_types["anti-virus"].sync_to_peer
        ):
            return BestPracticeNote.get_check(
                **check_attrs,
                check_message="When using sync to peer, ensure that the minutes past the hour"
                " is not the same on the peer.",
            )

    def _check_anti_virus_content_note(
        self, updates: DynamicUpdatesModel
    ) -> Union[BestPracticeWarning, BestPracticeNote, None]:
        # Check does not apply to templates / stacks
        if updates.template_name is not None:
            return

        av_age = self.content_deltas.get("av-release-date")
        if av_age is None:
            return

        av_age_days = av_age / 86400
        check_attrs = self.check_info["238"]
        if av_age_days > 7:
            check_attrs["check_type"] = "Warning"
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="Antivirus content update version is over a week old.",
            )
        elif av_age_days > 1:
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Antivirus content update version is over a day old.",
            )

    def _check_apps_threats(self, updates: DynamicUpdatesModel) -> BestPracticeWarning:
        check_attrs = self.check_info["189"]
        if updates.update_types["threats"] is None:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="Apps & Threats update is not configured.",
            )

        message_lst = []
        if updates.update_types["threats"].recurrence not in [
            "every-30-mins",
            "hourly",
            "daily",
        ]:
            message_lst.append(
                "Apps & Threats update recurrence should be every 30 minutes, hourly or daily."
            )
        if updates.update_types["threats"].action != "download-and-install":
            message_lst.append(
                'Apps & Threats update action is not set to "download-and-install".'
            )
        if updates.update_types["threats"].threshold > 48:
            message_lst.append(
                "Apps & Threats update threshold is greater than 48 hours."
            )

        if message_lst:
            return BestPracticeWarning.get_check(
                **check_attrs, check_passed=False, check_message=" ".join(message_lst)
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_apps_threats_note(
        self, updates: DynamicUpdatesModel
    ) -> Optional[BestPracticeNote]:
        check_attrs = self.check_info["192"]
        if (
            updates.update_types["threats"]
            and updates.update_types["threats"].sync_to_peer
        ):
            return BestPracticeNote.get_check(
                **check_attrs,
                check_message="When using sync to peer, ensure that the minutes past the hour "
                "is not the same on the peer",
            )

    def _check_apps_threats_content_note(
        self, updates: DynamicUpdatesModel
    ) -> Union[BestPracticeWarning, BestPracticeNote, None]:
        # Check does not apply to templates / stacks
        if updates.template_name is not None:
            return

        age = self.content_deltas.get("app-release-date")
        if age is None:
            return

        age_days = age / 86400
        check_attrs = self.check_info["237"]
        if age_days > 30:
            check_attrs["check_type"] = "Warning"
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="Apps & Threats content update version is over a month old.",
            )
        elif age_days > 7:
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Apps & Threats content update version is over a week old.",
            )

    def _check_wildfire(self, updates: DynamicUpdatesModel) -> BestPracticeWarning:
        check_attrs = self.check_info["190"]
        if updates.update_types["wildfire"] is None:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="WildFire update is not configured.",
            )

        message_lst = []
        if updates.update_types["wildfire"].recurrence != "every-min":
            message_lst.append(
                'WildFire update recurrence should be set to "every minute".'
            )
        if updates.update_types["wildfire"].action != "download-and-install":
            message_lst.append(
                'WildFire update action is not set to "download-and-install".'
            )

        if message_lst:
            return BestPracticeWarning.get_check(
                **check_attrs, check_passed=False, check_message=" ".join(message_lst)
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_wildfire_content_note(
        self, updates: DynamicUpdatesModel
    ) -> Optional[BestPracticeWarning]:
        # Check does not apply to templates / stacks
        if updates.template_name is not None:
            return

        age = self.content_deltas.get("wildfire-release-date")
        if age is None:
            return

        age_days = age / 86400
        check_attrs = self.check_info["239"]
        if age_days > 1:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="WildFire content update version is over a day old.",
            )

    def _check_global_protect(
        self, updates: DynamicUpdatesModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["194"]
        if self.objects.tree.ngfw:
            if updates.update_types["global-protect-datafile"] is None:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message="GlobalProtect update is not configured.",
                )

            message_lst = []
            if updates.update_types["global-protect-datafile"].recurrence != "hourly":
                message_lst.append("GlobalProtect update recurrence should be hourly.")
            if (
                updates.update_types["global-protect-datafile"].action
                != "download-and-install"
            ):
                message_lst.append(
                    'GlobalProtect update action is not set to "download-and-install".'
                )

            if message_lst:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message=" ".join(message_lst),
                )
            else:
                return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_gp_clientless_vpn(
        self, updates: DynamicUpdatesModel
    ) -> BestPracticeWarning:
        """NOTE: GlobalProtect Clientless VPN Dynamic Update is only applicable to NGFWs
                 running PAN-OS 8.0+.
        """
        check_attrs = self.check_info["195"]
        if self.objects.tree.ngfw and self.objects.tree.version >= 8:
            if updates.update_types["global-protect-clientless-vpn"] is None:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message="GlobalProtect Clientless VPN update is not configured.",
                )

            message_lst = []
            if (
                updates.update_types["global-protect-clientless-vpn"].recurrence
                != "hourly"
            ):
                message_lst.append(
                    "GlobalProtect Clientless VPN update recurrence should be hourly."
                )
            if (
                updates.update_types["global-protect-clientless-vpn"].action
                != "download-and-install"
            ):
                message_lst.append(
                    'GlobalProtect Clientless VPN update action is not set to "download-and-install".'
                )

            if message_lst:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message=" ".join(message_lst),
                )
            else:
                return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_apps_and_threats_app_id_threshold(
        self, updates: DynamicUpdatesModel
    ) -> BestPracticeWarning:
        # APP-ID threshold is only in PAN OS 8.1+
        check_attrs = self.check_info["219"]
        if (
            updates.update_types["threats"] is not None
            and self.objects.tree.version >= 8.1
        ):
            message_lst = []
            if updates.update_types["threats"].new_app_threshold == 0:
                message_lst.append(
                    "Apps & Threats New App-ID Threshold for updates should be set to ensure you "
                    "have given sufficient time before New APP-IDs are installed in your network."
                )
            if message_lst:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message=" ".join(message_lst),
                )
            else:
                return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def get_checks(self) -> List:
        """For NGFWs, need to check license info to determine relevant checks."""
        if self.objects.tree.ngfw:
            checks = [
                "_check_anti_virus_content_note",
                "_check_apps_threats_content_note",
                "_check_wildfire_content_note",
            ]
            license_info = self.objects.license_info
            if license_info.has_active_license("WildFire License"):
                checks.append("_check_wildfire")
            if license_info.has_active_license("Threat Prevention"):
                checks.extend(
                    [
                        "_check_anti_virus",
                        "_check_anti_virus_note",
                        "_check_apps_threats",
                        "_check_apps_threats_note",
                        "_check_apps_and_threats_app_id_threshold",
                    ]
                )
            if license_info.has_active_gp_license():
                checks.extend(["_check_global_protect", "_check_gp_clientless_vpn"])
            return [getattr(self, check) for check in checks]
        return super().get_checks()
