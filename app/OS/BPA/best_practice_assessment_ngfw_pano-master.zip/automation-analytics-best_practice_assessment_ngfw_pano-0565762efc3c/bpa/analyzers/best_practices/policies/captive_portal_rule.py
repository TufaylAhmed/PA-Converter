from typing import Optional

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote
from ....models.device.authentication_profile import AuthenticationProfileModel
from ....models.device.authentication_sequence import AuthenticationSequenceModel
from ....models.utils.searching import (
    get_object_from_ancestors,
    get_objects_from_ancestors,
)


class CaptivePortalRuleAnalyzer(BestPracticesAnalyzer):

    # TODO: Sync with Samshodh on check_type and implementation
    def _check_internal_zones(
        self, captive_portal_rule
    ) -> Optional[BestPracticeWarning]:
        """
        Skip this check if action is no-captive-portal
        If default-browser-challenge > fail
        If default-web-form > pass
        If custom authentication enforcement with a method of web-form > pass
        If custom authentication enforcement with a method of browser-challenge and Kerberos auth profile > pass
        """
        check_id = "22"
        check_attrs = self.check_info[check_id]
        check = BestPracticeWarning.get_check(**check_attrs, check_passed=False)

        """Helper routines for _check_internal_zones"""

        def get_auth_object(location, auth_obj_name):
            """Get Auth Object with given name"""
            model_sets = {"object": self.objects.get("authentication_object")}
            return get_object_from_ancestors(
                model_manager=self.objects,
                location=location,
                model_set=model_sets["object"],
                name=auth_obj_name,
            )

        def get_auth_prof_seq(location, auth_prof_name):
            """Get Auth Profile or Sequence with given name"""
            model_sets = {
                "profile": self.objects.get("authentication_profile"),
                "sequence": self.objects.get("authentication_sequence"),
            }
            profiles = get_objects_from_ancestors(
                model_manager=self.objects,
                location=location,
                model_set=model_sets["profile"],
                name=auth_prof_name,
            )

            # Return first profile, since template_name cannot be provided.
            if profiles and len(profiles) > 0:
                return profiles[0]

            sequences = get_objects_from_ancestors(
                model_manager=self.objects,
                location=location,
                model_set=model_sets["sequence"],
                name=auth_prof_name,
            )

            # Return first sequence, since template_name cannot be provided.
            if sequences and len(sequences) > 0:
                return sequences[0]

        def using_kerberos_auth_prof(location, auth_prof_name):
            auth_prof_seq = get_auth_prof_seq(location, auth_prof_name)
            if isinstance(auth_prof_seq, AuthenticationProfileModel):
                return auth_prof_seq.method == "kerberos"
            elif isinstance(auth_prof_seq, AuthenticationSequenceModel):
                return any(
                    prof.method == "kerberos"
                    for prof in auth_prof_seq.auth_profile_objs
                )
            return False

        """Core logic for _check_internal_zones"""

        if captive_portal_rule.action.endswith("no-captive-portal"):
            return

        if captive_portal_rule.action in {"web-form", "default-web-form"}:
            check.check_passed = True
        elif captive_portal_rule.action in {
            "browser-challenge",
            "default-browser-challenge",
        }:
            check.check_passed = False
        else:
            # Custom Authentication Object is being used
            auth_object = get_auth_object(
                captive_portal_rule.location, captive_portal_rule.action
            )
            if auth_object:
                if auth_object.authentication_method == "web-form":
                    check.check_passed = True
                else:
                    check.check_passed = using_kerberos_auth_prof(
                        captive_portal_rule.location, auth_object.authentication_profile
                    )
        return check

    def _check_services(self, captive_portal_rule) -> BestPracticeWarning:
        """Warn if services are not set to any."""
        check_id = "23"
        check_attrs = self.check_info[check_id]
        if not all(service in captive_portal_rule.services for service in ["any"]):
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="Services not set to any"
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_no_action(self, captive_portal_rule) -> Optional[BestPracticeWarning]:
        """Note whether policy with no-captive-portal action is required."""
        check_id = "198"
        check_attrs = self.check_info[check_id]
        if captive_portal_rule.action.endswith("no-captive-portal"):
            return BestPracticeNote.get_check(
                **check_attrs,
                check_message="Action is currently set to no-captive-portal, so check whether the policy is still needed"
            )

    def _check_timeout(self, captive_portal_rule) -> Optional[BestPracticeNote]:
        """Skip note if PAN-OS < 8.0 or using custom authentication enforecement."""
        check_id = "211"
        check_attrs = self.check_info[check_id]
        if self.objects.tree.version < 8:
            return
        elif captive_portal_rule.action in {
            "default-web-form",
            "default-browser-challenge",
            "no-captive-portal",
        }:
            return
        if captive_portal_rule.timeout > 480:
            return BestPracticeNote.get_check(
                **check_attrs, check_message="Timeout should be <= 480 minutes."
            )
        return BestPracticeNote.get_check(
            **check_attrs,
            check_message=(
                "For DC or critical systems set low timeout values (60 mins). "
                "For perimeter access, set timeout up to 480 minutes."
            )
        )
