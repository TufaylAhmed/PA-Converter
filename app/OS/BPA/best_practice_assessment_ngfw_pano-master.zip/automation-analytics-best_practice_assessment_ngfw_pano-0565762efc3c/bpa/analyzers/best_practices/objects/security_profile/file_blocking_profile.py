# -*- coding: utf-8 -*-
from ...bp_check import BestPracticeWarning
from ...objects.security_profile.common import SecurityProfileAnalyzer
from .....models.objects.security_profile.file_blocking_profile import (
    FileBlockingProfileModel,
)


class FileBlockingProfileAnalyzer(SecurityProfileAnalyzer):
    """BestPracticesAnalyzer > FileBlockingProfileAnalyzer"""

    @classmethod
    def build_model_key(cls):
        """NOTE: Added since the model key is hardcoded"""
        return FileBlockingProfileModel.build_model_key()

    def _check_alert_file_types(
        self, profile: FileBlockingProfileModel
    ) -> BestPracticeWarning:
        check_id = "45"
        check_attrs = self.check_info[check_id]
        strict_file_types = {
            "7z",
            "bat",
            "cab",
            "chm",
            "class",
            "cpl",
            "dll",
            "exe",
            "flash",
            "hlp",
            "hta",
            "msi",
            "Multi-Level-Encoding",
            "ocx",
            "PE",
            "pif",
            "rar",
            "scr",
            "tar",
            "torrent",
            "vbe",
            "wsf",
            "encrypted-rar",
            "encrypted-zip",
            "jar",
        }
        correct_alert_rule = False
        message = []

        for rule in profile.rules:
            if rule.direction == "both" and "any" in rule.applications:
                if rule.action == "block" and "any" in rule.file_types:
                    return BestPracticeWarning.get_check(
                        **check_attrs, check_passed=True
                    )
                if rule.action == "alert" and "any" in rule.file_types:
                    correct_alert_rule = True
                elif rule.action == "block":
                    strict_file_types -= set(rule.file_types)
                elif rule.action == "continue":
                    # encrypted-rar and encrypted-zip can receive credit if action is continue
                    strict_file_types -= {
                        ft
                        for ft in rule.file_types
                        if ft in {"encrypted-rar", "encrypted-zip"}
                    }
        if not correct_alert_rule:
            message.append(
                "It is recommended to have a rule in your File Blocking Profile that meets the "
                "following criteria: Applications=any, File Types=any, Direction=both, "
                "Action=alert."
            )
        if strict_file_types:
            block_msg = (
                "It is recommended to add a rule to your File Blocking Profile that meets the "
                "following criteria: Applications=any, File Types={}, Direction=both, "
                "Action=block."
            ).format(", ".join(strict_file_types))
            message.append(block_msg)

        if message:
            return BestPracticeWarning.get_check(
                **check_attrs, check_passed=False, check_message=" ".join(message)
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
