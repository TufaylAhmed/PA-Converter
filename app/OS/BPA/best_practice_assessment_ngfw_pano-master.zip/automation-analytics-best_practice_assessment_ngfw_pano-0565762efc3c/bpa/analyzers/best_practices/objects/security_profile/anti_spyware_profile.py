# -*- coding: utf-8 -*-
from typing import Dict, Optional

from ...bp_check import BestPracticeWarning, BestPracticeNote
from ...objects.security_profile.common import SecurityProfileAnalyzer
from .....models.objects.security_profile.anti_spyware_profile import (
    AntiSpywareProfileModel,
)


class AntiSpywareProfileAnalyzer(SecurityProfileAnalyzer):
    """BestPracticesAnalyzer > AntiSpywareProfileAnalyzer"""

    @classmethod
    def build_model_key(cls):
        """NOTE: Added since the model key is hardcoded"""
        return AntiSpywareProfileModel.build_model_key()

    def get_configuration(self, model) -> Dict:
        """NOTE: Avoid duplicate data."""
        config = super().get_configuration(model)
        if self.objects.tree.version >= 9.0:
            config.pop("edl_domains")
        else:
            config.pop("dns_signatures")
        return config

    def _check_spyware_threat_exceptions(
        self, profile: AntiSpywareProfileModel
    ) -> Optional[BestPracticeNote]:
        """Checks if there are any spyware threat exceptions."""
        check_id = "36"
        check_attrs = self.check_info[check_id]
        if profile.spyware_threat_exceptions:
            return BestPracticeNote.get_check(
                **check_attrs,
                check_severity="Caution",
                check_message="Ensure you need threat exceptions. If there is a false positive, "
                "please open a support case with TAC to fix the issue.",
            )

    def _check_botnet_threat_exceptions(
        self, profile: AntiSpywareProfileModel
    ) -> Optional[BestPracticeNote]:
        """Checks if there are any botnet threat exceptions."""
        check_id = "37"
        check_attrs = self.check_info[check_id]
        if profile.botnet_threat_exceptions:
            return BestPracticeNote.get_check(
                **check_attrs,
                check_severity="Caution",
                check_message="Ensure you need threat exceptions for DNS Signatures. If there is a false positive, "
                "please open a support case with TAC to fix the issue.",
            )

    def _check_dns_sinkhole_enabled(
        self, profile: AntiSpywareProfileModel
    ) -> BestPracticeWarning:
        """Checks if dns sinkhole is enabled and properly configured.

        Fail if default EDL Domain has action other than sinkhole
        Fail if DNS Signature Packet Capture is disabled
        Fail if Sinkhole IPv4 is set to Loopback IP
        """
        check_attrs = self.check_info["38"]
        message = []

        if self.objects.tree.version < 9:
            bad_edls = [
                d.name
                for d in profile.edl_domains
                if d.action != "sinkhole" and d.name == "default-paloalto-dns"
            ]
            if bad_edls:
                message.append(
                    'The default EDL Domain has an action other than "sinkhole".'
                )

        if self.objects.tree.version < 9:
            if profile.dns_signature_packet_capture == "disable":
                message.append(
                    'The DNS Signature Packet Capture needs to be set to "single-packet".'
                )

        bad_signatures = []
        if self.objects.tree.version >= 9:
            for dns_signature in profile.dns_signatures:
                if dns_signature.packet_capture == "disable":
                    bad_signatures.append(dns_signature.name)

        if self.objects.tree.version >= 8:
            if getattr(profile, "sinkhole_ipv4", None) == "127.0.0.1":
                message.append("Sinkhole IPv4 is set to Loopback IP.")

        if bad_signatures:
            message.append(
                "Please enable packet capture for the following DNS Signatures: "
                + ", ".join(bad_signatures)
                + "."
            )

        if message:
            return BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=" ".join(message)
            )

        return BestPracticeWarning.passing(**check_attrs)

    def _check_passive_dns_monitoring_enabled(
        self, profile: AntiSpywareProfileModel
    ) -> Optional[BestPracticeWarning]:
        """Checks if passive dns monitoring is enabled."""
        if self.objects.tree.version < 8:
            if hasattr(profile, "passive_dns_monitoring_enabled"):
                check_id = "39"
                check_attrs = self.check_info[check_id]
                if not profile.passive_dns_monitoring_enabled:
                    return BestPracticeWarning.get_check(
                        **check_attrs,
                        check_passed=False,
                        check_message="It is recommended to have Passive DNS Monitoring enabled.",
                    )
                else:
                    return BestPracticeWarning.get_check(
                        **check_attrs, check_passed=True
                    )

    def _check_strict_profile(
        self, profile: AntiSpywareProfileModel
    ) -> BestPracticeWarning:
        """Apply strict AS check.

            Fail if AS Profile rulebase is missing a rule for critical/high/medium severity
            with a "passing" action, "any" category, and Packet Capture enabled.
        """
        check_attrs = self.check_info["40"]
        passing_actions = [
            "drop",
            "reset-both",
            "reset-client",
            "reset-server",
            "block-ip",
        ]
        severities = {"critical", "high", "medium"}
        for rule in profile.rules:
            if (
                rule.category == "any"
                and rule.packet_capture != "disable"
                and rule.action in passing_actions
            ):
                severities = severities - rule.get_severities()

        if severities:
            word = "severities" if len(severities) > 1 else "severity"
            passing_actions[-1] = "or " + passing_actions[-1]
            message = 'It is recommended to add the following rule {} with a {} action, "any" category, and "single-packet" packet capture configured: {}'.format(
                word, ", ".join(passing_actions), ", ".join(severities)
            )
            return BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=message
            )

        return BestPracticeWarning.passing(**check_attrs)

    def _check_low_info_profile(
        self, profile: AntiSpywareProfileModel
    ) -> BestPracticeWarning:
        """Checks profile rules to see if there is a reset-both action on
           informational and low severities.

           Since the action is default, DO NOT consider rules with 'any' severity
           configured as passing.

           NOTE: Recommended action is 'default', but any of the passing actions below are acceptable.
        """
        check_id = "201"
        check_attrs = self.check_info[check_id]
        passing_actions = [
            "default",
            "drop",
            "reset-both",
            "reset-client",
            "reset-server",
            "block-ip",
        ]
        missing_rules = {"informational", "low"}

        for rule in profile.rules:
            if rule.action in passing_actions and rule.category == "any":
                missing_rules -= rule.get_severities()

        if missing_rules:
            missing_rules = list(missing_rules)
            if len(missing_rules) == 1:
                severities = missing_rules[0] + " severity has"
            else:
                severities = " and ".join(missing_rules) + " severities have"

            message = (
                "It is recommended that {} the action set to 'default' for 'any' category"
            ).format(severities)
            return BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=message
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_reset_action(
        self, profile: AntiSpywareProfileModel
    ) -> Optional[BestPracticeNote]:
        """Checks if "reset-client" or "reset-server" actions are used in rules."""
        if any(
            rule
            for rule in profile.rules
            if rule.action in {"reset-client", "reset-server"}
        ):
            check_id = "206"
            check_attrs = self.check_info[check_id]
            return BestPracticeNote.get_check(
                **check_attrs,
                check_message='It is recommended to only use "reset-client" or "reset-server" actions '
                "if there is a specific business case.",
            )

    def _check_dns_cloud_security(
        self, profile: AntiSpywareProfileModel
    ) -> Optional[BestPracticeWarning]:
        if self.objects.tree.version < 9:
            return
        if self.objects.tree.panorama:
            return

        # NOTE: Skip if DNS Security license is either inactive or missing
        feature = "DNS Security"
        if feature not in self.objects.license_info:
            return
        if self.objects.license_info[feature].expired:
            return

        check_attrs = self.check_info["253"]

        bad_sigs = any(
            sig
            for sig in profile.dns_signatures
            if sig.name == "default-paloalto-cloud"
            and (sig.action != "sinkhole" or sig.packet_capture == "disable")
        )

        if bad_sigs:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message=(
                    "Configure DNS cloud security and set the action to Sinkhole"
                    " and packet capture to single packet."
                ),
            )

        return BestPracticeWarning.passing(**check_attrs)
