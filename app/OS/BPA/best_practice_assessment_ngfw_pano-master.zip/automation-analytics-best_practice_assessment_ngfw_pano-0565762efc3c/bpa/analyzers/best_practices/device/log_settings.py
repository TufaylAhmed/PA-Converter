from typing import Union

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote
from ....models.device.log_settings import (
    LogSettingsSystemModel,
    LogSettingsConfigModel,
)


class LogSettingsSystemAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > LogSettingsSystemAnalyzer"""

    def _check_log_send_to_info(
        self, system: LogSettingsSystemModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["177"]
        if not system.log_send_to_info and not system.log_send_to_all:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='A log setting has not been configured for the severity of "informational".'
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_log_send_to_low(
        self, system: LogSettingsSystemModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["178"]
        if not system.log_send_to_low and not system.log_send_to_all:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='A log setting has not been configured for the severity of "low".'
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_log_send_to_medium(
        self, system: LogSettingsSystemModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["179"]
        if not system.log_send_to_medium and not system.log_send_to_all:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='A log setting has not been configured for the severity of "medium".'
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_log_send_to_high(
        self, system: LogSettingsSystemModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["180"]
        if not system.log_send_to_high and not system.log_send_to_all:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='A log setting has not been configured for the severity of "high".'
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_log_send_to_critical(
        self, system: LogSettingsSystemModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["181"]

        if not system.log_send_to_critical and not system.log_send_to_all:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='A log setting has not been configured for the severity of "critical".'
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_log_send_to_critical_content_description(
        self, system: LogSettingsSystemModel
    ) -> Union[BestPracticeWarning, BestPracticeNote, None]:
        if self.objects.tree.version < 8:
            return

        check_attrs = self.check_info["222"]

        if system.critical_content_logs:
            return BestPracticeWarning.passing(**check_attrs)

        # Now the type of the return value will depend on BP 181 passing or failing
        bp_check_181 = self._check_log_send_to_critical(system)

        if bp_check_181.check_passed:
            best_practice_note = BestPracticeNote(
                **check_attrs,
                check_message="It is recommended to selectively monitor Content based Critical system logs"
                "and take necessary action"
            )
            return best_practice_note
        else:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to have a filter with syntax: (severity eq critical) and"
                " ( (description contains Content) or (description contains content) )"
            )


class LogSettingsConfigAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > LogSettingsConfigAnalyzer"""

    def _check_config_log(self, config: LogSettingsConfigModel) -> BestPracticeWarning:
        check_attrs = self.check_info["182"]
        if not config.config_logs_all and not config.config_logs_custom:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='A log setting has not been configured for the "Config" logs.'
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
