import logging

from ...bp_check import BestPracticeWarning
from .common import DeviceSetupAnalyzer


LOG = logging.getLogger(__name__)


class MinimumPasswordComplexitySettingsAnalyzer(DeviceSetupAnalyzer):
    """BestPracticesAnalyzer > DeviceSetupAnalyzer > MinimumPasswordComplexitySettingsAnalyzer"""

    target_attr = "min_password_complexity"

    @classmethod
    def build_analyzer_key(cls) -> str:
        return "device_setup_min_password_complexity"

    def _check_minimum_password_complexity_enabled(
        self, min_pw_complexity, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["103"]
        message = []

        if not min_pw_complexity.enabled:
            message.append("Minimum Password Complexity should be enabled.")
        if not min_pw_complexity.block_username_inclusion:
            message.append("Block Username Inclusion should be enabled.")
        if min_pw_complexity.minimum_length < 8:
            message.append("Minimum Length should be set to 8 or more.")
        if min_pw_complexity.minimum_uppercase_letters < 1:
            message.append("Minimum Uppercase Letters should be set to 1 or more.")
        if min_pw_complexity.minimum_lowercase_letters < 1:
            message.append("Minimum Lowercase Letters should be set to 1 or more.")

        if message:
            message = " ".join(message)
            return BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=message
            )
        return BestPracticeWarning.passing(**check_attrs)
