import logging
from collections import OrderedDict
from typing import List, Dict, Tuple, Union

from bpa.analyzers.best_practices.bp_result import BestPracticeResult
from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning
from ....models.device.scheduled_config_export import ScheduledConfigExportModel

LOG = logging.getLogger(__name__)


class ScheduledConfigExportAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > ScheduledConfigExportAnalyzer"""

    def _check_scheduled_config_export_configured(
        self, scheduled_config_exports: List[ScheduledConfigExportModel]
    ) -> Union[Tuple[BestPracticeWarning, Dict[str, list]], Tuple[bool, Dict]]:
        """
        Passing: if panorama, host_name, port, enable and scheduled_export_start_time are configured and enabled then pass
        Fail: if not panorama or no host_name or no port or not enable or not scheduled_export_start_time then fail

        """

        if not self.objects.tree.panorama:
            return False, {}
        check_attrs = self.check_info["268"]
        if not scheduled_config_exports:
            settings = {
                "scheduled_config_export": "Scheduled Config Export not configured"
            }
            return (
                BestPracticeWarning(
                    **check_attrs,
                    check_passed=False,
                    check_message="Scheduled Config Export not configured"
                ),
                settings,
            )
        all_scheduled_config_export = [
            scheduled_config_export.to_dict()
            for scheduled_config_export in scheduled_config_exports
        ]
        container_for_scheduled_config_export = []
        settings = {}
        for scheduled_config_export_data in all_scheduled_config_export:
            container_for_scheduled_config_export.append(
                OrderedDict(
                    {
                        "name": scheduled_config_export_data["name"],
                        "scheduled_export_start_time": scheduled_config_export_data[
                            "scheduled_export_start_time"
                        ],
                        "host_name": scheduled_config_export_data["host_name"],
                        "port": scheduled_config_export_data["port"],
                        "enable": scheduled_config_export_data["enable"],
                    }
                )
            )
        settings["scheduled_config_export"] = container_for_scheduled_config_export
        configure = set()
        enable = set()
        for scheduled_config_export in scheduled_config_exports:
            scheduled_config_export_data = {
                "host_name": True,
                "port": True,
                "enable": True,
                "scheduled_config_export_start_time": True,
            }
            if not scheduled_config_export.host_name:
                scheduled_config_export_data["host_name"] = False
                configure.add("hostname")
            if not scheduled_config_export.port:
                scheduled_config_export_data["port"] = False
                configure.add("port")
            if not scheduled_config_export.enable != "no":
                scheduled_config_export_data["enable"] = False
                enable.add("enable scheduled config export")
            if not scheduled_config_export.scheduled_export_start_time:
                scheduled_config_export_data[
                    "scheduled_config_export_start_time"
                ] = False
                configure.add("scheduled export start time(daily)")
            not_configured_data = [
                key for key, value in scheduled_config_export_data.items() if not value
            ]
            if not not_configured_data:
                return BestPracticeWarning.passing(**check_attrs), settings
        base_string = "It is recommended to "
        if configure:
            base_string += "configure "
        base_string += ", ".join(list(configure) + list(enable))
        return (
            BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=base_string
            ),
            settings,
        )

    def get_results(self) -> List[BestPracticeResult]:
        """Get list of results"""
        results = []
        models = list(self.get_models(self.build_model_key()))
        checks = []
        for method in self.get_checks():
            check, settings = method(models)
            if isinstance(check, BestPracticeWarning):
                checks.append(check)
                configuration = {**settings}
                results.append(BestPracticeResult(configuration, checks))
        return results
