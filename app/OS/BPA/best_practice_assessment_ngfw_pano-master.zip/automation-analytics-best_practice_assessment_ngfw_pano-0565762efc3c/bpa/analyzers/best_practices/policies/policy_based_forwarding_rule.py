from typing import Optional, Union

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote


class PolicyBasedForwardingRuleAnalyzer(BestPracticesAnalyzer):
    def _check_monitoring(
        self, policy_based_forwarding_rule
    ) -> Union[BestPracticeNote, BestPracticeWarning]:
        """
        Warn if monitor is disabled.

        Skip the check if action is no-pbf, since there is no option to enabled monitoring
        in that configuration.
        """
        check_id = "17"
        check_attrs = self.check_info[check_id]
        if policy_based_forwarding_rule.action == "forward":
            if not policy_based_forwarding_rule.monitor_enabled:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message="If you have a PBF Rule, then monitoring should be enabled and a profile should be configured."
                )
            else:
                return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
        else:
            return BestPracticeNote.get_check(
                **check_attrs,
                check_message='PBF checks only apply when the Action is configured to "Forward"'
            )

    def _check_forwarding_profile_ip(
        self, policy_based_forwarding_rule
    ) -> Optional[BestPracticeWarning]:
        """
        Warn if monitoring is enabled AND IP address is not configured.

        Skip the check if monitor is disabled.
        """
        check_id = "18"
        check_attrs = self.check_info[check_id]
        if policy_based_forwarding_rule.monitor_enabled:
            if policy_based_forwarding_rule.ip_address is None:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message="Monitoring is enabled, but an IP Address is not configured."
                )
            else:
                return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
