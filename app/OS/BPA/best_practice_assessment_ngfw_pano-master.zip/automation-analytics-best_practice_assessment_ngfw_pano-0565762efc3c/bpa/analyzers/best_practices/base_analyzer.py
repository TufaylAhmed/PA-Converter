import inspect
import os
import weakref
from abc import ABCMeta
from typing import Dict, List, Union

from bpa.utils.common import common_key
from bpa.models.mixins import TemplateMixin
from bpa.models.model_set import ModelSet

from .bp_result import BestPracticeResult


class BestPracticesAnalyzer(metaclass=ABCMeta):
    """Best Practices Analyzer.

    All analyzers should have at least one _check method. By default, each
    _check method expects a single model instance as its parameter. If
    the `get_results` method gets overridden by a custom analyzer,
    the _check methods can accept any number of parameters.

    Attributes:
        model_manager: Weak reference to ModelManager.
        check_info: Check information as a dictionary.
    """

    def __init__(self, model_manager: weakref.ReferenceType, check_info: Dict):
        self.model_manager = model_manager
        self.check_info = check_info

    @property
    def objects(self):
        """Helper to call the model_manager weakref."""
        return self.model_manager()

    @property
    def stacks(self):
        """Helper to get template stack names."""
        return [
            ts.name
            for ts in self.objects.get("template_stack")
            if len(ts.templates) > 0
        ]

    @property
    def templates(self):
        """Helper to get template names."""
        return [t.name for t in self.objects.get("template")]

    @classmethod
    def folder(cls):
        """Provides rough approximation of the analyzer category.

        NOTE: Assume that the following best_practices folder
        follows child folders under it, and all analyzers fall
        under each child folder.

        Raises:
            AttributeError if directly executed from the BaseAnalyzer.
        """
        fp = inspect.getfile(cls)
        path_lst = os.path.normpath(fp).split(os.path.sep)
        target_index = path_lst.index("best_practices") + 1
        return path_lst[target_index]

    @classmethod
    def build_analyzer_key(cls) -> str:
        return common_key(cls)

    @classmethod
    def build_model_key(cls) -> str:
        return common_key(cls)

    def get_checks(self) -> List:
        """Get list of checks"""
        return [
            getattr(self, method) for method in dir(self) if method.startswith("_check")
        ]

    def run_checks(self) -> List:
        """Get list of check results"""
        checks = []
        for check in self.get_checks():
            output = check()
            if output is not None:
                checks.append(output)
        return checks

    def get_configuration(self, model) -> Dict:
        return model.to_dict()

    def get_models(self, model_key) -> Union[List, ModelSet]:
        """Get models.

        If template stack is needed:
            Find template stacks with tied to model_key
            with devices and where template name is none.
            Retrieve models from each of the template stacks
            and get models where template_name is None.
        Otherwise:
            Simply retrieve models from model set.

        Returns:
            ModelSet instance with relevant models.
        """
        # Step 1: Ignore template stacks if not applicable
        if (
            not issubclass(self.objects.model_lookup[model_key], TemplateMixin)
            or self.objects.tree.ngfw
            or self.objects.tree.version < 8.1
        ):
            return self.objects.get(model_key)

        # Step 2: Build model set from scratch
        results = ModelSet()

        # Step 3: Add model entries under template stacks
        for template_stack in self.objects.get("template_stack"):
            if len(template_stack.devices) > 0:
                results.extend(template_stack.get(model_key))

        # Step 4: Add model entries under Panorama
        results.extend(self.objects.get(model_key).findall(template_name=None))

        # Step 5: Return built model set
        return results

    def get_results(self) -> List[BestPracticeResult]:
        """Get list of results"""
        results = []
        for model in self.get_models(self.build_model_key()):
            configuration = self.get_configuration(model)
            checks = []
            for method in self.get_checks():
                check = method(model)
                if check is not None:
                    checks.append(check)
            results.append(BestPracticeResult(configuration, checks))
        return results
