from typing import Optional

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning
from ....models.network.gre_tunnel import GreTunnelModel


class GreTunnelAnalyzer(BestPracticesAnalyzer):
    """Applies only to PAN-OS versions 9.0 and above."""

    def _check_keep_alive_enabled(
        self, gre_tunnel: GreTunnelModel
    ) -> Optional[BestPracticeWarning]:
        if self.objects.tree.version < 9:
            return
        check_attrs = self.check_info["246"]
        if gre_tunnel.keep_alive_enable is False:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="Configure Keep-alive for GRE tunnel stability and monitoring."
            )
        return BestPracticeWarning.passing(**check_attrs)
