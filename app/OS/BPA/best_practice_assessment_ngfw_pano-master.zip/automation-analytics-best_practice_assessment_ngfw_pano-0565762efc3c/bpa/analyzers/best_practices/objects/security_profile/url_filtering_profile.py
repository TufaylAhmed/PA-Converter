# -*- coding: utf-8 -*-
import logging
from typing import Optional, Union

from ...bp_check import BestPracticeNote, BestPracticeWarning
from ...objects.security_profile.common import SecurityProfileAnalyzer
from .....models.objects.security_profile.url_filtering_profile import (
    UrlFilteringProfileModel,
)


LOG = logging.getLogger(__name__)


class UrlFilteringProfileAnalyzer(SecurityProfileAnalyzer):
    """BestPracticesAnalyzer > UrlFilteringProfileAnalyzer"""

    @classmethod
    def build_model_key(cls):
        """NOTE: Added since the model key is hardcoded"""
        return UrlFilteringProfileModel.build_model_key()

    def _check_allow_categories(
        self, profile: UrlFilteringProfileModel
    ) -> BestPracticeWarning:
        check_id = "196"
        check_attrs = self.check_info[check_id]
        if profile.site_access_categories["allow"]:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='It is not recommended to have any URL categories with an action of "allow" '
                'and to instead set action to "alert" at a minimum.'
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_block_categories(
        self, profile: UrlFilteringProfileModel
    ) -> BestPracticeWarning:
        check_id = "43"
        check_attrs = self.check_info[check_id]
        block_only_categories = {
            "paloaltonetworks": {
                "hacking",
                "malware",
                "phishing",
                "proxy-avoidance-and-anonymizers",
                "command-and-control",
                "unknown",
                "dynamic-dns",
                "extremism",
                "copyright-infringement",
                "parked",
                "grayware",
            },
            "brightcloud": {
                "hacking",
                "confirmed-spam-sources",
                "unconfirmed-spam-sources",
                "keyloggers-and-monitoring",
                "malware-sites",
                "spam-urls",
                "spyware-and-adware",
                "phishing-and-other-frauds",
                "open-http-proxies",
                "proxy-avoidance-and-anonymizers",
                "cheating",
                "gross",
                "violence",
                "bot-nets",
                "unknown",
                "hate-and-racism",
                "illegal",
                "parked-domains",
                "dead-sites",
            },
        }

        missing_block_categories = block_only_categories[self.objects.tree.urldb] - set(
            profile.site_access_categories["block"]
        )
        if missing_block_categories:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="The following categories should be blocked: {}.".format(
                    ", ".join(missing_block_categories)
                )
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_url_profile_settings(
        self, profile: UrlFilteringProfileModel
    ) -> BestPracticeWarning:
        check_id = "44"
        check_attrs = self.check_info[check_id]
        if not profile.log_container_page_only_enabled:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='The "Log container page only" setting should be enabled.'
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_credential_theft(
        self, profile: UrlFilteringProfileModel
    ) -> Optional[BestPracticeWarning]:
        """
        1) NO Credential Enforcement Categories should be set to "allow"
        2) At least ONE Credential Enforcement Category should be set to "block"
        3) Log Severity should be set to medium, high, or critical
        """
        check_id = "207"
        check_attrs = self.check_info[check_id]

        if self.objects.tree.version < 8:
            return

        error_lst = []

        if profile.credential_enforcement.categories["allow"]:
            error_lst.append(
                'No categories should have a User Credential Submission action of "Allow".'
            )

        if not profile.credential_enforcement.categories["block"]:
            error_lst.append(
                "URL categories vulnerable to credential phishing should have a "
                'User Credential Submission action of "Block".'
            )

        if profile.credential_enforcement.log_severity in ["low", "informational"]:
            error_lst.append(
                "Log Severity should be set to medium, high, or critical.")

        if error_lst:
            return BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=" ".join(error_lst)
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_credential_phishing_mode(
        self, profile: UrlFilteringProfileModel
    ) -> Optional[Union[BestPracticeNote, BestPracticeWarning]]:
        check_id = "227"
        check_attrs = self.check_info[check_id]

        if self.objects.tree.version < 8:
            return

        if profile.credential_enforcement.mode == "disabled":
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="User Credential Detection should be enabled."
            )
        elif profile.credential_enforcement.mode in ["ip-user", "group-mapping"]:
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="It is best to use Domain Credential Filter"
            )
        elif profile.credential_enforcement.mode == "domain-credentials":
            return BestPracticeWarning.passing(**check_attrs)
        else:
            raise ValueError("Unknown phishing mode detected")

    # TODO: Wait for Samshodh to define license info criteria for all
    #       security profiles before implementing.
    # def get_checks(self) -> List:
    #     """On NGFWs using BrightCloud, only evaluate URL Filtering Profile checks if there is an active
    #     BrightCloud URL Filtering license."""
    #     if self.objects.tree.ngfw and self.objects.tree.urldb == 'brightcloud':
    #         if not self.objects.license_info.has_active_license('BrightCloud URL Filtering'):
    #             LOG.debug('No active BrightCloud license, so skipping URL Filtering Profile checks')
    #             return []
    #     return super().get_checks()
