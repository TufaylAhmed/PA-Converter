from typing import List, Optional

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeNote
from ..bp_result import BestPracticeResult
from ....models.device.template import TemplateModel
from ....models.device.template_stack import TemplateStackModel


class TemplateAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > TemplateAnalyzer"""

    def build_model_key(self):
        if self.objects.tree.version >= 8.1:
            return "template_stack"
        else:
            return "template"

    def _check_template_for_devices(
        self, templates: List[TemplateModel]
    ) -> Optional[BestPracticeNote]:
        check_attrs = self.check_info["225"]
        bad_templates = [
            template.name for template in templates if len(template.devices) == 0
        ]
        if len(bad_templates) > 0:
            return BestPracticeNote(
                **check_attrs,
                check_message=(
                    f'The following templates have no devices attached: {", ".join(bad_templates)}.'
                ),
            )

    def _check_stack_for_devices(
        self, stacks: List[TemplateStackModel]
    ) -> Optional[BestPracticeNote]:
        check_attrs = self.check_info["226"]
        bad_stacks = [stack.name for stack in stacks if len(stack.devices) == 0]
        if len(bad_stacks) > 0:
            return BestPracticeNote(
                **check_attrs,
                check_message=(
                    f'The following template stacks have no devices attached: {", ".join(bad_stacks)}.'
                ),
            )

    def get_results(self) -> List[BestPracticeResult]:
        if self.objects.tree.ngfw:
            return []
        models = self.get_models(self.build_model_key())
        configuration = {}
        templates = [model.to_dict() for model in models]
        checks = []
        if self.objects.tree.version >= 8.1:
            check = self._check_stack_for_devices(models)
            label = "template_stacks"
        else:
            check = self._check_template_for_devices(models)
            label = "templates"
        if check is not None:
            checks.append(check)
        configuration[label] = templates
        return [BestPracticeResult(configuration, checks)]
