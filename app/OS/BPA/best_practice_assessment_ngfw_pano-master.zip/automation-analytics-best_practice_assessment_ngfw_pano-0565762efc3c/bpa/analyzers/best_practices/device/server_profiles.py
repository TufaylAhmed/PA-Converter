import logging

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning
from ....models.device.server_profiles import (
    SnmpTrapServerProfileModel,
    SyslogServerProfileModel,
    LdapServerProfileModel,
    RadiusServerProfileModel,
    TacPlusServerProfileModel,
)


LOG = logging.getLogger(__name__)


class SnmpTrapServerProfileAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > SnmpTrapServerProfileAnalyzer"""

    def _check_version(
        self, profile: SnmpTrapServerProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["183"]
        if profile.version == "v2c":
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to set Version to "V3"'
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_admin_password_profile(
        self, profile: SnmpTrapServerProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["184"]
        if profile.community in ("PUBLIC", "PRIVATE"):
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='It is not recommended to set Community to "PUBLIC" or "PRIVATE" when using Version "V2c"'
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)


class SyslogServerProfileAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > SyslogServerProfileAnalyzer"""

    def _check_transport(
        self, profile: SyslogServerProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["185"]
        if profile.transport != "SSL":
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to set Transport to "SSL"'
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)


class LdapServerProfileAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > LdapServerProfileAnalyzer"""

    def _check_require_ssl_tls_secured_connection(
        self, profile: LdapServerProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["186"]
        if not profile.require_ssl_tls_secured_connection:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to enable "Require SSL/TLS secured connection"'
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_verify_server_certificate_for_ssl_sessions(
        self, profile: LdapServerProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["187"]
        if not profile.verify_server_certificate_for_ssl_sessions:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to enable "Verify Server Certificate for SSL sessions"'
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_server_redundancy(
        self, profile: LdapServerProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["199"]
        if len(profile.server_list) < 2:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to have two or more servers in the server list"
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)


class RadiusServerProfileAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > RadiusServerProfileAnalyzer"""

    def _check_protocol(self, profile: RadiusServerProfileModel) -> BestPracticeWarning:
        check_attrs = self.check_info["233"]
        if "EAP" not in profile.protocol:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to set Protocol to EAP"
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)


class TacPlusServerProfileAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > TacPlusServerProfileAnalyzer"""

    def _check_protocol(
        self, profile: TacPlusServerProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["234"]
        if profile.protocol != "CHAP":
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to set Protocol to CHAP"
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
