from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning
from ..bp_result import BestPracticeResult
from ....models.constants import NONE
from ....models.utils.searching import get_objects_from_mapping


class DecryptionRuleAnalyzer(BestPracticesAnalyzer):
    def _check_profile(self, decryption_rule) -> BestPracticeWarning:
        check_id = "19"
        check_attrs = self.check_info[check_id]
        if decryption_rule.decryption_profile == NONE:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended for a Decryption Profile to be configured"
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)


class DecryptionRulebaseAnalyzer(BestPracticesAnalyzer):
    def _check_ssh_proxy_ssh_tunnel(
        self, decryption_rules, security_rules
    ) -> BestPracticeWarning:
        check_id = "20"
        check_attrs = self.check_info[check_id]
        settings = {
            "ssh_proxy_decrypt_rule_exists": False,
            "ssh_security_allow_rule_exists": False,
            "ssh_tunnel_security_deny_rule_exists": False,
            "decryption_rules": any([rule.to_dict() for rule in decryption_rules]),
            "security_rules": any([rule.to_dict() for rule in security_rules]),
        }

        settings["ssh_proxy_decrypt_rule_exists"] = any(
            dr.rule_type == "ssh-proxy" for dr in decryption_rules
        )

        for sr in security_rules:
            if sr.action == "allow" and "ssh" in sr.applications:
                settings["ssh_security_allow_rule_exists"] = True
            elif sr.action != "allow" and "ssh-tunnel" in sr.applications:
                settings["ssh_tunnel_security_deny_rule_exists"] = True

        passing = all(settings.values())
        message = (
            (
                "It is recommended to configure SSH Proxy to detect and block SSH Tunneling "
                "and to limit user access to SSH traffic"
            )
            if passing is False
            else None
        )

        result = (
            BestPracticeWarning(
                **check_attrs, check_passed=passing, check_message=message
            ),
            settings,
        )
        return result

    def get_results(self):
        dr_ms_map = self.objects.get("decryption_rule").group_by("location")
        sr_ms_map = self.objects.get("security_rule").group_by("location")
        results = []
        for location in self.objects.tree.locations:
            keys = [(ancestor,) for ancestor in self.objects.tree.ancestors[location]]
            decryption_rules = get_objects_from_mapping(keys, dr_ms_map)
            security_rules = get_objects_from_mapping(keys, sr_ms_map)
            check, settings = self._check_ssh_proxy_ssh_tunnel(
                decryption_rules, security_rules
            )
            configuration = {"location": location, **settings}
            results.append(
                BestPracticeResult(checks=[check], configuration=configuration)
            )

        return results
