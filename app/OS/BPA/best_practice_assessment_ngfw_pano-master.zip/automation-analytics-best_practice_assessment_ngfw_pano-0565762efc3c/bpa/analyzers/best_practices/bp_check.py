from abc import ABCMeta, abstractmethod
from typing import Optional

from dataclasses import dataclass


@dataclass
class BestPracticeCheck(metaclass=ABCMeta):
    """An individual best practice check.

    This is an abstract class, which is not meant to be initialized
    on its own. Rather, you must initialize one of its sub-classes::

        - BestPracticeWarning
            - SecurityRuleWarning
        - BestPracticeNote

    Each of the subclasses have their own unique attributes for
    different use cases.

    Attributes:
        check_id: Check identifier.
        check_name: Check name.
        check_type: Check type.
        check_message: Check message.
    """

    check_id: int
    check_name: str
    check_type: str
    check_message: Optional[str]

    @abstractmethod
    def __bool__(self):
        """bool relates to nothing."""
        return True

    @classmethod
    def get_check(cls, **kwargs):
        """Factory method for retrieving correct check.

        You must run this routine via a subclass of BestPracticeCheck.
        This helps improve the clarity of the analyzer checks
        that the team continues to develop.

        Returns:
            A subclass of BestPracticeCheck.

        Raises:
            TypeError if called via BestPracticeCheck.
        """

        # https://stackoverflow.com/questions/3862310/how-to-find-all-the-subclasses-of-a-class-given-its-name
        def all_subclasses(cls):
            return set(cls.__subclasses__()).union(
                [s for c in cls.__subclasses__() for s in all_subclasses(c)]
            )

        if cls is BestPracticeCheck:
            subclasses = [kls.__name__ for kls in all_subclasses(cls)]
            raise TypeError(f"Run this routine via a subclass: {subclasses}")

        # NOTE: Not all checks have a valid check_message
        kwargs.setdefault("check_message", None)

        return cls(**kwargs)


@dataclass
class BestPracticeWarning(BestPracticeCheck):
    """An individual best practice warning."""

    check_passed: bool

    def __bool__(self):
        """bool relates to check_passed."""
        return self.check_passed

    @classmethod
    def passing(cls, **kwargs):
        """Generate passing BestPracticeWarning.

        Helper method so you do not need to pass a check_passed or check_message argument
        when BestPracticeWarning instance is passing.
        """
        attrs = {"check_passed": True, "check_message": None, **kwargs}
        return cls(**attrs)


@dataclass
class SecurityRuleWarning(BestPracticeWarning):
    """An individual security rule warning."""

    check_excluded: bool = False
    check_passed: Optional[bool] = None

    def __bool__(self):
        """bool relates to check_passed and check_excluded."""
        if self.check_excluded or self.check_passed is None:
            return True
        return super().__bool__()


@dataclass
class BestPracticeNote(BestPracticeCheck):
    """An individual best practice note.
    Attributes:
        check_severity : Check severity can be either 'Info' or 'Caution' but is 'Info' by default
    """

    check_severity: str = "Info"

    def __bool__(self):
        """bool borrows from BestPracticeCheck."""
        return super().__bool__()
