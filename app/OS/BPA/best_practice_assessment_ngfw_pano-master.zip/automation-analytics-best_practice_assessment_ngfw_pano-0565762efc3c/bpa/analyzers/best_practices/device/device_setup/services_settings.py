import copy
import logging
from typing import Optional

from ...bp_check import BestPracticeWarning
from .common import DeviceSetupAnalyzer


LOG = logging.getLogger(__name__)


class ServicesSettingsAnalyzer(DeviceSetupAnalyzer):
    """BestPracticesAnalyzer > DeviceSetupAnalyzer > ManagementInterfaceSettingsAnalyzer"""

    target_attr = "services"

    @classmethod
    def build_analyzer_key(cls) -> str:
        return "device_setup_services"

    def get_configuration(self, model, device_setup):
        config = copy.deepcopy(super().get_configuration(model, device_setup))
        if self.objects.tree.version < 9.0:
            config.pop("fqdn_refresh_time")
        return config

    def _check_verify_update_server_identity_enabled(
        self, services_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["104"]
        if not services_settings.verify_update_server_identity_enabled:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to enable Verify Update Server Identity",
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_ntp_server_address(
        self, services_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["105"]
        if not all(
            [
                services_settings.primary_ntp_server_address,
                services_settings.secondary_ntp_server_address,
            ]
        ):
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to configure a primary and secondary NTP Server Address",
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_ntp_server_auth_type(
        self, services_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["106"]
        auth_types = [
            services_settings.primary_ntp_server_auth_type,
            services_settings.secondary_ntp_server_auth_type,
        ]
        if any(auth_type is None for auth_type in auth_types):
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to configure a primary and secondary NTP Server Authentication Type",
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_fqdn_refresh_time(
        self, services_settings, device_setup
    ) -> Optional[BestPracticeWarning]:
        check_attrs = self.check_info["245"]
        if self.objects.tree.version < 9:
            return
        if services_settings.fqdn_refresh_time > 30:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="Set the FQDN refresh time to 30 seconds or less to have latest results from DNS.",
            )
        return BestPracticeWarning.passing(**check_attrs)
