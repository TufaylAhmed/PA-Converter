import copy
from typing import Optional

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote
from ....models.device.user_id import UserIdModel


class UserIdAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > UserIdAnalyzer"""

    def get_configuration(self, model):
        config = copy.deepcopy(super().get_configuration(model))
        if self.objects.tree.version < 9.0:
            for monitor in config["server_monitors"]:
                monitor.pop("transport_protocol")
        return config

    def _check_included_networks(self, user_id: UserIdModel) -> BestPracticeWarning:
        check_attrs = self.check_info["161"]
        if not user_id.include_networks:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to have at least one Include Network defined",
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_user_id(self, user_id: UserIdModel) -> BestPracticeNote:
        check_attrs = self.check_info["176"]
        return BestPracticeNote.get_check(
            **check_attrs,
            check_message="Use a dedicated server account for user ID with minimal permissions necessary",
        )

    def _check_server_log_monitor_frequency(
        self, user_id: UserIdModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["163"]
        if not (2 <= user_id.server_log_monitor_frequency <= 30):
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="Server Log Monitor Frequency should be set to a value between 2 and 30 seconds",
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_probing_enabled(self, user_id: UserIdModel) -> BestPracticeWarning:
        check_attrs = self.check_info["164"]
        if user_id.probing_enabled:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is not recommended to enable probing",
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_user_id_timeout_enabled(
        self, user_id: UserIdModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["165"]
        if not user_id.user_id_timeout_enabled:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is not recommended to disable User ID Timeout",
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_user_id_timeout_warning(
        self, user_id: UserIdModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["166"]
        if user_id.user_id_timeout < 60:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to set User ID Timeout to a value greater than 60 minutes",
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_user_id_timeout_note(
        self, user_id: UserIdModel
    ) -> Optional[BestPracticeNote]:
        check_attrs = self.check_info["210"]
        if user_id.user_id_timeout_enabled:
            return BestPracticeNote.get_check(
                **check_attrs,
                check_message="User ID Timeout should be set to the half-life of DHCP or the Kerberos ticket lifetime.",
            )

    def _check_server_monitors(self, user_id: UserIdModel) -> BestPracticeWarning:
        check_attrs = self.check_info["167"]
        if len(user_id.server_monitors) < 2:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to have two or more User ID Monitored Servers defined.",
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_included_groups(self, user_id: UserIdModel) -> BestPracticeWarning:
        check_attrs = self.check_info["169"]
        missing_included_groups = [
            group_mapping.name
            for group_mapping in user_id.group_mappings
            if not group_mapping.included_groups_used
        ]

        if missing_included_groups:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="The following Group Mappings are missing Included Groups: {}".format(
                    ", ".join(missing_included_groups)
                ),
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_captive_portal_enabled(
        self, user_id: UserIdModel
    ) -> Optional[BestPracticeWarning]:
        check_attrs = self.check_info["171"]
        if user_id.captive_portal_setting is None:
            return None

        if not user_id.captive_portal_setting.enabled:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="Captive Portal should be enabled",
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_captive_portal_mode(
        self, user_id: UserIdModel
    ) -> Optional[BestPracticeWarning]:
        check_attrs = self.check_info["172"]
        if user_id.captive_portal_setting is None:
            return None

        if user_id.captive_portal_setting.mode != "redirect":
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='Captive Portal Mode should be set to "Redirect"',
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_captive_portal_session_cookie_timeout(
        self, user_id: UserIdModel
    ) -> Optional[BestPracticeWarning]:
        check_attrs = self.check_info["173"]
        if (
            user_id.captive_portal_setting is None
            or not user_id.captive_portal_setting.session_cookie_enabled
        ):
            return None

        if user_id.captive_portal_setting.session_cookie_timeout > 480:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is not recommended to enable Captive Portal Session Cookie with a Timeout greater than 480",
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_captive_portal_ssl_tls_service_profile(
        self, user_id: UserIdModel
    ) -> Optional[BestPracticeWarning]:
        check_attrs = self.check_info["174"]
        if user_id.captive_portal_setting is None:
            return None

        if (
            user_id.captive_portal_setting.ssl_tls_service_profile_min_version
            != "tls1-2"
        ):
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended for the SSL/TLS Service Profile to have a Min version of TLSv1.2",
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_connection_security_configured(
        self, user_id: UserIdModel
    ) -> Optional[BestPracticeWarning]:
        check_attrs = self.check_info["231"]

        user_id_configured = len(user_id.user_id_agents) > 0
        terminal_services_configured = len(user_id.terminal_services_agents) > 0

        agents_configured = user_id_configured or terminal_services_configured

        if not agents_configured:
            return

        agents_type = (
            "User ID Agents" if user_id_configured else "Terminal Services Agents"
        )

        if agents_configured and not user_id.connection_security_configured:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message=f"Please enable Connection Security for {agents_type}",
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_custom_group(self, user_id: UserIdModel) -> Optional[BestPracticeNote]:
        check_attrs = self.check_info["232"]

        if self.objects.tree.version < 8.0:
            return

        if not user_id.group_mappings:
            return

        if any(len(gm.custom_groups) > 0 for gm in user_id.group_mappings):
            return BestPracticeNote.get_check(
                **check_attrs,
                check_severity="Info",
                check_message="Please check whether security rules are using custom groups",
            )

        return BestPracticeNote.get_check(
            **check_attrs,
            check_severity="Caution",
            check_message="Custom groups in group mapping help to allow user traffic based on user attributes",
        )

    def _check_transport_protocol(
        self, user_id: UserIdModel
    ) -> Optional[BestPracticeWarning]:
        check_attrs = self.check_info["244"]

        if self.objects.tree.version < 9.0:
            return

        bad_monitors = []
        for monitor in user_id.server_monitors:
            if "WinRM-HTTP" not in monitor.transport_protocol:
                bad_monitors.append(monitor.name)

        if bad_monitors:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message=(
                    "Please configure transport protocol to be WinRM-HTTP or WinRM-HTTPS "
                    f'for the following server monitors: {", ".join(bad_monitors)}'
                ),
            )

        return BestPracticeWarning.passing(**check_attrs)
