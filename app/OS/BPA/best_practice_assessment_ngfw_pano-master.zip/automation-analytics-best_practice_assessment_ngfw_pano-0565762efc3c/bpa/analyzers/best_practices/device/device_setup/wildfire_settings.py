import logging
from typing import List, Optional, Union

from ...bp_check import BestPracticeNote, BestPracticeWarning
from ...bp_result import BestPracticeResult
from .common import DeviceSetupAnalyzer


LOG = logging.getLogger(__name__)


class WildfireSettingsAnalyzer(DeviceSetupAnalyzer):
    """BestPracticesAnalyzer > DeviceSetupAnalyzer > WildfireSettingsAnalyzer"""

    target_attr = "wildfire"

    @classmethod
    def build_analyzer_key(cls) -> str:
        return "device_setup_wildfire"

    def get_results(self) -> List[BestPracticeResult]:
        """Get list of results

        NOTE: WildFire Settings checks only apply to NGFWs and device templates.
        """
        results = super().get_results()
        if self.objects.tree.panorama:
            results = [
                result
                for result in results
                if result.configuration["template_name"] is not None
            ]
        return results

    def get_limit_check(
        self, limit_key, tversion, wildfire_settings, check_attrs
    ) -> Union[BestPracticeNote, BestPracticeWarning]:
        if tversion < 9:
            expected_limits = wildfire_settings.size_limits.get_expected_limits()
            current_value = wildfire_settings.size_limits[limit_key]
            default_or_expected_value = expected_limits[limit_key]
            comparison_result = wildfire_settings.size_limits.compare_helper(
                current_value=current_value, expected_value=default_or_expected_value
            )

        else:
            default_or_expected_value = wildfire_settings.size_limits.get_default_size(
                tversion, limit_key
            )
            comparison_result = wildfire_settings.size_limits.compare_to_default(
                tversion, limit_key
            )

        if comparison_result == -1:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message=(
                    f'It is recommended to set the file size limit for "{limit_key}" to a value of'
                    f" {default_or_expected_value}"
                ),
            )
        elif comparison_result == 0:
            return BestPracticeWarning.passing(**check_attrs)
        else:
            result = BestPracticeNote(
                **check_attrs,
                check_message=(
                    f"The default size limit is {default_or_expected_value} for this file type and it"
                    " helps ensure all file types get equal priority to be sent for"
                    " inspection"
                ),
            )
            # result.check_type = "Note"
            return result

    def _check_wildfire_public_cloud_note(
        self, wildfire_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if (
            wildfire_settings.wildfire_public_cloud == "wildfire.paloaltonetworks.com"
            and wildfire_settings.timezone is not None
        ):
            check_attrs = self.check_info["119"]
            message = "It is recommended to use the {cloud} if the device is located in {region}."
            if wildfire_settings.timezone.startswith("Europe"):
                message = message.format(
                    cloud="EU Wildfire Cloud (eu.wildfire.paloaltonetworks.com)",
                    region="the EU",
                )
            elif wildfire_settings.timezone == "Japan":
                message = message.format(
                    cloud="Japan Wildfire Cloud (jp.wildfire.paloaltonetworks.com)",
                    region="Japan",
                )
            elif wildfire_settings.timezone in ["Singapore", "Asia/Singapore"]:
                message = message.format(
                    cloud="Singapore Wildfire Cloud (sg.wildfire.paloaltonetworks.com)",
                    region="Singapore",
                )
            else:
                message = message.format(
                    cloud=(
                        "EU Wildfire Cloud (eu.wildfire.paloaltonetworks.com), "
                        "Japan Wildfire Cloud (jp.wildfire.paloaltonetworks.com), or "
                        "Singapore Wildfire Cloud (sg.wildfire.paloaltonetworks.com)"
                    ),
                    region="the EU, Japan, or Singapore respectively",
                )
            return BestPracticeNote(**check_attrs, check_message=message)

    def _check_pe_size_limit_warn(
        self, wildfire_settings, device_setup
    ) -> Union[BestPracticeNote, BestPracticeWarning]:
        tversion = self.objects.tree.version
        check_attrs = self.check_info["109"]
        return self.get_limit_check("pe", tversion, wildfire_settings, check_attrs)

    def _check_apk_size_limit_warn(
        self, wildfire_settings, device_setup
    ) -> Union[BestPracticeNote, BestPracticeWarning]:
        tversion = self.objects.tree.version
        check_attrs = self.check_info["110"]
        return self.get_limit_check("apk", tversion, wildfire_settings, check_attrs)

    def _check_pdf_size_limit_warn(
        self, wildfire_settings, device_setup
    ) -> Union[BestPracticeNote, BestPracticeWarning]:
        tversion = self.objects.tree.version
        check_attrs = self.check_info["111"]
        return self.get_limit_check("pdf", tversion, wildfire_settings, check_attrs)

    def _check_ms_office_size_limit_warn(
        self, wildfire_settings, device_setup
    ) -> Union[BestPracticeNote, BestPracticeWarning]:
        tversion = self.objects.tree.version
        check_attrs = self.check_info["112"]
        return self.get_limit_check(
            "ms-office", tversion, wildfire_settings, check_attrs
        )

    def _check_jar_size_limit_warn(
        self, wildfire_settings, device_setup
    ) -> Union[BestPracticeNote, BestPracticeWarning]:
        tversion = self.objects.tree.version
        check_attrs = self.check_info["113"]
        return self.get_limit_check("jar", tversion, wildfire_settings, check_attrs)

    def _check_flash_size_limit_warn(
        self, wildfire_settings, device_setup
    ) -> Union[BestPracticeNote, BestPracticeWarning]:
        tversion = self.objects.tree.version
        check_attrs = self.check_info["114"]
        return self.get_limit_check("flash", tversion, wildfire_settings, check_attrs)

    def _check_macosx_size_limit_warn(
        self, wildfire_settings, device_setup
    ) -> Union[BestPracticeWarning, BestPracticeNote, None]:
        tversion = self.objects.tree.version
        if tversion < 7.1:
            return
        check_attrs = self.check_info["115"]
        return self.get_limit_check("MacOSX", tversion, wildfire_settings, check_attrs)

    def _check_archive_size_limit_warn(
        self, wildfire_settings, device_setup
    ) -> Union[BestPracticeNote, BestPracticeWarning, None]:
        tversion = self.objects.tree.version
        if tversion < 7.1:
            return
        check_attrs = self.check_info["204"]
        return self.get_limit_check("archive", tversion, wildfire_settings, check_attrs)

    def _check_linux_size_limit_warn(
        self, wildfire_settings, device_setup
    ) -> Union[BestPracticeNote, BestPracticeWarning, None]:
        tversion = self.objects.tree.version
        if tversion < 8:
            return
        check_attrs = self.check_info["205"]
        return self.get_limit_check("linux", tversion, wildfire_settings, check_attrs)

    def _check_script_size_limit_warn(
        self, wildfire_settings, device_setup
    ) -> Union[BestPracticeNote, BestPracticeWarning, None]:
        tversion = self.objects.tree.version
        if tversion < 8.1:
            return
        check_attrs = self.check_info["251"]
        return self.get_limit_check("script", tversion, wildfire_settings, check_attrs)

    def _check_report_grayware_files_enabled_warn(
        self, wildfire_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["117"]
        if not wildfire_settings.report_grayware_files_enabled:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to enable "Report Grayware Files"',
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_session_info_settings_warn(
        self, wildfire_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["118"]
        disabled = wildfire_settings.session_info.get_disabled_settings()

        if disabled:
            message = (
                "It is not recommended to disable any of the Session Information Settings. "
                "Please enable the following: {}".format(", ".join(disabled))
            )
            return BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=message
            )
        return BestPracticeWarning.passing(**check_attrs)
