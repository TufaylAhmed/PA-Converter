import logging
from typing import List, Optional

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeNote
from ..bp_result import BestPracticeResult

LOG = logging.getLogger(__name__)


class SupportAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > SupportAnalyzer"""

    def _check_support_license_note(self) -> Optional[BestPracticeNote]:
        if self.objects.tree.panorama:
            return
        check_attrs = self.check_info["258"]
        if (
            self.objects.license_info.is_license_found_from_tsf("Premium")
            or self.objects.license_info.is_license_found_from_tsf("Standard")
            or self.objects.license_info.is_license_found_from_tsf("Platinum")
        ):
            if (
                self.objects.license_info.has_active_license("Premium")
                or self.objects.license_info.has_active_license("Standard")
                or self.objects.license_info.is_license_found_from_tsf("Platinum")
            ):
                return
            else:
                msg = (
                    "Your device may not get support assistance or PAN-OS "
                    "software updates as there is no active support license."
                )
                return BestPracticeNote(**check_attrs, check_message=msg)
        else:
            msg = "No data available on Support information."
            return BestPracticeNote(**check_attrs, check_message=msg)

    def get_results(self) -> List[BestPracticeResult]:
        """Get list of results"""
        results = []
        configuration = {
            k: v
            for k, v in self.objects.license_info.to_json().items()
            if ("Standard" in k or "Premium" in k or "Platinum" in k)
        }
        checks = []
        for method in self.get_checks():
            check = method()
            if check is not None:
                checks.append(check)
        results.append(BestPracticeResult(configuration, checks))
        return results
