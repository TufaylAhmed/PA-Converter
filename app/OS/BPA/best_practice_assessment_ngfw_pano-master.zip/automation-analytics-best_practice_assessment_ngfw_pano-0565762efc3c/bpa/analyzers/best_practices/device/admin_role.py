import logging

from typing import Dict, List, Optional

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeNote
from ..bp_result import BestPracticeResult
from ....models.device.admin_role import AdminRoleModel


LOG = logging.getLogger(__name__)


class AdminRoleAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > AdminRoleAnalyzer

    Note: Admin Roles are analyzed in aggregate by template name, so we need to
    override the get_results method.
    """

    def _check_custom_admin_roles(
        self, admin_roles: List[AdminRoleModel]
    ) -> Optional[BestPracticeNote]:
        if not admin_roles:
            check_attrs = self.check_info["154"]
            return BestPracticeNote.get_check(
                **check_attrs,
                check_message="It is recommended to create and use custom admin roles"
            )

    @staticmethod
    def get_configuration(template_name, admin_roles: List[AdminRoleModel]) -> Dict:
        """Helper to get configuration."""

        def to_dict(admin_role):
            return {
                key: val
                for key, val in admin_role.to_dict().items()
                if key not in {"model_manager", "template_name"}
            }

        config = {}
        config["admin_roles"] = [to_dict(admin_role) for admin_role in admin_roles]
        config["template_name"] = template_name
        return config

    def get_results(self) -> List[BestPracticeResult]:
        """Administrator elements do no show up in the XML unless configured,
        so need to use template names from DeviceConfigModel ModelSet to create
        a BestPracticeResult for each template name as well as the
        device (i.e. where template_name = None).
        """
        results = []
        admin_roles = self.get_models("admin_role").group_by("template_name")
        check_methods = self.get_checks()
        for template_name in self.stacks:
            try:
                target_admin_roles = admin_roles[(template_name,)]
            except KeyError:
                target_admin_roles = []
            config = self.get_configuration(template_name, target_admin_roles)
            checks = []
            for method in check_methods:
                check = method(target_admin_roles)
                if check is not None:
                    checks.append(check)
            results.append(BestPracticeResult(config, checks))
        return results
