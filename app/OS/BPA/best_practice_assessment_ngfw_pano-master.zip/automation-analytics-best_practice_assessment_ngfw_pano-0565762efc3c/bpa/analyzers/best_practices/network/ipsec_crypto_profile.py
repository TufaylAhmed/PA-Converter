from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning
from ....models.network.ipsec_crypto_profile import IpSecCryptoProfileModel


class IpSecCryptoProfileAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > IpSecCryptoProfileAnalyzer"""

    def _check_protocol(self, profile: IpSecCryptoProfileModel) -> BestPracticeWarning:
        check_attrs = self.check_info["82"]
        if profile.protocol != "esp":
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='Recommended to set protocol to "ESP"'
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_encryption_algorithms(
        self, profile: IpSecCryptoProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["83"]
        bad_encryption_algorithms = [
            algo
            for algo in profile.encryption_algorithms
            if algo != "aes-128-gcm" and algo != "aes-256-gcm"
        ]
        if bad_encryption_algorithms:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="Recommended to only use aes-128-gcm or aes-256-gcm for encryption. "
                "Please remove the following: {}".format(
                    ", ".join(bad_encryption_algorithms)
                )
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_authentication_algorithms(
        self, profile: IpSecCryptoProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["84"]
        message = None
        if not profile.authentication_algorithms:
            message = "Recommended to use SHA for authentication."
        else:
            bad_authentication_algorithms = [
                algo
                for algo in profile.authentication_algorithms
                if algo not in {"sha256", "sha384", "sha512"}
            ]
            if bad_authentication_algorithms:
                message = (
                    "Recommended to only use SHA256 or higher for authentication. "
                    "Please remove the following: {}".format(
                        ", ".join(bad_authentication_algorithms)
                    )
                )
        if message is not None:
            return BestPracticeWarning.get_check(
                **check_attrs, check_passed=False, check_message=message
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
