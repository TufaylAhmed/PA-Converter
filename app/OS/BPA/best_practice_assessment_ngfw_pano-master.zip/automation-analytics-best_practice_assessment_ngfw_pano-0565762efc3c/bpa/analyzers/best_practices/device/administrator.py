import logging

from typing import Dict, List, Optional

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote
from ..bp_result import BestPracticeResult
from ....models.device.administrator import AdministratorModel


LOG = logging.getLogger(__name__)


class AdministratorAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > AdministratorAnalyzer

    Note: Administrators are analyzed in aggregate by template name, so we need to
    override the get_results method.
    """

    def _check_admin_password_profile(
        self, template_name: Optional[str], admins: List[AdministratorModel]
    ) -> Optional[BestPracticeWarning]:
        """Fail if neither a password profile or an authentication profile are used."""
        if not admins:
            return None

        users_without_password_profile = [
            user.mask("name")
            for user in admins
            if user.password_profile is None and user.authentication_profile is None
        ]
        check_attrs = self.check_info["153"]
        if users_without_password_profile:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="The following administrators are not using a password profile or an authentication profile: "
                "{}".format(", ".join(users_without_password_profile)),
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_admin_auth_on_device(
        self, template_name: Optional[str], admins: List[AdministratorModel]
    ) -> Optional[BestPracticeWarning]:
        """Fail if min password complexity settings are invalid, local admin is not using a password profile, or
        the password profile does not have a password change period set to 90 days.

        Skip this check if no local admins are configured.
        """
        local_admins = [a for a in admins if a.is_local()]
        if not local_admins:
            LOG.debug(f"No local admins found for template {template_name}")
            return

        check_attrs = self.check_info["202"]

        failed_check = BestPracticeWarning.get_check(
            **check_attrs,
            check_passed=False,
            check_message="Minimum Password Complexity Settings are not configured correctly.",
        )

        device_setup = self.get_models("device_setup").find(template_name=template_name)
        if not device_setup:
            return failed_check
        elif not device_setup.min_password_complexity.valid():
            return failed_check

        no_pw_prof, bad_change_period, message = [], [], []
        for admin in local_admins:
            admin_masked = admin.mask("name")
            if admin.password_profile is None:
                no_pw_prof.append(admin_masked)
            elif admin.pw_prof_obj.password_change_period != "90":
                bad_change_period.append(admin_masked)
        if no_pw_prof:
            message.append(
                f'The following local admins are not using a password profile: {", ".join(no_pw_prof)}.'
            )
        if bad_change_period:
            message.append(
                "The following local admins as using a password profile with a Required Password Change Period "
                f'not set to 90 days: {", ".join(bad_change_period)}.'
            )
        if message:
            return BestPracticeWarning.get_check(
                **check_attrs, check_passed=False, check_message=" ".join(message)
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_admin_server_profile(
        self, template_name: Optional[str], admins: List[AdministratorModel]
    ) -> Optional[BestPracticeNote]:
        """Add caution if at least one administrator has an insecure server profile."""
        check_attrs = self.check_info["235"]
        bad_admins = []
        for admin in admins:
            auth_prof = admin.auth_prof_obj
            if auth_prof is None:
                continue
            if auth_prof.method not in {"radius", "tacplus"}:
                continue
            svr_prof = auth_prof.svr_prof_obj
            if svr_prof is None:
                continue
            if auth_prof.method == "radius" and "EAP" not in svr_prof.protocol:
                bad_admins.append(admin.mask("name"))
            elif auth_prof.method == "tacplus" and svr_prof.protocol != "CHAP":
                bad_admins.append(admin.mask("name"))
        if len(bad_admins) > 0:
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message=(
                    "Server profile protocol is not secure for the following administrators: "
                    "{}".format(", ".join(bad_admins))
                ),
            )

    @staticmethod
    def get_configuration(template_name, admins: List[AdministratorModel]) -> Dict:
        """Helper to get configuration."""

        def to_dict(admin):
            return {
                key: val
                for key, val in admin.to_dict().items()
                if key not in {"model_manager", "template_name"}
            }

        config = {}
        config["admins"] = [to_dict(admin) for admin in admins]
        config["template_name"] = template_name
        return config

    @property
    def targets(self):
        # Retrieve targets from NGFW
        if self.objects.tree.ngfw:
            return [None]
        # Retrieve targets from Panorama plus templates
        elif self.objects.tree.version < 8.1:
            return self.templates + [None]
        # Retrieve targets from Panorama plus stacks
        return self.stacks + [None]

    def get_results(self) -> List[BestPracticeResult]:
        """Administrator elements do no show up in the XML unless configured,
        so need to use template names from DeviceConfigModel ModelSet to create
        a BestPracticeResult for each template name as well as the
        device (i.e. where template_name = None).
        """
        results = []

        admins = self.get_models("administrator")
        admins_by_template = admins.group_by("template_name")
        for template_name in self.targets:
            target_admins = admins_by_template[(template_name,)]
            config = self.get_configuration(template_name, target_admins)
            methods = [
                self._check_admin_password_profile,
                self._check_admin_auth_on_device,
                self._check_admin_server_profile,
            ]
            checks = []
            for method in methods:
                check = method(template_name, target_admins)
                if check is not None:
                    checks.append(check)
            results.append(BestPracticeResult(config, checks))

        return results
