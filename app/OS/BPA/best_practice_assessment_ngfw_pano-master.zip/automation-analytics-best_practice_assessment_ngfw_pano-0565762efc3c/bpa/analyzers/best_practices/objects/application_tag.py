# -*- coding: utf-8 -*-
from typing import Dict, List, Optional

from bpa.models.base_model import BaseModel
from bpa.models.monitor.pdf_reports.user_activity_report import UserActivityReportModel
from bpa.models.objects.application_tag import ApplicationTagModel

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote
from ..bp_result import BestPracticeResult


class ApplicationTagAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > ApplicationTagAnalyzer"""

    def _check_sanctioned_app(
        self, apps: Dict[str, ApplicationTagModel]
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["27"]
        if not any("Sanctioned" in app.tags for app in apps.values()):
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message='Business approved Applications should be tagged as "Sanctioned"'
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_saas_report(
        self,
        apps: Dict[str, ApplicationTagModel],
        reports: Dict[str, UserActivityReportModel],
    ) -> Optional[BestPracticeNote]:
        """SaaS Application Usage Report Note only applies if the sanctioned
        application tag is being used."""
        if not any("Sanctioned" in app.tags for app in apps.values()):
            return

        check_attrs = self.check_info["28"]
        if not any(
            report.report_type == "saas-application-usage-report"
            for report in reports.values()
        ):
            return BestPracticeNote(
                **check_attrs,
                check_message=(
                    'When using the "Sanctioned" application tag, it is recommended '
                    "to also leverage the SaaS Application Usage Report"
                )
            )

    def get_results(self) -> List[BestPracticeResult]:
        """Get list of results"""
        self.register_modelsets()
        results = []
        for location in self.objects.tree.locations:
            apps = self.get_applications(location)
            reports = self.get_reports(location)
            checks = [self._check_sanctioned_app(apps)]
            note = self._check_saas_report(apps, reports)
            if note is not None:
                checks.append(note)
            configuration = {
                "location": location,
                "tagged_applications": self.clean_dict(apps),
                "predefined_reports": self.clean_dict(reports),
            }
            results.append(BestPracticeResult(configuration, checks))
        return results

    def clean_dict(self, collection: Dict[str, BaseModel]) -> List[Dict]:
        lst = []
        for val in collection.values():
            val = val.to_dict()
            val.pop("location")
            lst.append(val)
        return lst

    def register_modelsets(self):
        self.application_groups = self.objects.get("application_tag").group_by(
            "location"
        )
        self.report_groups = self.objects.get("user_activity_report").group_by(
            "location"
        )

    def get_applications(self, location) -> Dict:
        apps = {}
        for ancestor in reversed(self.objects.tree.ancestors[location]):
            for app in self.application_groups[(ancestor,)]:
                apps[app.name] = app
        return apps

    def get_reports(self, location) -> Dict:
        reports = {}
        for ancestor in reversed(self.objects.tree.ancestors[location]):
            for report in self.report_groups[(ancestor,)]:
                reports[report.name] = report
        return reports
