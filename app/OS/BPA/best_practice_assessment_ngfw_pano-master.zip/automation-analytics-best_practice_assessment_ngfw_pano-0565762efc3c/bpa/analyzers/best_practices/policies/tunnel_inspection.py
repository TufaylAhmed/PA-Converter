from typing import Optional

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning

from bpa.models.policies.tunnel_inspection import TunnelInspectionModel


class TunnelInspectionAnalyzer(BestPracticesAnalyzer):
    def _check_security_options_enabled(
        self, tunnel_inspect: TunnelInspectionModel
    ) -> Optional[BestPracticeWarning]:
        if self.objects.tree.version < 9:
            return
        check_attrs = self.check_info["247"]
        if not any(proto == "vxlan" for proto in tunnel_inspect.tunnel_protocols):
            return
        if not tunnel_inspect.security_options_enabled:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="Create Tunnel source and destination zones to inspect at layer 7 and apply granular policy."
            )
        return BestPracticeWarning.passing(**check_attrs)
