import logging
from collections import OrderedDict
from typing import Dict, List, Optional, Union

from bpa.analyzers.best_practices.bp_check import BestPracticeNote
from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning
from ..bp_result import BestPracticeResult

LOG = logging.getLogger(__name__)


class LicenseAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > LicenseAnalyzer"""

    def _check_threat_protection_license_warn(self) -> Optional[BestPracticeWarning]:
        if self.objects.tree.panorama:
            return
        if self.objects.get("security_rule").using_threat_prevention:
            check_attrs = self.check_info["254"]
            if self.objects.license_info.has_active_license("Threat Prevention"):
                return BestPracticeWarning.passing(**check_attrs)
            else:
                msg = (
                    "You have configured Threat Prevention capabilities, "
                    "but the license is not applied or expired so the feature "
                    "would not work at its best."
                )
                return BestPracticeWarning(
                    **check_attrs, check_passed=False, check_message=msg
                )

    def _check_wildfire_license_warn(
        self,
    ) -> Union[BestPracticeWarning, BestPracticeNote, None]:
        if self.objects.tree.panorama:
            return
        check_attrs = self.check_info["255"]
        is_license_active = self.objects.license_info.has_active_license(
            "WildFire License"
        )
        is_using_wildfire = self.objects.get("antivirus_profile").using_wildfire
        # active | using -> pass
        if is_license_active and is_using_wildfire:
            return BestPracticeWarning.passing(**check_attrs)
        # active | not used -> notes
        elif is_license_active and not is_using_wildfire:
            return BestPracticeNote(
                **check_attrs,
                check_message="License is active but Wildfire feature is not applied.",
                check_severity="Caution"
            )
        # !active | ! using -> skip
        elif not is_license_active and not is_using_wildfire:
            return
        # expired | using cap. -> fail
        else:
            msg = (
                "You have configured Wildfire capabilities, "
                "but the license is not applied or expired so the feature "
                "would not work at its best."
            )
            return BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=msg
            )

    def _check_url_filtering_license_warn(self) -> Optional[BestPracticeWarning]:
        if self.objects.tree.panorama:
            return
        if self.objects.get("security_rule").using_url_filtering:
            check_attrs = self.check_info["256"]
            if self.objects.license_info.has_active_license("PAN-DB URL Filtering"):
                return BestPracticeWarning.passing(**check_attrs)
            else:
                msg = (
                    "You have configured URL Filtering capabilities, "
                    "but the license is not applied or expired so the feature "
                    "would not work at its best."
                )
                return BestPracticeWarning(
                    **check_attrs, check_passed=False, check_message=msg
                )

    def multiple_external_gateways(self) -> bool:
        """Check if more than one external gateway configured"""
        for portal in self.objects.get("global_protect_portal"):
            if any(
                len(agent.external_gateway_ips) > 1 for agent in portal.agent_configs
            ):
                return True
        return False

    def hip_profiles_applied_on_rules(self) -> bool:
        """Check if any HIP profiles applied on security rules"""
        return any(
            rules
            for rules in self.objects.get(
                "security_rule"
            ).hip_profiles_with_rules.values()
        )

    def _check_gp_gateway_license_warn(
        self,
    ) -> Union[BestPracticeWarning, BestPracticeNote, None]:
        if self.objects.tree.panorama:
            return
        check_attrs = self.check_info["257"]
        is_license_active = self.objects.license_info.has_active_license(
            "GlobalProtect Gateway"
        )
        conditions_check_for_gp_gateway = any(
            [
                self.objects.tree.clientless_vpn_enabled,
                self.multiple_external_gateways(),
                self.hip_profiles_applied_on_rules(),
            ]
        )
        # active | using -> pass
        if is_license_active and conditions_check_for_gp_gateway:
            return BestPracticeWarning.passing(**check_attrs)
        # active | not used -> notes
        elif is_license_active and not conditions_check_for_gp_gateway:
            return BestPracticeNote(
                **check_attrs,
                check_message="License is active but Global Protect gateway feature is not applied.",
                check_severity="Caution"
            )
        # !active | ! using -> skip
        elif not is_license_active and not conditions_check_for_gp_gateway:
            return
        # expired | using cap. -> fail
        else:
            msg = (
                "You have configured GP Gateway capabilities, "
                "but the license is not applied or expired so the feature "
                "would not work at its best."
            )
            return BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=msg
            )

    def get_configuration(self) -> Dict:
        lics = []
        for key, val in self.objects.license_info.to_json().items():
            if key not in ["Standard", "Premium"]:
                lic = OrderedDict({"Feature": key, **val})
                # val["Feature"] = key
                lics.append(lic)
        return {"Licenses": lics}
        return {
            k: v
            for k, v in self.objects.license_info.to_json().items()
            if k not in ["Standard", "Premium"]
        }

    def get_results(self) -> List[BestPracticeResult]:
        """Get list of results"""
        results = []
        configuration = self.get_configuration()
        checks = []
        for method in self.get_checks():
            check = method()
            if check is not None:
                checks.append(check)
        results.append(BestPracticeResult(configuration, checks))
        return results

    def _is_dns_signature_check_in_profile(self) -> bool:

        anti_spyware_profile = self.objects.get("anti_spyware_profile")
        if anti_spyware_profile:
            for profile in anti_spyware_profile:
                for signature in profile.dns_signatures:
                    if signature.name == "default-paloalto-cloud":
                        return True
        return False

    def _check_dns_security_license_warn(
        self,
    ) -> Union[BestPracticeWarning, BestPracticeNote, None]:
        """
         check if dns_cloud_security license is active and check if profile is set.
        """
        if self.objects.tree.version < 9 or self.objects.tree.panorama:
            return
        dns_signature_check = self._is_dns_signature_check_in_profile()
        # NOTE: Skip if DNS Security license is either inactive or missing
        feature = "DNS Security"
        check_attrs = self.check_info["266"]
        is_license_active = self.objects.license_info.has_active_license(feature)
        # active | using -> pass
        if is_license_active and dns_signature_check:
            return BestPracticeWarning.passing(**check_attrs)
        # active | not used -> notes
        elif is_license_active and not dns_signature_check:
            return BestPracticeNote(
                **check_attrs,
                check_message="License is active but DNS Security feature is not applied.",
                check_severity="Caution",
            )
        # !active | ! using -> skip
        elif not is_license_active and not dns_signature_check:
            return
        # expired | using cap. -> fail
        else:
            msg = (
                "You have configured DNS Security capabilities, "
                "but the license is not applied or expired so the feature "
                "would not work at its best."
            )

            return BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=msg
            )
