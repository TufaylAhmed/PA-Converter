import re
from typing import List, Optional, Tuple

from ..bp_check import BestPracticeNote
from ..bp_result import BestPracticeResult
from ..base_analyzer import BestPracticesAnalyzer


class VirtualSystemAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > VirtualSystemAnalyzer"""

    def get_configuration(
        self, template_name: str, virtual_systems: List, user_id_hubs: List
    ):
        def get_id(name: str) -> Tuple[int, str]:
            """Try to extract the vsys ID."""
            match = re.search(r"^vsys(\d+)$", name)
            compare_first = -1 if match is None else int(match.group(1))
            return (compare_first, name)

        return {
            "template_name": template_name,
            "virtual_systems": sorted([v.name for v in virtual_systems], key=get_id),
            "user_id_hub": [u.name for u in user_id_hubs],
        }

    def _check_shared_user_id(
        self, virtual_systems: List, user_id_hubs: List
    ) -> Optional[BestPracticeNote]:
        if len(virtual_systems) < 2:
            return
        check_attrs = self.check_info["248"]
        invalid_hub = False
        if len(user_id_hubs) == 0:
            invalid_hub = True
        elif user_id_hubs[0].name not in {v.name for v in virtual_systems}:
            invalid_hub = True
        if invalid_hub:
            return BestPracticeNote(
                **check_attrs,
                check_message=(
                    "If it is possible to share User-IDs between multiple virtual"
                    " systems, it is recommended to make one vsys the User-ID hub."
                    " This helps to save User-ID resources and maintain a"
                    " single source of truth."
                ),
            )

    def get_results(self) -> List[BestPracticeResult]:
        if self.objects.tree.version < 9.0:
            return []
        vmap = self.get_models("virtual_system").group_by("template_name")
        hmap = self.get_models("user_id_hub").group_by("template_name")
        results = []
        for key in vmap:
            vsys = vmap[key]
            hubs = hmap[key]
            config = self.get_configuration(key[0], vsys, hubs)
            check_output = self._check_shared_user_id(vsys, hubs)
            checks = [] if check_output is None else [check_output]
            results.append(BestPracticeResult(config, checks))
        return results
