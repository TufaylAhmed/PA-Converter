import logging

from ...bp_check import BestPracticeWarning
from .common import DeviceSetupAnalyzer


LOG = logging.getLogger(__name__)


class TelemetrySettingsAnalyzer(DeviceSetupAnalyzer):
    """BestPracticesAnalyzer > DeviceSetupAnalyzer > TelemetrySettingsAnalyzer"""

    target_attr = "telemetry"

    @classmethod
    def build_analyzer_key(cls) -> str:
        return "device_setup_telemetry"

    def _check_telemetry_enabled_warn(
        self, telemetry_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["197"]
        missing_feeds = telemetry_settings.disabled_feeds()
        if missing_feeds:
            if self.objects.tree.version < 8:
                telemetry_type = "Statistic Services"
            else:
                telemetry_type = "Telemetry"
            message = "The following {telemetry_type} feeds are not enabled: {feeds}".format(
                telemetry_type=telemetry_type, feeds=", ".join(missing_feeds)
            )
            return BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=message
            )
        return BestPracticeWarning.passing(**check_attrs)
