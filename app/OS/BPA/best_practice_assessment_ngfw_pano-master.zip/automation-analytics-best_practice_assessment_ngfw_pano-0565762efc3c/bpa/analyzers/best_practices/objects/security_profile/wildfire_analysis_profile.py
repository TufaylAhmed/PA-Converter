# -*- coding: utf-8 -*-
from bpa.analyzers.best_practices.bp_check import BestPracticeWarning
from bpa.analyzers.best_practices.objects.security_profile.common import (
    SecurityProfileAnalyzer,
)
from bpa.models.objects.security_profile.wildfire_analysis_profile import (
    WildfireAnalysisProfileModel,
)
from bpa.models.device.device_setup.wildfire import SizeLimits


class WildfireAnalysisProfileAnalyzer(SecurityProfileAnalyzer):
    """BestPracticesAnalyzer > WildfireAnalysisProfileAnalyzer"""

    @classmethod
    def build_model_key(cls):
        """NOTE: Added since the model key is hardcoded"""
        return WildfireAnalysisProfileModel.build_model_key()

    def _check_rules(
        self, profile: WildfireAnalysisProfileModel
    ) -> BestPracticeWarning:
        """ Checks rule application, direction and file_types for wildfire. """
        check_id = "47"
        check_attrs = self.check_info[check_id]
        upload_passed, download_passed = False, False
        upload_file_types = set(
            SizeLimits.get_default_sizes(self.objects.tree.version).keys()
        )
        download_file_types = upload_file_types.copy()

        for rule in profile.rules:
            if "any" in rule.applications:
                if rule.direction == "both":
                    if "any" in rule.file_types:
                        upload_passed, download_passed = True, True
                        break
                    else:
                        for file_type in rule.file_types:
                            upload_file_types.discard(file_type)
                            download_file_types.discard(file_type)
                elif rule.direction == "upload":
                    if "any" in rule.file_types:
                        upload_passed = True
                    else:
                        for file_type in rule.file_types:
                            upload_file_types.discard(file_type)
                elif rule.direction == "download":
                    if "any" in rule.file_types:
                        download_passed = True
                    else:
                        for file_type in rule.file_types:
                            download_file_types.discard(file_type)

        if upload_passed and download_passed:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
        elif not upload_file_types and not download_file_types:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
        else:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to use "any" when configuring applications and file types in the WildFire Profile '
                "rulebase for both directions"
            )
