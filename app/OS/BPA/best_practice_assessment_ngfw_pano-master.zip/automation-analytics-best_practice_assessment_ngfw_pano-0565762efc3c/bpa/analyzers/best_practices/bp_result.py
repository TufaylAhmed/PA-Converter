from typing import Dict, List

from dataclasses import dataclass

from .bp_check import BestPracticeCheck, BestPracticeWarning, BestPracticeNote


@dataclass(init=False)
class BestPracticeResult:
    """Collection of best practice checks and configuration.

    Attributes:
        configuration: XML configuration mapped out as dictionary.
        checks: List of best practice checks.
    """

    configuration: Dict
    warnings: List[BestPracticeWarning]
    notes: List[BestPracticeNote]

    def __init__(self, configuration, checks):
        self.configuration = configuration
        self.warnings = []
        self.notes = []
        for check in checks:
            if isinstance(check, BestPracticeWarning):
                self.warnings.append(check)
            elif isinstance(check, BestPracticeNote):
                self.notes.append(check)
            else:
                raise TypeError(
                    f"{check.__class__.__name__} is not a BestPracticeWarning or BestPracticeNote"
                )

    @property
    def checks(self) -> List[BestPracticeCheck]:
        return [*self.notes, *self.warnings]
