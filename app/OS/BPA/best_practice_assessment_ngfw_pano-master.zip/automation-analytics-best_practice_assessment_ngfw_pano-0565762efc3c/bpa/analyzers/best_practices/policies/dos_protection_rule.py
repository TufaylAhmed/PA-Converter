from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning
from ....models.policies.dos_protection_rule import DosProtectionRuleModel


class DosProtectionRuleAnalyzer(BestPracticesAnalyzer):
    def _check_protect_deny_rules(
        self, rule: DosProtectionRuleModel
    ) -> BestPracticeWarning:
        check_id = "26"
        check_attrs = self.check_info[check_id]
        if rule.action != "protect":
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message=(
                    'Ensure that all DoS Protection Rules have an action of "Protect" '
                    "and the number of Destination Addresses is limited."
                )
            )
        else:
            return BestPracticeWarning.passing(**check_attrs)
