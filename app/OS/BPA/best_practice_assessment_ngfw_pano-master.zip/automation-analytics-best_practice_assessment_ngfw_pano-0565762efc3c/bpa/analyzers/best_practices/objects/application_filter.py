# -*- coding: utf-8 -*-
from typing import Optional

from bpa.models.objects.application_filter import ApplicationFilterModel

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeNote


class ApplicationFilterAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > ApplicationFilterAnalyzer"""

    def applied_on_rule(self, model_manager, filt: ApplicationFilterModel):
        rule_ms = model_manager.get("security_rule")
        return len(rule_ms.app_filters_with_rules[(filt.location, filt.name)]) > 0

    def get_configuration(self, filt: ApplicationFilterModel):
        config = super().get_configuration(filt)
        config["applied_on_security_rule"] = self.applied_on_rule(self.objects, filt)
        return config

    def _check_app_filter_is_proper(
        self, filt: ApplicationFilterModel
    ) -> Optional[BestPracticeNote]:
        if self.objects.tree.version < 8.1:
            return
        check_attrs = self.check_info["250"]
        if not self.applied_on_rule(self.objects, filt):
            return BestPracticeNote(
                **check_attrs,
                check_message=(
                    "This is an unused application filter. If the filter is still"
                    " required, apply it to a security rule."
                ),
            )
