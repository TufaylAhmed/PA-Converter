import logging
from collections import OrderedDict
from typing import Dict, List, Optional

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote
from ..bp_result import BestPracticeResult
from ....models.device.authentication_sequence import AuthenticationSequenceModel


LOG = logging.getLogger(__name__)


class AuthenticationSequenceAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > AuthenticationSequenceAnalyzer

    Analyzes INDIVIDUAL Authentication Sequences.
    """

    def _check_auth_profiles(
        self, sequence: AuthenticationSequenceModel
    ) -> Optional[BestPracticeNote]:
        if len(sequence.auth_profiles) < 2:
            message = "It is recommended to use more than one authentication profile"

            # Local authentication cannot be configured on a Panorama device,
            # so customize message for NGFWs and device templates
            if self.objects.tree.ngfw or sequence.template_name is not None:
                message += " and ensure an external authentication is used before a local authentication in the sequence"

            return BestPracticeNote.get_check(
                **self.check_info["160"], check_message=message
            )


class AuthenticationSequencesAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > AuthenticationSequencesAnalyzer

    Analyzes Authentication Sequences in AGGREGATE, grouped by template name.
    """

    def _check_sequence_exists(
        self, target_sequences: Dict[str, List[AuthenticationSequenceModel]]
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["159"]
        bad_locations = []
        for location, sequences in target_sequences.items():
            if not any(len(seq) >= 2 for seq in sequences):
                bad_locations.append(location)
        if bad_locations:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message=(
                    "At least one authentication sequence with two or more profiles should be defined in "
                    f'the following locations: {", ".join(bad_locations)}'
                ),
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    @staticmethod
    def get_configuration(
        template_name: str,
        target_sequences: Dict[str, List[AuthenticationSequenceModel]],
    ) -> Dict:
        """Since this is an AGGREGATE analyzer, show the template name as well as the
        auth sequences broken down by their location."""
        all_sequences = [
            seq for sublist in target_sequences.values() for seq in sublist
        ]
        config = {"template_name": template_name}
        sequences = []
        signatures = set()
        for sequence in all_sequences:
            sig = (sequence.location, sequence.name, tuple(sequence.auth_profiles))
            if sig not in signatures:
                signatures.add(sig)
                sequences.append(
                    OrderedDict(
                        {
                            "location": sequence.location,
                            "name": sequence.name,
                            "profiles": sequence.auth_profiles,
                        }
                    )
                )
        config["sequences"] = sequences
        return config

    def get_results(self) -> List[BestPracticeResult]:
        """Will create a BestPracticeResult for each template name (including None for the NGFW/Panorama)"""
        results = []
        sequences = self.get_models("authentication_sequence").group_by(
            "template_name", "location"
        )

        for config in self.get_models("device_config"):
            # Auth Sequences on a Panorama are stored under the panorama element,
            # so need to process them differently
            if config.template_name is None and self.objects.tree.panorama:
                continue
            target_sequences = {}
            shared_sequences = sequences[(config.template_name, "shared")]
            locations = [_ for _ in config.locations if _ != "shared"]
            for location in locations:
                vsys_sequences = sequences[(config.template_name, location)]
                target_sequences[location] = [*shared_sequences, *vsys_sequences]
            configuration = self.get_configuration(
                config.template_name, target_sequences
            )
            checks = [self._check_sequence_exists(target_sequences)]
            results.append(BestPracticeResult(configuration, checks))

        if self.objects.tree.panorama:
            pano_sequences = {"panorama": sequences[None, "panorama"]}
            configuration = self.get_configuration(None, pano_sequences)
            checks = [self._check_sequence_exists(pano_sequences)]
            results.append(BestPracticeResult(configuration, checks))

        return results
