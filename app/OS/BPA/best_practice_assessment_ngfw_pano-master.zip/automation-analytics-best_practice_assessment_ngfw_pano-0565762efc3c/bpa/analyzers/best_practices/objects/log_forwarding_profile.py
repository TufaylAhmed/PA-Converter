# -*- coding: utf-8 -*-
from typing import Union

from .utils import get_percent
from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote
from ....models.objects.log_forwarding_profile import LogForwardingProfileModel


class LogForwardingProfileAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > LogForwardingProfileAnalyzer"""

    def _check_traffic_settings(
        self, profile: LogForwardingProfileModel
    ) -> BestPracticeWarning:
        """Fail if all logs are not forwarded to at least one location."""
        check_id = "51"
        check_attrs = self.check_info[check_id]

        def setting_passing():
            """Passing logic for PAN-OS < 8.0"""
            traffic_settings = next(
                iter(s for s in profile.settings if s.log_type == "traffic"), None
            )
            if traffic_settings is None:
                return False
            return traffic_settings.forwarding_valid("any")

        def match_list_passing():
            """Passing logic for PAN-OS 8.0+"""
            severity_collector = set()
            for s in profile.settings:
                if s.log_type == "traffic" and s.forwarding_valid():
                    if s.filter == "All Logs":
                        return True
                    severity_collector.update(s.parse_filter())
            return set(profile.SEVERITIES) == severity_collector

        if self.objects.tree.version < 8:
            passing = setting_passing()
        else:
            passing = match_list_passing()

        if passing:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
        else:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to forward all traffic logs to at least one location.",
            )

    def _check_threat_settings(
        self, profile: LogForwardingProfileModel
    ) -> Union[BestPracticeWarning, BestPracticeNote]:
        """Fail if all logs are not filtered to Panorama and at least one other location."""
        check_id = "52"
        check_attrs = self.check_info[check_id]

        def helper_threat_setting():
            return next(
                iter(s for s in profile.settings if s.log_type == "threat"), None
            )

        def setting_passing():
            """Passing logic for PAN-OS < 8.0"""
            threat_settings = helper_threat_setting()
            if threat_settings is None:
                return False
            return all(
                threat_settings.forwarding_valid(severity)
                for severity in profile.SEVERITIES
            )

        def match_list_passing():
            """Passing logic for PAN-OS 8.0+"""
            threat_settings = helper_threat_setting()
            if threat_settings is None:
                return False

            result = []
            severity_collector = set()
            for setting in profile.settings:
                if setting.log_type == "threat":
                    if setting.panorama and threat_settings.forwarding_valid():
                        if setting.filter == "All Logs":
                            return True
                        severity_collector.update(setting.parse_filter())
                    elif not setting.panorama and threat_settings.forwarding_valid():
                        result.append("note")
            return result if result else set(profile.SEVERITIES) == severity_collector

        if self.objects.tree.version < 8:
            passing = setting_passing()
        else:
            passing = match_list_passing()

        if isinstance(passing, list):
            return BestPracticeNote.get_check(
                **check_attrs,
                check_severity="Caution",
                check_message="Enable log forwarding to Panorama if configured to ensure all threat logs are at one place to run Reports, ACC widgets and identify any patterns and so on.",
            )
        if passing:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
        else:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to forward all threat logs to Panorama and at least one additional location.",
            )

    def _check_wildfire_settings(
        self, profile: LogForwardingProfileModel
    ) -> Union[BestPracticeWarning, BestPracticeNote]:
        """Fail if grayware, malicious, and (if version >= 8) phishing logs are not filtered to
        Panorama and at least one other location.
        """
        check_id = "53"
        check_attrs = self.check_info[check_id]

        def helper_wildfire_settings():
            return next(
                iter(s for s in profile.settings if s.log_type == "wildfire"), None
            )

        def setting_passing():
            """Passing logic for PAN-OS < 8.0"""
            wildfire_settings = helper_wildfire_settings()

            if wildfire_settings is None:
                return False

            return all(
                wildfire_settings.forwarding_valid(verdict)
                for verdict in profile.verdicts
            )

        def match_list_passing():
            """Passing logic for PAN-OS 8.0+"""
            wildfire_settings = helper_wildfire_settings()

            if wildfire_settings is None:
                return False
            result = []
            verdict_collector = set()
            for s in profile.settings:
                if s.log_type == "wildfire":
                    if s.panorama and s.forwarding_valid():
                        if s.filter == "All Logs":
                            return True
                        verdict_collector.update(s.parse_filter())
                    elif not s.panorama and s.forwarding_valid():
                        result.append("note")
            return result if result else set(profile.verdicts) == verdict_collector

        if self.objects.tree.version < 8:
            passing = setting_passing()
        else:
            passing = match_list_passing()

        if isinstance(passing, list):
            return BestPracticeNote.get_check(
                **check_attrs,
                check_severity="Caution",
                check_message="Enable log forwarding to Panorama if configured to ensure all wildfire logs are at one place to run Reports, ACC widgets and identify any patterns and so on.",
            )

        if passing:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
        else:
            if self.objects.tree.version < 8:
                verdicts = "grayware and malicious"
            else:
                verdicts = "grayware, malicious, and phishing"
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message=f"It is recommended to forward {verdicts} logs to Panorama and at least one additional location.",
            )

    def _check_url_settings(
        self, profile: LogForwardingProfileModel
    ) -> Union[BestPracticeWarning, BestPracticeNote, None]:
        """Fail if all logs are not forwarded to at least one location."""
        check_id = "259"
        check_attrs = self.check_info[check_id]

        def match_list_passing():
            """Passing logic for PAN-OS 8.1+"""
            url_settings = next(
                iter(s for s in profile.settings if s.log_type == "url"), None
            )
            if url_settings is None:
                return "note"

            for ps in profile.settings:
                if ps.log_type == "url" and ps.forwarding_valid():
                    return "pass"
            return "fail"

        # This check is supported on PanOS 8.1 and higher
        if self.objects.tree.version < 8.1:
            return None
        passing = match_list_passing()

        if passing == "pass":
            return BestPracticeWarning.passing(**check_attrs)
        elif passing == "note":
            return BestPracticeNote.get_check(
                **check_attrs,
                check_severity="Caution",
                check_message="Ensure URL Log forwarding is applied if URL capability is used.",
            )
        else:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to forward URL logs to an external logging or storage system.",
            )

    def _check_auth_settings(
        self, profile: LogForwardingProfileModel
    ) -> Union[BestPracticeWarning, BestPracticeNote, None]:
        """Fail if authentication logs are not forwarded to at least one location."""
        check_id = "260"
        check_attrs = self.check_info[check_id]

        def match_list_passing():
            """Passing logic for PAN-OS 8.1+"""
            auth_settings = next(
                iter(s for s in profile.settings if s.log_type == "auth"), None
            )

            if auth_settings is None:
                return "note"

            for ps in profile.settings:
                if ps.log_type == "auth" and ps.forwarding_valid():
                    return "pass"
            return "fail"

        # This check is supported on PanOS 8.1 and higher
        if self.objects.tree.version < 8.1:
            return None
        passing = match_list_passing()

        if passing == "pass":
            return BestPracticeWarning.passing(**check_attrs)
        elif passing == "note":
            return BestPracticeNote.get_check(
                **check_attrs,
                check_severity="Caution",
                check_message="Ensure Authentication Log forwarding is applied if Authentication policies are used.",
            )
        else:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to forward Authentication logs to an external logging or storage system.",
            )

    def get_results(self):
        results = super().get_results()
        rule_ms = self.objects.get("security_rule")
        rule_ms_map = rule_ms.group_by("location")
        profiles_with_rules = rule_ms.log_profiles_with_rules
        return get_percent(
            results,
            rule_ms_map,
            profiles_with_rules,
            self.objects.tree.descendants,
            rule_filters={"rule_enabled": True},
        )
