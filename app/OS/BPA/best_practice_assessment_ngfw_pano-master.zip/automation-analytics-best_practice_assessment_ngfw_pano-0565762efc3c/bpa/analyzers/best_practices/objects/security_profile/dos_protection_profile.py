# -*- coding: utf-8 -*-
from ..utils import get_percent
from ...bp_check import BestPracticeWarning, BestPracticeNote
from ...objects.security_profile.common import SecurityProfileAnalyzer
from .....models.objects.security_profile.dos_protection_profile import (
    DosProtectionProfileModel,
)


class DosProtectionProfileAnalyzer(SecurityProfileAnalyzer):
    """BestPracticesAnalyzer > DosProtectionProfileAnalyzer"""

    @classmethod
    def build_model_key(cls):
        """NOTE: Added since the model key is hardcoded"""
        return DosProtectionProfileModel.build_model_key()

    def _check_flood_protection_enabled(
        self, profile: DosProtectionProfileModel
    ) -> BestPracticeWarning:
        check_id = "49"
        check_attrs = self.check_info[check_id]

        disabled_tabs = [
            tab.flood_type for tab in profile.flood_protections if not tab.enabled
        ]
        if disabled_tabs:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="Please enable the following Flood Types: {}".format(
                    ", ".join(disabled_tabs)
                )
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_flood_protection_default_values_note(
        self, profile: DosProtectionProfileModel
    ) -> BestPracticeNote:
        check_id = "50"
        check_attrs = self.check_info[check_id]

        message = []
        bad_rates = []
        bad_block_duration = []
        default_vals = {"alarm": 10000, "activate": 10000, "maximal": 40000}

        for tab in profile.flood_protections:
            if any(
                getattr(tab, val) == default_vals[val]
                for val in ["alarm", "activate", "maximal"]
            ):
                bad_rates.append(getattr(tab, "flood_type"))
            if getattr(tab, "block_duration") != 300:
                bad_block_duration.append(getattr(tab, "flood_type"))

        if bad_rates:
            msg = (
                "Change the following Flood Type(s) to non-default "
                "Alarm(10000) / Activate(10000) / Max(40000) Rates: {}."
            ).format(", ".join(bad_rates))
            message.append(msg)
        if bad_block_duration:
            msg = "Change the following Flood Type(s) so the Block Duration is 300."
            message.append(msg)

        if message:
            return BestPracticeNote.get_check(
                **check_attrs, check_severity="Caution", check_message=" ".join(message)
            )

    def get_results(self):
        results = super().get_results()
        rule_ms = self.objects.get("dos_protection_rule")
        rule_ms_map = rule_ms.group_by("location")
        profiles_with_rules = rule_ms.dos_profiles_with_rules
        return get_percent(
            results,
            rule_ms_map,
            profiles_with_rules,
            self.objects.tree.descendants,
            rule_filters={"rule_enabled": True},
        )
