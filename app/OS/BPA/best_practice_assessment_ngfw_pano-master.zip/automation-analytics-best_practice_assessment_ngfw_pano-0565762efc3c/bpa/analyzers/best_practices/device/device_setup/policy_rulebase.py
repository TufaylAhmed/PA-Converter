import logging

from typing import Optional

from ...bp_check import BestPracticeWarning
from .common import DeviceSetupAnalyzer


LOG = logging.getLogger(__name__)


class PolicyRulebaseAnalyzer(DeviceSetupAnalyzer):
    """BestPracticesAnalyzer > DeviceSetupAnalyzer > PolicyRulebaseAnalyzer"""

    target_attr = "policy_rulebase"

    @classmethod
    def build_analyzer_key(cls) -> str:
        return "device_setup_policy_rulebase"

    def _check_rule_hit_count_enabled(
        self, policy_rulebase, device_setup
    ) -> Optional[BestPracticeWarning]:
        if self.objects.tree.version < 9.0:
            return
        check_attrs = self.check_info["242"]
        if policy_rulebase.rule_hit_count is False:

            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message=(
                    "Enable Rule Hit Count to identify frequently used and unused policies in the rulebase."
                )
            )
        return BestPracticeWarning.passing(**check_attrs)
