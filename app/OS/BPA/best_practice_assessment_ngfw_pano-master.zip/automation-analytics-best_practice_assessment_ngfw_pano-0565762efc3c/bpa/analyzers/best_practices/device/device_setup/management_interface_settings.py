import logging
from typing import Optional, Union

from iptools import IpRangeList
from iptools.ipv4 import cidr2block

from ...bp_check import BestPracticeWarning, BestPracticeNote
from .common import DeviceSetupAnalyzer


LOG = logging.getLogger(__name__)


class ManagementInterfaceSettingsAnalyzer(DeviceSetupAnalyzer):
    """BestPracticesAnalyzer > DeviceSetupAnalyzer > ManagementInterfaceSettingsAnalyzer"""

    target_attr = "management_interface"

    @classmethod
    def build_analyzer_key(cls) -> str:
        return "device_setup_management_interface"

    @classmethod
    def is_private_ip(cls, ip_address: str) -> Optional[bool]:
        """Returns True if given IP address is private."""
        private_ips = IpRangeList("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16")

        # TODO: Sync with Samshodh on how to handle IPv6 addresses
        # NOTE: For now we do not check whether IPv6 addresses are public
        # NOTE: For now we do not check template variables
        if not cls.is_ipv4(ip_address) or cls.is_template_variable(ip_address):
            return

        if cls.using_cidr_notation(ip_address):
            # If the IP is using CIDR notation address format, check the network block start and end addresses
            return all(ip in private_ips for ip in cidr2block(ip_address))
        else:
            return ip_address in private_ips

    @staticmethod
    def is_ipv4(ip_address: str) -> bool:
        return ":" not in ip_address

    @staticmethod
    def is_template_variable(ip_address: str) -> bool:
        return ip_address.startswith("$")

    @staticmethod
    def using_cidr_notation(ip_address: str) -> bool:
        return "/" in ip_address

    def _check_permitted_ip_addresses(
        self, mgmt_interface, device_setup
    ) -> Union[BestPracticeWarning, BestPracticeNote, None]:
        """Checks whether Permitted IP addresses are configured.

        Skip if management IP address is not configured.
        Fail if permitted IP addresses are NOT configured.
        If IPv4 management IP address is PRIVATE, all permitted IPv4 address must also be private to pass.

        If management IP address is PUBLIC and permitted IP addresses are configured, NOTE that permitted IP
        addresses should be limited.
        """
        if mgmt_interface.management_ip_address is None:
            return

        if self.is_template_variable(mgmt_interface.management_ip_address):
            return

        check_attrs = self.check_info["100"]

        if not mgmt_interface.permitted_ip_addresses:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="Permitted IP Addresses should be configured"
            )

        if self.is_private_ip(mgmt_interface.management_ip_address):
            public_ips = [
                ip1
                for ip1, ip2 in zip(
                    mgmt_interface.mask("permitted_ip_addresses"),
                    mgmt_interface.permitted_ip_addresses,
                )
                if not self.is_private_ip(ip2)
            ]
            if public_ips:
                return BestPracticeWarning(
                    **check_attrs,
                    check_passed=False,
                    check_message=(
                        "Only private IP addresses should be permitted. "
                        "Please remove the following public IP addresses: {}".format(
                            ", ".join(public_ips)
                        )
                    )
                )
            else:
                return BestPracticeWarning.passing(**check_attrs)
        else:
            # PUBLIC management IP with permitted IP addresses configured
            return BestPracticeNote(
                **check_attrs,
                check_message=(
                    "Ensure access to management interface is limited to a select set of Permitted IP addresses "
                    "per business needs to reduce the attack surface."
                )
            )

    def _check_disabled_services(
        self, mgmt_interface, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["102"]
        if not all([mgmt_interface.telnet_disabled, mgmt_interface.http_disabled]):
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to disable both "HTTP" and "Telnet" for Network Connectivity Services'
            )
        return BestPracticeWarning.passing(**check_attrs)
