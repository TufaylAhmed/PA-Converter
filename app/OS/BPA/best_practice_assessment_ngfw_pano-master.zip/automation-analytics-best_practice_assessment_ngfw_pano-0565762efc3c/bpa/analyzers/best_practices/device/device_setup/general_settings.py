import logging
from typing import Optional

from ...bp_check import BestPracticeWarning
from .common import DeviceSetupAnalyzer


LOG = logging.getLogger(__name__)


class GeneralSettingsAnalyzer(DeviceSetupAnalyzer):
    """BestPracticesAnalyzer > DeviceSetupAnalyzer > GeneralSettingsAnalyzer"""

    target_attr = "general"

    @classmethod
    def build_analyzer_key(cls) -> str:
        return "device_setup_general"

    def _check_login_banner_enabled(
        self, general_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["91"]
        if not general_settings.login_banner_enabled:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to have a descriptive Login Banner"
            )
        return BestPracticeWarning.passing(**check_attrs, check_passed=True)

    def _check_auto_acquire_commit_lock_enabled(
        self, general_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["88"]
        if not general_settings.auto_acquire_commit_lock_enabled:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to enable "Automatically Acquire Commit Lock"'
            )
        return BestPracticeWarning.passing(**check_attrs, check_passed=True)

    def _check_cert_expiration_check_enabled(
        self, general_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["89"]
        not_ssl_check = BestPracticeWarning(
            **check_attrs,
            check_passed=False,
            check_message="The SSL/TLS Service Profile is not configured"
        )

        if general_settings.ssl_tls_service_profile is None:
            return not_ssl_check

        if general_settings.cert_expiration_check_enabled is False:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to enable "Certification Expiration Check"'
            )
        # TODO Samshodh checking this: Below line can return duplicate ssl profiles (with same name, same template BUT different locations) How does PAN OS resolve this? No location in device - general settings
        ssl_profiles = self.get_models("ssl_tls_service_profile").findall(
            template_name=device_setup.template_name,
            name=general_settings.ssl_tls_service_profile,
        )

        # NOTE: Assume there is only one match, otherwise
        # the check above is worthless
        if len(ssl_profiles) == 0:
            return not_ssl_check

        ssl_profile = ssl_profiles[0]

        not_cert_configured = BestPracticeWarning(
            **check_attrs,
            check_passed=False,
            check_message="SSL/TLS Service Profile does not have a certificate configured"
        )

        if ssl_profile.certificate is None:
            return not_cert_configured

        cert = self.get_models("certificate").find(
            template_name=device_setup.template_name, name=ssl_profile.certificate
        )
        if cert is None:
            return not_cert_configured

        if cert.issuer_hash == cert.subject_hash:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="SSL/TLS Service Profile is using a self signed certificate"
            )

        return BestPracticeWarning.passing(**check_attrs, check_passed=True)

    def _check_hostname(
        self, general_settings, device_setup
    ) -> Optional[BestPracticeWarning]:
        """Only applies to NGFW or Panorama device (not device templates)"""
        if device_setup.template_name is None:
            check_attrs = self.check_info["90"]
            if general_settings.hostname in {"localhost", None}:
                return BestPracticeWarning(
                    **check_attrs,
                    check_passed=False,
                    check_message="It is recommended to configure a Hostname"
                )
            return BestPracticeWarning.passing(**check_attrs)
