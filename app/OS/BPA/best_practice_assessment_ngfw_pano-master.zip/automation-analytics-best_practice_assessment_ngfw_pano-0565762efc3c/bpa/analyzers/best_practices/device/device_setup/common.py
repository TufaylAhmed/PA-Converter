import logging
from abc import ABCMeta, abstractmethod
from typing import Dict, List

from ...base_analyzer import BestPracticesAnalyzer
from ...bp_result import BestPracticeResult


LOG = logging.getLogger(__name__)


class DeviceSetupAnalyzer(BestPracticesAnalyzer, metaclass=ABCMeta):
    def get_configuration(self, model, device_setup) -> Dict:
        return {**model.to_dict(), "template_name": device_setup.template_name}

    def get_results(self) -> List[BestPracticeResult]:
        """Get list of results"""
        results = []
        for device_setup in self.get_models("device_setup"):
            target = getattr(device_setup, self.target_attr)
            if target is None:
                LOG.debug(
                    f"Skipping result for {self.__class__.__name__} because {self.target_attr} is None "
                    f"on DeviceSetupModel with template_name={device_setup.template_name}."
                )
                continue
            configuration = self.get_configuration(target, device_setup)
            checks = []
            for method in self.get_checks():
                check = method(target, device_setup)
                if check is not None:
                    checks.append(check)
            results.append(BestPracticeResult(configuration, checks))
        return results

    @classmethod
    @abstractmethod
    def build_analyzer_key(cls) -> str:
        raise NotImplementedError("Need to implement build_analyzer_key")
