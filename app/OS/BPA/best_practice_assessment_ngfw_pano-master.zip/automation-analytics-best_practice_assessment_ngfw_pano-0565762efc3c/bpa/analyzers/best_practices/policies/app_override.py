from typing import Optional

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning


class AppOverrideAnalyzer(BestPracticesAnalyzer):
    def _check_app_override(self, app_override) -> BestPracticeWarning:
        check_id = "21"
        check_attrs = self.check_info[check_id]
        return BestPracticeWarning.get_check(
            **check_attrs,
            check_passed=False,
            check_message="Verify that you need to use Application Override"
        )

    def _check_custom_app(self, app_override) -> Optional[BestPracticeWarning]:
        check_id = "230"
        check_attrs = self.check_info[check_id]

        if self.objects.tree.version < 8.1:
            return

        custom_app = app_override.custom_app
        if custom_app is None:
            return

        if custom_app.defaults_configured:
            return

        if len(custom_app.signatures) > 0:
            return

        # NOTE: Cache result since it only needs to be executed once
        if not hasattr(self, "svc_timeouts_configured"):
            self.svc_timeouts_configured = any(
                [_.timeouts_configured for _ in self.objects.get("service")]
            )

        if self.svc_timeouts_configured and not custom_app.timeouts_configured:
            return BestPracticeWarning.passing(**check_attrs)

        return BestPracticeWarning.get_check(
            **check_attrs,
            check_passed=False,
            check_message=(
                "Please use Service (Objects > Services) with custom timeouts"
                " and use in Security Policy."
            )
        )
