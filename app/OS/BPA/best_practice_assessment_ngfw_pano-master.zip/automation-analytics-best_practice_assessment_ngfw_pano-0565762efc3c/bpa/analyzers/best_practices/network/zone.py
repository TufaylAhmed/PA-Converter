from typing import Optional

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote
from ....models.network.zone import ZoneModel


class ZoneAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > ZoneAnalyzer"""

    def _check_zone_protection_profile(self, zone: ZoneModel) -> BestPracticeWarning:
        check_attrs = self.check_info["60"]
        if zone.zone_protection_profile is None:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="Zone should have a zone protection profile applied"
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_user_id_acl_include(
        self, zone: ZoneModel
    ) -> Optional[BestPracticeWarning]:
        """Note: This check should only apply if User ID is enabled on the zone. If not, skip."""
        check_attrs = self.check_info["61"]
        if zone.user_id_enabled:
            if not zone.using_acl_include_list:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message="When User ID is enabled, you should also be using an ACL Include List"
                )
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_user_id_enabled(self, zone: ZoneModel) -> Optional[BestPracticeNote]:
        check_attrs = self.check_info["62"]
        if zone.user_id_enabled:
            return BestPracticeNote.get_check(
                **check_attrs, check_message="Only enable User ID on trusted zones"
            )

    def _check_packet_buffer_protection_enabled(
        self, zone: ZoneModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["212"]
        if self.objects.tree.version >= 8:
            if not zone.packet_buffer_protection_enabled:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message="It is recommended to enable Packet Buffer Protection."
                )
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
