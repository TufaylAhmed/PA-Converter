import copy
from typing import Dict, Optional

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote
from ....models.constants import NONE
from ....models.device.high_availability import HighAvailabilityModel


class HighAvailabilityAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > HighAvailabilityAnalyzer"""

    # NOTE: Noticed the "Unknown" constant in CLI output
    UNKNOWN = "Unknown"

    content_categories = (
        "anti-virus",
        "application-content",
        "threat-content",
        "url-database",
    )

    def get_configuration(self, model) -> Dict:
        """Get configuration.

        NOTE: Requires deepcopy to avoid cache being modified
        if publisher is run multiple times on the same
        controller instance.
        """
        config = copy.deepcopy(model.to_dict())
        for attr in ["ha1_config", "ha2_config", "ha3_config"]:
            config[attr] = config["general_config"].pop(attr)
        tree, sys_info = self.objects.tree, self.objects.system_info
        if tree.ngfw:
            category_config = {"content_versions": []}
            any_known_local_versions = False
            any_known_peer_versions = False
            for category in self.content_categories:
                local_key = f"ha-local-{category}"
                peer_key = f"ha-peer-{category}"
                local_val = sys_info.get(local_key, self.UNKNOWN)
                peer_val = sys_info.get(peer_key, self.UNKNOWN)
                any_known_local_versions |= local_val != self.UNKNOWN
                any_known_peer_versions |= peer_val != self.UNKNOWN
                category_config["content_versions"].append(
                    {
                        "name": category,
                        "local_version": local_val,
                        "peer_version": peer_val,
                    }
                )
            if not any_known_local_versions:
                for v in category_config["content_versions"]:
                    v.pop("local_version")
            if not any_known_peer_versions:
                for v in category_config["content_versions"]:
                    v.pop("peer_version")
            if any_known_local_versions or any_known_peer_versions:
                config = {**config, **category_config}
        return config

    def _check_config_sync(
        self, ha: HighAvailabilityModel
    ) -> Optional[BestPracticeWarning]:
        check_attrs = self.check_info["136"]
        if ha.ha_enabled:
            if ha.general_config.config_sync_enabled is False:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message='If HA is enabled, it is recommended to also turn on "Enable Config Sync".',
                )
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_peer_ip_backup(
        self, ha: HighAvailabilityModel
    ) -> Optional[BestPracticeWarning]:
        check_attrs = self.check_info["138"]
        if ha.ha_enabled and (self.objects.tree.ngfw or ha.template_name is not None):
            if ha.general_config.peer_ip_backup == NONE:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message="If HA is enabled, it is recommended to configure a Peer IP Backup.",
                )
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_passive_link_state(
        self, ha: HighAvailabilityModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["139"]
        if ha.ha_enabled and ha.general_config.mode == "active-passive":
            if ha.general_config.passive_link_state == "auto":
                return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
            else:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message='It is recommended to set the Passive Link State to "Auto".',
                )

    def _check_preemptive_enabled_note(
        self, ha: HighAvailabilityModel
    ) -> BestPracticeNote:
        check_attrs = self.check_info["140"]
        if ha.ha_enabled:
            if not ha.general_config.preemptive_enabled:
                return BestPracticeNote.get_check(
                    **check_attrs,
                    check_severity="Caution",
                    check_message="Disabling Preemptive is good in environments that need minimal failover events "
                    "or want to do root cause analysis for failover event. If we want the primary device "
                    "to resume as active, Preemptive should be enabled.",
                )
            else:
                return BestPracticeNote.get_check(
                    **check_attrs,
                    check_severity="Caution",
                    check_message="Enabling Preemptive is good if we want the primary device to resume as active. "
                    "If we want minimal failover events or want to do root cause analysis for failover "
                    "events, Preemptive should be disabled.",
                )

    def _check_heartbeat_backup_enabled(
        self, ha: HighAvailabilityModel
    ) -> BestPracticeWarning:
        """
        If HA1 and HA1-backup are configured with data plane ports -> Heartbeat backup is needed.
        If Management port is used as HA1 backup -> Heartbeat backup is not needed.
        """
        check_attrs = self.check_info["141"]
        if (
            ha.ha_enabled
            and ha.general_config.ha1_config is not None
            and ha.general_config.ha1_config.backup_port != "management"
        ):
            if not ha.general_config.heartbeat_backup_enabled:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message='It is recommended to enable "Heartbeat Backup".',
                )
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_timers(self, ha: HighAvailabilityModel) -> BestPracticeWarning:
        check_attrs = self.check_info["142"]
        if ha.ha_enabled:
            if ha.general_config.timers != "recommended":
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message='It is recommended to set "HA Timer Settings" to "Recommended".',
                )
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_ha1_encryption_enabled(
        self, ha: HighAvailabilityModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["143"]
        if ha.ha_enabled and ha.general_config.ha1_config is not None:
            if not ha.general_config.ha1_config.encryption_enabled:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message="HA1 encryption needed only if the HA pair firewalls are physically far apart OR "
                    "HA1 connection goes through a network device where the HA1 traffic "
                    "can be inspected or packet capture made.",
                )
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_ha2_session_sync_enabled(
        self, ha: HighAvailabilityModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["144"]
        if ha.ha_enabled and ha.general_config.ha2_config is not None:
            if not ha.general_config.ha2_config.session_sync_enabled:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message='It is recommended to enable "Session Syncronization".',
                )
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_ha2_keep_alive_enabled(
        self, ha: HighAvailabilityModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["145"]
        if ha.ha_enabled and ha.general_config.ha2_config is not None:
            if not ha.general_config.ha2_config.keep_alive_enabled:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message='It is recommended to enable "HA2 Keep-alive".',
                )
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_ha2_action(self, ha: HighAvailabilityModel) -> BestPracticeWarning:
        check_attrs = self.check_info["146"]
        if ha.ha_enabled and ha.general_config.ha2_config is not None:
            if ha.general_config.ha2_config.action != "log-only":
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message='It is recommended to set the "Keep-alive Action" to "log-only".',
                )
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_ha3_interface(self, ha: HighAvailabilityModel) -> BestPracticeWarning:
        check_attrs = self.check_info["147"]
        if ha.ha_enabled and ha.general_config.mode == "active-active":
            if ha.general_config.ha3_config.interface == NONE:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message="When using Active-Active mode, you must configure an HA3 interface.",
                )
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    # TODO: Sync with Samshodh on the logic for this check
    def _check_ha3_session_owner_selection(
        self, ha: HighAvailabilityModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["148"]
        if ha.ha_enabled:
            if ha.general_config.mode == "active-active":
                if (
                    ha.general_config.ha3_config.session_owner_selection
                    != "primary-device"
                ):
                    return BestPracticeWarning.get_check(
                        **check_attrs, check_passed=True
                    )
                else:
                    return BestPracticeWarning.get_check(
                        **check_attrs,
                        check_passed=False,
                        check_message='When using Active-Active mode, it is recommended to use "first-packet" '
                        "for the Session Owner Selection.",
                    )

    def _check_link_path_monitoring(
        self, ha: HighAvailabilityModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["149"]
        if ha.ha_enabled:
            if not any(
                [
                    ha.link_path_monitoring_config.path_monitoring_enabled,
                    ha.link_path_monitoring_config.link_monitoring_enabled,
                ]
            ):
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message="It is recommended to enable and configure Link Monitoring or Path Monitoring.",
                )
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_link_monitoring_groups(
        self, ha: HighAvailabilityModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["150"]
        if ha.ha_enabled and ha.link_path_monitoring_config.link_monitoring_enabled:
            if not ha.link_path_monitoring_config.link_monitoring_groups:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message="If Link Monitoring is enabled, it is recommended to configure "
                    "at least one Link Group.",
                )
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_path_monitoring_groups(
        self, ha: HighAvailabilityModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["151"]
        message_lst = []
        if ha.ha_enabled:
            if not ha.link_path_monitoring_config.path_monitoring_enabled:
                message_lst.append(
                    "If High Availability (HA) is enabled, it is recommended to enable Path Monitoring"
                )
            if not self.objects.tree.panorama:
                if not ha.link_path_monitoring_config.destination_ip_set:
                    message_lst.append(
                        "If Path Monitoring is enabled, it is recommended to configure and set Destination IP for at "
                        "least one Path Group"
                    )
                if not ha.link_path_monitoring_config.one_group_enabled:
                    message_lst.append(
                        "If Path Monitoring is enabled, it is recommended to configure at least one of the following:"
                        " Path Monitoring Groups Vlan, Path Monitoring Groups Vwire or Path Monitoring Groups Vrouter"
                    )
            else:
                if not ha.link_path_monitoring_config.destination_ip_set:
                    message_lst.append(
                        "If Path Monitoring is enabled, it is recommended to configure and set Destination IP for at "
                        "least one Path Group"
                    )
                if not ha.link_path_monitoring_config.one_group_enabled:
                    message_lst.append(
                        "If Path Monitoring is enabled, it is recommended to configure and enable at least one "
                        "Path Group"
                    )
            if message_lst:
                return BestPracticeWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message=" AND ".join(message_lst),
                )
            else:
                return BestPracticeWarning.passing(**check_attrs)

    def _check_pair_content_version(
        self, ha: HighAvailabilityModel
    ) -> Optional[BestPracticeNote]:
        if self.objects.tree.panorama:
            return
        check_attrs = self.check_info["265"]
        local_versions = []
        peer_versions = []
        for category in self.content_categories:
            local_k = f"ha-local-{category}"
            peer_k = f"ha-peer-{category}"
            if local_k not in self.objects.system_info:
                continue
            if peer_k not in self.objects.system_info:
                continue
            local_v = self.objects.system_info[local_k]
            local_versions.append(local_v)
            peer_v = self.objects.system_info[peer_k]
            peer_versions.append(peer_v)
        if all(v == self.UNKNOWN for v in local_versions):
            return
        if all(v == self.UNKNOWN for v in peer_versions):
            return
        for local_v, peer_v in zip(local_versions, peer_versions):
            if local_v != peer_v:
                return BestPracticeNote(
                    check_message=(
                        "HA Pair content versions needs to be same for "
                        "Apps & Threat, Antivirus and URL database version so that "
                        "both the devices work exactly the same without change in "
                        "the behavior."
                    ),
                    **check_attrs,
                )
