# -*- coding: utf-8 -*-
import logging
from typing import List, Dict

from ..base_analyzer import BestPracticesAnalyzer
from ....models.objects.hip_profile import HipProfileModel

LOG = logging.getLogger(__name__)


class HipProfileAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > HipProfileAnalyzer"""

    def check_hip_profiles_not_in_rules(self, profile: HipProfileModel) -> str:
        """

        Args:
            profile: takes individual HipProfileModel

        Returns:
             "yes" or "no"
        """
        rule_ms = self.objects.get("security_rule")

        key = (profile.location, profile.name)
        rules = rule_ms.hip_profiles_with_rules[key]

        for rule in rules:
            if profile.name in rule.hip_profiles:
                return "Yes"
        else:
            return "No"

    def get_checks(self) -> List:
        """On NGFWs, only evaluate HIP Profile checks if there is an active
        GlobalProtect Portal or GlobalProtect Gateway license."""
        if self.objects.tree.ngfw:
            if not self.objects.license_info.has_active_gp_license():
                LOG.debug("No active GP licenses, so skipping HIP Profile checks")
                return []
        return super().get_checks()

    def get_configuration(self, model) -> Dict:
        model_dict = model.to_dict()
        model_dict["profile_used_in_rules"] = self.check_hip_profiles_not_in_rules(
            model
        )
        return model_dict
