import copy
import logging
from typing import Optional, Union

from bpa.analyzers.best_practices.bp_check import BestPracticeNote
from ...bp_check import BestPracticeWarning
from .common import DeviceSetupAnalyzer


LOG = logging.getLogger(__name__)


class AuthenticationSettingsAnalyzer(DeviceSetupAnalyzer):
    """BestPracticesAnalyzer > DeviceSetupAnalyzer > GeneralSettingsAnalyzer"""

    target_attr = "authentication"

    @classmethod
    def build_analyzer_key(cls) -> str:
        return "device_setup_authentication"

    def get_configuration(self, model, device_setup):
        config = copy.deepcopy(super().get_configuration(model, device_setup))
        if self.objects.tree.version < 9.0:
            config.pop("api_key_lifetime")
        return config

    def _validate_external_authentication(self, profile_or_seq_name, template_name):
        """
        1.1.1) Is it type: Authentication Profile & has an external method of authentication set.
            OR
        1.1.2) Is it type: Authentication Sequence & the first Authentication Profile
            has an external method of authentication set.

        """
        # Need to determine if it is a profile or sequence and check if it has and external method
        auth_profile = self.get_models("authentication_profile").findany(
            template_name=template_name, name=profile_or_seq_name
        )
        if auth_profile is not None:
            return bool(auth_profile.external_method)

        auth_sequence = self.get_models("authentication_sequence").findany(
            template_name=template_name, name=profile_or_seq_name
        )
        if auth_sequence is not None:
            # First should be external
            if (
                auth_sequence.auth_profile_objs
                and auth_sequence.auth_profile_objs[0].external_method
            ):
                return True
        return False

    def _has_external_authentication_setup(self, auth_settings, device_setup) -> bool:
        """
        1.1) Device tab > Setup > Management > Auth Settings
            Has an authentication profile configured with external authentication method
        OR
        1.2) Device Tab > Administrators
            At least 1 Admin should have External Auth profile configure
        """
        # 1.1) Device tab > Setup > Management > Auth Settings
        if auth_settings.authentication_profile is not None:
            # Need to determine if it is a profile or sequence and check if it has and external method
            _is_external_setup = self._validate_external_authentication(
                profile_or_seq_name=auth_settings.authentication_profile,
                template_name=device_setup.template_name,
            )
            if _is_external_setup:
                return True

        # 1.2) Device Tab > Administrators
        admins = self.get_models("administrator").findall(
            template_name=device_setup.template_name
        )
        if admins:
            # At least 1 Admin should have External Auth profile configured
            for admin in admins:
                if admin.authentication_profile:
                    _is_external_setup = self._validate_external_authentication(
                        profile_or_seq_name=admin.authentication_profile,
                        template_name=device_setup.template_name,
                    )
                    if _is_external_setup:
                        return True
        return False

    def _check_authentication_profile_warn(
        self, auth_settings, device_setup
    ) -> Union[BestPracticeWarning, BestPracticeNote]:
        """Warn if an Auth Profile is not configured.

        Checks
            1) Check External Authentication Methods setup
            2) Check Local Authentication Methods setup as backup options

        Failing: If Check 1 fails
        Passing: Both 1 & 2 need to pass for check to pass
        Note: If Check 1 passes but Check 2 Fails

        """
        check_attrs = self.check_info["92"]

        # Check for external authentication either at
        #   Device tab > Setup > Management > Auth Settings
        #       OR Administrators > having Auth profiles with External Authentication
        _has_external_authentication = self._has_external_authentication_setup(
            auth_settings=auth_settings, device_setup=device_setup
        )

        if not _has_external_authentication:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message=f"It is recommended to setup external authentication for admin access into the system.",
            )

        admins = self.get_models("administrator").findall(
            template_name=device_setup.template_name
        )
        local_auth_admins = sum(admin.using_local_authentication() for admin in admins)

        if local_auth_admins < 1:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message=f"It is recommended to setup one or two admins (currently you have: {local_auth_admins}) "
                f"with local authentication configured as a backup",
            )
        elif local_auth_admins in (1, 2):
            return BestPracticeWarning.passing(**check_attrs)
        else:
            return BestPracticeNote(
                **check_attrs,
                check_message=f"Ensure only one or two admins are configured with local authentication "
                f"as it is only needed as a backup (currently you have: {local_auth_admins})",
            )

    def _check_certificate_profile_warn(
        self, auth_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["93"]
        if auth_settings.certificate_profile is None:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to configure a certification profile.",
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_idle_timeout_warn(
        self, auth_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["94"]
        if 0 < auth_settings.idle_timeout <= 10:
            return BestPracticeWarning.passing(**check_attrs)
        return BestPracticeWarning(
            **check_attrs,
            check_passed=False,
            check_message="It is recommended for idle timeout to be set to a value between 1 and 10.",
        )

    def _check_failed_attempts_warn(
        self, auth_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["95"]
        if 0 < auth_settings.failed_attempts <= 5:
            return BestPracticeWarning.passing(**check_attrs)
        else:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to configure the number of failed attempts to a value ranging from 1 to 5.",
            )

    def _check_lockout_time_warn(
        self, auth_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["96"]
        if 30 <= auth_settings.lockout_time <= 45:
            return BestPracticeWarning.passing(**check_attrs)
        return BestPracticeWarning(
            **check_attrs,
            check_passed=False,
            check_message="It is recommended to configure lockout time to a value between 30 and 45 minutes.",
        )

    def _check_api_key_lifetime_warn(
        self, auth_settings, device_setup
    ) -> Optional[BestPracticeWarning]:
        if self.objects.tree.version < 9.0:
            return
        check_attrs = self.check_info["243"]
        if auth_settings.api_key_lifetime <= 0:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to configure API key lifetime to a non-zero value to have a definite expiration time.",
            )
        return BestPracticeWarning.passing(**check_attrs)
