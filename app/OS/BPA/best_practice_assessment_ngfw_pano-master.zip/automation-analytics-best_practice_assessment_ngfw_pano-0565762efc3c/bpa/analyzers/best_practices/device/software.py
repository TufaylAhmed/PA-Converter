import logging
from typing import List, Optional, Union

from bpa.models.utils.software import get_release_date_info

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeNote, BestPracticeWarning
from ..bp_result import BestPracticeResult

LOG = logging.getLogger(__name__)


class SoftwareAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > SoftwareAnalyzer"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.is_eol, self.eol_date = self.objects.is_eol
        self.version = self.objects.tree.version

    def _check_version_eol(self) -> Optional[BestPracticeNote]:
        if self.is_eol:
            check_attrs = self.check_info["240"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message=(
                    f"PAN-OS v{self.version} reached End-of-Life on {self.eol_date}. "
                    "It is recommended to upgrade."
                ),
            )

    def _check_old_version(self) -> Union[BestPracticeNote, BestPracticeWarning, None]:
        version = self.objects.tree._version
        release_date_info = get_release_date_info(version, self.objects.release_dates)
        if release_date_info is None:
            LOG.error(f"Unknown release date for version {version}")
            return
        release_date, days_since_release = release_date_info
        check_attrs = self.check_info["269"]
        if days_since_release < 180:
            result = BestPracticeWarning.passing(**check_attrs)
        elif days_since_release > 365:
            result = BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message=f"PAN-OS version {version} is over 365 days old.",
            )
        else:
            result = BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message=f"PAN-OS version {version} is over 180 days old.",
            )
        return result

    def get_results(self) -> List[BestPracticeResult]:
        release_date_info = get_release_date_info(
            self.objects.tree._version, self.objects.release_dates
        )
        configuration = {
            "PAN-OS Version": self.objects.tree._version,
            "End-of-Life Date": self.eol_date,
        }
        if release_date_info is not None:
            release_date, days_since_release = release_date_info
            configuration.update(
                {
                    "Release Date": release_date.strftime("%m/%d/%Y"),
                    "Days Since Release": days_since_release,
                }
            )
        checks = self.run_checks()
        return [BestPracticeResult(configuration, checks)]
