import logging
from typing import Optional, Dict

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning
from ....models.device.certificate import CertificateModel

LOG = logging.getLogger(__name__)


class CertificateAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > CertificateAnalyzer"""

    def _check_forward_decryption_certificate(
        self, certificate: CertificateModel
    ) -> Optional[BestPracticeWarning]:
        """
        Passing: Either forward_trust or forward_untrust is set on a given certificate
        Fail: Both forward_trust and forward_untrust are set on a given certificate
        Skip: Neither forward_trust nor forward_untrust is set on a given certificate

        """
        check_attrs = self.check_info["267"]

        if (
            certificate.forward_trust_certificate
            and certificate.forward_untrust_certificate
        ):
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="Both forward trust and forward untrust should not be set on the same certificate"
            )
        elif (
            certificate.forward_trust_certificate
            or certificate.forward_untrust_certificate
        ):
            return BestPracticeWarning.passing(**check_attrs)

    def get_configuration(self, model) -> Dict:
        return {
            "name": model.name,
            "expiry": model.expiry,
            "forward_trust_certificate": model.forward_trust_certificate,
            "forward_untrust_certificate": model.forward_untrust_certificate,
        }
