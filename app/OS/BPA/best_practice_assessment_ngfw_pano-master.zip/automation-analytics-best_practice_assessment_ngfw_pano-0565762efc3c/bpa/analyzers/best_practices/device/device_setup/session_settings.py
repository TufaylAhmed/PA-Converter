import logging
from typing import Optional

from ...bp_check import BestPracticeNote, BestPracticeWarning
from .common import DeviceSetupAnalyzer


LOG = logging.getLogger(__name__)


class ServicesSettingsAnalyzer(DeviceSetupAnalyzer):
    """BestPracticesAnalyzer > DeviceSetupAnalyzer > ManagementInterfaceSettingsAnalyzer"""

    target_attr = "session"

    @classmethod
    def build_analyzer_key(cls) -> str:
        return "device_setup_session"

    def _check_rematch_sessions_enabled_warn(
        self, session_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["120"]
        if not session_settings.rematch_sessions_enabled:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to have Rematch Sessions enabled"
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_accelerated_aging_enabled_warn(
        self, session_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["121"]
        if not session_settings.accelerated_aging_enabled:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to have Accelerated Aging enabled"
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_timeout_default_warn(
        self, session_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["122"]
        if session_settings.timeout_settings.default != 30:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to use default settings for Session Timeouts."
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_timeout_discard_default_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if session_settings.timeout_settings.discard_default != 60:
            check_attrs = self.check_info["123"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Please ensure you intended to change the timeout setting from the default."
            )

    def _check_timeout_discard_tcp_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if session_settings.timeout_settings.discard_tcp != 90:
            check_attrs = self.check_info["124"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Please ensure you intended to change the timeout setting from the default."
            )

    def _check_timeout_discard_udp_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if session_settings.timeout_settings.discard_udp != 60:
            check_attrs = self.check_info["125"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Please ensure you intended to change the timeout setting from the default."
            )

    def _check_timeout_icmp_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if session_settings.timeout_settings.icmp != 6:
            check_attrs = self.check_info["126"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Please ensure you intended to change the timeout setting from the default."
            )

    def _check_timeout_scan_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if session_settings.timeout_settings.scan != 10:
            check_attrs = self.check_info["127"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Please ensure you intended to change the timeout setting from the default."
            )

    def _check_timeout_tcp_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if session_settings.timeout_settings.tcp != 3600:
            check_attrs = self.check_info["128"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Please ensure you intended to change the timeout setting from the default."
            )

    def _check_timeout_tcp_handshake_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if session_settings.timeout_settings.tcp_handshake != 10:
            check_attrs = self.check_info["129"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Please ensure you intended to change the timeout setting from the default."
            )

    def _check_timeout_tcp_init_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if session_settings.timeout_settings.tcp_init != 5:
            check_attrs = self.check_info["130"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Please ensure you intended to change the timeout setting from the default."
            )

    def _check_timeout_tcp_half_closed_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if session_settings.timeout_settings.tcp_half_closed != 120:
            check_attrs = self.check_info["131"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Please ensure you intended to change the timeout setting from the default."
            )

    def _check_timeout_tcp_time_wait_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if session_settings.timeout_settings.tcp_time_wait != 15:
            check_attrs = self.check_info["132"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Please ensure you intended to change the timeout setting from the default."
            )

    def _check_timeout_unverified_rst_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if session_settings.timeout_settings.unverified_rst != 30:
            check_attrs = self.check_info["133"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Please ensure you intended to change the timeout setting from the default."
            )

    def _check_timeout_udp_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if session_settings.timeout_settings.udp != 30:
            check_attrs = self.check_info["134"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Please ensure you intended to change the timeout setting from the default."
            )

    def _check_timeout_captive_portal_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeNote]:
        if session_settings.timeout_settings.captive_portal != 30:
            check_attrs = self.check_info["135"]
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Please ensure you intended to change the timeout setting from the default."
            )

    def _check_session_packet_buffer_protection_warn(
        self, session_settings, device_setup
    ) -> Optional[BestPracticeWarning]:
        packet_buffer_protection = session_settings.packet_buffer_protection
        if packet_buffer_protection is None:
            return

        check_attrs = self.check_info["213"]
        message = []
        if not packet_buffer_protection.enabled:
            message.append("It is recommended to enable Packet Buffer Protection.")

        bad_settings = []
        for setting in ["alert", "activate", "block_hold_time", "block_duration"]:
            if getattr(packet_buffer_protection, setting) == 0:
                bad_settings.append(setting.replace("_", " ").title())
        if bad_settings:
            message.append(
                "The following Packet Buffer Protection settings "
                "should NOT be set to 0: {}.".format(", ".join(bad_settings))
            )

        if message:
            return BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=" ".join(message)
            )
        return BestPracticeWarning.passing(**check_attrs)

    def _check_exceed_oo_queue_disabled_warn(
        self, session_settings, device_setup
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["214"]
        if session_settings.exceed_tcp_out_of_order_queue_enabled:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message='It is recommended to disable "Forward segments exceeding TCP out-of-order queue"'
            )
        return BestPracticeWarning.passing(**check_attrs)
