import logging
from collections import OrderedDict
from typing import Dict, List

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote
from ..bp_result import BestPracticeResult
from ....models.device.authentication_profile import AuthenticationProfileModel


LOG = logging.getLogger(__name__)


class AuthenticationProfileAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > AuthenticationProfileAnalyzer

    Analyzes INDIVIDUAL Authentication Profiles.
    """

    def _check_lockout_time(
        self, profile: AuthenticationProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["156"]
        if 30 <= profile.lockout_time <= 45:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
        return BestPracticeWarning.get_check(
            **check_attrs,
            check_passed=False,
            check_message="It is recommended to configure lockout time to a value between 30 and 45 minutes.",
        )

    def _check_failed_attempts(
        self, profile: AuthenticationProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["157"]
        if 0 < profile.failed_attempts <= 5:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
        else:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to configure the number of failed attempts to a value ranging from 1 to 5.",
            )

    def _check_allow_list(
        self, profile: AuthenticationProfileModel
    ) -> BestPracticeNote:
        if "all" in profile.allow_list:
            return BestPracticeNote.get_check(
                **self.check_info["158"],
                check_message='It is recommended to use specific users or user groups instead of "all" in the allow list.',
            )


class AuthenticationProfilesAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > AuthenticationProfileAnalyzer

    Analyzes Authentication Profiles in AGGREGATE grouped by template name.
    """

    def _check_external_admin_auth(
        self, target_profiles: Dict[str, List[AuthenticationProfileModel]]
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["155"]
        bad_locations = []
        for location, profiles in target_profiles.items():
            if not any(profile.external_method for profile in profiles):
                bad_locations.append(location)
        if bad_locations:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message=(
                    "At least one authentication profile should use external authentication for the "
                    f'following locations: {", ".join(bad_locations)}'
                ),
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    @staticmethod
    def get_configuration(
        template_name: str, target_profiles: Dict[str, List[AuthenticationProfileModel]]
    ) -> Dict:
        """Since this is an AGGREGATE analyzer, show the template name as well as the
        auth profiles broken down by their location."""
        all_profiles = [
            profile for sublist in target_profiles.values() for profile in sublist
        ]
        config = {"template_name": template_name}
        profiles = []
        signatures = set()
        for profile in all_profiles:
            sig = (profile.location, profile.name, profile.method)
            if sig not in signatures:
                signatures.add(sig)
                profiles.append(
                    OrderedDict(
                        {
                            "location": profile.location,
                            "name": profile.name,
                            "method": profile.method,
                        }
                    )
                )
        config["profiles"] = profiles
        return config

    def get_results(self) -> List[BestPracticeResult]:
        """Will create a BestPracticeResult for each template name (including None for the NGFW/Panorama)"""
        results = []
        profiles = self.get_models("authentication_profile").group_by(
            "template_name", "location"
        )
        for config in self.get_models("device_config"):
            # Auth Profiles on a Panorama are stored under the panorama element,
            # so need to process them differently
            if config.template_name is None and self.objects.tree.panorama:
                continue
            target_profiles = {}
            shared_profiles = profiles[(config.template_name, "shared")]
            locations = [_ for _ in config.locations if _ != "shared"]
            for location in locations:
                vsys_profiles = profiles[(config.template_name, location)]
                target_profiles[location] = [*shared_profiles, *vsys_profiles]
            configuration = self.get_configuration(
                config.template_name, target_profiles
            )
            checks = [self._check_external_admin_auth(target_profiles)]
            results.append(BestPracticeResult(configuration, checks))

        if self.objects.tree.panorama:
            pano_profiles = {"panorama": profiles[None, "panorama"]}
            configuration = self.get_configuration(None, pano_profiles)
            checks = [self._check_external_admin_auth(pano_profiles)]
            results.append(BestPracticeResult(configuration, checks))

        return results
