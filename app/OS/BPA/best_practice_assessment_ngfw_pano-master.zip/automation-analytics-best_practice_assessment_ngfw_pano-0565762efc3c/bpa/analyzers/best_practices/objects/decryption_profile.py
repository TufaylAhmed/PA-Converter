# -*- coding: utf-8 -*-
from typing import Union

from .utils import get_percent
from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote
from ....models.objects.decryption_profile import DecryptionProfileModel
from ....models.utils.searching import find_valid_descendants


class DecryptionProfileAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > DecryptionProfileAnalyzer"""

    def _check_decryption_profile_action(
        self, profile: DecryptionProfileModel
    ) -> Union[BestPracticeNote, BestPracticeWarning, None]:
        if self.objects.tree.version < 9.0:
            return None
        check_attrs = self.check_info["270"]
        message = []
        if not profile.ssl_protocol_settings.keyxchg_algo_ecdhe:
            message.append("Ensure ECDHE exchange algorithm is enabled")
        if profile.ssl_forward_proxy.strip_alpn:
            message.append("Ensure ‘Strip ALPN’ is disabled to inspect HTTP/2 protocol")
        # default location for panorama and ngfw
        location = ["shared", "predefined"]
        #  for shared and predefined any child can access and modify data so no need to pass location.
        if profile.location in location:
            decryption_profile_models = (
                self.model_manager()
                .get("decryption_rule")
                .findall(
                    decryption_profile=profile.name, action="decrypt", rule_enabled=True
                )
            )
        else:
            # dictionary of descendant with tree data strcuture. It will only have one root node where you can traverse
            # whole tree.
            tree_dict = self.objects.tree.tree_dict
            descendants = tree_dict[profile.location]
            traverseable_descendants = find_valid_descendants(
                profiles=self.objects.get("decryption_profile"),
                descendants=descendants,
                result=[profile.location],
                name=profile.name,
            )

            decryption_profile_models = []
            # iterate through only traverseable_descendants to see if it's been used anywhere in decryption_rule
            # for ex dec. profile is from dg-usa and traverseable_descendants is dg-usa and dg-texas so only need to
            # traverse for this locations. NOTE overwritten location won't come in traversable_descendant
            for traversable_descendant in traverseable_descendants:
                decryption_profile_models.extend(
                    self.model_manager()
                    .get("decryption_rule")
                    .findall(
                        location=str(traversable_descendant),
                        decryption_profile=profile.name,
                        action="decrypt",
                        rule_enabled=True,
                    )
                )
        if len(decryption_profile_models) == 0:
            message.append(
                "Ensure Decryption policies are configured and enabled to decrypt and process HTTP/2 protocol"
            )
        if not message:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
        else:
            return BestPracticeNote.get_check(
                **check_attrs,
                check_severity="Caution",
                check_message=" , ".join(message) + ".",
            )

    def _check_ssl_forward_proxy(
        self, profile: DecryptionProfileModel
    ) -> BestPracticeWarning:
        """Fail if one of the enabled list elements are False or Fail if one of the disabled list
        elements are True """
        check_id = "55"

        message = []
        enabled = [
            "block_expired_certificate",
            "block_untrusted_issuer",
            "block_unknown_cert",
            "block_unsupported_version",
            "block_unsupported_cipher",
            "block_client_cert",
        ]
        disabled = ["block_if_no_resource", "block_if_hsm_unavailable"]
        not_enabled = [
            val for val in enabled if not getattr(profile.ssl_forward_proxy, val)
        ]
        not_disabled = [
            val for val in disabled if getattr(profile.ssl_forward_proxy, val)
        ]

        if not_enabled:
            message.append(
                "The following options need to be ENABLED: {}".format(
                    ", ".join(not_enabled)
                )
            )
        if not_disabled:
            message.append(
                "The following options need to be DISABLED: {}".format(
                    ", ".join(not_disabled)
                )
            )
        check_attrs = self.check_info[check_id]
        if message:
            return BestPracticeWarning.get_check(
                **check_attrs, check_passed=False, check_message=". ".join(message)
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_ssl_inbound_inspection(
        self, profile: DecryptionProfileModel
    ) -> BestPracticeWarning:
        """Fail if one of the not_enabled list elements are False or Fail if one of the not_disabled list
        elements are True """
        check_id = "56"
        check_attrs = self.check_info[check_id]
        message = []
        not_enabled = [
            x
            for x in ["block_unsupported_version", "block_unsupported_cipher"]
            if not getattr(profile.ssl_inbound_inspection, x, False)
        ]
        not_disabled = [
            x
            for x in ["block_if_no_resource", "block_if_hsm_unavailable"]
            if getattr(profile.ssl_inbound_inspection, x, False)
        ]

        if not_enabled:
            message.append(
                "Enable the following options: {}.".format(", ".join(not_enabled))
            )
        if not_disabled:
            message.append(
                "Disable the following options: {}.".format(", ".join(not_disabled))
            )

        if message:
            return BestPracticeWarning.get_check(
                **check_attrs, check_passed=False, check_message=" ".join(message)
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_ssl_protocol_settings(
        self, profile: DecryptionProfileModel
    ) -> BestPracticeWarning:
        """Fail if min and max protocol settings not on correct level or fail if MD5 or SHA1 are being used """
        check_id = "57"
        check_attrs = self.check_info[check_id]
        warn_message_lst = []
        if profile.ssl_protocol_settings.min_version != "tls1-2":
            warn_message_lst.append('Min Version should be set to "TLSv1.2"')
        if profile.ssl_protocol_settings.max_version != "max":
            warn_message_lst.append('Max Version should be set to "Max"')

        old_auth_algos = []
        if profile.ssl_protocol_settings.auth_algo_md5:
            old_auth_algos.append("MD5")
        if profile.ssl_protocol_settings.auth_algo_sha1:
            old_auth_algos.append("SHA1")

        old_enc_algos = []
        if profile.ssl_protocol_settings.enc_algo_rc4:
            old_enc_algos.append("RC4")
        if profile.ssl_protocol_settings.enc_algo_3des:
            old_enc_algos.append("3DES")

        def sanitize_message(collection, flavor):
            offenders = " and ".join(collection)
            middle = "they are" if len(collection) > 1 else "it is a"
            ending = flavor + " " + "algorithm"
            if len(collection) > 1:
                ending += "s"
            return f"{offenders} should not be used as {middle} weaker {ending}"

        if old_auth_algos:
            warn_message_lst.append(sanitize_message(old_auth_algos, "authentication"))

        if old_enc_algos:
            warn_message_lst.append(sanitize_message(old_enc_algos, "encryption"))

        disabled_options = []
        exclude_fields = {
            "min_version",
            "max_version",
            "auth_algo_sha1",
            "auth_algo_md5",
            "enc_algo_rc4",
            "enc_algo_3des",
        }
        for field in profile.ssl_protocol_settings.__dict__.keys():
            if (
                field not in exclude_fields
                and not profile.ssl_protocol_settings.__dict__[field]
            ):
                disabled_options.append(field)

        if disabled_options:
            warn_message_lst.append(
                "The following need to be enabled: {}".format(
                    ", ".join(disabled_options)
                )
            )
        if warn_message_lst:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message=". ".join(warn_message_lst) + ".",
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_no_decryption(
        self, profile: DecryptionProfileModel
    ) -> BestPracticeWarning:
        """Fail if one of the disabled_options list elements are False """
        check_id = "58"
        check_attrs = self.check_info[check_id]
        disabled_options = [
            field
            for field in profile.no_decryption.__dict__.keys()
            if not profile.no_decryption.__dict__[field]
        ]
        if disabled_options:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="The following options need to be enabled: {}".format(
                    ", ".join(disabled_options)
                ),
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_ssh_proxy(self, profile: DecryptionProfileModel) -> BestPracticeWarning:
        """Fail if one of the disabled_options list elements are False """
        check_id = "59"
        check_attrs = self.check_info[check_id]
        disabled_options = [
            field
            for field in profile.ssh_proxy.__dict__.keys()
            if not profile.ssh_proxy.__dict__[field]
        ]
        if disabled_options:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="The following options need to be enabled: {}".format(
                    ", ".join(disabled_options)
                ),
            )
        else:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def get_results(self):
        results = super().get_results()
        rule_ms = self.objects.get("decryption_rule")
        rule_ms_map = rule_ms.group_by("location")
        profiles_with_rules = rule_ms.decrypt_profiles_with_rules
        return get_percent(
            results,
            rule_ms_map,
            profiles_with_rules,
            self.objects.tree.descendants,
            rule_filters={"rule_enabled": True},
        )
