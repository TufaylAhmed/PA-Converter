import logging
from typing import Dict, Optional, Tuple, List, Union
from collections import defaultdict
from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import SecurityRuleWarning
from ..bp_result import BestPracticeResult
from bpa.models.policies.security_rule import SecurityRuleModel
from ....models.utils.searching import (
    get_object_from_ancestors,
    arrange_by_rulebase,
)
from bpa.models.constants import NONE_LOWER

LOG = logging.getLogger(__name__)


class SecurityRuleAnalyzer(BestPracticesAnalyzer):
    predefined_rules = ("intrazone-default", "interzone-default")

    def _check_description(self, security_rule) -> SecurityRuleWarning:
        """
        Checks that a description is configured on the rule.

        NOTE: Cannot configure a description on default rules, so exclude them from the check.
        """
        check_id = "3"
        check_attrs = self.check_info[check_id]
        if security_rule.rule_name in self.predefined_rules:
            return SecurityRuleWarning.get_check(**check_attrs, check_excluded=True)
        if not security_rule.description:
            return SecurityRuleWarning.get_check(**check_attrs, check_passed=False)
        return SecurityRuleWarning.get_check(**check_attrs, check_passed=True)

    def _check_source_destination(self, security_rule) -> SecurityRuleWarning:
        """
        Checks that allow rules do not have source/destination zones and addresses all configured to 'any'.

        NOTE: Intrazone rules are excluded from this check.
        """
        check_id = "4"
        check_attrs = self.check_info[check_id]
        if (
            security_rule.rule_type == "intrazone"
            or security_rule.rule_name in self.predefined_rules
        ):
            return SecurityRuleWarning.get_check(**check_attrs, check_excluded=True)
        if security_rule.action == "allow":
            if security_rule.source_zones == [
                "any"
            ] and security_rule.source_addresses == ["any"]:
                if security_rule.dest_zones == [
                    "any"
                ] and security_rule.dest_addresses == ["any"]:
                    return SecurityRuleWarning.get_check(
                        **check_attrs, check_passed=False
                    )
        return SecurityRuleWarning.get_check(**check_attrs, check_passed=True)

    def _check_service(self, security_rule) -> SecurityRuleWarning:
        """
        Checks that allow rules do not have service configured to 'any'.

        NOTE: Intrazone rules are excluded from this check.
        """
        check_id = "5"
        check_attrs = self.check_info[check_id]
        if (
            security_rule.rule_type == "intrazone"
            or security_rule.rule_name in self.predefined_rules
        ):
            return SecurityRuleWarning.get_check(**check_attrs, check_excluded=True)
        if "any" in security_rule.services and security_rule.action == "allow":
            return SecurityRuleWarning.get_check(**check_attrs, check_passed=False)
        return SecurityRuleWarning.get_check(**check_attrs, check_passed=True)

    def _check_application(self, security_rule) -> SecurityRuleWarning:
        """
        Checks that rules do not have application configured to 'any'.

        NOTE: Intrazone rules are excluded from this check.
        """
        check_id = "208"
        check_attrs = self.check_info[check_id]
        if (
            security_rule.action != "allow"
            or security_rule.rule_type == "intrazone"
            or security_rule.rule_name in self.predefined_rules
        ):
            return SecurityRuleWarning.get_check(**check_attrs, check_excluded=True)
        if "any" in security_rule.applications:
            return SecurityRuleWarning.get_check(**check_attrs, check_passed=False)
        return SecurityRuleWarning.passing(**check_attrs)

    def _check_app_id_service(self, security_rule) -> SecurityRuleWarning:
        """
        Fail if rule is using APP-ID without configuring a service.

        NOTE: Intrazone rules or rules with application configured to 'any' are excluded from this check.
        """
        check_id = "220"
        check_attrs = self.check_info[check_id]
        if (
            security_rule.rule_type == "intrazone"
            or security_rule.action != "allow"
            or "any" in security_rule.applications
            or security_rule.rule_name in self.predefined_rules
        ):
            return SecurityRuleWarning.get_check(**check_attrs, check_excluded=True)
        if "any" in security_rule.services:
            return SecurityRuleWarning.get_check(**check_attrs, check_passed=False)
        return SecurityRuleWarning.get_check(**check_attrs, check_passed=True)

    def _check_log_start(self, security_rule) -> SecurityRuleWarning:
        check_id = "6"
        check_attrs = self.check_info[check_id]
        if security_rule.log_start_enabled:
            return SecurityRuleWarning(
                **check_attrs, check_passed=False, check_message=None
            )
        return SecurityRuleWarning.passing(**check_attrs)

    def _check_log_forwarding(self, security_rule) -> SecurityRuleWarning:
        check_id = "7"
        check_attrs = self.check_info[check_id]
        if security_rule.log_forwarding_profile == NONE_LOWER:
            return SecurityRuleWarning.get_check(**check_attrs, check_passed=False)
        return SecurityRuleWarning.get_check(**check_attrs, check_passed=True)

    def _check_expired_non_recurring_schedule(
        self, security_rule
    ) -> SecurityRuleWarning:
        check_id = "8"
        check_attrs = self.check_info[check_id]
        if security_rule.rule_name in self.predefined_rules:
            return SecurityRuleWarning.get_check(**check_attrs, check_excluded=True)
        schedule_name = security_rule.schedule
        if schedule_name != "":
            schedule = get_object_from_ancestors(
                self.objects,
                security_rule.location,
                self.objects.get("schedules"),
                name=schedule_name,
            )
            if (
                schedule
                and any(rng.expired for rng in schedule.schedule_ranges) is True
            ):
                return SecurityRuleWarning(
                    **check_attrs, check_passed=False, check_message=None
                )
        return SecurityRuleWarning.passing(**check_attrs)

    def _check_disable_server_response_inspection_enabled(
        self, security_rule
    ) -> SecurityRuleWarning:
        check_id = "9"
        check_attrs = self.check_info[check_id]
        if security_rule.rule_name in self.predefined_rules:
            return SecurityRuleWarning.get_check(**check_attrs, check_excluded=True)
        if security_rule.disable_server_response_inspection_enabled:
            return SecurityRuleWarning.get_check(**check_attrs, check_passed=False)
        return SecurityRuleWarning.get_check(**check_attrs, check_passed=True)

    def get_configuration(self, model) -> Dict:
        configuration = super().get_configuration(model)
        rule_usage_info = self.objects.rule_usage_info

        # Validating if rule usage info is available.
        # (If it isn't then the dictionary will be empty and we will skip it)
        if rule_usage_info:
            # Validating if usage info for the particular rule is available.
            rule_usage = rule_usage_info.get(model.rule_uuid)
            configuration.update(
                {"traffic_hit": rule_usage.traffic_hit if rule_usage else False}
            )
        return configuration


class SecurityRulebaseAnalyzer(BestPracticesAnalyzer):
    def _check_quic_deny_rule(self, security_rules) -> Tuple[SecurityRuleWarning, Dict]:
        """Check whether a QUIC deny rule exists before any allow rules in the rulebase."""
        settings = {}
        check_attrs = self.check_info["241"]

        def correct_rulebase(rule) -> bool:
            """If panorama, check show be in pre-rulebase."""
            if self.objects.tree.panorama:
                return rule.rulebase == "pre-rulebase"
            else:
                return True

        check = SecurityRuleWarning(
            **check_attrs,
            check_passed=False,
            check_message=(
                "It is recommended to have a security rule with application = 'quic' and action != 'allow' before "
                "any allow rules to ensure encrypted traffic is decrypted and inspected"
            ),
        )
        enabled_rules = (rule for rule in security_rules if rule.rule_enabled)

        for rule in enabled_rules:
            if rule.action == "allow":
                break
            elif (
                rule.action != "allow"
                and "quic" in rule.applications
                and correct_rulebase(rule)
            ):
                check = SecurityRuleWarning.passing(**check_attrs)
                break
        return (check, settings)

    def _check_intrazone_default_rule(
        self, security_rules
    ) -> Tuple[SecurityRuleWarning, Dict]:
        """
        Validates whether intrazone any/any allow rule exists with IPS configured.

        Checking that action is allow and log at session end is enabled on an intrazone or universal rule.
        """
        check_attrs = self.check_info["13"]
        settings = {}
        _any = ["any"]

        for rule in security_rules:
            intrazone_any_rule = all(
                (
                    rule.rule_enabled is True,
                    rule.log_end_enabled is True,
                    rule.applications == _any,
                    rule.hip_profiles == _any,
                    rule.services == _any,
                    rule.source_addresses == _any,
                    rule.source_users == _any,
                    rule.dest_addresses == _any,
                    rule.is_intrazone is True,
                )
            )
            if intrazone_any_rule:
                if rule.action != "allow":
                    return (
                        SecurityRuleWarning.get_check(
                            **check_attrs, check_excluded=True
                        ),
                        settings,
                    )
                elif rule.using_ips_profile is True and rule.action == "allow":
                    return (SecurityRuleWarning.passing(**check_attrs), settings)
        return (
            SecurityRuleWarning(
                **check_attrs,
                check_passed=False,
                check_message=(
                    "It is recommended to override the intrazone-default rule with Action "
                    "set to 'allow', Log at Session End enabled, and IPS capability enabled."
                ),
            ),
            settings,
        )

    def _check_interzone_default_rule(
        self, security_rules
    ) -> Tuple[SecurityRuleWarning, Dict]:
        """
        Validates whether interzone any/any deny rule exists.

        Checking that action is deny and log at session end is enabled on an interzone or universal rule.
        """
        check_attrs = self.check_info["12"]
        settings = {}
        _any = ["any"]
        rule_types = {"interzone", "universal"}

        for rule in security_rules:
            passing = all(
                (
                    rule.rule_enabled is True,
                    rule.log_end_enabled is True,
                    rule.action != "allow",
                    rule.applications == _any,
                    rule.hip_profiles == _any,
                    rule.services == _any,
                    rule.source_addresses == _any,
                    rule.source_users == _any,
                    rule.source_zones == _any,
                    rule.dest_addresses == _any,
                    rule.dest_zones == _any,
                    rule.rule_type in rule_types,
                )
            )
            if passing:
                return (SecurityRuleWarning.passing(**check_attrs), settings)
        return (
            SecurityRuleWarning(
                **check_attrs,
                check_passed=False,
                check_message=(
                    "It is recommended to override the interzone-default rule with any Action except 'allow' and "
                    "Log at Session End enabled."
                ),
            ),
            settings,
        )

    def _check_disabled_rules(self, security_rules) -> Tuple[SecurityRuleWarning, Dict]:
        check_id = "11"
        check_attrs = self.check_info[check_id]
        settings = {}

        disabled_count = len([rule for rule in security_rules if not rule.rule_enabled])

        if disabled_count > 0:
            return (
                SecurityRuleWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message=f"{disabled_count} disabled rules exist",
                ),
                settings,
            )
        return (
            SecurityRuleWarning.get_check(**check_attrs, check_passed=True),
            settings,
        )

    def _check_rules_using_hip_profile(
        self, security_rules
    ) -> Tuple[SecurityRuleWarning, Dict]:
        check_id = "15"
        check_attrs = self.check_info[check_id]
        settings = {}

        rules_using_hip_profile = any(
            rule for rule in security_rules if len(rule.hip_profiles) > 0
        )

        if not rules_using_hip_profile:
            return (
                SecurityRuleWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message="It is recommended to use HIP Profiles in rulebase",
                ),
                settings,
            )
        return (
            SecurityRuleWarning.get_check(**check_attrs, check_passed=True),
            settings,
        )

    def _check_user_id_rules_without_user_id_on_zone(
        self, security_rules
    ) -> Tuple[Optional[SecurityRuleWarning], Optional[Dict]]:
        """Fail if there are any enabled allow rules with User-ID configured where any of the source zones
        do not also have User-ID configured.

        NOTE: This check currently only applies to NGFWs.
        """
        check_id = "16"
        check_attrs = self.check_info[check_id]
        settings = {}

        if self.objects.tree.panorama:
            return (None, None)

        zones = self.objects.get("zone")

        bad_zone_names = []

        # TODO: Sync with Samshodh on for loop
        if self.objects.tree.panorama:
            base_loc = "vsys1"
        else:
            base_loc = None

        applicable_rules = False
        for rule in security_rules:
            if not all(
                [
                    rule.rule_enabled is True,
                    rule.action == "allow",
                    rule.user_id_configured(),
                ]
            ):
                continue
            applicable_rules = True
            for source_zone in rule.source_zones:
                zone = zones.find(
                    name=source_zone,
                    template_name=None,
                    location=base_loc or rule.location,
                )
                if zone is not None:
                    if not zone.user_id_enabled:
                        bad_zone_names.append(zone.name)

        if applicable_rules is False:
            return (None, None)

        if bad_zone_names:
            bad_content = ", ".join(bad_zone_names)
            return (
                SecurityRuleWarning.get_check(
                    **check_attrs,
                    check_passed=False,
                    check_message=f"The following zones do not have User ID enabled: {bad_content}",
                ),
                settings,
            )
        return (
            SecurityRuleWarning.get_check(**check_attrs, check_passed=True),
            settings,
        )

    def _check_new_apps_with_app_filter(
        self, security_rules
    ) -> Tuple[SecurityRuleWarning, Optional[Dict]]:
        # NOTE: Applies to 8.1+ and NGFW
        if self.objects.tree.version < 8.1 or self.objects.tree.panorama:
            return (None, None)

        check_attrs = self.check_info["249"]

        # Point 1: Ensure there is an Application Filter Object with check box enabled for "Apply to New APP-IDs only"
        # Point 2: Check if a Security rule has this App filter configured and Action set to Permit.
        good_rule_exists = False
        for rule in security_rules:
            allow_action = rule.action == "allow"
            good_filter = any(f.new_app_id_enabled for f in rule.app_filters)
            good_rule_exists = good_rule_exists or (good_filter and allow_action)

        # NOTE: Only one DynamicUpdatesModel exists in NGFW devices
        updates_ms = self.objects.get("dynamic_updates")
        updates = updates_ms.findany()

        # Point 3: Check in Dynamic Updates > (Apps, Threat content Update)
        # This option "Disable new apps in content update" is not enabled.
        bad_updates = []
        for k, v in updates.update_types.items():
            if k == "threats" and v and v.disable_new_content:
                bad_updates.append(k)

        messages = []
        if not good_rule_exists:
            messages.append(
                "Configure a security rule with an action of allow"
                ' and an application filter with "new App-IDs only" enabled'
                " to ensure business critical applications"
                " function as expected"
            )
        if bad_updates:
            messages.append(
                'Ensure that the "Disable new apps in content update"'
                " option in the Application and Threats Update Schedule"
                " is NOT enabled"
            )

        if messages:
            return (
                SecurityRuleWarning(
                    **check_attrs, check_passed=False, check_message=". ".join(messages)
                ),
                {},
            )
        return SecurityRuleWarning.passing(**check_attrs), {}

    def _check_panw_known_malicious_ip_inbound_rule(
        self, security_rules: List[SecurityRuleModel]
    ) -> Union[Tuple[SecurityRuleWarning, Dict], Tuple[None, None]]:
        """
        Fail if any of the conditions are not met:
        - Source address should be Palo Alto Networks - Known malicious IP addresses
        - Deny traffic if matched
        - Enable logging at session end
        - Ensure a log forwarding profile is set
        """

        # Check is only applicable on OS 8.1 and higher
        if self.objects.tree.version < 8.1:
            return None, None

        check_attrs = self.check_info["261"]
        settings = {}
        manditory_source_address = "panw-known-ip-list"

        for rule in security_rules:
            passing = all(
                (
                    rule.rule_enabled is True,
                    manditory_source_address in rule.source_addresses,
                    rule.action != "allow",
                    rule.log_end_enabled is True,
                    rule.is_log_forwarding_enabled,
                )
            )
            if passing:
                return SecurityRuleWarning.passing(**check_attrs), settings
        return (
            SecurityRuleWarning(
                **check_attrs,
                check_passed=False,
                check_message=(
                    "It is recommended to configure and enable a deny rule with "
                    "the 'Palo Alto Networks - Known malicious IP addresses' EDL in the source address, "
                    "Log at Session End enabled, and a Log Forwarding Profile configured"
                ),
            ),
            settings,
        )

    def _check_panw_known_malicious_ip_outbound_rule(
        self, security_rules: List[SecurityRuleModel]
    ) -> Union[Tuple[SecurityRuleWarning, Dict], Tuple[None, None]]:
        """
        Fail if any of the conditions are not met:
        - Destination address should be Palo Alto Networks - Known malicious IP addresses
        - Deny traffic if matched
        - Enable logging at session end
        - Ensure a log forwarding profile is set
        """

        # Check is only applicable on OS 8.1 and higher
        if self.objects.tree.version < 8.1:
            return None, None

        check_attrs = self.check_info["262"]
        settings = {}
        manditory_destination_address = "panw-known-ip-list"

        for rule in security_rules:
            passing = all(
                (
                    rule.rule_enabled is True,
                    manditory_destination_address in rule.dest_addresses,
                    rule.action != "allow",
                    rule.log_end_enabled is True,
                    rule.is_log_forwarding_enabled,
                )
            )
            if passing:
                return SecurityRuleWarning.passing(**check_attrs), settings
        return (
            SecurityRuleWarning(
                **check_attrs,
                check_passed=False,
                check_message=(
                    "It is recommended to configure and enable a deny rule with "
                    "the 'Palo Alto Networks - Known malicious IP addresses' EDL in the destination address, "
                    "Log at Session End enabled, and a Log Forwarding Profile configured"
                ),
            ),
            settings,
        )

    def _check_panw_known_high_risk_ip_inbound_rule(
        self, security_rules: List[SecurityRuleModel]
    ) -> Union[Tuple[SecurityRuleWarning, Dict], Tuple[None, None]]:
        """Passing condition:
        - OS version should be 8.1 or higher,
        - Rule should be enabled,
        - Source address should contain Palo Alto Networks - High risk IP addresses,
        - Log at session end should be enabled along with log forwarding
        - Action can be deny OR allow. However if action is allow then profile should be
          configured with Antivirus, Vulnerablility Protection, Anti-Spyware and URL Filtering.
        - If it is a panaroma it should be configured in the pre-rulebase
        """

        # Check is only applicable on OS 8.1 and higher
        if self.objects.tree.version < 8.1:
            return None, None

        check_attrs = self.check_info["263"]
        settings = {}
        panw_highrisk_external_dynamic_list = "panw-highrisk-ip-list"

        for rule in security_rules:
            common_configurations = all(
                (
                    rule.rule_enabled is True,
                    panw_highrisk_external_dynamic_list in rule.source_addresses,
                    rule.log_end_enabled is True,
                    rule.is_log_forwarding_enabled,
                )
            )
            action_correctly_configured = any(
                (
                    rule.action
                    in {"deny", "drop", "reset-client", "reset-server", "reset-both"},
                    all(
                        (
                            rule.action == "allow",
                            rule.profile_antivirus,
                            rule.profile_anti_spyware,
                            rule.profile_vulnerability_protection,
                            rule.profile_url_filtering,
                        )
                    ),
                )
            )

            # Panaroma correctly configured
            if self.objects.tree.panorama and rule.rulebase != "pre-rulebase":
                rulebase_correctly_configured = False
            else:
                rulebase_correctly_configured = True

            passing = all(
                (
                    common_configurations,
                    action_correctly_configured,
                    rulebase_correctly_configured,
                )
            )

            if passing:
                return SecurityRuleWarning.passing(**check_attrs), settings

        panaroma_specific_warning = ""
        if self.objects.tree.panorama:
            panaroma_specific_warning = "under Pre Rules "

        return (
            SecurityRuleWarning(
                **check_attrs,
                check_passed=False,
                check_message=(
                    f"""It is recommended to configure and enable a deny rule {panaroma_specific_warning}with
                    the 'Palo Alto Networks - High risk IP addresses' EDL in the source address,
                    Log at Session End enabled, and a Log Forwarding Profile configured
                    OR an allow rule with the same configurations along with Antivirus, Vulnerablility Protection,
                    Anti-Spyware and URL Filtering profiles configured"""
                ),
            ),
            settings,
        )

    def _check_panw_known_high_risk_ip_outbound_rule(
        self, security_rules: List[SecurityRuleModel]
    ) -> Union[Tuple[SecurityRuleWarning, Dict], Tuple[None, None]]:
        """Passing condition:
        - OS version should be 8.1 or higher,
        - Rule should be enabled,
        - Destination address should contain Palo Alto Networks - High risk IP addresses,
        - Log at session end should be enabled along with log forwarding
        - Action can be deny OR allow. However if action is allow then profile should be
            configured with Antivirus, Vulnerablility Protection, Anti-Spyware and URL Filtering.
        - If it is a panaroma it should be configured in the pre-rulebase
        """

        # Check is only applicable on OS 8.1 and higher
        if self.objects.tree.version < 8.1:
            return None, None

        check_attrs = self.check_info["264"]
        settings = {}
        panw_highrisk_external_dynamic_list = "panw-highrisk-ip-list"

        for rule in security_rules:
            common_configurations = all(
                (
                    rule.rule_enabled is True,
                    panw_highrisk_external_dynamic_list in rule.dest_addresses,
                    rule.log_end_enabled is True,
                    rule.is_log_forwarding_enabled,
                )
            )
            action_correctly_configured = any(
                (
                    rule.action
                    in {"deny", "drop", "reset-client", "reset-server", "reset-both"},
                    all(
                        (
                            rule.action == "allow",
                            rule.profile_antivirus,
                            rule.profile_anti_spyware,
                            rule.profile_vulnerability_protection,
                            rule.profile_url_filtering,
                        )
                    ),
                )
            )

            # Panaroma correctly configured
            if self.objects.tree.panorama and rule.rulebase != "pre-rulebase":
                rulebase_correctly_configured = False
            else:
                rulebase_correctly_configured = True

            passing = all(
                (
                    common_configurations,
                    action_correctly_configured,
                    rulebase_correctly_configured,
                )
            )

            if passing:
                return SecurityRuleWarning.passing(**check_attrs), settings

        panaroma_specific_warning = ""
        if self.objects.tree.panorama:
            panaroma_specific_warning = "under Pre Rules "

        return (
            SecurityRuleWarning(
                **check_attrs,
                check_passed=False,
                check_message=(
                    f"""It is recommended to configure and enable a deny rule {panaroma_specific_warning}with
                    the 'Palo Alto Networks - High risk IP addresses' EDL in the destination address,
                    Log at Session End enabled, and a Log Forwarding Profile configured
                    OR an allow rule with the same configurations along with Antivirus, Vulnerablility Protection,
                    Anti-Spyware and URL Filtering profiles configured"""
                ),
            ),
            settings,
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.cache: Dict[
            Tuple[str], Tuple[List[SecurityRuleWarning], List[SecurityRuleModel]]
        ] = {}
        self.cache_lookups: Dict[str, Tuple] = {}

    def get_results(self) -> List[BestPracticeResult]:
        """Returns security rulebase checks."""

        data = self.objects.get("security_rule")
        sr_ms_map = defaultdict(
            lambda: defaultdict(
                list,
                {
                    "pre-rulebase": [],
                    "post-rulebase": [],
                    "rulebase": [],
                    "default-security-rules": [],
                },
            )
        )
        for location_data in data:
            sr_ms_map[(location_data.location,)][location_data.rulebase].append(
                location_data
            )
        results = []
        for location in self.objects.tree.locations:
            #  Need to check if coming from panorama or not since needs to reverse ancestors for panorama to handle bug
            #  for quic app deny rule. For NGFW there is no need to reverse.
            if self.objects.tree.panorama:
                ancestors = self.objects.tree.ancestors[location][::-1]
            else:
                ancestors = self.objects.tree.ancestors[location]
            # If rules are not defined in the target location (i.e. rules are only
            # defined in ancestor locations), check the cache to see if we have already
            # calculated the results for that ancestor hierarchy. The intention is to improve
            # performance for devices with a large number of device groups which do not
            # contain any rules themselves, but instead inherit them from the same ancestors.
            if (location,) not in sr_ms_map:
                cache_lookup = tuple(
                    ancestors[1:]
                )  # Exclude the first item since that is the current location
            else:
                cache_lookup = tuple(ancestors)
            self.cache_lookups[location] = cache_lookup

            try:
                checks, rules = self.cache[cache_lookup]
            except KeyError:
                pass
            else:
                configuration = {"security_rules": rules, "location": location}
                results.append(
                    BestPracticeResult(checks=checks, configuration=configuration)
                )
                continue

            LOG.debug(f"Generating results for {location} --> {cache_lookup}")
            keys = [(ancestor,) for ancestor in ancestors]
            arranged_rules_lst = arrange_by_rulebase(
                keys, sr_ms_map, self.objects.tree.panorama
            )
            rules_lst = [rule.to_dict() for rule in arranged_rules_lst]
            configuration = {"security_rules": rules_lst, "location": location}
            checks = []
            for method in self.get_checks():
                check, _ = method(arranged_rules_lst)
                if check is not None:
                    checks.append(check)

            results.append(
                BestPracticeResult(checks=checks, configuration=configuration)
            )
            self.cache[cache_lookup] = checks, rules_lst
        return results
