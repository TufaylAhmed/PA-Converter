# -*- coding: utf-8 -*-
from abc import ABCMeta
from typing import Optional

from ..utils import get_percent
from ...bp_check import BestPracticeNote
from ...base_analyzer import BestPracticesAnalyzer


class SecurityProfileAnalyzer(BestPracticesAnalyzer, metaclass=ABCMeta):
    """BestPracticesAnalyzer > SecurityProfileAnalyzer"""

    def _check_unused_security_profile(self, profile) -> Optional[BestPracticeNote]:
        """Check implementation.

        Check against each of the security profile instances
        against the security_rule_model_set - and see whether
        the profile has at least one allow rule associated with it
        using the len() function. If it is 0 - then the check fails.
        Otherwise, it succeeds.

        NOTE: Check 221 applies to Antivirus, Vulnerability Protection, Anti-Spyware,
        URL Filtering, File Blocking, Data Filtering, WildFire Analysis
        DOES NOT apply to Dos Protection or Hip Profile (has own similar check).
        """
        check_id = "221"
        check_attrs = self.check_info[check_id]
        rule_ms = self.objects.get("security_rule")

        key = (profile.location, profile.name, profile.build_model_key())
        rules = rule_ms.sec_profiles_with_allow_rules[key]

        if len(rules) == 0:
            return BestPracticeNote.get_check(
                **check_attrs,
                check_message=(
                    f"{profile.name} is not being used by any rules."
                    " Check to see if the profile can be removed."
                ),
            )

    def get_results(self):
        results = super().get_results()
        key = self.build_model_key()

        # NOTE: Avoid additional processing for DoS Protection
        if key == "dos_protection_profile":
            return results

        rule_ms = self.objects.get("security_rule")
        rule_ms_map = rule_ms.group_by("location")
        profiles_with_rules = rule_ms.sec_profiles_with_allow_rules
        return get_percent(
            results,
            rule_ms_map,
            profiles_with_rules,
            self.objects.tree.descendants,
            key=key,
            rule_filters={"rule_enabled": True, "action": "allow"},
        )
