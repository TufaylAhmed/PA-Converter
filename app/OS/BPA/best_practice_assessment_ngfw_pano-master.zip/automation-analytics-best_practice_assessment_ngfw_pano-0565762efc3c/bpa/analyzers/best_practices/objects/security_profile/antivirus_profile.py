# -*- coding: utf-8 -*-
from ...bp_check import BestPracticeWarning, BestPracticeNote
from ...objects.security_profile.common import SecurityProfileAnalyzer
from .....models.objects.security_profile.antivirus_profile import AntivirusProfileModel


class AntivirusProfileAnalyzer(SecurityProfileAnalyzer):
    """BestPracticesAnalyzer > AntivirusProfileAnalyzer"""

    @classmethod
    def build_model_key(cls):
        """NOTE: Added since the model key is hardcoded"""
        return AntivirusProfileModel.build_model_key()

    def _check_threat_exceptions_note(
        self, profile: AntivirusProfileModel
    ) -> BestPracticeNote:
        check_id = "31"
        check_attrs = self.check_info[check_id]

        if profile.threat_exceptions:
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Ensure you need threat exceptions. If there is a false positive, "
                "please open a support case with TAC to fix the issue."
            )

    def _check_application_exceptions_note(
        self, profile: AntivirusProfileModel
    ) -> BestPracticeNote:
        check_id = "32"
        check_attrs = self.check_info[check_id]
        if profile.application_exceptions:
            return BestPracticeNote(
                **check_attrs,
                check_severity="Caution",
                check_message="Ensure you need application exceptions. If there is a false positive, "
                "please open a support case with TAC to fix the issue."
            )

    def _check_decoders_action(
        self, profile: AntivirusProfileModel
    ) -> BestPracticeWarning:
        check_id = "33"
        check_attrs = self.check_info[check_id]

        passing_actions = ["drop", "reset-both", "reset-client", "reset-server"]
        bad_decoders = [
            decoder.name
            for decoder in profile.decoders
            if decoder.name in ("smtp", "smb", "ftp", "http", "http2")
            and decoder.action not in passing_actions
        ]

        if bad_decoders:
            passing_actions[-1] = "or " + passing_actions[-1]
            message = """
                The following decoder actions should be set to either {passing_actions}: {bad_decoders}
            """.format(
                passing_actions=", ".join(passing_actions),
                bad_decoders=", ".join(bad_decoders),
            )

            return BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=message
            )
        else:
            return BestPracticeWarning.passing(**check_attrs)

    def _check_decoders_wildfire_action(
        self, profile: AntivirusProfileModel
    ) -> BestPracticeWarning:
        check_id = "34"
        check_attrs = self.check_info[check_id]

        passing_actions = ["drop", "reset-both", "reset-client", "reset-server"]
        bad_decoders = [
            decoder.name
            for decoder in profile.decoders
            if decoder.name in ("smtp", "smb", "ftp", "http", "http2")
            and decoder.wildfire_action not in passing_actions
        ]

        if bad_decoders:
            passing_actions[-1] = "or " + passing_actions[-1]
            message = """
                The following decoder WildFire actions should be set to either {passing_actions}: {bad_decoders}
            """.format(
                passing_actions=", ".join(passing_actions),
                bad_decoders=", ".join(bad_decoders),
            )

            return BestPracticeWarning(
                **check_attrs, check_passed=False, check_message=message
            )
        else:
            return BestPracticeWarning.passing(**check_attrs)

    def _check_packet_capture(self, profile: AntivirusProfileModel) -> BestPracticeNote:
        check_id = "35"
        check_attrs = self.check_info[check_id]

        if profile.packet_capture_enabled:
            return BestPracticeNote(
                **check_attrs,
                check_message="It is not recommended to have Packet Capture enabled. If this is a requirement, "
                "ensure there is sufficient log storage."
            )

    def _check_reset_action_note(
        self, profile: AntivirusProfileModel
    ) -> BestPracticeNote:
        check_id = "206"
        check_attrs = self.check_info[check_id]

        if any(
            decoder
            for decoder in profile.decoders
            if decoder.action in {"reset-client", "reset-server"}
        ):
            return BestPracticeNote(
                **check_attrs,
                check_message='It is recommended to only use "reset-client" or "reset-server" actions '
                "if there is a specific business case."
            )
