from typing import DefaultDict, List, Optional, Dict

from bpa.analyzers.best_practices.bp_result import BestPracticeResult


def get_percent(
    results: List[BestPracticeResult],
    rule_ms_map: DefaultDict,
    profiles_with_rules: DefaultDict,
    tree_descendants: DefaultDict,
    key: str = None,
    rule_filters: Optional[Dict] = None,
) -> List[BestPracticeResult]:
    """Get rule usage info for a collection of profiles.

    NOTE: This logic is typically executed in the context of a profile
    analyzer. It is not designed to be used anywhere else. Future
    refactoring would be required to make this routine more robust
    but it works OK at the moment.

    Arguments:
        results: List of original Best Practice Results.
        rule_ms_map: Models grouped by location tuple.
        profiles_with_rules: Profile-rule mapping provided by model set.
        tree_descendants: Generally provided by model manager.
        key: Really only used for security rule model set.
        rule_filters: A dict whose key is an attribute of the rule model
                and value is the expect condition

    Returns:
        List of transformed Best Practice Results, sorted by the
        attribute rules_using_profile.
    """

    def filter_rules(rules: List, filtering_condition: Dict) -> List:
        """
        This will go over every rule given in rules and return only
        a list of rules that satisfy all the filtering conditions

        Args:
            rules: A List of Rule Models
            filtering_condition: A dict whose key is an attribute of the rule model
                and value is the expect condition

        Returns:

        """
        if filtering_condition:
            filtered_rules = []
            filtering_condition_items = filtering_condition.items()
            for rule in rules:
                if all(
                    [
                        getattr(rule, rule_attr) == expected_value
                        for rule_attr, expected_value in filtering_condition_items
                    ]
                ):
                    filtered_rules.append(rule)
            return filtered_rules
        else:
            return rules

    final_results = []

    # NOTE: Start additional processing for each BP result
    for result in results:
        location = result.configuration["location"]
        name = result.configuration["name"]
        sig = (location, name) if key is None else (location, name, key)

        # Step 1: Calculate numerator - number of rules using the profile
        used_rules = profiles_with_rules[sig]

        # Filtering rules
        rules_using_profile = len(
            filter_rules(rules=used_rules, filtering_condition=rule_filters)
        )

        # Step 2: Calculate denominator - number of "relevant" rules that
        # are capable of using the profile. This refers to enabled, allow rules
        # in the same location or a descendant location, so long as the descendant
        # location has not overridden the profile.
        descendants = tree_descendants[location] - {location}
        invalid_descendants = set()

        for d in descendants:
            # Ignore invalid descendants
            if d in invalid_descendants:
                continue

            # Ignore rules in current location and descendants
            # since a profile override was applied at the
            # current location
            dsig = (d, name) if key is None else (d, name, key)
            if len(profiles_with_rules[dsig]) > 0:
                invalid_descendants = invalid_descendants.union(tree_descendants[d])

        valid_rules = []
        descendants.add(location)  # need to add the originating location back in
        descendants = descendants - invalid_descendants
        for vloc in descendants:
            valid_rules.extend(
                filter_rules(
                    rules=rule_ms_map[(vloc,)], filtering_condition=rule_filters
                )
            )

        rules_that_can_use_profile = len(valid_rules)

        # Step 3: Pre-process warnings and notes
        if rules_using_profile == 0:
            if result.configuration["location"] == "predefined":
                continue
            # NOTE: Only applies for SecurityProfileAnalyzer and its subclasses.
            elif key is not None:
                result.warnings = []
                result.notes = [
                    check for check in result.notes if check.check_id == 221
                ]

        # Step 4: Store configuration to BP result
        result.configuration["rules_using_profile"] = rules_using_profile
        if rules_that_can_use_profile == 0:
            result.configuration["rules_using_profile_pct"] = "N/A"
        else:
            result.configuration["rules_using_profile_pct"] = "{:.0%}".format(
                rules_using_profile / rules_that_can_use_profile
            )

        final_results.append(result)

    final_results.sort(
        key=lambda r: r.configuration["rules_using_profile"], reverse=True
    )
    return final_results
