from typing import Optional, Union

from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning, BestPracticeNote
from ....models.constants import NONE
from ....models.network.global_protect import GlobalProtectPortalModel
from ....models.utils.searching import get_object_from_ancestors


class GlobalProtectPortalAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > GlobalProtectPortalAnalyzer"""

    def _check_enforce_gp_connection_for_network_access(
        self, portal: GlobalProtectPortalModel
    ) -> BestPracticeWarning:
        """Fail if any agent config doesn't have "No direct access to local network" enabled.

        Only applies when Tunnel Mode is enabled.
        """
        check_attrs = self.check_info["71"]
        bad_agents = [
            agent.name
            for agent in portal.agent_configs
            if agent.enforce_gp_connection_for_network_access
        ]
        if bad_agents:
            return BestPracticeWarning(
                **check_attrs,
                check_passed=False,
                check_message=f'The following Agent Configs have "Enforce GlobalProtect Connection for Network Access" enabled: {", ".join(bad_agents)}',
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_ssl_tls_service_profile_min_version(
        self, portal: GlobalProtectPortalModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["63"]
        fail_check = BestPracticeWarning.get_check(**check_attrs, check_passed=False)
        if portal.ssl_tls_service_profile == NONE:
            fail_check.check_message = "The SSL/TLS Service Profile is not configured"
            return fail_check

        ms = self.get_models("ssl_tls_service_profile")
        profile = get_object_from_ancestors(
            self.objects,
            portal.location,
            ms,
            template_name=portal.template_name,
            name=portal.ssl_tls_service_profile,
        )

        # TODO: Sync with Samshodh on whether portal is truly corrupt
        if profile is None:
            fail_check.check_message = (
                "Corrupt reference to SSL/TLS Service Profile: "
                f"{portal.ssl_tls_service_profile} @ {portal.location}"
            )
            return fail_check

        if profile.min_version != "tls1-2":
            fail_check.check_message = "The SSL/TLS Service Profile you are using ({}) has a Min Version other than "
            "TLSv1.2".format(profile.name)
            return fail_check
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_certificate_profile(
        self, portal: GlobalProtectPortalModel
    ) -> Optional[BestPracticeWarning]:
        """Two ways for check to pass:

        1) GP Gateway > Authentication Tab > Client Authentication > Authentication Profiles all have Authentication Type of Radius or SAML
        2) GP Gateway > Authentication Tab > Client Authentication > Configured with auth profile of any type
            AND Certificate Profile is configured.
        """
        check_attrs = self.check_info["64"]
        if portal.certificate_profile != NONE:
            return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
        if not portal.auth_clients:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to utilize a Certificate Profile or have all "
                "Client Authentication configs use Radius or SAML for authentication",
            )

        bad_clients = []
        for client in portal.auth_clients:
            auth_prof = get_object_from_ancestors(
                self.objects,
                portal.location,
                self.get_models("authentication_profile"),
                template_name=portal.template_name,
                name=client.auth_profile,
            )
            if auth_prof is not None and not auth_prof.using_radius_saml():
                bad_clients.append(client.name)

        if bad_clients:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="The following Client Authentication configs are not "
                f'configured to use Radius or SAML: {", ".join(bad_clients)}',
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_agent_trusted_root_ca(
        self, portal: GlobalProtectPortalModel
    ) -> BestPracticeNote:
        check_attrs = self.check_info["65"]
        if not portal.agent_trusted_root_ca:
            return BestPracticeNote.get_check(
                **check_attrs,
                check_message="It is recommended to utilize Agent Trusted Root CA",
            )
        else:
            return BestPracticeNote.get_check(
                **check_attrs,
                check_severity="Caution",
                check_message="To have the endpoints trust the GP Portal and GP Gateway Server Certificate, "
                "they should have the Root/Intermediate Certificates installed "
                "that have signed the Server Certificates.",
            )

    def _check_save_user_credentials(
        self, portal: GlobalProtectPortalModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["66"]
        saving_user_credentials = [
            config.name
            for config in portal.agent_configs
            if config.save_user_credentials == "Yes"
            or config.save_user_credentials == "Save Username Only"
        ]
        if saving_user_credentials:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is not recommended save user credentials. Please change on the following "
                "Agent Configs: {}".format(", ".join(saving_user_credentials)),
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_two_factor_authentication(
        self, portal: GlobalProtectPortalModel
    ) -> Union[BestPracticeWarning, BestPracticeNote]:
        check_attrs = self.check_info["67"]
        no_two_factor_auth = [
            config.name
            for config in portal.agent_configs
            if not config.two_factor_authentication
        ]
        if no_two_factor_auth:
            return BestPracticeNote.get_check(
                **check_attrs,
                check_message="It is recommended to use two-factor authentication for GP portal and gateways. Please add to "
                "the following Agent Configs: {}".format(", ".join(no_two_factor_auth)),
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_internal_host_detection_enabled(
        self, portal: GlobalProtectPortalModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["68"]
        no_internal_host_detection = [
            config.name
            for config in portal.agent_configs
            if not config.internal_host_detection_enabled
        ]
        if no_internal_host_detection:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended enable Internal Host Detection. Please add to the "
                "following Agent Configs: {}".format(
                    ", ".join(no_internal_host_detection)
                ),
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_using_disable_gp_app(
        self, portal: GlobalProtectPortalModel
    ) -> BestPracticeWarning:
        """Check passes if all disable timeout values are between 0 and 480 minutes.

        Value of 0 means unlimited timeout, so it should fail.
        """
        check_attrs = self.check_info["69"]
        no_disable_timeout = [
            config.name
            for config in portal.agent_configs
            if not 0 < config.disable_timeout < 480
        ]

        if no_disable_timeout:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to set Disable Timeout to be less than 8 hours. "
                "Please adjust to the following Agent Configs: {}".format(
                    ", ".join(no_disable_timeout)
                ),
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_collect_hip_data_enabled(
        self, portal: GlobalProtectPortalModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["72"]
        collect_hip_data_disabled = [
            config.name
            for config in portal.agent_configs
            if not config.collect_hip_data_enabled
        ]
        if collect_hip_data_disabled:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommened to Collect HIP Data. Please enable on the following "
                "Agent Configs: {}".format(", ".join(collect_hip_data_disabled)),
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_satellite_ocsp_responder(
        self, portal: GlobalProtectPortalModel
    ) -> Optional[BestPracticeWarning]:
        """If no satellites configed, skip the check,
        otherwise ensure GP portal has OCSP responder configured.
        """
        check_attrs = self.check_info["73"]
        if not portal.satellites_configured:
            return

        if portal.satellite_ocsp_responder == NONE:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to configure a Satellite OCSP Responder",
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)

    def _check_satellite_trusted_root_ca(
        self, portal: GlobalProtectPortalModel
    ) -> Optional[BestPracticeWarning]:
        check_attrs = self.check_info["74"]
        if not portal.satellites_configured:
            return

        if not portal.satellite_trusted_root_ca:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message="It is recommended to utilize Satellite Trusted Root CA",
            )
        return BestPracticeWarning.get_check(**check_attrs, check_passed=True)
