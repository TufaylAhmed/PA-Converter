from ..base_analyzer import BestPracticesAnalyzer
from ..bp_check import BestPracticeWarning
from bpa.models.network.interface_management_profile import (
    InterfaceManagementProfileModel,
)


class InterfaceManagementProfileAnalyzer(BestPracticesAnalyzer):
    """BestPracticesAnalyzer > InterfaceManagementProfileAnalyzer"""

    def _check_protocols(
        self, profile: InterfaceManagementProfileModel
    ) -> BestPracticeWarning:
        check_attrs = self.check_info["228"]
        suggestion = (
            "Management access should only be done via HTTPS or SSH. "
            "Please remove the following protocols: "
        )
        bad = {"http", "telnet"}
        bad_protocols = bad.intersection(profile.protocols)
        if len(bad_protocols) > 0:
            return BestPracticeWarning.get_check(
                **check_attrs,
                check_passed=False,
                check_message=(suggestion + ", ".join(bad_protocols))
            )
        return BestPracticeWarning.passing(**check_attrs)
