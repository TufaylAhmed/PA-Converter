import logging

from typing import Dict, Optional, Set, Tuple

from ...bp_check import BestPracticeNote, BestPracticeWarning
from .common import DeviceSetupAnalyzer


LOG = logging.getLogger(__name__)


class LoggingReportingSettingsAnalyzer(DeviceSetupAnalyzer):
    """BestPracticesAnalyzer > DeviceSetupAnalyzer > GeneralSettingsAnalyzer"""

    target_attr = "logging_reporting"

    # NOTE: Caches retention info for all models
    retention_info = {}

    @staticmethod
    def get_report_data(device_setup) -> Tuple[Set, Set]:
        pdf_reports = set()
        predefined_reports = set(
            device_setup.predefined_reports.enabled_predefined_reports
        )
        pdf_report_group_models = device_setup.objects.get("pdf_report_group")
        pdf_summary_report_models = device_setup.objects.get("pdf_summary_report")
        for report_group_model in pdf_report_group_models:
            for report in report_group_model.reports:
                pdf_reports.add(report)
        for pdf_summary_report in pdf_summary_report_models:
            for report in pdf_summary_report.reports:
                pdf_reports.add(report)
        return pdf_reports, predefined_reports

    @staticmethod
    def get_excess_reports(device_setup):
        pdf_reports, predefined_reports = LoggingReportingSettingsAnalyzer.get_report_data(
            device_setup
        )
        return predefined_reports - pdf_reports

    @classmethod
    def build_analyzer_key(cls) -> str:
        return "device_setup_logging_reporting"

    def get_configuration(self, model, device_setup) -> Dict:
        """
        NOTE:
        Panorama has Buffered Log Forwarding from Device configuration option (log_forwarding_from_device_enabled),
        whereas NGFWs / device templates have Log on High DP Load configuration option (log_on_high_dp_load_enabled)
        """
        config = super().get_configuration(model, device_setup)
        if device_setup.objects.tree.ngfw or device_setup.template_name is not None:
            config.pop("log_forwarding_from_device_enabled")
        else:
            config.pop("log_on_high_dp_load_enabled")
        if device_setup.template_name is None:
            self.retention_info = (
                self.retention_info
                if self.retention_info
                else {
                    k: v
                    for k, v in self.objects.system_info.items()
                    if k.startswith("log-retention")
                }
            )
            config.update(self.retention_info)
            excess_reports = self.get_excess_reports(device_setup)
            if len(excess_reports) > 0:
                config["Unused Predefined Reports"] = excess_reports
        return config

    def _check_log_on_high_dp_load_enabled(
        self, logging_reporting, device_setup
    ) -> Optional[BestPracticeWarning]:
        if logging_reporting.log_on_high_dp_load_enabled is not None:
            check_attrs = self.check_info["97"]
            if not logging_reporting.log_on_high_dp_load_enabled:
                return BestPracticeWarning(
                    **check_attrs,
                    check_passed=False,
                    check_message='It is recommended to enable "Log on High DP Load"'
                )
            return BestPracticeWarning.passing(**check_attrs)

    def _check_log_forwarding_from_device(
        self, logging_reporting, device_setup
    ) -> Optional[BestPracticeWarning]:
        if logging_reporting.log_forwarding_from_device_enabled is not None:
            check_attrs = self.check_info["98"]
            if not logging_reporting.log_forwarding_from_device_enabled:
                return BestPracticeWarning(
                    **check_attrs,
                    check_passed=False,
                    check_message="It is recommended to enable Buffered Log Forwarding from Device"
                )
            return BestPracticeWarning.passing(**check_attrs)

    def _check_log_retention_period(
        self, logging_reporting, device_setup
    ) -> BestPracticeNote:
        check_attrs = self.check_info["236"]
        return BestPracticeNote(
            **check_attrs,
            check_message=(
                "Review the current log retention for each log type "
                "and if it is more or less than necessary then change "
                "the quota settings as needed."
            )
        )

    def _check_predefined_reports(self, logging_reporting, device_setup):
        check_attrs = self.check_info["252"]
        if device_setup.template_name is not None:
            return
        excess_reports = self.get_excess_reports(device_setup)

        if len(excess_reports) > 0:
            return BestPracticeNote(
                **check_attrs,
                check_message=(
                    "Enable predefined reports only that are needed for review and analysis. Consider disabling all unused predefined reports."
                )
            )
