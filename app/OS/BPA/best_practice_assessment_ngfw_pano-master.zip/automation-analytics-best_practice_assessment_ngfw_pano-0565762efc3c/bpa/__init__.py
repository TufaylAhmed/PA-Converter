import os

from .version import __version__  # noqa


# Repo paths
base_path = os.path.dirname(os.path.realpath(__file__))
data_path = os.path.join(base_path, "data")
