import importlib
import inspect
import logging
import pkgutil
import re
from types import ModuleType
from typing import Dict

from pandas.io.json import json_normalize

LOG = logging.getLogger(__name__)


def camel_to_snake(name):
    """Convert CamelCase to snake_case.

    https://stackoverflow.com/a/1176023/614770

    Args:
        name: CamelCase name as input.

    Returns:
        snake_case name as output.
    """
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def common_key(kls) -> str:
    """Get default analyzer or model key.

    This assumes that model and analyzer class names are identical except
    for the "Model" or "Analyzer" suffix.

    Example::

        common_key(FakeModel) -> 'fake'
        common_key(FakeAnalyzer) -> 'fake'

    Args:
        kls: A model or analyzer class.

    Returns:
        A string representing the model or analyzer key.
    """
    return "_".join(camel_to_snake(kls.__name__).split("_")[:-1])


def find_classes(
    pkg: ModuleType, base_class: object, build_key: str = "default"
) -> Dict:
    """Identify classes from given package.

    Helpful links:

    - https://stackoverflow.com/questions/1707709/list-all-the-modules-that-are-part-of-a-python-package
    - https://stackoverflow.com/questions/22119850/get-all-class-names-in-a-python-package

    NOTE: Identified classes must satisfy the following criteria: it is a subclass
    of the specified base class and it has no subclasses.

    NOTE: Assume that all child classes do not have the same names. Otherwise, there would be a name
    clash in the case that build_key was set to default.

    Args:
        pkg: Package that acts as the starting point for searching.
        base_class: Used to check whether found classes are a subclass of this class.
        build_key: String name of class method used to build model/analyzer key.

    Returns:
        Mapping of subclasses discovered in target package.
    """
    valid_classes = set()
    child_classes = {}

    path = pkg.__path__
    prefix = pkg.__name__ + "."

    # Step 1: Identify valid classes
    for importer, modname, ispkg in pkgutil.walk_packages(path, prefix):
        if ispkg:
            continue
        mod = importlib.import_module(modname)
        for _, kls in inspect.getmembers(mod, inspect.isclass):
            if issubclass(kls, base_class):
                valid_classes.add(kls)

    # Step 2: Identify child classes
    for kls in valid_classes:
        if kls.__subclasses__() or inspect.isabstract(kls):
            continue
        if build_key == "default":
            key = kls.__name__
        else:
            key = getattr(kls, build_key)()
        if key not in child_classes:
            LOG.debug(f"Register {key} for {base_class.__name__}")
            child_classes[key] = kls

    return child_classes


def flatten_json(data):
    """Helper function to flatten JSON data.

    Args:
        data: dictionary containing arbitrarily nested dictionaries

    Returns:
        Shallow dictionary in which keys use dot notation to denote
        the flattened levels.
    """
    return json_normalize(data).to_dict(orient="records")[0]
