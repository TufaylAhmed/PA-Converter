# -*- coding: utf-8 -*-
from __future__ import print_function, unicode_literals
import argparse
import json
import logging
import sys
import weakref

from lxml import etree
from pandas.io.json import json_normalize
from six import iteritems

from bpa.controller import Controller
from bpa.publishers.formats.html.adapters.xml_config import XMLConfig


class SetEncoder(json.JSONEncoder):
    def default(self, obj):
       if isinstance(obj, set):
          return list(obj)
       return json.JSONEncoder.default(self, obj)


def process_normal(xml_config, args):
    """Generate data normally.
    Args:
        xml_config: XMLConfig instance.
        args: Argparse arguments.
    """
    if args.type == 'bpat':
        data = json_normalize(xml_config.bpa.json()).iloc[0].to_dict()
    elif args.type == 'heatmap':
        data = xml_config.heatmap.rules_values

    if args.stdout:
        sys.stdout.write(json.dumps(data, cls=SetEncoder))
        sys.stdout.flush()
        sys.stdout.close()
    else:
        file_name = args.xml.name
        print('Parsing config file: {}'.format(file_name))

        # Output the data to a json file
        if args.outfile is not None:
            out = open(args.outfile, 'w')
        else:
            name = '{name}{suffix}.json'.format(
                name=file_name.split('.')[0],
                suffix='-heatmap' if args.type == 'heatmap' else ''
            )

            out = open(name, 'w')

        with out as f:
            json.dump(data, f, cls=SetEncoder)


def process_autoassistant(xml_config, args):
    """Generate data for AutoAssistant.

    Args:
        xml_config: XMLConfig instance.
        args: Argparse arguments.
    """
    if args.type == 'bpat':
        try:
            data = json_normalize(xml_config.bpa.json()).iloc[0].to_dict()
        except etree.XMLSyntaxError:
            print('panw: Config file is corrupt or was modified incorrectly', file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print('panw: Config: {}'.format(e), file=sys.stderr)
            sys.exit(1)
        # AutoAssistant: Loop over each BP, Print to stdout for storing a summary
        # in the DB, then print to file for storing the details
        navCounter = {}
        for navKey, navArray in iteritems(data):
            topNav, leftNav = navKey.split(".", 1)
            topNav = topNav.replace(".", " > ").replace("_", " ").title()
            leftNav = leftNav.replace(".", " > ").replace("_", " ").title()
            for bpItem in navArray:
                # Print the individual BP, but no more than 5,000 of the same
                # topNav + leftNav (security rules can be more)
                if (topNav + leftNav in navCounter):
                    navCounter[topNav + leftNav] += 1
                else:
                    navCounter[topNav + leftNav] = 0
                if navCounter[topNav + leftNav] <= 5000:
                    # Reformat for A2 client before writing to file
                    if 'bp_check' in bpItem:
                        for index in range(len(bpItem['bp_check'])):
                            bpItem['bp_check'][index]['result'] = bpItem['bp_check'][index]['result'].title()
                            if 'type' in bpItem['bp_check'][index]:
                                if bpItem['bp_check'][index]['type'] == 'warn':
                                    bpItem['bp_check'][index]['severity'] = 'Warning'
                                elif bpItem['bp_check'][index]['type'] == 'note':
                                    bpItem['bp_check'][index]['severity'] = 'Notice'
                                bpItem['bp_check'][index].pop('type')  # remove type
                            else:
                                bpItem['bp_check'][index]['severity'] = 'Notice'
                    # Write to file for storing the details
                    with open(args.outfile, 'a') as outfile:
                        bpItem['topNav'] = topNav
                        bpItem['leftNav'] = leftNav
                        bpItem['bpCheck'] = bpItem.pop('bp_check')  # rename bp_check to bpCheck
                        outfile.write(json.dumps(bpItem, cls=SetEncoder) + "\n")
                    # Reformat for A2 DB before printing summary to stdout
                    bpItem.pop('configuration')  # remove configuration
                    if 'bpCheck' in bpItem:
                        for index in range(len(bpItem['bpCheck'])):
                            if ('name' in bpItem['bpCheck'][index]):
                                bpItem['bpCheck'][index].pop('name')  # remove name
                            if ('message' in bpItem['bpCheck'][index]):
                                bpItem['bpCheck'][index].pop('message')  # remove message
                            if ('severity' in bpItem['bpCheck'][index]):
                                bpItem['bpCheck'][index].pop('severity')  # remove severity
                            bpItem['bpCheck'][index]['bpId'] = bpItem['bpCheck'][index].pop('id')  # rename id to bpId
                            bpItem['bpCheck'][index]['result'] = 0 if bpItem['bpCheck'][index][
                                'result'] == 'Fail' else 1 if bpItem['bpCheck'][index]['result'] == 'Pass' else None
                    # Print summary to stdout
                    print(
                        json.dumps(
                            {
                                'table': 'BestPractice',
                                'topNav': topNav,
                                'leftNav': leftNav,
                                'bpCheck': bpItem['bpCheck']
                            },
                            cls=SetEncoder
                        )
                    )
                    sys.stdout.flush()
        sys.stdout.close()
    elif args.type == 'heatmap':
        try:
            heatmap = xml_config.heatmap
        except etree.XMLSyntaxError:
            print('panw: Config file is corrupt or was modified incorrectly', file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print('panw: Config: {}'.format(e), file=sys.stderr)
            sys.exit(1)

        bool_map = {'yes': 1, 'no': 0}
        for rule in heatmap.rules_values:
            for key, val in rule.items():
                try:
                    rule[key] = bool_map[val]
                except KeyError:
                    continue
            # AutoAssistant: Print to stdout for storing a summary in the DB, then print to file for storing the details
            # Print to stdout first
            if rule['rule_enabled'] == 1:
                # enabled allow rules - print all with IncludeInAnalytics true
                if rule['action'] == 'allow':
                    print(
                        json.dumps(
                            {
                                'table': 'FeatureAdoption',
                                'featureCategory': 'Security Rules',
                                'IncludeInAnalytics': 1,
                                'feature': {
                                    'wildfire': rule['wildfire_enabled'],
                                    'fileBlocking': rule['file_blocking_enabled'],
                                    'antivirus': rule['antivirus_enabled'],
                                    'antispyware': rule['antispyware_enabled'],
                                    'dnsSinkhole': rule['dns_sinkhole_enabled'],
                                    'vulnerability': rule['vulnerability_enabled'],
                                    'urlFiltering': rule['url_filtering_enabled'],
                                    'dataFiltering': rule['data_filtering_enabled'],
                                    'appId': rule['app_id_enabled'],
                                    'userId': rule['user_id_enabled'],
                                    'logStart': rule['log_start'],
                                    'logEnd': rule['log_end']
                                }
                            },
                            cls=SetEncoder
                        )
                    )
                    sys.stdout.flush()
                # enabled deny/drop rules - print userId, appId, logStart, logEnd, with IncludeInAnalytics True,
                # and the rest with IncludeInAnalytics False
                else:
                    print(
                        json.dumps(
                            {
                                'table': 'FeatureAdoption',
                                'featureCategory': 'Security Rules',
                                'IncludeInAnalytics': 1,
                                'feature': {
                                    'appId': rule['app_id_enabled'],
                                    'userId': rule['user_id_enabled'],
                                    'logStart': rule['log_start'],
                                    'logEnd': rule['log_end']
                                }
                            },
                            cls=SetEncoder
                        )
                    )
                    sys.stdout.flush()

                    print(
                        json.dumps(
                            {
                                'table': 'FeatureAdoption',
                                'featureCategory': 'Security Rules',
                                'IncludeInAnalytics': 0,
                                'feature': {
                                    'wildfire': rule['wildfire_enabled'],
                                    'fileBlocking': rule['file_blocking_enabled'],
                                    'antivirus': rule['antivirus_enabled'],
                                    'antispyware': rule['antispyware_enabled'],
                                    'dnsSinkhole': rule['dns_sinkhole_enabled'],
                                    'vulnerability': rule['vulnerability_enabled'],
                                    'urlFiltering': rule['url_filtering_enabled'],
                                    'dataFiltering': rule['data_filtering_enabled'],
                                }
                            },
                            cls=SetEncoder
                        )
                    )
                    sys.stdout.flush()
            # For disabled rules, print all with IncludeInAnalytics False
            else:
                print(
                    json.dumps(
                        {
                            'table': 'FeatureAdoption',
                            'featureCategory': 'Security Rules',
                            'IncludeInAnalytics': 0,
                            'feature': {
                                'wildfire': rule['wildfire_enabled'],
                                'fileBlocking': rule['file_blocking_enabled'],
                                'antivirus': rule['antivirus_enabled'],
                                'antispyware': rule['antispyware_enabled'],
                                'dnsSinkhole': rule['dns_sinkhole_enabled'],
                                'vulnerability': rule['vulnerability_enabled'],
                                'urlFiltering': rule['url_filtering_enabled'],
                                'dataFiltering': rule['data_filtering_enabled'],
                                'appId': rule['app_id_enabled'],
                                'userId': rule['user_id_enabled'],
                                'logStart': rule['log_start'],
                                'logEnd': rule['log_end']
                            }
                        },
                        cls=SetEncoder
                    )
                )
                sys.stdout.flush()

            # Write the details to file
            with open(args.outfile, 'a') as outfile:
                outfile.write(
                    json.dumps(
                        {
                            'object': {
                                'type': 'Security Rule',
                                'name': rule['rulename']},
                            'property': {
                                'parent': rule['target'] if not rule['device_group'] else rule['device_group'],
                                'action': rule['action'],
                                'state': 'enabled' if rule['rule_enabled'] == 1 else 'disabled',
                                'tag': rule['tags']},
                            'feature': {
                                'wildfire': rule['wildfire_enabled'],
                                'fileBlocking': rule['file_blocking_enabled'],
                                'antivirus': rule['antivirus_enabled'],
                                'antispyware': rule['antispyware_enabled'],
                                'dnsSinkhole': rule['dns_sinkhole_enabled'],
                                'vulnerability': rule['vulnerability_enabled'],
                                'urlFiltering': rule['url_filtering_enabled'],
                                'dataFiltering': rule['data_filtering_enabled'],
                                'appId': rule['app_id_enabled'],
                                'userId': rule['user_id_enabled'],
                                'logStart': rule['log_start'],
                                'logEnd': rule['log_end']}
                        },
                        cls=SetEncoder
                    ) + "\n"
                )


def main():
    """Main routine.

    To use this module, run the following command at the same directory level as best_practice_assessment:

    python -m best_practice_assessment.generate --xml path/to/config.xml --flatten
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('-x', '--xml', type=argparse.FileType('r'), help='XML config file location')
    parser.add_argument(
        '-t', '--type', default='bpat', const='bpat', nargs='?', choices=['bpat', 'heatmap'],
        help='generate JSON for bpat or heatmap (default: %(default)s)'
    )
    parser.add_argument('-o', '--outfile', help='Custom filepath to save data', nargs='?', type=str)
    parser.add_argument('-f', '--flatten', help='Flatten the JSON structure', action='store_true')
    parser.add_argument('-s', '--stdout', help='Output the data to STDOUT', action='store_true')
    parser.add_argument('-a2', '--autoassistant', help='Output the data as needed for AutoAssistant', action='store_true')
    args = parser.parse_args()

    if args.autoassistant:
        logging.getLogger('bpa').setLevel(logging.ERROR)

    controller = Controller.from_xml(args.xml, system_info={})
    publisher = controller.publisher_manager.publisher_lookup['report'](controller.publisher_manager)
    xml_config = XMLConfig(publisher.publisher_manager, publisher.arch_mappings, publisher.industry_attrs)

    if args.autoassistant:
        process_autoassistant(xml_config, args)
    else:
        process_normal(xml_config, args)


if __name__ == "__main__":
    main()
