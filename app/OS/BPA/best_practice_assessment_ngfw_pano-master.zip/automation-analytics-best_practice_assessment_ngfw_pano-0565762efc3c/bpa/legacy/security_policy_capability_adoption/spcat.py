# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from collections import defaultdict
import itertools
import json
from six import iteritems
from typing import List, Dict
from lxml import etree
import pandas as pd
from bpa.models.query import using_zpp
from .SecurityRule import SecurityRule
from .Profile import Profile
from .common import SetEncoder


class SecurityPolicyCapabilityAdoption(object):
    """Conducts a SecurityPolicyCapabilityAdoption analysis."""
    # Cache all choices for Area of Architecture and Zone Type
    ARCH_VALUES = [
        'Perimeter',
        'Internet',
        'DMZ',
        '3rd Party/Vendor',
        'Internal Core',
        'Users',
        'IT Infrastructure',
        'Out-of-Band Management',
        'Remote Office/MPLS',
        'Mobility',
        'Remote Users/VPN',
        'Guest',
        'BYOD',
        'Datacenter',
        'Web-tier',
        'App-tier',
        'DB-tier',
        'PCI',
        'SCADA/ICS',
        'R&D',
        'Lab/Test',
        'Decommissioned/Not-in-use',
        'Undefined',
    ]

    _rule_detail_columns = (
        'device_group',
        'target',
        'source_area_of_architecture',
        'dest_area_of_architecture',
        'rulename',
        'tags',
        'service',
        'rulebase',
        'source_zone',
        'source_user',
        'dest_zone',
        'application',
        'action',
        'rule_enabled',
        'wildfire_enabled',
        'file_blocking_enabled',
        'antivirus_enabled',
        'antispyware_enabled',
        'dns_sinkhole_enabled',
        'vulnerability_enabled',
        'url_filtering_enabled',
        'credential_theft_enabled',
        'data_filtering_enabled',
        'app_id_enabled',
        'user_id_enabled',
        'service_port_configured',
        'zone_protection_profile_enabled',
        'profile_used',
        'profile_group_used',
        'profile_group_name',
        'av_profile_name',
        'vuln_profile_name',
        'spyware_profile_name',
        'url_filtering_profile_name',
        'file_blocking_profile_name',
        'data_filtering_profile_name',
        'wildfire_profile_name',
        'log_end',
        'log_start',
        'log_forwarding_profile'
    )

    # Profile group queries
    get_profile_group_from_dg = etree.XPath(
        '/config/devices/entry/*[self::vsys or self::device-group]'
        '/entry[@name=$device_group]/profile-group/entry[@name=$profile_group]')
    get_profile_group_from_shared = etree.XPath(
        '/config/shared/profile-group/entry[@name=$profile_group]')

    # Profile queries
    get_profile_from_dg = etree.XPath(
        '/config/devices/entry/*[self::vsys or self::device-group]'
        '/entry[@name=$device_group]/profiles/*[name()=$tag]/entry[@name=$name]')
    get_profile_from_shared = etree.XPath(
        '/config/shared/profiles/*[name()=$tag]/entry[@name=$name]')

    # Decryption policies
    get_decryption_policies = etree.XPath('//decryption/rules/entry')

    def __init__(self, xml_config):
        self._xml = xml_config.tree
        self.serial_number = xml_config.serial_number
        zone_mappings = getattr(xml_config, 'zone_mappings', [])
        self._area_of_architecture_mappings = self.get_mappings_for_serial_number(self.serial_number, zone_mappings)
        self.version = str(xml_config.version)
        self.url_db = xml_config.urldb
        self.panorama = xml_config.panorama
        self.set_dgs_with_devices(self._xml)
        self.device_group_hierarchy = xml_config.ancestors
        self.dg_descendants = xml_config.descendants
        self.set_deployment_update_schedules()
        self.set_update_schedules()
        self.set_decryption_reporting()

        # Cache the zones that have a Zone Protection Profile enabled
        self.zpp_zones_cache = {}

        self.save_attribute_cache = []
        self.record_attributes_cache = []

        self.rule_attribute_values = defaultdict(set)

        # vsys > profile type > profile name > valid
        self.profile_collector = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))

        # vsys > profile group > profile type > profile name
        self.profile_group_collector = defaultdict(
            lambda: defaultdict(
                lambda: defaultdict(
                    lambda: 'none')))

        self.rules = []
        self.parse_rules()

        self._rules_values = None
        self._heatmap_values = None

    def zone_using_zpp(self, zone_name: str) -> bool:
        """Checks whether a zone has a Zone Protection Profile applied.

        First checks to see if there is already a cached valued before querying the XML.
        """
        cached_val = self.zpp_zones_cache.get(zone_name)
        if cached_val is not None:
            return cached_val
        self.zpp_zones_cache[zone_name] = using_zpp(self._xml, zone=zone_name)
        return self.zpp_zones_cache[zone_name]

    @property
    def rules_values(self):
        if self._rules_values is None:
            self._rules_values = self.get_detail_json()
            return self._rules_values
        else:
            return self._rules_values

    @property
    def heatmap_values(self):
        if self._heatmap_values is None:
            self._heatmap_values = self.get_aggregate_json()
            return self._heatmap_values
        else:
            return self._heatmap_values

    def parse_rules(self):
        """Parses all security rules."""
        for dg_el in self._xml.xpath(
                '/config/shared | /config/devices/entry/*[self::device-group or self::vsys]/entry'):
            dg_name = dg_el.get('name', 'shared')
            for rulebase_el in dg_el.xpath('rulebase | pre-rulebase | post-rulebase'):
                rulebase_name = rulebase_el.tag
                security_rules = rulebase_el.xpath('*[self::security or self::default-security-rules]/rules/entry')
                for rule in security_rules:
                    self.rules.append(SecurityRule(rule, dg_name, rulebase_name, self)._record)

    def set_decryption_reporting(self):
        """Collect decryption policy attributes for note on heatmap summary page.

        For policies with action of 'decrypt', collect the count of rules by type.
        For policies with action of 'no-decrypt', collect the categories.
        """
        decryption_policies = self.get_decryption_policies(self._xml)
        self.decryption_reporting = {
            'rule_count': len(decryption_policies),
            'decrypt': defaultdict(int),
            'no-decrypt': set(),
        }
        for policy in decryption_policies:
            action = policy.findtext('action')
            if action == 'decrypt':
                policy_type = policy.find('type/*').tag
                self.decryption_reporting['decrypt'][policy_type] += 1
            else:  # no-decrypt
                categories = policy.xpath('category/member[text() != "any"]/text()')
                self.decryption_reporting['no-decrypt'].update(categories)

    @staticmethod
    def get_mappings_for_serial_number(serial_number: str, zone_mappings: List) -> Dict:
        """Looks up the area of architecture and zone type mappings for the
        SecurityPolicyCapabilityAdoption instance's serial number."""
        arch_lookup = {}
        for mapping in zone_mappings:
            key = (mapping['zone'], mapping['vsys'])
            arch_lookup[key] = mapping['area_of_architecture']
        return arch_lookup

    @staticmethod
    def create_devices_records(devices):
        """Creates a list of tuples where the first item is
        the device serial number and the second item is a vsys if applicable.

        For instance, this devices element:
            <devices>
              <entry name="007901000280">
                <vsys>
                  <entry name="vsys1" />
                </vsys>
              </entry>
            </devices>

        would return :
        [('007901000280', 'vsys1')]
        """
        device_lst = []
        for entry in devices.findall('entry'):
            serial_number = entry.get('name')
            try:
                vsys = entry.find('vsys/entry').get('name')
            except BaseException:
                vsys = 'no-vsys'
            device_lst.append((serial_number, vsys))

        return device_lst

    def set_dgs_with_devices(self, xml):
        """
        Parse all device groups that contain devices.

        Returns a dictiory where keys are device groups and values are
        lists of tuples where the first item is the device serial number
        and the second item is the vsys.
        """
        self.dgs_with_devices = defaultdict(list)

        device_groups_with_devices = xml.xpath(
            '/config/devices/entry/device-group/entry[devices/entry]')

        for device_group in device_groups_with_devices:
            self.dgs_with_devices[device_group.get('name')] = (
                self.create_devices_records(device_group.find('devices')))

    def get_device_group_targeted_devices(self, device_group_name):
        """Looks up the devices targeted by a given device group.
        This includes any descendant device groups.
        """
        targeted_devices = [
            self.dgs_with_devices[dg]
            for dg in self.dg_descendants[device_group_name]
        ]
        # Return a flattened list
        return list(itertools.chain.from_iterable(targeted_devices))

    def get_profile_names(self, profile_group_name, device_group):
        """Looks up the profile names belonging to a given profile group.

        We need to reference the device group hierarchy since
        a profile group can only use profiles defined in the same level or a
        parent level in the device device group hierarchy.

        Args:
            profile_group_name: string representing the profile group's name
            device_group: vsys or device group containing the rule where
            this profile group is being referenced.


        Returns:
            A dictionary where keys are the profile name attributes to be set in a
            SecurityRule instance and values are the corresponding profile names.
        """
        # First check to see if the profile group as already been cached
        for dg in self.device_group_hierarchy[device_group]:
            if self.profile_group_collector[dg][profile_group_name]:
                return self.profile_group_collector[dg][profile_group_name]

        # Parse the profile group if this is the first time encountering it
        for dg in self.device_group_hierarchy[device_group]:
            if dg != 'shared':
                profile_group = self.get_profile_group_from_dg(
                    self._xml, device_group=dg, profile_group=profile_group_name)
            else:
                profile_group = self.get_profile_group_from_shared(
                    self._xml, profile_group=profile_group_name)

            if profile_group:
                # Cache the profile group values in case they are referenced
                # later
                for attr, node, default, metric in SecurityRule._profile_attrs:
                    try:
                        self.profile_group_collector[dg][profile_group_name][attr] = (
                            profile_group[0].find('{node}/member'.format(node=node)).text)
                    except BaseException:
                        pass

                return self.profile_group_collector[dg][profile_group_name]

        raise ProfileException(
            'Profile group: {} not found in device group hierarchy of {}.'.format(
                profile_group_name, device_group))

    def validate_profile(self, tag, profile_name, device_group):
        """Looks up whether a given profile is valid.

        Args:
            tag: A string representing the tag name for the profile type.
            profile_name: A string representing the profile name.
            device_group: A string representing the device group of the
            security rule using the profile.

        Returns:
            An integer value of 1 or 0 depending on whether the profile is valid.
        """
        PREDEFINED_PROFILES = {
            'virus': ['default'],
            'spyware': ['default', 'strict'],
            'vulnerability': ['default', 'strict'],
            'url-filtering': ['default'],
            'file-blocking': ['basic file blocking', 'strict file blocking'],
            'wildfire-analysis': ['default'],
            'data-filtering': [],
        }

        if profile_name == 'none':
            return 0
        elif profile_name in PREDEFINED_PROFILES[tag]:
            return 1

        # Check to see if the profile as already been validated
        for dg in self.device_group_hierarchy[device_group]:
            # Integer defaultdict, so need to check for existance of
            # profile name as a nested key rather than an implicit True/False.
            if profile_name in self.profile_collector[dg][tag].keys():
                return self.profile_collector[dg][tag][profile_name]

        # Validate the profile if this is the first time encountering it
        for dg in self.device_group_hierarchy[device_group]:
            if dg != 'shared':
                profile_el = self.get_profile_from_dg(self._xml, device_group=dg, tag=tag, name=profile_name)

            else:
                profile_el = self.get_profile_from_shared(
                    self._xml, tag=tag, name=profile_name)

            if profile_el:
                # Cache the profile validation in case it is referenced later
                profile = Profile.get_profile(profile_el[0], tag)
                self.profile_collector[dg][tag][profile_name] = profile.valid_profile(
                )
                # Save sinkhole vaidation for later lookup
                if tag == 'spyware':
                    self.profile_collector[dg]['sinkhole'][profile_name] = profile.valid_profile_sinkhole()
                elif int(self.version[0]) >= 8 and tag == 'url-filtering':
                    self.profile_collector[dg]['credential_theft'][profile_name] = (
                        profile.valid_profile_credential_theft()
                    )

                return self.profile_collector[dg][tag][profile_name]

        raise ProfileException(
            'Profile not found in hierarchy: {}'.format(profile_name))

    def validate_sinkhole(self, profile_name, device_group):
        """Validates DNS Sinkhole on an Anti-Spyware Profile.

        Args:
            profile_name: A string representing the Anti-Spyware profile name.
            device_group: A string representing the device group of the
            security rule using the Anti-Spyware profile.

        Returns:
            An integer value of 1 or 0 depending on whether DNS Sinkhole is valid.
        """
        if profile_name in ['none', 'default', 'strict']:
            return 0

        for dg in self.device_group_hierarchy[device_group]:
            if profile_name in self.profile_collector[dg]['sinkhole'].keys():
                return self.profile_collector[dg]['sinkhole'][profile_name]

        raise ProfileException(
            'Anti-Spyware Profile not found in hierarchy: {}'.format(profile_name))

    def validate_credential_theft(self, profile_name, device_group):
        """Validates Credential Theft on a URL Filtering Profile.

        Args:
            profile_name: A string representing the URL Filtering profile name.
            device_group: A string representing the device group of the
            security rule using the Anti-Spyware profile.

        Returns:
            An integer value of 1 or 0 depending on whether DNS Sinkhole is valid.
        """
        if profile_name in ['none', 'default']:
            return 0

        for dg in self.device_group_hierarchy[device_group]:
            if profile_name in self.profile_collector[dg]['credential_theft'].keys():
                return self.profile_collector[dg]['credential_theft'][profile_name]

        raise ProfileException(
            'URL Filtering Profile not found in hierarchy: {}'.format(profile_name))

    def get_zone_mappings(self, zones, vsys):
        """Looks up the area of architecture and zone type mappings for a list of zones.

        Args:
            zones: A list of zones.
            vsys: vsys or device group

        Returns:
            A tuple pair of sets. The first item is a list of
            the areas of architecture and the second item is a list of
            zone types.
        """
        areas_of_architecture = set()
        if 'any' in zones:
            areas_of_architecture.add('any')
        else:
            for zone in zones:
                areas_of_architecture.add(
                    self._area_of_architecture_mappings.get((zone, vsys), 'Internet'))

        return sorted(areas_of_architecture)

    @staticmethod
    def parse_update_schedule(schedule_type_el, deployment=False):
        """Parses an update schedule belonging to deployment dynamic updates or local
        dynamic updates.

        Args:
            schedule_type_el: An lxml Element for an update schedule type such as
            threats, wildfire, etc.
            deployment: A boolean indicating whether the schedule_type_el is from a
            deployment update schedule. This is used to determine how to parse the action.

        Returns:
            A dictionary containing key/value pairs for schedule type, recurrence, and action.
        """
        schedule_info = {}
        schedule_info['type'] = schedule_type_el.tag
        recurrence_found = schedule_type_el.xpath(
            'recurring/*[name() != "sync-to-peer" and name() != "threshold"]')
        if recurrence_found:
            recurrence_el = recurrence_found[0]
            schedule_info['recurrence'] = recurrence_el.tag
            # Action value is a nested element under <action> for <deployment-update-schedule>,
            # but the text node of <action> if <update-schedule>.
            action_el = recurrence_el.find('action')
            if action_el is not None:
                if deployment:
                    schedule_info['action'] = action_el.find('*').tag
                else:
                    schedule_info['action'] = action_el.text
            else:
                schedule_info['action'] = 'no-action'
        else:
            schedule_info['recurrence'] = 'none'
            schedule_info['action'] = 'no-action'

        return schedule_info

    def set_deployment_update_schedules(self):
        """Parses deployment update schedules."""
        self.deployment_update_schedules = []
        for deployment_update_schedule in self._xml.xpath(
                '/config/devices/entry/deviceconfig/system/deployment-update-schedule/entry'):
            info = {'name': deployment_update_schedule.get('name')}
            info.update(
                self.parse_update_schedule(
                    deployment_update_schedule.find('*'),
                    True))
            self.deployment_update_schedules.append(info)

    def set_update_schedules(self):
        """Parses local update schedules."""
        self.update_schedules = [
            self.parse_update_schedule(update_schedule) for update_schedule
            in self._xml.xpath(
                '/config/devices/entry/deviceconfig/system/update-schedule'
                '/*[name() != "statistics-service"]')
        ]

    @property
    def column_json(self):
        """Returns a JSON object of rule_attribute_values with case insensitive sorted values."""
        attr_dict = {}
        for attr, vals in iteritems(self.rule_attribute_values):
            if attr not in ['source_area_of_architecture', 'dest_area_of_architecture']:
                attr_dict[attr] = sorted(vals, key=lambda s: s.lower())

        return json.dumps(attr_dict, cls=SetEncoder)

    def get_aggregate_json(self):
        """Generates aggregate JSON data to be injected into HTML report.

        Returns:
            A list of dictionaries or pandas DataFrame representing
            the aggregate records used in the heatmap tables.
        """
        if not self.rules:
            return []

        all_rules = pd.DataFrame(self.rules)
        enabled_rules = all_rules[all_rules['rule_enabled'] == 'yes']
        enabled_allow_rules = enabled_rules[enabled_rules['action'] == 'allow']

        dimensions = [
            'device_group', 'target', 'tags', 'source_zone', 'dest_zone',
            'source_area_of_architecture', 'dest_area_of_architecture',
        ]

        # Aggregate measures that rely on ENABLED rules
        enabled_measures = enabled_rules.groupby(
            dimensions, as_index=False)[[
                'total_rule_count', 'allow_rule_count', 'deny_rule_count', 'app_id_enabled',
                'user_id_enabled', 'log_end', 'log_forwarding_enabled']].sum()

        # Aggregate measures that rely on ENABLED ALLOW rules
        measures = [
            'wildfire_enabled', 'antivirus_enabled', 'antispyware_enabled',
            'dns_sinkhole_enabled', 'vulnerability_enabled', 'file_blocking_enabled',
            'url_filtering_enabled', 'data_filtering_enabled', 'service_port_configured',
            'zone_protection_profile_enabled',
        ]
        if int(self.version[0]) >= 8:
            measures.append('credential_theft_enabled')
        enabled_allow_measures = enabled_allow_rules.groupby(dimensions, as_index=False)[measures].sum()

        # Merge enabled and enabled allow metrics into final data set
        all_measures = pd.merge(enabled_measures, enabled_allow_measures, how='outer', on=dimensions)
        all_measures.fillna(0, inplace=True)

        return all_measures.to_dict(orient='records')

    def get_detail_json(self):
        """Generates detail JSON data to be injected into HTML report.

        Returns:
            A list of dictionaries or pandas DataFrame representing
            the detail records used in the heatmap tables.
        """
        if not self.rules:
            return []

        all_rules = pd.DataFrame(self.rules)
        all_rules.replace([1, 0], ['yes', 'no'], inplace=True)
        all_rules.drop(
            labels=['total_rule_count', 'allow_rule_count', 'deny_rule_count'],
            axis=1,
            inplace=True
        )

        return all_rules.to_dict(orient='records')

    @property
    def rule_detail_columns(self):
        """"""
        rule_detail_columns = list(self._rule_detail_columns)
        if not self.panorama:
            rule_detail_columns = [x for x in rule_detail_columns if x not in ['device_group', 'rulebase']]
        if int(self.version[0]) < 8:
            rule_detail_columns = [x for x in rule_detail_columns if x != 'credential_theft_enabled']
        return rule_detail_columns

    @classmethod
    def from_file(cls, xml_file_path, serial_number=''):
        """Returns a SecurityPolicyCapabilityAdoption instance given a XML config file path."""
        # TODO(Andrew) investigate bs4.UnicodeDammit and cchardet as alternatives
        # http://lxml.de/elementsoup.html#using-soupparser-as-a-fallback
        try:
            parser = etree.XMLParser(ns_clean=True, recover=True, encoding='utf-8')
            xml = etree.parse(xml_file_path, parser)
        except etree.XMLSyntaxError:
            parser = etree.XMLParser(ns_clean=True, recover=True, encoding='latin1')
            xml = etree.parse(xml_file_path, parser)

        return cls(xml, serial_number)


class ProfileException(Exception):
    """Raise for profile exceptions."""
