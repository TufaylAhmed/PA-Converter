# security_policy_capability_adoption

Contains the following entities:

- Profile
- Security Rule

These are used within the `spcat` module.

Common utilities exist to assist with text nodes and other concerns.
