from collections import defaultdict


class Profile(object):
    """Profile class."""

    def __init__(self, xml):
        """Parse generic profile.
        Args:
            xml: A profile entry element.
        """
        self.name = xml.get('name')
        self.rules = xml.find('rules/entry') is not None

    def valid_profile(self):
        if self.rules:
            return 1
        else:
            return 0

    @staticmethod
    def get_profile(xml, tag):
        """Profile factory function.

        Args:
            xml: A profile entry element.
            tag: A string representing the profile tag name.

        Returns:
            An instance of the correct profile class.
        """
        profile_classes = {
            'virus': AntiVirusProfile,
            'spyware': AntiSpywareProfile,
            'wildfire-analysis': WildFireProfile,
            'url-filtering': URLFilteringProfile,
            'file-blocking': FileBlockingProfile,
            'data-filtering': DataFilteringProfile,
            'vulnerability': VulnerabilityProfile
        }
        profile_class = profile_classes.get(tag)
        assert profile_class is not None
        return profile_class(xml)


class WildFireProfile(Profile):

    def __init__(self, xml):
        super(WildFireProfile, self).__init__(xml=xml)


class URLFilteringProfile(Profile):

    def __init__(self, xml):
        super(URLFilteringProfile, self).__init__(xml=xml)
        self._version = int(xml.getroottree().getroot().get('version')[0])
        self._credential_enforcement = xml.find('credential-enforcement')

    def valid_profile(self):
        return 1

    def valid_profile_credential_theft(self):
        if self._version < 8:
            return

        if self._credential_enforcement is None:
            return 0

        mode = self._credential_enforcement.find('mode/*').tag

        non_allow_categories_predicate = ' or '.join(
            ['self::' + action for action in ['alert', 'block', 'continue']]
        )
        non_allow_categories = int(
            self._credential_enforcement.xpath('count(*[{}]/member)'.format(non_allow_categories_predicate))
        )

        if mode == 'disabled' or non_allow_categories == 0:
            return 0
        else:
            return 1


class AntiVirusProfile(Profile):

    def __init__(self, xml):
        super(AntiVirusProfile, self).__init__(xml=xml)
        self.decoders = xml.find('decoder/entry') is not None

    def valid_profile(self):
        if self.decoders:
            return 1
        else:
            return 0


class AntiSpywareProfile(Profile):

    def __init__(self, xml):
        super(AntiSpywareProfile, self).__init__(xml=xml)
        self.dns_sinkhole = xml.xpath(
            'boolean(botnet-domains/action/sinkhole | botnet-domains/sinkhole)')

    def valid_profile_sinkhole(self):
        if self.dns_sinkhole:
            return 1
        else:
            return 0


class VulnerabilityProfile(Profile):
    vulnerability_profiles = defaultdict(set)

    def __init__(self, xml):
        super(VulnerabilityProfile, self).__init__(xml=xml)


class FileBlockingProfile(Profile):

    def __init__(self, xml):
        super(FileBlockingProfile, self).__init__(xml=xml)


class DataFilteringProfile(Profile):

    def __init__(self, xml):
        super(DataFilteringProfile, self).__init__(xml=xml)
