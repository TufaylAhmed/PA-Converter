import weakref
from six import iteritems, text_type
from lxml import etree
from .common import get_text_node, join_text_nodes


class SecurityRule(object):
    # Attribute name, node tag, default value, and metric name
    _profile_attrs = [
        ('av_profile_name', 'virus', 'none', 'antivirus_enabled'),
        ('vuln_profile_name', 'vulnerability', 'none', 'vulnerability_enabled'),
        ('spyware_profile_name', 'spyware', 'none', 'antispyware_enabled'),
        ('url_filtering_profile_name', 'url-filtering', 'none', 'url_filtering_enabled'),
        ('data_filtering_profile_name', 'data-filtering', 'none', 'data_filtering_enabled'),
        ('wildfire_profile_name', 'wildfire-analysis', 'none', 'wildfire_enabled'),
        ('file_blocking_profile_name', 'file-blocking', 'none', 'file_blocking_enabled'),
    ]

    # Metrics tracked besides profiles enabled
    _metric_attrs = {'dns_sinkhole_enabled': 0, 'user_id_enabled': 0, 'app_id_enabled': 0,
                     'service_port_configured': 0, 'total_rule_count': 0, 'allow_rule_count': 0,
                     'deny_rule_count': 0, 'log_end': 1, 'log_start': 0, 'rule_enabled': 'no',
                     'profile_group_used': 0, 'profile_used': 0, 'log_forwarding_enabled': 0,
                     'zone_protection_profile_enabled': 0
                     }

    def __init__(self, xml, device_group, rulebase, parent):
        """Constructor for SecurityRule.

        Args:
            xml: entry element for the security rule
            device_group: device group or vsys value
            rulebase: rulebase, pre-rulebase, or post-rulebase
            parent: instance of SecurityPolicyCapabilityAdoption class

        """
        self._xpatheval = etree.XPathEvaluator(xml)
        self._parent = weakref.proxy(parent)
        self.rulename = xml.get('name')

        # Initialize default values.
        # Setting all profile names to none in case the rule is using a profile group
        # missing one of the profile types.
        self.__dict__.update({x[0]: x[2] for x in self._profile_attrs})
        self.__dict__.update({x[3]: 0 for x in self._profile_attrs})
        self.__dict__.update(self._metric_attrs)

        self.rulebase = rulebase

        # Represents the device group or vsys
        self.device_group = device_group

        self.action = xml.find('action').text
        if 'yes' not in self._xpatheval('disabled/text()'):
            self.rule_enabled = 'yes'
            self.total_rule_count = 1
            # Rule counts only consider enabled rules
            if self.action == 'allow':
                self.allow_rule_count = 1
            else:
                self.deny_rule_count = 1

        # log-end and log-start have different default configurations
        for node in ['log-end', 'log-start']:
            try:
                if xml.find(node).text == 'yes':
                    setattr(self, node.replace('-', '_'), 1)
                else:
                    setattr(self, node.replace('-', '_'), 0)
            except BaseException:
                # leave default value
                pass

        self.description = get_text_node(xml, 'description', 'none')
        self.log_forwarding_profile = get_text_node(xml, 'log-setting', 'none')
        if self.rule_enabled == 'yes' and self.log_forwarding_profile != 'none':
            self.log_forwarding_enabled = 1

        # Property methods defined below for accessing attributes as strings
        self._tags = self._xpatheval('tag/member/text()')
        self._source_user = self._xpatheval('source-user/member/text()')
        self._application = self._xpatheval('application/member/text()')
        self._service = self._xpatheval('service/member/text()')
        self._source_zone = self._xpatheval('from/member/text()')
        self._dest_zone = self._xpatheval('to/member/text()')
        self._target = self._get_target(xml)

        if 'any' not in self._source_zone and self.rule_enabled == 'yes' and self.action == 'allow':
            if any(self._parent.zone_using_zpp(zone) for zone in self._source_zone):
                self.zone_protection_profile_enabled = 1

        # Determine if rule is using a profile or a profile group
        self.profile_group_name = 'none'
        if xml.find('profile-setting') is not None:
            if self._xpatheval('profile-setting/profiles/*'):
                self.profile_used = 1
                # Set profile names
                for attr, tag, val, metric in self._profile_attrs:
                    setattr(
                        self, attr,
                        join_text_nodes(
                            self._xpatheval.evaluate,
                            'profile-setting/profiles/{}/member/text()'.format(tag),
                            default=val
                        )
                    )

            else:
                profile_group_el = xml.find('profile-setting/group/member')
                if profile_group_el is not None:
                    self.profile_group_used = 1
                    # Set profile group name
                    self.profile_group_name = profile_group_el.text

        # If the rule is using a profile group, get the profile names used in
        # the group
        if self.profile_group_used:
            for attr, profile_name in iteritems(
                    parent.get_profile_names(self.profile_group_name, device_group)):
                setattr(self, attr, profile_name)

        # Set adoption metrics
        for attr, tag, default, metric in self._profile_attrs:
            profile_name = getattr(self, attr)
            setattr(
                self,
                metric,
                parent.validate_profile(
                    tag,
                    profile_name,
                    device_group))

        self.dns_sinkhole_enabled = parent.validate_sinkhole(self.spyware_profile_name, device_group)

        if int(parent.version[0]) >= 8:
            self.credential_theft_enabled = parent.validate_credential_theft(
                self.url_filtering_profile_name, device_group
            )

        self.user_id_enabled = 1 if self._source_user and not bool({'any', 'unknown'} & set(self._source_user)) else 0
        self.app_id_enabled = 1 if self._application and 'any' not in self._application else 0
        if self._service and 'any' not in self._service:
            self.service_port_configured = 1

        self._source_area_of_architecture = parent.get_zone_mappings(self._source_zone, self.device_group)
        self._dest_area_of_architecture = parent.get_zone_mappings(self._dest_zone, self.device_group)

        self._save_attribute_values()

    @property
    def source_area_of_architecture(self):
        return ', '.join(self._source_area_of_architecture)

    @property
    def dest_area_of_architecture(self):
        return ', '.join(self._dest_area_of_architecture)

    @property
    def tags(self):
        if not self._tags:
            return 'NO_TAG'
        else:
            return ', '.join(self._tags)

    @property
    def application(self):
        if not self._application:
            return 'any'
        else:
            return ', '.join(self._application)

    @property
    def service(self):
        if not self._service:
            return 'any'
        else:
            return ', '.join(self._service)

    @property
    def source_user(self):
        if not self._source_user:
            return 'any'
        else:
            return ', '.join(sorted(self._source_user))

    @property
    def source_zone(self):
        if not self._source_zone:
            return 'any'
        else:
            return ', '.join(sorted(self._source_zone))

    @property
    def dest_zone(self):
        if not self._dest_zone:
            return 'any'
        else:
            return ', '.join(sorted(self._dest_zone))

    def _get_target(self, xml):
        """Returns a concatenated string of the devices targets.

        Args:
            xml: lxml Element for the security rule entry.

        Retruns:
            A list of target device/vsys combinations.
        """
        if not self._parent.panorama:  # NGFW
            if self.device_group == 'shared':
                target_devices = [(self._parent.serial_number, 'no-vsys')]
            else:
                target_devices = [
                    (self._parent.serial_number, self.device_group)]

        else:  # Panorama
            target_devices_el = xml.find('target/devices')

            if target_devices_el is not None:
                target_devices = (
                    self._parent.create_devices_records(target_devices_el))
            else:
                # Target device are not listed on rule, so use the devices attached to
                # the device group and any of its descendants.
                target_devices = self._parent.get_device_group_targeted_devices(
                    self.device_group)

            # Check if target negated
            if 'yes' in self._xpatheval('target/negate/text()'):
                device_group_targeted_devices = (
                    self._parent.get_device_group_targeted_devices(self.device_group))
                target_devices = [
                    x for x in device_group_targeted_devices if x not in target_devices
                ]

        return [':'.join(record) for record in sorted(target_devices)]

    def _save_attribute_values(self):
        """Adds rule attributes to parent collector."""
        if not self._parent.save_attribute_cache:
            self._parent.save_attribute_cache = [
                key for key in self.__dict__.keys()
                if key not in self._metric_attrs.keys()
                and not key.endswith('_enabled') and not key.endswith('_count')
                and isinstance(getattr(self, key), (str, list))
            ]

        for key, val in iteritems(self.__dict__):
            if key in self._parent.save_attribute_cache:
                attr = key.lstrip('_')
                if isinstance(val, text_type):
                    self._parent.rule_attribute_values[attr].add(val)
                else:
                    self._parent.rule_attribute_values[attr].update(val)

        return None

    @property
    def target(self):
        if not self._target:
            return 'NO_TARGET'
        else:
            return ', '.join(self._target)

    @property
    def _record(self):
        """Returns a dictionary of all public attributes"""
        if not self._parent.record_attributes_cache:
            self._parent.record_attributes_cache = (
                [attr for attr in dir(self) if not attr.startswith('_')])
        return {attr: getattr(self, attr)
                for attr in self._parent.record_attributes_cache}
