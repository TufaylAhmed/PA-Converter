import json
from os import path
from sqlalchemy import create_engine


def get_connection(name, server='production', database=None, **kwargs):
    """Returns a sqlalchemy connection engine.

    Assumes that a connections.json file exists in the same directory as the module."""
    with open(path.join(path.dirname(__file__), 'connections.json'), 'r') as connections:
        connection_data = json.load(connections)[name]

    connection_string = '{dialect}://{user}:{password}@{host}:{port}'.format(
        dialect=connection_data['dialect'],
        user=connection_data[server]['user'],
        password=connection_data[server]['password'],
        host=connection_data[server]['host'],
        port=connection_data[server]['port'])

    if database is not None:
        connection_string = '{connection_string}/{database}'.format(
            connection_string=connection_string,
            database=database)

    conn = create_engine(connection_string, **kwargs)
    return conn


def join_text_nodes(query, xpath, join_str=', ', sort=False, default=None):
    """Concatenates the text nodes beneath an element, or
    returns the optional default is none exist.

    Args:
            query: A query method (xml's .xpath or XPathEvaluator's .evaluate)
            xpath: The xpath query to execute.
            join_str: The token used to join multiple resultset items.
            sort: A boolean flag indicating whether the resultset should be sorted.
            default: A default string to return if the resultset is empty.

    Returns:
            A string representing the query result or default value.
    """
    if sort:
        combined = join_str.join(sorted(query(xpath)))
    else:
        combined = join_str.join(query(xpath))

    if not combined and default is not None:
        return default
    else:
        return combined


def get_text_node(el, xpath, default=''):
    """Returns the text node for a single element.
    If unavailable, returns a default value."""
    try:
        text = el.find(xpath).text
    except BaseException:
        text = default
    else:
        if text is None:
            text = default
    finally:
        return text


class SetEncoder(json.JSONEncoder):
    """JSON Encoder to coerce sets to lists.

    Usage:
        json.dumps(set([1,2,3,4,5]), cls=SetEncoder)
    """

    def default(self, obj):
        if isinstance(obj, set):
            return list(obj)
        return json.JSONEncoder.default(self, obj)
