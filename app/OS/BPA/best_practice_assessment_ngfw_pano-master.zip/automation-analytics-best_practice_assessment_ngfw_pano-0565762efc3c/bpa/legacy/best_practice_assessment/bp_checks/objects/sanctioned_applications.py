# -*- coding: utf-8 -*-
"""
Created on Fri Feb 10 13:53:20 2017

@author: anmendoza
"""
# https://jira-hq.paloaltonetworks.local/browse/CST-46

from collections import namedtuple
from ..warn_note import BP_Check


class SanctionedApplications(object):
    xpath = '//application-tag/entry'

    def __init__(self, xml):
        # tagging did not exist before 7.1
        self.tagging_capable = float(xml.getroot().get('version')[:3]) >= 7.1

        if self.tagging_capable:
            self.predefined_reports = list(
                set(
                    xml.xpath(
                        '/config/shared/report-group/entry/predefined/text()')
                )
            )
            self.tagged_applications = self.get_tagged_applications(
                xml.findall(self.xpath))

    def get_tagged_applications(self, entries):
        Application = namedtuple('Application', ['name', 'tags'])
        applications_lst = []
        for entry in entries:
            name = entry.get('name')
            tags = [member.text for member in entry.findall('tag/member')]
            applications_lst.append(Application(name, tags))
        return applications_lst

    @property
    def sanctioned_app_warn(self):
        if not any('Sanctioned' in app.tags for app in self.tagged_applications):
            return BP_Check(
                27, 'Sanctioned Applications', 'warn', 'fail',
                'Business approved Applications should be tagged as "Sanctioned"')
        else:
            return BP_Check(27, 'Sanctioned Applications', 'warn', 'pass', '')

    @property
    def saas_report_note(self):
        """SaaS Application Usage Report Note only applies if the sanctioned
        application tag is being used."""
        if not any('Sanctioned' in app.tags for app in self.tagged_applications):
            return None
        elif 'saas-application-usage-report' not in self.predefined_reports:
            return BP_Check(
                28, 'SaaS Application Usage Report', 'note', '',
                'When using the "Sanctioned" application tag, it is recommended '
                'to also leverage the SaaS Application Usage Report')
        else:
            return None

    @property
    def record(self):
        if self.tagging_capable:
            configuration = {
                'tagged_applications': [app._asdict() for app in self.tagged_applications],
                'predefined_reports': self.predefined_reports
            }
            bp_check = [
                check._asdict()
                for check in [self.sanctioned_app_warn, self.saas_report_note]
                if check is not None
            ]
            return [{'configuration': configuration, 'bp_check': bp_check}]
        else:
            return []
