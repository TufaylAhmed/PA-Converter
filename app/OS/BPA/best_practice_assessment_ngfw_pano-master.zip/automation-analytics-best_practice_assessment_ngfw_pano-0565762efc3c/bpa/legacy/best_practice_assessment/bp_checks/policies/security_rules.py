# -*- coding: utf-8 -*-
"""
Created on Tue Feb 21 09:34:37 2017

@author: nbitting
"""
from datetime import datetime
from collections import defaultdict
from six import iteritems
from lxml import etree
from itertools import chain
import weakref

from ...common import str_attr
from ..base import Base
from ..warn_note import BP_Check


class SecurityRulesContainer(object):
    """Container class to orchestrate checks on individual security rules
    and security rulebases."""

    get_platforms = etree.XPath(
        '/config/shared | '
        '/config/devices/entry/vsys/entry | '
        '/config/devices/entry/device-group/entry'
    )

    rule_query = etree.XPath(
        '*[self::rulebase or self::pre-rulebase or self::post-rulebase]/*[self::security or self::default-security-rules]/rules/entry'
    )

    non_recurring_schedules = etree.XPath(
        'schedule/entry[schedule-type/non-recurring/member]')

    schedule_times = etree.XPath('schedule-type/non-recurring/member/text()')

    get_default_rules = etree.XPath(
        '*[self::rulebase or self::pre-rulebase or self::post-rulebase]/default-security-rules/rules/entry'
    )

    using_ips_profile = etree.XPath(
        'boolean(profile-setting/profiles/*[self::virus or self::spyware or self:: vulnerability]/member)'
    )

    get_device_group_el = etree.XPath('/config/devices/entry/device-group/entry[@name=$name]')
    is_ips_profile_group = etree.XPath(
        'boolean(profile-group/entry[@name=$name]/*[self::virus or self::spyware or self::vulnerability]/member)'
    )

    def __init__(
            self, xml, dgs_with_devices, device_group_hierarchy,
            zones_with_user_id_enabled, panorama=False):
        self.panorama = panorama
        self.zones_with_user_id_enabled = zones_with_user_id_enabled
        self.rulebase_dict = defaultdict(lambda: defaultdict(int))
        self.user_id_checks = defaultdict(lambda: defaultdict(int))
        self.expired_schedules = defaultdict(lambda: defaultdict(bool))

        # vsys > allow rule count
        self.all_allow_rules = defaultdict(int)

        # vsys > profile group > allow rule count
        self.profile_group_allow_rules = defaultdict(lambda: defaultdict(int))

        # vsys > profile group > ips enabled flag
        self.profile_group_ips_enabled = defaultdict(dict)

        # vsys > profile type > profile name > allow rule count
        self.profile_allow_rules = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))

        # vsys > hip profile name > boolean flag
        self.hip_profile_used = defaultdict(lambda: defaultdict(bool))

        self.rules = defaultdict(list)

        self.dgs_with_devices = dgs_with_devices
        self.device_group_hierarchy = device_group_hierarchy

        # vsys > rule name > entry element
        self.default_rules = defaultdict(dict)

        # vsys > boolean
        self.custom_intrazone_rule = {}

        platforms = self.get_platforms(xml)

        # Check schedules first since they will be refereced in rule checks
        for platform in platforms:
            self.check_schedule_expirations(
                platform.get('name', 'shared'), self.non_recurring_schedules(platform))

        for platform in platforms:
            name = platform.get('name', 'shared')
            self.rules[name] = [
                SecurityRule(entry=e, vsys=name, parent=self, panorama=panorama).record
                for e in self.rule_query(platform)
            ]
            self.default_rules[name] = {entry.get('name'): entry for entry in self.get_default_rules(platform)}

    def ips_enabled(self, entry, vsys):
        """Checks whether a rule has enabled IPS.

        Looking to see whether an AV, AS, or Vulnerability Protection profile is being used either
        directly or via a profile group.

        When checking profile groups, first checks to see if a value is already cached before running
        the XPATH queries.

        Args:
            entry: security rule entry element
            vsys: vsys or device group name where rule is located

        Returns:
            A boolean value.
        """
        if self.using_ips_profile(entry):
            return True
        else:
            profile_group_name = entry.findtext('profile-setting/group/member')
            if profile_group_name is None:
                return False
            else:
                cached_val = self.profile_group_ips_enabled[vsys].get(profile_group_name)
                if cached_val is not None:
                    return cached_val

            shared_el = entry.getroottree().find('shared')
            element_lst = [shared_el]

            if self.panorama:
                for dg in self.device_group_hierarchy[vsys][:-1]:
                    element_lst.extend(self.get_device_group_el(entry, name=dg))
            else:
                element_lst.extend(
                    entry.xpath('/config/devices/entry/vsys/entry[@name="{}"]'.format(vsys))
                )

            result = any(self.is_ips_profile_group(el, name=profile_group_name) for el in element_lst)

            # cache the value for future use
            self.profile_group_ips_enabled[vsys][profile_group_name] = result

            return result

    def get_security_rule_records(self):
        """Returns a list of SecurityRule records"""
        return list(chain.from_iterable(self.rules.values()))

    def get_security_rulebase_records(self):
        """Returns a list of SecurityRulebase records.

        If Panorama, only include rulebases in a device group with devices.
        If NGFW, only include rulebases in a vsys.
        """
        if self.panorama:
            targeted_rulebases = self.dgs_with_devices.keys()
        else:  # NGFW
            targeted_rulebases = [
                vsys for vsys in self.rules.keys() if vsys != 'shared']

        return [SecurityRulebase(tr, self).record for tr in targeted_rulebases]

    def check_schedule_expirations(self, vsys, schedules):
        """Checks a list of non-recurring schedules to see whether their their latest
        time has already expired."""
        for schedule in schedules:
            max_end_date = None
            for time in self.schedule_times(schedule):
                try:
                    end_date = datetime.strptime(time[17:27], '%Y/%m/%d')
                except ValueError:
                    continue
                else:
                    if max_end_date is None or max_end_date < end_date:
                        max_end_date = end_date

            self.expired_schedules[vsys][schedule.get('name')] = (
                max_end_date is None or max_end_date < datetime.today()
            )


class SecurityRule(Base):
    """Checks performed at the individual rule level"""
    xpath = None
    profile_types = ('spyware', 'vulnerability', 'virus',
                     'file-blocking', 'url-filtering', 'wildfire-analysis')

    # Create XPath classes for the longer / more complex queries
    profile_name_query = etree.XPath(
        'profile-setting/profiles/*[name()=$name]/member/text()')
    profile_group_query = etree.XPath('profile-setting/group/member/text()')
    rulebase_type = etree.XPath(
        'name(ancestor::pre-rulebase | ancestor::post-rulebase)')
    server_response_inspect_disabled = etree.XPath(
        'option/disable-server-response-inspection/text()')

    def __init__(self, entry, parent, vsys, panorama=False):
        self.rule_name = entry.get('name')
        self.vsys = vsys
        self.panorama = panorama

        # Use XPathEvaluator to run simpler queries on the entry element
        entry_eval = etree.XPathEvaluator(entry)
        self.rule_enabled = 'yes' not in entry_eval('disabled/text()')
        self.description = ''.join(entry_eval('description/text()'))
        # By default, "Log at Session Start" is DISABLED and "Log at Session
        # End" is ENABLED
        self.log_start_enabled = str_attr(entry, 'log-start', 'no') == 'yes'
        self.log_end_enabled = str_attr(entry, 'log-end', 'yes') == 'yes'
        self.hip_profiles = entry_eval('hip-profiles/member/text()')
        self.source_zone = ', '.join(entry_eval('from/member/text()'))
        self.source_address = ', '.join(entry_eval('source/member/text()'))
        self.source_user = ', '.join(entry_eval('source-user/member/text()'))
        self.dest_zone = ', '.join(entry_eval('to/member/text()'))
        self.dest_address = ', '.join(entry_eval('destination/member/text()'))
        self.application = ', '.join(entry_eval('application/member/text()'))
        self.service = ', '.join(entry_eval('service/member/text()'))
        self.action = ''.join(entry_eval('action/text()'))
        self.rule_type = self.parse_rule_type(entry)
        self.log_forwarding_profile = ''.join(entry_eval('log-setting/text()'))
        self.schedule = ''.join(entry_eval('schedule/text()'))
        self.schedule_expired = self.get_schedule_expired(parent)
        self.disable_server_response_inpsection_enabled = 'yes' in self.server_response_inspect_disabled(entry)

        if self.panorama:
            self.rulebase = self.rulebase_type(entry)
        else:
            self.rulebase = 'rulebase'

        # Add to allow rule counters
        if self.action == 'allow':
            parent.all_allow_rules[vsys] += 1
            if entry_eval('profile-setting'):
                if entry_eval('profile-setting/profiles'):
                    for profile_type in self.profile_types:
                        try:
                            profile_name = self.profile_name_query(
                                entry, name=profile_type)[0]
                        except BaseException:
                            pass
                        else:
                            parent.profile_allow_rules[vsys][profile_type][profile_name] += 1
                else:
                    try:
                        profile_group = self.profile_group_query(entry)[0]
                    except BaseException:
                        pass
                    else:
                        parent.profile_group_allow_rules[vsys][profile_group] += 1

        if self.hip_profiles and self.hip_profiles[0] not in ['any', 'no-hip']:
            parent.rulebase_dict[vsys]['rules_using_hip_profile'] += 1
            for hip_profile in self.hip_profiles:
                parent.hip_profile_used[vsys][hip_profile] = True

        if not self.rule_enabled:
            parent.rulebase_dict[vsys]['disabled_rules'] += 1

        # Increment User ID checks collector
        if self.source_user != 'any' and self.source_zone != 'any' and \
                self.rule_name not in ('intrazone-default', 'interzone-default'):
            for source_zone in self.source_zone.split(', '):
                if source_zone not in parent.zones_with_user_id_enabled:
                    parent.user_id_checks[vsys][source_zone] += 1

        # Any/Any Intrazone check. Considers any rule with a rule type that is not
        # interzone (i.e. intrazone or universal). If rule type attribute is not present,
        # the default value is universal.
        if not parent.custom_intrazone_rule.get(vsys, False):
            parent.custom_intrazone_rule[vsys] = all(
                [
                    self.rule_enabled,
                    self.log_end_enabled,
                    self.rule_type != 'interzone',
                    self.action == 'allow',
                    self.source_zone == self.dest_zone,
                    parent.ips_enabled(entry, vsys)
                ]
            )

    def parse_rule_type(self, entry: etree._Element) -> str:
        if self.rule_name == 'intrazone-default':
            return 'intrazone'
        elif self.rule_name == 'interzone-default':
            return 'interzone'
        else:
            return entry.findtext('rule-type', 'universal')

    @property
    def description_warn(self):
        """Checks that a description is configured on the rule.

        NOTE: Cannot configure a description on default rules, so exclude them from the check.
        """
        if self.rule_name in ['interzone-default', 'intrazone-default']:
            return {'id': 3, 'name': 'Description Populated', 'result': 'exclude'}
        if not self.description:
            return {'id': 3, 'name': 'Description Populated', 'result': 'fail'}
        else:
            return {'id': 3, 'name': 'Description Populated', 'result': 'pass'}

    @property
    def source_destination_warn(self):
        """Checks that allow rules do not have source/destination zones and addresses all configured to 'any'.

        NOTE: Intrazone rules are excluded from this check.
        """
        if self.rule_type == 'intrazone':
            return {'id': 4, 'name': 'Source/Destination = any/any', 'result': 'exclude'}
        if (self.action == 'allow' and self.source_zone == 'any' and self.source_address == 'any' and
                self.dest_zone == 'any' and self.dest_address == 'any'):
            return {'id': 4, 'name': 'Source/Destination = any/any', 'result': 'fail'}
        else:
            return {'id': 4, 'name': 'Source/Destination = any/any', 'result': 'pass'}

    @property
    def service_warn(self):
        """Checks that allow rules do not have service configured to 'any'.

        NOTE: Intrazone rules are excluded from this check.
        """
        if self.rule_type == 'intrazone':
            return {'id': 5, 'name': 'Service = any', 'result': 'exclude'}
        elif self.service == 'any' and self.action == 'allow':
            return {'id': 5, 'name': 'Service = any', 'result': 'fail'}
        else:
            return {'id': 5, 'name': 'Service = any', 'result': 'pass'}

    @property
    def application_warn(self):
        """Checks that rules do not have application configured to 'any'.

        NOTE: Intrazone rules are excluded from this check.
        """
        if self.rule_type == 'intrazone':
            return {'id': 208, 'name': 'Application != any', 'result': 'exclude'}
        if self.application == 'any':
            return {'id': 208, 'name': 'Application != any', 'result': 'fail'}
        else:
            return {'id': 208, 'name': 'Application != any', 'result': 'pass'}

    @property
    def app_id_service_warn(self):
        """Fail if rule is using APP-ID without configuring a service.

        NOTE: Intrazone rules or rules with application configured to 'any' are excluded from this check.
        """
        if self.application == 'any' or self.rule_type == 'intrazone':
            return {'id': 220, 'name': 'APP-ID with Service', 'result': 'exclude'}
        elif self.service == 'any':
            return {'id': 220, 'name': 'APP-ID with Service', 'result': 'fail'}
        else:
            return {'id': 220, 'name': 'APP-ID with Service', 'result': 'pass'}

    @property
    def log_start_warn(self):
        if self.log_start_enabled:
            return {'id': 6, 'name': 'Not Logging at Start of Session',
                    'result': 'fail'}
        else:
            return {'id': 6, 'name': 'Not Logging at Start of Session',
                    'result': 'pass'}

    @property
    def log_forwarding_warn(self):
        if not self.log_forwarding_profile:
            return {'id': 7, 'name': 'Log Forwarding', 'result': 'fail'}
        else:
            return {'id': 7, 'name': 'Log Forwarding', 'result': 'pass'}

    def get_schedule_expired(self, parent):
        """Checks whether the rule's schedule is expired."""
        if not self.schedule:
            return False
        if self.panorama:
            return any(parent.expired_schedules[dg][self.schedule] for dg
                       in parent.device_group_hierarchy[self.vsys])
        else:  # NGFW
            return any(parent.expired_schedules[v][self.schedule] for v
                       in (self.vsys, 'shared'))

    @property
    def expired_non_recurring_schedule_warn(self):
        if self.schedule_expired:
            return {'id': 8, 'name': 'Expired Non-Recurring Schedules',
                    'result': 'fail'}
        else:
            return {'id': 8, 'name': 'Expired Non-Recurring Schedules',
                    'result': 'pass'}

    @property
    def disable_server_response_inpsection_enabled_warn(self):
        if self.disable_server_response_inpsection_enabled:
            return {
                'id': 9, 'name': 'Disable Server Response Inspection', 'result': 'fail'}
        else:
            return {
                'id': 9, 'name': 'Disable Server Response Inspection', 'result': 'pass'}

    @property
    def record(self):
        configuration = {
            'rule_name': self.rule_name,
            'rule_enabled': self.rule_enabled,
            'vsys': self.vsys,
            'rulebase': self.rulebase}

        return {
            'configuration': configuration,
            'bp_check': [
                self.description_warn,
                self.source_destination_warn,
                self.service_warn,
                self.application_warn,
                self.app_id_service_warn,
                self.log_start_warn,
                self.log_forwarding_warn,
                self.expired_non_recurring_schedule_warn,
                self.disable_server_response_inpsection_enabled_warn
            ]
        }


class SecurityRulebase(object):
    """Performs checks at the rulebase level.

    If Panorama, the rulebase consists of rules in the current device group
    as well as any rules in ancestor device groups.

    If NGFW, the rulebase consists of rules in the current vsys and shared.
    """

    def __init__(self, vsys, parent):
        self.panorama = parent.panorama
        self.vsys = vsys
        self.parent = weakref.ref(parent)
        self.user_id_rules_without_user_id_on_zone = defaultdict(int)

        if self.panorama:
            hierarchy = parent.device_group_hierarchy[vsys]
        else:
            hierarchy = [vsys, 'shared']

        for boolean_metric in ('intrazone_default_rule',
                               'interzone_default_rule'):
            setattr(self, boolean_metric,
                    any(parent.rulebase_dict[target][boolean_metric] for target in hierarchy))

        for numeric_metric in ('disabled_rules', 'rules_using_hip_profile'):
            setattr(self, numeric_metric,
                    sum(parent.rulebase_dict[target][numeric_metric] for target in hierarchy))

        for target in hierarchy:
            for zone in parent.user_id_checks[target].keys():
                self.user_id_rules_without_user_id_on_zone[zone] += (parent.user_id_checks[target][zone])

    @property
    def intrazone_default_rule_warn(self):
        """Validates whether intrazone-default has been overridden and at least one
        custom intrazone rule has been properly configured.

        Overridden rules are inherited from the closest ancestor, so check the hierachy
        if intrazone-default rule is not overridden or custom intrazone rule is not defined
        on the vsys / device group itself.
        """
        default_rule_overridden = False
        custom_intrazone_rule = False

        for location in self.parent().device_group_hierarchy.get(self.vsys, [self.vsys, 'shared']):
            rule_el = self.parent().default_rules[location].get('intrazone-default')
            if not default_rule_overridden and rule_el is not None:
                default_rule_overridden = all(
                    [
                        rule_el.findtext('action') == 'allow',
                        rule_el.findtext('log-end') == 'yes',
                        self.parent().ips_enabled(rule_el, location),
                    ]
                )
            if not custom_intrazone_rule:
                custom_intrazone_rule = self.parent().custom_intrazone_rule.get(location)

        errors = []

        if not default_rule_overridden:
            errors.append(
                "It is recommended to override the intrazone-default rule with Action "
                "set to 'allow', Log at Session End enabled, and IPS capability enabled."
            )

        if not custom_intrazone_rule:
            errors.append(
                "There should be a custom intrazone rule configured with Action "
                "set to 'allow', Log at Session End enabled, and IPS capability enabled."
            )

        if errors:
            return BP_Check(
                13, 'Intrazone Allow Rules with Logging', 'warn', 'fail', ' '.join(errors)
            )
        else:
            return BP_Check(13, 'Intrazone Allow Rules with Logging', 'warn', 'pass', '')

    @property
    def interzone_default_rule_warn(self):
        """Validates whether interzone-default rule has been overridden.

        Checking that action is deny and log at session end is enabled on overridden rule.

        Overridden rules are inherited from the closest ancestor, so check the hierachy
        if interzone-default rule is not overridden on the vsys / device group itself.
        """
        for location in self.parent().device_group_hierarchy.get(self.vsys, [self.vsys, 'shared']):
            rule_el = self.parent().default_rules[location].get('interzone-default')
            if rule_el is not None:
                passing = all(
                    [
                        rule_el.findtext('action') == 'deny',
                        rule_el.findtext('log-end') == 'yes',
                    ]
                )
                break
        else:
            passing = False

        if passing:
            return BP_Check(12, 'Interzone Deny Rule with Logging', 'warn', 'pass', '')
        else:
            return BP_Check(
                12, 'Interzone Deny Rule with Logging', 'warn', 'fail',
                "It is recommended to override the interzone-default rule with Action set to 'deny' and "
                "Log at Session End enabled."
            )

    @property
    def disabled_rules_warn(self):
        if self.disabled_rules:
            return BP_Check(
                11, 'Disabled Rules', 'warn', 'fail',
                'It is recommended to remove disabled rules. '
                '({} disabled rules exist)'.format(self.disabled_rules))
        else:
            return BP_Check(11, 'Disabled Rules', 'warn', 'pass', '')

    @property
    def rules_using_hip_profile_warn(self):
        if not self.rules_using_hip_profile:
            return BP_Check(
                15, 'HIP Profiles used in Rules', 'warn', 'fail',
                'It is recommended to use HIP Profiles in rulebase')
        else:
            return BP_Check(15, 'HIP Profiles used in Rules', 'warn', 'pass', '')

    @property
    def user_id_rules_without_user_id_on_zone_warn(self):
        if self.panorama:
            return None
        if sum(self.user_id_rules_without_user_id_on_zone.values()):
            message_lst = []
            for zone, rule_count in iteritems(self.user_id_rules_without_user_id_on_zone):
                message_lst.append(f'{zone} ({rule_count} rule{"s" if rule_count > 1 else ""})')
            return BP_Check(
                16, 'User ID Rules without User ID enabled on Zone', 'warn', 'fail',
                ('The following zones do not have User ID enabled, '
                 'but User ID is used on the rule: {}').format(', '.join(message_lst)))
        else:
            return BP_Check(
                16, 'User ID Rules without User ID enabled on Zone', 'warn', 'pass', '')

    @property
    def record(self):
        return {
            'configuration': {'vsys': self.vsys},
            'bp_check': [getattr(self, check)._asdict() for check in dir(self)
                         if check.endswith('_warn') and getattr(self, check) is not None]
        }
