# -*- coding: utf-8 -*-
"""
Created on Mon Jan 30 09:52:03 2017

@author: anmendoza
"""

from collections import namedtuple
from six import iteritems

from ..warn_note import BP_Check
from ..base import Base


class Zone(Base):
    xpath = '//vsys/entry/zone/entry[not(ancestor::readonly)]'

    def __init__(self, entry, version: str, panorama=False):
        super(Zone, self).__init__(element=entry, panorama=panorama)
        self.name = entry.get('name')
        self.user_id_enabled = entry.findtext('enable-user-identification', 'no') == 'yes'
        self.using_acl_include_list = entry.find('user-acl/include-list') is not None
        self.zone_protection_profile = entry.findtext('network/zone-protection-profile')
        if int(version[0]) >= 8:
            self.packet_buffer_protection_enabled = entry.findtext('network/enable-packet-buffer-protection', 'no') == 'yes'

    @property
    def zone_protection_profile_warn(self):
        """Warns if Zone Protection Profile is not applied."""
        if self.zone_protection_profile is None:
            return BP_Check(
                60, 'Zone Protection Profile Applied to Zone', 'warn', 'fail',
                'Zone should have a zone protection profile applied')
        else:
            return BP_Check(
                60, 'Zone Protection Profile Applied to Zone', 'warn', 'pass', '')

    @property
    def user_id_acl_include_warn(self):
        """Warns if User ID is enabled but not using ACL Include List."""
        if self.user_id_enabled:
            if not self.using_acl_include_list:
                return BP_Check(
                    61, 'ACL Include List for User ID', 'warn', 'fail',
                    'When User ID is enabled, you should also be using an ACL Include List')
            else:
                return BP_Check(61, 'ACL Include List for User ID', 'warn', 'pass', '')

    @property
    def user_id_enabled_note(self):
        """Adds note if User ID is enabled on Zone."""
        if self.user_id_enabled:
            return BP_Check(
                62, 'User ID on Untrusted Zones', 'note', '',
                'Only enable User ID on trusted zones'
            )

    @property
    def packet_buffer_protection_enabled_warn(self):
        """Enable Packet Buffer Protection only exists on PAN-OS 8+"""
        try:
            if not self.packet_buffer_protection_enabled:
                return BP_Check(
                    212, 'Enable Packet Buffer Protection', 'warn', 'fail',
                    'It is recommended to enable Packet Buffer Protection.'
                )
            return BP_Check(212, 'Enable Packet Buffer Protection', 'warn', 'pass', '')
        except AttributeError:
            return None

    @property
    def record(self):
        configuration = {
            'name': self.name,
            'vsys': self.vsys,
            'user_id_enabled': self.user_id_enabled,
            'using_acl_include_list': self.using_acl_include_list,
            'zone_protection_profile': self.zone_protection_profile
        }

        if self.panorama:
            configuration['template_name'] = self.template_name

        if hasattr(self, 'packet_buffer_protection_enabled'):
            configuration['packet_buffer_protection_enabled'] = self.packet_buffer_protection_enabled

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}

    @staticmethod
    def get_zones_with_user_id_enabled(zones):
        return [zone.name for zone in zones if zone.user_id_enabled]


class PacketBasedAttackProtection(object):
    """Packet Based Attack Protection settings within a Zone Protection Profile."""
    def __init__(self, entry):
        self.ip_option_drop_malformed = entry.findtext('discard-malformed-option', 'no') == 'yes'
        self.tcp_drop = {
            'mismatched_overlapping_tcp_segment': entry.findtext('discard-overlapping-tcp-segment-mismatch', 'no'),
            'tcp_syn_with_data': entry.findtext('discard-tcp-syn-with-data', 'yes') == 'yes',
            'tcp_synack_with_data': entry.findtext('discard-tcp-synack-with-data', 'yes') == 'yes',
            'strip_tcp_timestamp': entry.findtext('remove-tcp-timestamp', 'no') == 'yes'
        }


class ZoneProtectionProfile(Base):
    xpath = '//network/profiles/zone-protection-profile/entry'

    def __init__(self, entry, panorama=False):
        super(ZoneProtectionProfile, self).__init__(element=entry, panorama=panorama)
        self.name = entry.get('name')
        self.entry = entry
        self.packet_based_attack_protection = PacketBasedAttackProtection(entry)

    @property
    def flood_protection(self):
        FloodProtection = namedtuple('FloodProtection',
                                     ['tcp_syn', 'icmp', 'icmp_v6', 'other_ip', 'udp'])

        FloodProtectionFeature = namedtuple('FloodProtectionFeature',
                                            ['enabled', 'alert', 'activate', 'maximum'])
        feature_lst = []
        for feature in ('tcp-syn', 'icmp', 'icmpv6', 'other-ip', 'udp'):
            feature_settings = []
            feature_settings.append(
                self.entry.findtext('flood/%s/enable' % feature, 'no') == 'yes'  # enable setting
            )
            for setting, default in iteritems(
                    {'alarm-rate': 10000, 'activate-rate': 10000, 'maximal-rate': 40000}):
                try:
                    val = int(
                        self.entry.xpath(
                            'flood/%s/*/%s/text()' %
                            (feature, setting))[0])
                except BaseException:
                    val = default
                finally:
                    feature_settings.append(val)
            feature_lst.append(FloodProtectionFeature(*feature_settings))

        return FloodProtection(*feature_lst)

    @property
    def reconnaissance_protection(self):
        ReconnaissanceProtection = namedtuple('ReconnaissanceProtection',
                                              ['tcp_port_scan_enabled', 'host_sweep_enabled', 'udp_port_scan_enabled'])

        reconnaissance_protection_element = self.entry.find('scan')
        if reconnaissance_protection_element is None:
            return ReconnaissanceProtection(False, False, False)

        scan_type_lst = []
        for scan_type in (
                "8001", "8002", "8003"):  # tcp, host, and udp respectively
            scan_type_lst.append(
                reconnaissance_protection_element.find(
                    'entry[@name="{}"]'.format(scan_type)) is not None)

        return ReconnaissanceProtection(*scan_type_lst)

    @property
    def flood_protection_warn(self):
        display_dict = {'tcp_syn': 'SYN', 'icmp': 'ICMP', 'icmp_v6': 'ICMPv6',
                        'other_ip': 'Other IP', 'udp': 'UDP'}
        default_vals = (10000, 10000, 40000)

        not_enabled_fails = []
        default_value_fails = []
        for flood_type, checks in iteritems(self.flood_protection._asdict()):
            # check if not enabled
            if not checks.enabled:
                not_enabled_fails.append(display_dict[flood_type])
            # check if using any default alues
            if any(
                    (default, provided) for (default, provided)
                    in zip(default_vals, (checks.alert, checks.activate, checks.maximum))
                    if default == provided):
                default_value_fails.append(display_dict[flood_type])

        warn_message_lst = []
        if not_enabled_fails:
            warn_message_lst.append(
                'Flood Protection > {} should be enabled'.format(' / '.join(not_enabled_fails)))
        if default_value_fails:
            warn_message_lst.append(
                'Flood Protection > {} should NOT use default values (10000,10000,40000)'.format(
                    ' / '.join(default_value_fails)))

        if warn_message_lst:
            return BP_Check(85, 'Flood Protection', 'warn',
                            'fail', ' AND '.join(warn_message_lst))
        else:
            return BP_Check(85, 'Flood Protection', 'warn', 'pass', '')

    @property
    def reconnaissance_protection_warn(self):
        warn_message_lst = []
        display_dict = {
            'tcp_port_scan_enabled': 'TCP Port Scan',
            'host_sweep_enabled': 'Host Sweep',
            'udp_port_scan_enabled': 'UDP Port Scan'
        }

        for scan_type, enabled in iteritems(self.reconnaissance_protection._asdict()):
            if not enabled:
                warn_message_lst.append(display_dict[scan_type])

        if warn_message_lst:
            return BP_Check(
                86, 'Reconnaissance Protection', 'warn', 'fail',
                'Reconnaissance Protection > {} should be enabled'.format(' / '.join(warn_message_lst))
            )
        else:
            return BP_Check(86, 'Reconnaissance Protection', 'warn', 'pass', '')

    @property
    def packet_based_attack_protection_warn(self):
        errors = []

        if not self.packet_based_attack_protection.ip_option_drop_malformed:
            errors.append('IP Option Drop Malformed should be enabled.')

        for setting, enabled in iteritems(self.packet_based_attack_protection.tcp_drop):
            if not enabled:
                errors.append('TCP Drop {} should be enabled.'.format(' '.join(x.title() for x in setting.split('_'))))

        if errors:
            return BP_Check(87, 'Packet Based Attack Protection', 'warn', 'fail', ' '.join(errors))
        else:
            return BP_Check(87, 'Packet Based Attack Protection', 'warn', 'pass', '')

    @property
    def record(self):
        flood_protection = {}
        for tab in self.flood_protection._fields:
            flood_protection[tab] = {}
            for option in self.flood_protection._asdict()[tab]._fields:
                flood_protection[tab][option] = (
                    self.flood_protection._asdict()[tab]._asdict()[option])

        reconnaissance_protection = {
            'tcp_port_scan_enabled': self.reconnaissance_protection.tcp_port_scan_enabled,
            'host_sweep_enabled': self.reconnaissance_protection.host_sweep_enabled,
            'udp_port_scan_enabled': self.reconnaissance_protection.udp_port_scan_enabled
        }

        configuration = {
            'name': self.name,
            'flood_protection': flood_protection,
            'reconnaissance_protection': reconnaissance_protection,
            'packet_based_attack_protection': self.packet_based_attack_protection.__dict__,
        }

        if self.panorama:
            configuration['template_name'] = self.template_name

        return {'configuration': configuration,
                'bp_check': self.get_bp_checks()}
