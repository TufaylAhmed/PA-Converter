# -*- encoding: utf-8 -*-
from __future__ import unicode_literals
from lxml import etree
from pandas.io.json import json_normalize

# policies imports
from .bp_checks.policies.app_override import AppOverride
from .bp_checks.policies.captive_portal import CaptivePortalRule
from .bp_checks.policies.decryption_rule import DecryptionRule, DecryptionRulebases
from .bp_checks.policies.policy_based_forwarding import PolicyBasedForwardingRule
from .bp_checks.policies.security_rules import SecurityRulesContainer
from .bp_checks.policies.dos_protection import DOSProtectionRulebase

# objects imports
from .bp_checks.objects.decryption_profile import DecryptionProfile
from .bp_checks.objects.hip_object_profile import HIPProfiles
from .bp_checks.objects.log_forwarding_profile import LogForwardingProfile
from .bp_checks.objects.sanctioned_applications import SanctionedApplications
from .bp_checks.objects.security_profiles import (SecurityProfiles,
                                                  DOSProtectionProfile)

# network imports
from .bp_checks.network.ipsec_crypto_profile import IPSecCryptoProfile
from .bp_checks.network.zones import Zone, ZoneProtectionProfile
from .bp_checks.network.global_protect import (GlobalProtectPortal,
                                               GlobalProtectGateway)

# device imports
from .bp_checks.device.user_id import UserID
from .bp_checks.device.admins import Administrators, AdminRoles
from .bp_checks.device.log_settings import LogSettingsSystem, LogSettingsConfig
from .bp_checks.device.auth_profile_sequence import (AuthProfile, AuthProfiles,
                                                     AuthSequence, AuthSequences)
from .bp_checks.device.dynamic_updates import DynamicUpdates
from .bp_checks.device.high_availability import (HighAvailabilityGeneral,
                                                 HighAvailabilityLinkPathMonitoring)
from .bp_checks.device.server_profiles import (SNMPTrapServerProfile,
                                               SyslogServerProfile,
                                               LDAPServerProfile)
from .bp_checks.device.device_setup import (GeneralSettings,
                                            AuthenticationSettings,
                                            LoggingReportingSettings,
                                            PanoramaSettings,
                                            ManagementInterfaceSettings,
                                            MinimumPasswordComplexitySettings,
                                            ServicesSettings,
                                            ContentIDSettings,
                                            WildFireSettings,
                                            SessionSettings,
                                            TelemetrySettings)


class BestPracticeAssessment(object):
    get_gateway_interfaces = etree.XPath(
        'descendant::*[starts-with(name(), "global-protect-")]/entry/local-address/interface/text()'
    )

    def __init__(self, xml_config):
        xml = xml_config.tree
        self.version = str(xml_config.version)
        self.urldb = xml_config.urldb
        self.panorama = xml_config.panorama
        self.dgs_with_devices = xml_config.dgs_with_devices
        self.device_group_hierarchy = xml_config.ancestors
        self.dg_descendants = xml_config.descendants

        if self.panorama:
            self.device_prefix = 'template'
        else:
            self.device_prefix = 'device'

        if self.version[0] == '8':
            self.telemetry_prefix = 'telemetry'
        else:
            self.telemetry_prefix = 'statistics_services'

        user_id_var = '{}_user_id'.format(self.device_prefix)
        telemetry_settings_var = '{0}_{1}_settings'.format(self.device_prefix, self.telemetry_prefix)

        #########################
        # Device Tab
        #########################
        (self.template_general_settings,
            self.device_general_settings) = GeneralSettings.get_all(
            xml=xml, xml_config=xml_config, panorama=self.panorama)

        (self.template_authentication_settings,
            self.device_authentication_settings) = AuthenticationSettings.get_all(
            xml=xml, panorama=self.panorama)
        (self.template_logging_reporting_settings,
            self.device_logging_reporting_settings) = LoggingReportingSettings.get_all(
            xml=xml, panorama=self.panorama)
        (self.template_panorama_settings, self.device_panorama_settings) = PanoramaSettings.get_all(xml_config)
        (self.template_management_interface_settings,
            self.device_management_interface_settings) = ManagementInterfaceSettings.get_all(
            xml=xml, panorama=self.panorama)
        (self.template_minimum_password_complexity_settings,
            self.device_minimum_password_complexity_settings) = (
            MinimumPasswordComplexitySettings.get_all(xml=xml, panorama=self.panorama))
        (self.template_services_settings,
            self.device_services_settings) = ServicesSettings.get_all(
            xml=xml, panorama=self.panorama)
        (self.template_content_id_settings,
            self.device_content_id_settings) = ContentIDSettings.get_all(
            xml=xml, panorama=self.panorama, exclude_none=True)
        (self.template_wildfire_settings,
            self.device_wildfire_settings) = WildFireSettings.get_all(
            xml=xml, panorama=self.panorama, exclude_none=True)
        (self.template_session_settings,
            self.device_session_settings) = SessionSettings.get_all(
            xml=xml, version=self.version, panorama=self.panorama, exclude_none=True)
        # name attribute differently if panorama so that it matches UI
        setattr(self, telemetry_settings_var, TelemetrySettings.get_all(
            xml=xml, panorama=self.panorama, version=self.version,
            exclude_none=True, template_device_split=False))
        (self.template_administrators, self.device_administrators) = Administrators.get_all(xml_config)
        (self.template_admin_roles, self.device_admin_roles) = AdminRoles.get_all(xml=xml, panorama=self.panorama)
        (self.template_auth_profiles, self.device_auth_profiles) = AuthProfile.get_all(xml=xml, panorama=self.panorama)
        self.template_auth_profiles_aggregate = AuthProfiles(
            profiles=self.template_auth_profiles, xml=xml,
            template=True, panorama=self.panorama).records
        self.device_auth_profiles_aggregate = AuthProfiles(
            profiles=self.device_auth_profiles, xml=xml,
            template=False, panorama=self.panorama).records
        (self.template_auth_sequences,
            self.device_auth_sequences) = AuthSequence.get_all(xml=xml, panorama=self.panorama)
        self.template_auth_sequences = AuthSequences(
            xml=xml, sequences=self.template_auth_sequences,
            template=True, panorama=self.panorama).records + self.template_auth_sequences
        self.device_auth_sequences = AuthSequences(
            xml=xml, sequences=self.device_auth_sequences,
            template=False, panorama=self.panorama).records + self.device_auth_sequences
        # name attribute differently if panorama so that it matches UI
        setattr(self, user_id_var, UserID.get_all(xml=xml,
                                                  panorama=self.panorama,
                                                  template_device_split=False))
        (self.template_log_setting_system,
            self.device_log_setting_system) = LogSettingsSystem.get_all(
            xml=xml, panorama=self.panorama)
        (self.template_log_setting_config,
            self.device_log_setting_config) = LogSettingsConfig.get_all(
            xml=xml, panorama=self.panorama)
        (self.template_snmptrap_server_profiles,
            self.device_snmptrap_server_profiles) = SNMPTrapServerProfile.get_all(
            xml=xml, panorama=self.panorama)
        (self.template_syslog_server_profiles,
            self.device_syslog_server_profiles) = SyslogServerProfile.get_all(
            xml=xml, panorama=self.panorama)
        (self.template_ldap_server_profiles,
            self.device_ldap_server_profiles) = LDAPServerProfile.get_all(
            xml=xml, panorama=self.panorama)
        self.template_dynamic_updates, self.device_dynamic_updates = DynamicUpdates.get_all(xml_config)
        (self.template_high_availability_general,
            self.device_high_availability_general) = HighAvailabilityGeneral.get_all(
            xml=xml, panorama=self.panorama)
        (self.template_high_availability_link_path_monitoring,
            self.device_high_availability_link_path_monitoring) = (
            HighAvailabilityLinkPathMonitoring.get_all(xml=xml, panorama=self.panorama))

        #########################
        # Network Tab
        #########################
        zones = Zone.get_objects(xml, version=self.version, panorama=self.panorama)
        zones_with_user_id_enabled = Zone.get_zones_with_user_id_enabled(zones)
        self.zones = [zone.record for zone in zones]

        self.zone_protection_profiles = ZoneProtectionProfile.get_all(
            xml, panorama=self.panorama, template_device_split=False)

        self.gp_portals = GlobalProtectPortal.get_all(
            xml, panorama=self.panorama,
            template_device_split=False, xml_config=xml_config)

        self.gp_gateways = GlobalProtectGateway.get_all(
            xml, panorama=self.panorama, template_device_split=False, xml_config=xml_config)

        self.ipsec_crypto_profiles = IPSecCryptoProfile.get_all(
            xml, panorama=self.panorama, template_device_split=False)

        # Parse the security rules first since those elements will be used in
        # checks for both security profiles and security rules
        security_rules_container = SecurityRulesContainer(
            xml=xml, dgs_with_devices=self.dgs_with_devices,
            device_group_hierarchy=self.device_group_hierarchy,
            zones_with_user_id_enabled=zones_with_user_id_enabled,
            panorama=self.panorama)

        #########################
        # Objects Tab
        #########################
        self.sanctioned_applications = SanctionedApplications(xml).record

        self.hip_profiles = HIPProfiles.get_all(
            xml, panorama=self.panorama, security_rules_container=security_rules_container,
            dg_descendants=self.dg_descendants, template_device_split=False)

        self.security_profiles = SecurityProfiles(
            xml=xml,
            urldb=self.urldb,
            dg_descendants=self.dg_descendants,
            panorama=self.panorama,
            security_rules_container=security_rules_container,
        )

        # Create a separate attribute for each profile type
        self.wildfire_profiles = self.security_profiles.get_profile_records('wildfire_profiles')
        self.url_filtering_profiles = self.security_profiles.get_profile_records('url_filtering_profiles')
        self.antivirus_profiles = self.security_profiles.get_profile_records('antivirus_profiles')
        self.antispyware_profiles = self.security_profiles.get_profile_records('antispyware_profiles')
        self.vuln_protection_profiles = self.security_profiles.get_profile_records('vuln_protection_profiles')
        self.file_blocking_profiles = self.security_profiles.get_profile_records('file_blocking_profiles')

        self.dos_protection_profiles = DOSProtectionProfile.get_all(
            xml=xml, panorama=self.panorama, template_device_split=False)
        self.log_forwarding_profiles = LogForwardingProfile.get_all(
            xml=xml, panorama=self.panorama, version=self.version, template_device_split=False)

        self.decryption_profiles = DecryptionProfile.get_all(
            xml=xml, panorama=self.panorama, template_device_split=False)

        #########################
        # Policies Tab
        #########################
        self.security_rules = security_rules_container.get_security_rule_records()

        self.security_rulebase = security_rules_container.get_security_rulebase_records()

        self.policy_based_forwarding_rules = PolicyBasedForwardingRule.get_all(
            xml=xml, panorama=self.panorama, template_device_split=False)

        self.decryption_rulebase = DecryptionRulebases(
            xml=xml, dgs_with_devices=self.dgs_with_devices,
            device_group_hierarchy=self.device_group_hierarchy, panorama=self.panorama).records

        self.decryption_rules = DecryptionRule.get_all(
            xml=xml, panorama=self.panorama, template_device_split=False)

        self.app_override_rules = AppOverride.get_all(
            xml=xml, panorama=self.panorama, template_device_split=False)

        self.captive_portal_rules = CaptivePortalRule.get_all(
            xml=xml, panorama=self.panorama, template_device_split=False, xml_config=xml_config)

        self.dos_protection_rulebase = DOSProtectionRulebase(
            xml=xml, dgs_with_devices=self.dgs_with_devices,
            device_group_hierarchy=self.device_group_hierarchy, panorama=self.panorama).records

    def get_valid_security_profiles(self):
        """Collects security profiles that do not fail any best practice checks.

        For security profiles that do not have any failed checks, create a record
        for where the device group was created and any device group descendants so
        it can be more easily merged with the heatmap data.

        Returns:
            A list of dictionaries containing the device group, and profile name
        """
        security_profile_attrs = [
            ('wildfire_profiles', 'wildfire_profile_name', 'default'),
            ('url_filtering_profiles', 'url_filtering_profile_name', None),
            ('antivirus_profiles', 'av_profile_name', None),
            ('antispyware_profiles', 'spyware_profile_name', None),
            ('vuln_protection_profiles', 'vuln_profile_name', None),
            ('file_blocking_profiles', 'file_blocking_profile_name', 'strict file blocking'),
        ]
        results = []

        for attr, result_name, passing_default_name in security_profile_attrs:
            strict_profiles = [
                (prof['configuration']['vsys'], prof['configuration']['name']) for prof in getattr(self, attr)
                if not any(check['result'] == 'fail' for check in prof['bp_check'])
            ]
            if passing_default_name is not None:
                strict_profiles.append(('shared', passing_default_name))

            for vsys, profile_name in strict_profiles:
                for descendant in self.dg_descendants[vsys]:
                    results.append({'device_group': descendant, result_name: profile_name})

        return results

    def json(self, flatten=False):
        data_structure = {
            'objects': {
                'tags': self.sanctioned_applications,
                'global_protect': {
                    'hip_profiles': self.hip_profiles
                },
                'security_profiles': {
                    'antivirus': self.antivirus_profiles,
                    'antispyware': self.antispyware_profiles,
                    'vulnerability': self.vuln_protection_profiles,
                    'url_filtering': self.url_filtering_profiles,
                    'file_blocking': self.file_blocking_profiles,
                    'wildfire': self.wildfire_profiles,
                    'dos_protection': self.dos_protection_profiles
                },
                'log_forwarding': self.log_forwarding_profiles,
                'decryption_profiles': self.decryption_profiles
            },
            'policies': {
                'security_rules': self.security_rules,
                'security_rulebase': self.security_rulebase,
                'policy_based_forwarding': self.policy_based_forwarding_rules,
                'decryption': self.decryption_rules,
                'decryption_rulebase': self.decryption_rulebase,
                'app_override': self.app_override_rules,
                'captive_portal': self.captive_portal_rules,
                'dos_protection_rulebase': self.dos_protection_rulebase
            },
            'network': {
                'zones': self.zones,
                'global_protect': {
                    'portals': self.gp_portals,
                    'gateways': self.gp_gateways,
                },
                'network_profiles': {
                    'ipsec_crypto': self.ipsec_crypto_profiles,
                    'zone_protection': self.zone_protection_profiles
                }
            },
            'device': {
                'setup': {
                    'management': {
                        'general_settings': getattr(self, self.device_prefix + '_general_settings'),
                        'authentication_settings': getattr(self, self.device_prefix + '_authentication_settings'),
                        'logging_reporting_settings': getattr(self, self.device_prefix + '_logging_reporting_settings'),
                        'panorama_settings': getattr(self, self.device_prefix + '_panorama_settings'),
                        'management_interface_settings': getattr(self, self.device_prefix + '_management_interface_settings'),
                        'minimum_password_complexity': getattr(self, self.device_prefix + '_minimum_password_complexity_settings'),
                    },
                    'services': getattr(self, self.device_prefix + '_services_settings'),
                    'content_id': getattr(self, self.device_prefix + '_content_id_settings'),
                    'wildfire': getattr(self, self.device_prefix + '_wildfire_settings'),
                    'session': getattr(self, self.device_prefix + '_session_settings'),
                    'telemetry': getattr(self, '%s_%s_settings' % (self.device_prefix, self.telemetry_prefix)),
                },
                'high_availability': {
                    'general': getattr(self, self.device_prefix + '_high_availability_general'),
                    'link_path_monitoring': getattr(self, self.device_prefix + '_high_availability_link_path_monitoring'),
                },
                'administrators': getattr(self, self.device_prefix + '_administrators'),
                'admin_roles': getattr(self, self.device_prefix + '_admin_roles'),
                'authentication_profile': getattr(self, self.device_prefix + '_auth_profiles'),
                'authentication_profile_aggregate': getattr(self, self.device_prefix + '_auth_profiles_aggregate'),
                'authentication_sequence': getattr(self, self.device_prefix + '_auth_sequences'),
                'user_identification': getattr(self, self.device_prefix + '_user_id'),
                'log_settings': {
                    'system': getattr(self, self.device_prefix + '_log_setting_system'),
                    'config': getattr(self, self.device_prefix + '_log_setting_config'),
                },
                'server_profiles': {
                    'snmp_trap': getattr(self, self.device_prefix + '_snmptrap_server_profiles'),
                    'syslog': getattr(self, self.device_prefix + '_syslog_server_profiles'),
                    'ldap': getattr(self, self.device_prefix + '_ldap_server_profiles'),
                },
                'dynamic_updates': getattr(self, self.device_prefix + '_dynamic_updates'),
            },
            'panorama': {
                'setup': {
                    'management': {
                        'general_settings': self.device_general_settings,
                        'authentication_settings': self.device_authentication_settings,
                        'logging_reporting_settings': self.device_logging_reporting_settings,
                        'panorama_settings': self.device_panorama_settings,
                        'management_interface_settings': self.device_management_interface_settings,
                        'minimum_password_complexity': self.device_minimum_password_complexity_settings,
                    },
                    'services': self.device_services_settings,
                    'content_id': self.device_content_id_settings,
                    'wildfire': self.device_wildfire_settings,
                    'session': self.device_session_settings,
                },
                'high_availability': {
                    'general': self.device_high_availability_general,
                    'link_path_monitoring': self.device_high_availability_link_path_monitoring,
                },
                'administrators': self.device_administrators,
                'admin_roles': self.device_admin_roles,
                'authentication_profile': self.device_auth_profiles,
                'authentication_profile_aggregate': self.device_auth_profiles_aggregate,
                'authentication_sequence': self.device_auth_sequences,
                'log_settings': {
                    'system': self.device_log_setting_system,
                    'config': self.device_log_setting_config,
                },
                'server_profiles': {
                    'snmp_trap': self.device_snmptrap_server_profiles,
                    'syslog': self.device_syslog_server_profiles,
                    'ldap': self.device_ldap_server_profiles,
                },
                'dynamic_updates': self.device_dynamic_updates,
            }
        }

        if not self.panorama:
            del data_structure['panorama']

        if flatten:
            # flatten the json struture before returning output
            return json_normalize(data_structure).to_dict(orient='records')[0]
        else:
            return data_structure
