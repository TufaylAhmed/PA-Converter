# -*- coding: utf-8 -*-
"""
Created on Thu Feb 09 08:48:46 2017

@author: nbitting
"""
from six import iteritems

from iptools import IpRangeList
from iptools.ipv4 import cidr2block

from ...common import bool_attr, num_attr, str_attr, tag_val
from ..warn_note import BP_Check
from ..base import Base
import weakref


class GeneralSettings(Base):
    xpath = '//config/devices/entry[not(ancestor::readonly) and not(ancestor::template-stack)]'

    def __init__(self, entry, xml_config, panorama=False):
        super(GeneralSettings, self).__init__(entry, panorama)
        self.login_banner_enabled = entry.find(
            'deviceconfig/system/login-banner') is not None
        self.auto_acquire_commit_lock_enabled = bool_attr(
            entry, 'deviceconfig/setting/management/auto-acquire-commit-lock/text()')

        # Template hostname configuration is not a best practice.
        if not hasattr(self, 'template_name'):
            self.hostname = str_attr(
                entry, 'deviceconfig/system/hostname', 'None')

        # Certificate Expiration Check is not configurable on Panorama.
        # Certificate Expiration Check is DISABLED by default on NGFW / templates
        # and does not show up in XML unless value is modified.
        if not self.panorama or hasattr(self, 'template_name'):
            self.cert_expiration_check_enabled = str_attr(
                entry,
                'deviceconfig/setting/management/enable-certificate-expiration-check',
                'no'
            ) == 'yes'
        self.ssl_tls_service_profile = entry.findtext('deviceconfig/system/ssl-tls-service-profile', 'None')
        self._xml_config = weakref.ref(xml_config)

    @property
    def login_banner_enabled_warn(self):
        if not self.login_banner_enabled:
            return BP_Check(91, 'Login Banner', 'warn', 'fail',
                            'It is recommended to have a descriptive Login Banner')
        else:
            return BP_Check(91, 'Login Banner', 'warn', 'pass', '')

    @property
    def auto_acquire_commit_lock_enabled_warn(self):
        if not self.auto_acquire_commit_lock_enabled:
            return BP_Check(88, 'Automatically Acquire Commit Lock', 'warn', 'fail',
                            'It is recommended to enable "Automatically Acquire Commit Lock"')
        else:
            return BP_Check(
                88, 'Automatically Acquire Commit Lock', 'warn', 'pass', '')

    @property
    def cert_expiration_check_enabled_warn(self):
        if self.ssl_tls_service_profile == 'None':
            return BP_Check(
                89, 'Certificate Expiration Check', 'warn', 'fail',
                'The SSL/TLS Service Profile is not configured'
            )
        if hasattr(self, 'cert_expiration_check_enabled') and not self.cert_expiration_check_enabled:
            return BP_Check(
                89, 'Certificate Expiration Check', 'warn', 'fail',
                'It is recommended to enable "Certification Expiration Check"'
            )
        ssl_profile = next(iter(x for x in self._xml_config().collector.get('ssl_tls_service_profile') if x.name == self.ssl_tls_service_profile))
        if ssl_profile.certificate == 'None':
            return BP_Check(
                89, 'Certificate Expiration Check', 'warn', 'fail',
                'SSL/TLS Service Profile does not have certificate configured'
            )
        cert = next(iter(x for x in self._xml_config().collector.get('certificate') if x.name == ssl_profile.certificate))
        if cert.issuer_hash == cert.subject_hash:
            return BP_Check(
                89, 'Certificate Expiration Check', 'warn', 'fail',
                'SSL/TLS Service Profile is using a self signed certificate'
            )
        return BP_Check(89, 'Certificate Expiration Check', 'warn', 'pass', '')

    @property
    def hostname_warn(self):
        if not hasattr(self, 'template_name'):
            if self.hostname in ['localhost', 'None']:
                return BP_Check(90, 'Hostname', 'warn', 'fail',
                                'It is recommended to configure a Hostname')
            else:
                return BP_Check(90, 'Hostname', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {
            key: val for key, val in iteritems(self.__dict__)
            if key != 'panorama' and not key.startswith('_')
        }
        return {'configuration': configuration,
                'bp_check': self.get_bp_checks()}


class AuthenticationSettings(Base):
    xpath = '//config/devices/entry[not(ancestor::readonly) and not(ancestor::template-stack)]'

    def __init__(self, entry, panorama=False):
        super(AuthenticationSettings, self).__init__(entry, panorama)
        self._entry = entry
        self.authentication_profile = entry.findtext('deviceconfig/system/authentication-profile', 'None')
        self.certificate_profile = entry.findtext('deviceconfig/system/certificate-profile', 'None')
        self.idle_timeout = int(entry.findtext('deviceconfig/setting/management/idle-timeout', 60))
        self.failed_attempts = int(entry.findtext('deviceconfig/setting/management/admin-lockout/failed-attempts', 0))
        self.lockout_time = int(entry.findtext('deviceconfig/setting/management/admin-lockout/lockout-time', 0))

    @property
    def authentication_profile_warn(self):
        """Warn if an Auth Profile is not configured. There are three steps to this check:
            1) Pass if Auth Profile is configured under Authentication Settings
            2) Pass if less than three admins are locally configured (i.e. Auth Profile is
            None or Local)
            3) Fail
        """
        if self.authentication_profile != 'None':
            return BP_Check(92, 'Authentication Profile', 'warn', 'pass', '')
        else:
            config_el = self._entry.xpath('ancestor::config[1]')[0]

            admin_auth_profiles = [
                str_attr(entry, 'authentication-profile', 'None') for entry
                in config_el.xpath('mgt-config/users/entry')]

            # Admins can only be configured with Auth Profiles created in
            # shared or panorama
            local_auth_profiles = set(config_el.xpath(
                '*[name() = "shared" or name() = "panorama"]/authentication-profile/entry[method'
                '/*[name() = "none" or name() = "local-database"]]/@name'))

            if len(
                    [profile for profile in admin_auth_profiles
                     if profile == 'None' or profile in local_auth_profiles]) >= 3:
                return BP_Check(
                    92, 'Authentication Profile', 'warn', 'fail',
                    'It is recommended to use external authentication.')
            else:
                return BP_Check(
                    92, 'Authentication Profile', 'warn', 'pass',
                    'Passing because Administrators are configured '
                    'with a non-local authentication profile')

    @property
    def certificate_profile_warn(self):
        if self.certificate_profile == 'None':
            return BP_Check(93, 'Certificate Profile', 'warn', 'fail',
                            'It is recommended to configure a certification profile.')
        else:
            return BP_Check(93, 'Certificate Profile', 'warn', 'pass', '')

    @property
    def idle_timeout_warn(self):
        if self.idle_timeout > 10:
            return BP_Check(94, 'Idle Timeout', 'warn', 'fail',
                            'It is recommended for idle timeout to be set to a value lower than or equal to 10.')
        else:
            return BP_Check(94, 'Idle Timeout', 'warn', 'pass', '')

    @property
    def failed_attempts_warn(self):
        if self.failed_attempts != 5:
            return BP_Check(
                95, 'Failed Attempts', 'warn', 'fail',
                'It is recommended for failed attempts to be set to 5.'
            )
        else:
            return BP_Check(95, 'Failed Attempts', 'warn', 'pass', '')

    @property
    def lockout_time_warn(self):
        if 30 <= self.lockout_time <= 45:
            return BP_Check(96, 'Lockout Time', 'warn', 'pass', '')
        else:
            return BP_Check(
                96, 'Lockout Time', 'warn', 'fail',
                'It is recommended to configure lockout time to a value between 30 and 45 minutes.'
            )

    @property
    def record(self):
        return {
            'configuration': {
                key: val for key, val in iteritems(self.__dict__)
                if not key.startswith('_')},
            'bp_check': self.get_bp_checks()}


class LoggingReportingSettings(Base):
    xpath = '//config/devices/entry[not(ancestor::readonly) and not(ancestor::template-stack)]'

    def __init__(self, entry, panorama=False):
        super(LoggingReportingSettings, self).__init__(entry, panorama)
        # Panorama has Buffered Log Forwarding from Device configuration option,
        # whereas NGFW / device templates have Log on High DP Load
        # configuration option
        if self.panorama and not hasattr(self, 'template_name'):
            # Buffered Log Forwarding from Device is ENABLED by default
            self.log_forwarding_from_device_enabled = str_attr(
                entry,
                'deviceconfig/setting/management/log-forwarding-from-device/buffered',
                'yes'
            ) == 'yes'
        else:
            self.log_on_high_dp_load_enabled = bool_attr(
                entry, 'deviceconfig/setting/management/enable-log-high-dp-load/text()')

    @property
    def log_on_high_dp_load_enabled_warn(self):
        if hasattr(self, 'log_on_high_dp_load_enabled'):
            if not self.log_on_high_dp_load_enabled:
                return BP_Check(
                    97, 'Log on High DP Load', 'warn', 'fail',
                    'It is recommended to enable "Log on High DP Load"')
            else:
                return BP_Check(97, 'Log on High DP Load', 'warn', 'pass', '')

    @property
    def log_forwarding_from_device_warn(self):
        if hasattr(self, 'log_forwarding_from_device_enabled'):
            if not self.log_forwarding_from_device_enabled:
                return BP_Check(
                    98, 'Buffered Log Forwarding from Device', 'warn', 'fail',
                    'It is recommended to enable Buffered Log Forwarding from Device')
            else:
                return BP_Check(
                    98, 'Buffered Log Forwarding from Device', 'warn', 'pass', '')

    @property
    def record(self):
        return {
            'configuration':
                {key: val for key, val in iteritems(
                    self.__dict__) if key != 'panorama'},
            'bp_check': self.get_bp_checks()
        }


class PanoramaSettings(object):
    xpath = '//config/devices/entry[not(ancestor::readonly) and not(ancestor::template-stack)]'

    def __init__(self, setting):
        self._setting = setting
        self._xml_config = setting._xml_config
        self.version = setting._xml_config().version
        self.panorama = setting.panorama
        if not setting.panorama:
            self.panorama_servers = self._xml_config().tree.xpath('deviceconfig/system/panorama-server/text()')

    def is_applicable(self):
        """Panorama Settings only applies:

        1) For NGFWs being managed by a Panorama device
        2) For a Panorama that is managing other devices
        3) Device templates
        """
        return self.panorama or bool(self.panorama_servers)

    def valid_cert_type(self, comm):
        return comm.certificate_type != 'None'

    def valid_cert(self, comm):
        return getattr(comm, 'certificate', 'NA') != 'None'

    def valid_scep_prof(self, comm):
        return getattr(comm, 'scep_profile', 'NA') != 'None'

    def valid_cert_prof(self, comm):
        try:
            cert_prof = self.get_cert_profile()
        except StopIteration:
            return False
        else:
            return all([cert_prof.use_crl, cert_prof.use_ocsp])

    def valid_custom_comm(self, comm):
        return any(comm.customize_communication.values()), all(comm.customize_communication.values())

    # TODO - See if this can be refactored
    @property
    def secure_comm_settings_warn(self):
        """Different logic if PAN-OS is < 8.0"""
        def lt_8_passing():
            if self._setting._xml_config().version < 8:
                if self._setting.client_settings.certificate_type == 'None':
                    return BP_Check(
                        99, 'Secure Communication Settings', 'warn', 'fail',
                        'It is recommended to configure a certificate for Secure Client Communication'
                    )
                else:
                    return BP_Check(99, 'Secure Communication Settings', 'warn', 'pass', '')

        def gte_8_passing():
            """"""
            client_comm = self._setting.client_settings
            if not self.valid_cert_type(client_comm):
                return BP_Check(
                    99, 'Secure Communication Settings', 'warn', 'fail',
                    'It is recommended to configure "Local" or "SCEP" Certificate Type for Secure Client Communication'
                )
            if not self.valid_cert(client_comm):
                return BP_Check(
                    99, 'Secure Communication Settings', 'warn', 'fail',
                    'It is recommended to configure a certificate for Secure Client Communication'
                )
            if not self.valid_scep_prof(client_comm):
                return BP_Check(
                    99, 'Secure Communication Settings', 'warn', 'fail',
                    'It is recommended to configure a SCEP Profile for Secure Client Communication'
                )
            if not self.valid_cert_prof(client_comm):
                return BP_Check(
                    99, 'Secure Communication Settings', 'warn', 'fail',
                    'It is recommended to configure a Certificate Profile using CRL and OCSP for Secure Client Communication'
                )
            client_partial_credit, client_full_credit = self.valid_custom_comm(client_comm)
            if client_partial_credit and not client_full_credit:
                return BP_Check(
                    99, 'Secure Communication Settings', 'note', 'warning',
                    'All options under Customize Communication should be enabled for Secure Client Communication'
                )

            if hasattr(self._setting, 'server_settings'):
                if self._setting.server_settings.ssl_tls_service_profile == 'None':
                    return BP_Check(
                        99, 'Secure Communication Settings', 'warn', 'fail',
                        'It is recommended to configure a SSL/TLS Service Profile for Secure Server Communication'
                    )
                if not self.valid_cert_prof(self._setting.server_settings.certificate_profile):
                    return BP_Check(
                        99, 'Secure Communication Settings', 'warn', 'fail',
                        'It is recommended to configure a Certificate Profile using CRL and OCSP for Secure Server Communication'
                    )
                if not self._setting.server_settings.allow_custom_certificate_only:
                    return BP_Check(
                        99, 'Secure Communication Settings', 'warn', 'fail',
                        'It is recommended to enable "Allow Custom Certificate Only" for Secure Server Communication'
                    )

            return BP_Check(99, 'Secure Communication Settings', 'warn', 'pass', '')

        if self.version < 8:
            return lt_8_passing()
        return gte_8_passing()

    def get_cert_profile(self):
        """"""
        return next(
            iter(
                x for x in self._xml_config().collector.get('certificate_profile')
                if x.name == self._setting.client_settings.certificate_profile
            )
        )

    @property
    def record(self):
        if not self.is_applicable():
            return None

        configuration = {'Secure Client Communication': self._setting.client_settings.__dict__}
        if hasattr(self._setting, 'server_settings'):
            configuration['Secure Server Communication'] = self._setting.server_settings.__dict__
        if hasattr(self, 'panorama_servers'):
            configuration['Panorama Servers'] = self.panorama_servers
        if hasattr(self._setting, 'template_name'):
            configuration['template_name'] = self._setting.template_name

        return {'configuration': configuration, 'bp_check': [self.secure_comm_settings_warn._asdict()]}

    @classmethod
    def get_all(cls, xml_config):
        template_records, device_records = [], []
        for feature in xml_config.collector.get('secure_comm_setting'):
            rec = cls(feature).record
            if rec is not None:
                if hasattr(feature, 'template_name'):
                    template_records.append(rec)
                else:
                    device_records.append(rec)
        return template_records, device_records


class ManagementInterfaceSettings(Base):
    xpath = '//config/devices/entry[not(ancestor::readonly) and not(ancestor::template-stack)]'

    def __init__(self, entry, panorama=False):
        super(ManagementInterfaceSettings, self).__init__(entry, panorama)
        self.management_ip_address = entry.findtext('deviceconfig/system/ip-address')
        self.permitted_ip_addresses = entry.xpath('deviceconfig/system/permitted-ip/entry/@name')
        self.speed = str_attr(
            entry,
            'deviceconfig/system/speed-duplex',
            'auto-negotiate')

        # HTTP and Telnet are disabled by default in templates and NGFWs that have been pushed a template,
        # BUT 'disable-telnet' and 'disable-http' not included in the XML.
        # Assume the services are disabled if they are missing.
        self.telnet_disabled = entry.findtext('deviceconfig/system/service/disable-telnet', 'yes') == 'yes'
        self.http_disabled = entry.findtext('deviceconfig/system/service/disable-http', 'yes') == 'yes'

    @staticmethod
    def is_private_ip(ip_address):
        """Returns True if given IP address is private."""
        private_ips = IpRangeList('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16')
        # TODO(Samshodh) Investigate how to handle IPv6 addresses / variables
        if ip_address.startswith('$') or ':' in ip_address:
            return None
        elif '/' in ip_address:
            # If the IP is using CIDR notation address format, check the network block start and end addresses
            return all(ip in private_ips for ip in cidr2block(ip_address))
        else:
            return ip_address in private_ips

    @property
    def permitted_ip_addresses_warn(self):
        """Checks whether Permitted IP addresses are configured.

        Skip this best practice if checking a template where the management IP address is not configured.

        Fail the best practice if permitted IP addresses are NOT configured.

        If IPv4 management IP address is PRIVATE, all permitted IPv4 address must also be private to pass.

        If management IP address is PUBLIC and permitted IP addresses are configured, NOTE that permitted IP
        addresses should be limited.
        """
        if self.management_ip_address is None:
            return None

        if not self.permitted_ip_addresses:
            return BP_Check(
                100, 'Permitted IP Addresses', 'warn', 'fail', 'Permitted IP Addresses should be configured'
            )

        if self.is_private_ip(self.management_ip_address):
            # For now, do not check whether IPv6 addresses are public
            public_ips = [ip for ip in self.permitted_ip_addresses if ':' not in ip and not self.is_private_ip(ip)]
            if public_ips:
                return BP_Check(
                    100, 'Permitted IP Addresses', 'warn', 'fail',
                    'Only private IP addresses should be permitted. '
                    'Please remove the following public IP addresses: {}'.format(', '.join(public_ips))
                )
            else:
                return BP_Check(100, 'Permitted IP Addresses', 'warn', 'pass', '')
        else:
            # PUBLIC management IP with permitted IP addresses configured
            return BP_Check(
                100, 'Permitted IP Addresses', 'note', '',
                'Ensure access to management interface is limited to a select set of Permitted IP addresses '
                'per business needs to reduce the attack surface.'
            )

    @property
    def disabled_services_warn(self):
        if not all([self.telnet_disabled, self.http_disabled]):
            return BP_Check(
                102, 'Network Connectivity Services', 'warn', 'fail',
                'It is recommended to disable both "HTTP" and "Telnet" for Network Connectivity Services'
            )
        else:
            return BP_Check(102, 'Network Connectivity Services', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {
            'management_ip_address': self.management_ip_address,
            'permitted_ip_addresses': self.permitted_ip_addresses,
            'speed': self.speed,
            'telnet_disabled': self.telnet_disabled,
            'http_disabled': self.http_disabled,
        }
        if hasattr(self, 'template_name'):
            configuration['template_name'] = self.template_name

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}


class MinimumPasswordComplexitySettings(Base):
    xpath = '//mgt-config[not(ancestor::readonly) and not(ancestor::template-stack)]'

    def __init__(self, config, panorama=False):
        super(MinimumPasswordComplexitySettings, self).__init__(config, panorama)
        self.minimum_password_complexity_enabled = config.findtext('password-complexity/enabled', 'no') == 'yes'
        self.minimum_length = int(config.findtext('password-complexity/minimum-length', 0))
        self.minimum_uppercase_letters = int(config.findtext('password-complexity/minimum-uppercase-letters', 0))
        self.minimum_lowercase_letters = int(config.findtext('password-complexity/minimum-lowercase-letters', 0))

    @property
    def minimum_password_complexity_enabled_warn(self):
        message = []

        if not self.minimum_password_complexity_enabled:
            message.append('Minimum Password Complexity should be enabled')
        if self.minimum_length < 8:
            message.append('Minimum Length should be set to 8 or more')
        if self.minimum_uppercase_letters < 1:
            message.append('Minimum Uppercase Letters should be set to 1 or more')
        if self.minimum_lowercase_letters < 1:
            message.append('Minimum Lowercase Letters should be set to 1 or more')

        if message:
            message[-1] = message[-1] + '.'
            message = '. '.join(message)
            return BP_Check(103, 'Minimum Password Complexity', 'warn', 'fail', message)
        else:
            return BP_Check(103, 'Minimum Password Complexity', 'warn', 'pass', '')

    @property
    def record(self):
        return {
            'configuration': {key: val for key, val in iteritems(self.__dict__) if key != 'panorama'},
            'bp_check': [dict(self.minimum_password_complexity_enabled_warn._asdict())]
        }


class ServicesSettings(Base):
    xpath = '//config/devices[not(ancestor::readonly) and not(ancestor::template-stack)]'

    def __init__(self, entry, panorama=False):
        super(ServicesSettings, self).__init__(entry, panorama)
        self.verify_update_server_identity_enabled = entry.findtext(
            'entry/deviceconfig/system/server-verification', 'yes') == 'yes'
        self.primary_ntp_server_address = entry.findtext(
            'entry/deviceconfig/system/ntp-servers/primary-ntp-server/ntp-server-address', '')
        self.secondary_ntp_server_address = entry.findtext(
            'entry/deviceconfig/system/ntp-servers/secondary-ntp-server/ntp-server-address', '')
        self.primary_ntp_server_auth_type = tag_val(
            entry,
            'entry/deviceconfig/system/ntp-servers/primary-ntp-server/authentication-type/*',
            'None')
        self.secondary_ntp_server_auth_type = tag_val(
            entry,
            'entry/deviceconfig/system/ntp-servers/secondary-ntp-server/authentication-type/*',
            'None')

    @property
    def verify_update_server_identity_enabled_warn(self):
        if not self.verify_update_server_identity_enabled:
            return BP_Check(
                104, 'Verify Update Server Identity', 'warn', 'fail',
                'It is recommended to enable Verify Update Server Identity'
            )
        else:
            return BP_Check(104, 'Verify Update Server Identity', 'warn', 'pass', '')

    @property
    def ntp_server_address_warn(self):
        if not all([self.primary_ntp_server_address,
                    self.secondary_ntp_server_address]):
            return BP_Check(105, 'NTP Server Address', 'warn', 'fail',
                            'It is recommended to configure a primary and secondary NTP Server Address')
        else:
            return BP_Check(105, 'NTP Server Address', 'warn', 'pass', '')

    @property
    def ntp_server_auth_type_warn(self):
        if any(
                auth_type.title() == 'None'
                for auth_type in [self.primary_ntp_server_auth_type,
                                  self.secondary_ntp_server_auth_type]):
            return BP_Check(
                106, 'NTP Server Authentication Type', 'warn', 'fail',
                'It is recommended to configure a primary and secondary '
                'NTP Server Authentication Type')
        else:
            return BP_Check(
                106, 'NTP Server Authentication Type', 'warn', 'pass', '')

    @property
    def record(self):
        return {'configuration':
                {key: val for key, val in iteritems(
                    self.__dict__) if key != 'panorama'},
                'bp_check': self.get_bp_checks()
                }


class ContentIDSettings(Base):
    xpath = '//config/devices[not(ancestor::readonly) and not(ancestor::template-stack)]'

    def __init__(self, devices, panorama=False):
        super(ContentIDSettings, self).__init__(devices, panorama)
        self.use_x_forwarded_for_enabled = bool_attr(
            devices, 'entry/deviceconfig/setting/ctd/x-forwarded-for/text()')
        self.strip_x_forwarded_for_enabled = bool_attr(
            devices, 'entry/deviceconfig/setting/ctd/strip-x-fwd-for/text()')

        self.exceed_tcp_queue_enabled = devices.findtext(
            'entry/deviceconfig/setting/ctd/tcp-bypass-exceed-queue', 'yes') == 'yes'
        self.exceed_udp_queue_enabled = devices.findtext(
            'entry/deviceconfig/setting/ctd/udp-bypass-exceed-queue', 'yes') == 'yes'
        self.exceed_appID_queue_enabled = devices.findtext(
            'entry/deviceconfig/setting/application/bypass-exceed-queue', 'no') == 'yes'

        if not self.panorama:
            self.vsys_not_forwarding_decrypted_content = []
            vsys_with_decryption_policies = devices.xpath(
                'entry/vsys/entry[rulebase/decryption/rules/entry/action[text()="decrypt"]]'
            )
            for vsys in vsys_with_decryption_policies:
                try:
                    if vsys.find('setting/ssl-decrypt/allow-forward-decrypted-content').text != 'yes':
                        self.vsys_not_forwarding_decrypted_content.append(vsys.get('name'))
                # allow-forward-decrypted-content is DISABLED by default and does not show up in XML
                except AttributeError:
                    self.vsys_not_forwarding_decrypted_content.append(vsys.get('name'))

    @property
    def use_x_forwarded_for_enabled_note(self):
        if not self.use_x_forwarded_for_enabled:
            return BP_Check(
                107, 'Use X-Forwarded-For Header in User ID', 'note', 'warning',
                'If proxy is configured, it is recommended to enable "Use X-Forwarded-For Header in User ID"'
            )

    @property
    def strip_x_forwarded_for_enabled_note(self):
        if not self.strip_x_forwarded_for_enabled:
            return BP_Check(
                108, 'Strip X-Forwarded-For Header', 'note', 'warning',
                'If proxy is configured, it is recommended to enable "Strip X-Forwarded-For Header"'
            )

    @property
    def allow_forwarding_decrypted_content_warn(self):
        if not self.panorama:
            if self.vsys_not_forwarding_decrypted_content:
                message = (
                    'The following vsys are not configured to allow forwarding of decrypted content: '
                    f'{", ".join(self.vsys_not_forwarding_decrypted_content)}. '
                    'In a multi-vsys environment, this is configured in Device > Virtual Systems.'
                )
                return BP_Check(203, 'Decrypted Content Forward to Wildfire', 'warn', 'fail', message)
            else:
                return BP_Check(203, 'Decrypted Content Forward to Wildfire', 'warn', 'pass', '')

    @property
    def exceed_tcp_queue_disabled_warn(self):
        if self.exceed_tcp_queue_enabled:
            return BP_Check(215, 'TCP Content Inspection Queue', 'warn', 'fail',
                            'It is recommended to disable "Forward Segments Exceeding TCP Content Inspection Queue"')
        else:
            return BP_Check(215, 'TCP Content Inspection Queue', 'warn', 'pass', '')

    @property
    def exceed_udp_queue_disabled_warn(self):
        if self.exceed_udp_queue_enabled:
            return BP_Check(216, 'UDP Content Inspection Queue', 'warn', 'fail',
                            'It is recommended to disable "Forward Datagrams Exceeding UDP Content Inspection Queue"')
        else:
            return BP_Check(216, 'UDP Content Inspection Queue', 'warn', 'pass', '')

    @property
    def exceed_appID_queue_disabled_warn(self):
        if self.exceed_appID_queue_enabled:
            return BP_Check(217, 'APP-ID Inspection Queue', 'warn', 'fail',
                            'It is recommended to disable "Forward Segments Exceeding TCP APP-ID Inspection Queue"')
        else:
            return BP_Check(217, 'APP-ID Inspection Queue', 'warn', 'pass', '')

    @property
    def record(self):
        if (self.panorama and hasattr(self, 'template_name')) or not self.panorama:
            return {
                'configuration':
                    {key: val for key, val in iteritems(self.__dict__) if key not in ['panorama']},
                'bp_check': self.get_bp_checks()
            }


class WildFireSettings(Base):
    xpath = '//config/devices[not(ancestor::readonly) and not(ancestor::template-stack)]'

    size_limit_template_xpath = (
        'entry/deviceconfig/setting/wildfire/file-size-limit/entry[@name="%s"]/size-limit/text()'
    )

    # attr, node, default size limit
    size_limits = [
        ('pe_size_limit', 'pe', 10),
        ('apk_size_limit', 'apk', 10),
        ('pdf_size_limit', 'pdf', 500),
        ('ms_office_size_limit', 'ms-office', 500),
        ('jar_size_limit', 'jar', 1),
        ('flash_size_limit', 'flash', 5),
        ('macosx_size_limit', 'MacOSX', 1),
        ('archive_size_limit', 'archive', 10),
        ('linux_size_limit', 'linux', 2),
    ]

    session_info_xpath = 'entry/deviceconfig/setting/wildfire/session-info-select/%s'

    # attribute, node
    session_info_settings = [
        ('source_ip_enabled', 'exclude-src-ip'),
        ('source_port_enabled', 'exclude-src-port'),
        ('destination_ip_enabled', 'exclude-dest-ip'),
        ('destination_port_enabled', 'exclude-dest-port'),
        ('virtual_system_enabled', 'exclude-vsys-id'),
        ('application_enabled', 'exclude-app-name'),
        ('user_enabled', 'exclude-username'),
        ('url_enabled', 'exclude-url'),
        ('file_name_enabled', 'exclude-filename'),
        ('email_sender_enabled', 'exclude-email-sender'),
        ('email_recipient_enabled', 'exclude-email-recipient'),
        ('email_subject_enabled', 'exclude-email-subject')
    ]

    def __init__(self, entry, panorama=False):
        super(WildFireSettings, self).__init__(entry, panorama)
        self.wildfire_public_cloud = entry.findtext(
            'entry/deviceconfig/setting/wildfire/public-cloud-server',
            'wildfire.paloaltonetworks.com'
        )
        self.timezone = entry.findtext('entry/deviceconfig/system/timezone', 'None')

        self.set_file_size_limits(entry)

        self.set_session_info_settings(entry)

        self.report_grayware_files_enabled = bool_attr(
            entry, 'entry/deviceconfig/setting/wildfire/report-grayware-file/text()')

    def set_file_size_limits(self, entry):
        """Sets relevant file size limits depending on the version.

        7.0 - DOES NOT support macosx, linux, or archive file types
        7.1 - DOES NOT support linux file types
        """
        version = float(entry.getroottree().getroot().get('version')[:3])
        if version < 7.1:
            size_limits = self.size_limits[:-3]
        elif version < 8:
            size_limits = self.size_limits[:-1]
        else:
            size_limits = self.size_limits

        for attr, node, default in size_limits:
            setattr(
                self, attr, num_attr(entry, self.size_limit_template_xpath % node, default)
            )

    def set_session_info_settings(self, entry):
        """Sets Session Information settings attributes.

        Session Information settings are enabled by default and do not show up in
        the config unless modified.
        """
        for attr, node in self.session_info_settings:
            setattr(self, attr, entry.findtext(self.session_info_xpath % node, 'no') == 'no')

    @property
    def wildfire_public_cloud_note(self):
        if self.wildfire_public_cloud == 'wildfire.paloaltonetworks.com':
            message = 'It is recommended to use the {cloud} if the device is located in {region}.'
            if self.timezone.startswith('Europe'):
                message = message.format(
                    cloud='EU Wildfire Cloud (eu.wildfire.paloaltonetworks.com)', region='the EU')
            elif self.timezone == 'Japan':
                message = message.format(
                    cloud='Japan Wildfire Cloud (jp.wildfire.paloaltonetworks.com)', region='Japan')
            elif self.timezone in ['Singapore', 'Asia/Singapore']:
                message = message.format(
                    cloud='Singapore Wildfire Cloud (sg.wildfire.paloaltonetworks.com)', region='Singapore')
            else:
                message = message.format(
                    cloud=(
                        'EU Wildfire Cloud (eu.wildfire.paloaltonetworks.com), '
                        'Japan Wildfire Cloud (jp.wildfire.paloaltonetworks.com), or '
                        'Singapore Wildfire Cloud (sg.wildfire.paloaltonetworks.com)'
                    ),
                    region='the EU, Japan, or Singapore respectively'
                )

            return BP_Check(119, 'Wildfire Public Cloud', 'note', '', message)

    @property
    def pe_size_limit_warn(self):
        if self.pe_size_limit != 10:
            return BP_Check(
                109, 'PE File Size Limit', 'warn', 'fail',
                'It is recommended to set the file size limit for "pe" to 10'
            )
        else:
            return BP_Check(109, 'PE File Size Limit', 'warn', 'pass', '')

    @property
    def apk_size_limit_warn(self):
        if self.apk_size_limit != 30:
            return BP_Check(
                110, 'APK File Size Limit', 'warn', 'fail',
                'It is recommended to set the file size limit for "apk" to 30'
            )
        else:
            return BP_Check(110, 'APK File Size Limit', 'warn', 'pass', '')

    @property
    def pdf_size_limit_warn(self):
        if self.pdf_size_limit != 1000:
            return BP_Check(
                111, 'PDF File Size Limit', 'warn', 'fail',
                'It is recommended to set the file size limit for "pdf" to 1000'
            )
        else:
            return BP_Check(111, 'PDF File Size Limit', 'warn', 'pass', '')

    @property
    def ms_office_size_limit_warn(self):
        if self.ms_office_size_limit != 2000:
            return BP_Check(
                112, 'MS Office File Size Limit', 'warn', 'fail',
                'It is recommended to set the file size limit for "ms-office" to 2000'
            )
        else:
            return BP_Check(112, 'MS Office File Size Limit', 'warn', 'pass', '')

    @property
    def jar_size_limit_warn(self):
        if self.jar_size_limit != 5:
            return BP_Check(
                113, 'Jar File Size Limit', 'warn', 'fail',
                'It is recommended to set the file size limit for "jar" to 5')
        else:
            return BP_Check(113, 'Jar File Size Limit', 'warn', 'pass', '')

    @property
    def flash_size_limit_warn(self):
        if self.flash_size_limit != 5:
            return BP_Check(
                114, 'Flash File Size Limit', 'warn', 'fail',
                'It is recommended to set the file size limit for "flash" to a value of 5'
            )
        else:
            return BP_Check(114, 'Flash File Size Limit', 'warn', 'pass', '')

    @property
    def macosx_size_limit_warn(self):
        if not hasattr(self, 'macosx_size_limit'):
            return None

        if self.macosx_size_limit != 1:
            return BP_Check(
                115, 'MacOSX File Size Limit', 'warn', 'fail',
                'It is recommended to set the file size limit for "MacOSX" to a value of 1'
            )
        else:
            return BP_Check(115, 'MacOSX File Size Limit', 'warn', 'pass', '')

    @property
    def archive_size_limit_warn(self):
        if not hasattr(self, 'archive_size_limit'):
            return None

        if self.archive_size_limit != 10:
            return BP_Check(
                204, 'Archive File Size Limit', 'warn', 'fail',
                'It is recommended to set the file size limit for "archive" to a value of 10'
            )
        else:
            return BP_Check(204, 'Archive File Size Limit', 'warn', 'pass', '')

    @property
    def linux_size_limit_warn(self):
        if not hasattr(self, 'linux_size_limit'):
            return None

        if self.linux_size_limit != 2:
            return BP_Check(
                205, 'Linux File Size Limit', 'warn', 'fail',
                'It is recommended to set the file size limit for "linux" to a value of 2'
            )
        else:
            return BP_Check(205, 'Linux File Size Limit', 'warn', 'pass', '')

    @property
    def report_grayware_files_enabled_warn(self):
        if not self.report_grayware_files_enabled:
            return BP_Check(117, 'Report Grayware Files Enabled', 'warn', 'fail',
                            'It is recommended to enable "Report Grayware Files"')
        else:
            return BP_Check(
                117, 'Report Grayware Files Enabled', 'warn', 'pass', '')

    @property
    def session_info_settings_warn(self):
        disabled = [
            ' '.join(attr.split('_')[:-1]).title() for attr
            in (a for a, _ in self.session_info_settings)
            if not getattr(self, attr)
        ]

        if disabled:
            return BP_Check(118, 'Session Information Settings', 'warn', 'fail',
                            'It is not recommended to disable any of the Session Information Settings. '
                            'Please enable the following: {}'.format(', '.join(disabled)))
        else:
            return BP_Check(118, 'Session Information Settings', 'warn', 'pass', '')

    @property
    def record(self):
        if not self.panorama or hasattr(self, 'template_name'):
            return {
                'configuration': {key: val for key, val in iteritems(self.__dict__) if key != 'panorama'},
                'bp_check': self.get_bp_checks()
            }


class SessionSettings(Base):
    """Session Settings are only configurable for NGFW / device templates."""
    xpath = '//config/devices/entry[not(ancestor::readonly) and not(ancestor::template-stack)]'

    session_settings_template_xpath = 'deviceconfig/setting/session/%s/text()'

    # Tuples represent attribute, node name, and default value
    session_settings = [
        ('timeout_default', 'timeout-default', 30),
        ('timeout_discard_default', 'timeout-discard-default', 60),
        ('timeout_discard_tcp', 'timeout-discard-tcp', 90),
        ('timeout_discard_udp', 'timeout-discard-udp', 60),
        ('timeout_icmp', 'timeout-icmp', 6),
        ('timeout_scan', 'timeout-scan', 10),
        ('timeout_tcp', 'timeout-tcp', 3600),
        ('timeout_tcp_handshake', 'timeout-tcphandshake', 10),
        ('timeout_tcp_init', 'timeout-tcpinit', 5),
        ('timeout_tcp_half_closed', 'timeout-tcp-half-closed', 120),
        ('timeout_tcp_time_wait', 'timeout-tcp-time-wait', 15),
        ('timeout_unverified_rst', 'timeout-tcp-unverified-rst', 30),
        ('timeout_udp', 'timeout-udp', 30),
        ('timeout_captive_portal', 'timeout-captive-portal', 30),
    ]

    def __init__(self, entry, version: str, panorama=False):
        super(SessionSettings, self).__init__(entry, panorama)
        self.rematch_sessions_enabled = entry.findtext(
            'deviceconfig/setting/config/rematch', 'yes') == 'yes'
        self.exceed_tcp_out_of_order_queue_enabled = entry.findtext(
            'deviceconfig/setting/tcp/bypass-exceed-oo-queue', 'no') == 'yes'

        # Accelerated Aging is ENABLED by default
        self.accelerated_aging_enabled = entry.findtext(
            'deviceconfig/setting/session/accelerated-aging-enable', 'yes') == 'yes'

        if int(version[0]) >= 8:
            self.packet_buffer_protection_enabled = \
                entry.findtext('deviceconfig/setting/session/packet-buffer-protection-enable', 'no') == 'yes'
            self.packet_buffer_protection_alert = \
                int(entry.findtext('deviceconfig/setting/session/packet-buffer-protection-alert', 50))
            self.packet_buffer_protection_activate = \
                int(entry.findtext('deviceconfig/setting/session/packet-buffer-protection-activate', 50))
            self.packet_buffer_protection_block_hold_time = \
                int(entry.findtext('deviceconfig/setting/session/packet-buffer-protection-block-hold-time', 60))
            self.packet_buffer_protection_block_duration = \
                int(entry.findtext('deviceconfig/setting/session/packet-buffer-protection-block-duration-time', 3600))

        for attr, node, default in self.session_settings:
            setattr(self, attr, num_attr(
                entry, self.session_settings_template_xpath % node, default))

    @property
    def rematch_sessions_enabled_warn(self):
        if not self.rematch_sessions_enabled:
            return BP_Check(120, 'Rematch Sessions', 'warn', 'fail',
                            'It is recommended to have Rematch Sessions enabled')
        else:
            return BP_Check(120, 'Rematch Sessions', 'warn', 'pass', '')

    @property
    def accelerated_aging_enabled_warn(self):
        if not self.accelerated_aging_enabled:
            return BP_Check(121, 'Accelerated Aging', 'warn', 'fail',
                            'It is recommended to have Accelerated Aging enabled')
        else:
            return BP_Check(121, 'Accelerated Aging', 'warn', 'pass', '')

    @property
    def timeout_default_warn(self):
        if self.timeout_default != 30:
            return BP_Check(122, 'Session Timeouts: Default', 'warn', 'fail',
                            'It is recommended to use default settings for Session Timeouts.')
        else:
            return BP_Check(122, 'Session Timeouts: Default',
                            'warn', 'pass', '')

    @property
    def timeout_discard_default_warn(self):
        if self.timeout_discard_default != 60:
            return BP_Check(
                123, 'Session Timeouts: Discard Default', 'note', 'warning',
                'Please ensure you intended to change the timeout setting from the default..'
            )

    @property
    def timeout_discard_tcp_warn(self):
        if self.timeout_discard_tcp != 90:
            return BP_Check(
                124, 'Session Timeouts: Discard TCP', 'note', 'warning',
                'Please ensure you intended to change the timeout setting from the default.'
            )

    @property
    def timeout_discard_udp_warn(self):
        if self.timeout_discard_udp != 60:
            return BP_Check(
                125, 'Session Timeouts: Discard UDP', 'note', 'warning',
                'Please ensure you intended to change the timeout setting from the default.'
            )

    @property
    def timeout_icmp_warn(self):
        if self.timeout_icmp != 6:
            return BP_Check(
                126, 'Session Timeouts: ICMP', 'note', 'warning',
                'Please ensure you intended to change the timeout setting from the default.'
            )

    @property
    def timeout_scan_warn(self):
        if self.timeout_scan != 10:
            return BP_Check(
                127, 'Session Timeouts: Scan', 'note', 'warning',
                'Please ensure you intended to change the timeout setting from the default.'
            )

    @property
    def timeout_tcp_warn(self):
        if self.timeout_tcp != 3600:
            return BP_Check(
                128, 'Session Timeouts: TCP', 'note', 'warning',
                'Please ensure you intended to change the timeout setting from the default.'
            )

    @property
    def timeout_tcp_handshake_warn(self):
        if self.timeout_tcp_handshake != 10:
            return BP_Check(
                129, 'Session Timeouts: TCP handshake', 'note', 'warning',
                'Please ensure you intended to change the timeout setting from the default.'
            )

    @property
    def timeout_tcp_init_warn(self):
        if self.timeout_tcp_init != 5:
            return BP_Check(
                130, 'Session Timeouts: TCP init', 'note', 'warning',
                'Please ensure you intended to change the timeout setting from the default.'
            )

    @property
    def timeout_tcp_half_closed_warn(self):
        if self.timeout_tcp_half_closed != 120:
            return BP_Check(
                131, 'Session Timeouts: TCP Half Closed', 'note', 'warning',
                'Please ensure you intended to change the timeout setting from the default.'
            )

    @property
    def timeout_tcp_time_wait_warn(self):
        if self.timeout_tcp_time_wait != 15:
            return BP_Check(
                132, 'Session Timeouts: TC Time Wait', 'note', 'warning',
                'Please ensure you intended to change the timeout setting from the default.'
            )

    @property
    def timeout_unverified_rst_warn(self):
        if self.timeout_unverified_rst != 30:
            return BP_Check(
                133, 'Session Timeouts: Unverified RST', 'note', 'warning',
                'Please ensure you intended to change the timeout setting from the default.'
            )

    @property
    def timeout_udp_warn(self):
        if self.timeout_udp != 30:
            return BP_Check(
                134, 'Session Timeouts: UDP', 'note', 'warning',
                'Please ensure you intended to change the timeout setting from the default.'
            )

    @property
    def timeout_captive_portal_warn(self):
        if self.timeout_captive_portal != 30:
            return BP_Check(
                135, 'Session Timeouts: Captive Portal', 'note', 'warning',
                'Please ensure you intended to change the timeout setting from the default.'
            )

    @property
    def session_packet_buffer_protection_warn(self):
        if not hasattr(self, 'packet_buffer_protection_enabled'):
            return None
        message = []
        if not self.packet_buffer_protection_enabled:
            message.append('It is recommended to enable Packet Buffer Protection.')
        bad_settings = []
        for setting in ['alert', 'activate', 'block_hold_time', 'block_duration']:
            if getattr(self, f'packet_buffer_protection_{setting}') == 0:
                bad_settings.append(setting.replace('_', ' ').title())
        if bad_settings:
            message.append(
                'The following Packet Buffer Protection settings '
                'should NOT be set to 0: {}.'.format(', '.join(bad_settings))
            )
        if message:
            return BP_Check(213, 'Session Packet Buffer Protection', 'warn', 'fail', ' '.join(message))
        return BP_Check(213, 'Session Packet Buffer Protection', 'warn', 'pass', '')

    @property
    def exceed_oo_queue_disabled_warn(self):
        if self.exceed_tcp_out_of_order_queue_enabled:
            return BP_Check(214, 'TCP out-of-order traffic', 'warn', 'fail',
                            'It is recommended to disable "Forward segments exceeding TCP out-of-order queue"')
        else:
            return BP_Check(214, 'TCP out-of-order traffic', 'warn', 'pass', '')

    @property
    def record(self):
        if not self.panorama or hasattr(self, 'template_name'):
            return {
                'configuration': {key: val for key, val in iteritems(self.__dict__) if key != 'panorama'},
                'bp_check': self.get_bp_checks()
            }


class TelemetrySettings(Base):
    """Statistic Services was renamed to Telemetry in PAN OS 8.0"""
    xpath = '//config/devices/entry/deviceconfig'

    # TODO(Andrew) Refactor feeds into lists of tuples
    stats_service_feeds = (
        'application-and-threat-reports/application-usage',
        'application-and-threat-reports/attackers',
        'application-and-threat-reports/attacking-countries',
        'unknown-application-reports/unknown-applications-by-destination-ports',
        'unknown-application-reports/unknown-applications-by-destination-addresses',
        'url-reports/unknown-categories-by-url',
        'url-reports/malware-categories-by-url',
        'url-reports/dataplane-cache-url',
        'device/software-crash-info',
    )
    telemetry_feeds = (
        'application-reports',
        'threat-prevention-reports',
        'threat-prevention-pcap',
        'threat-prevention-information',
        'passive-dns-monitoring',
        'url-reports',
        'health-performance-reports',
        'file-identification-reports'
    )

    def __init__(self, deviceconfig, version=None, panorama=False):
        super(TelemetrySettings, self).__init__(deviceconfig, panorama)
        if version is None:
            self.version = int(
                deviceconfig.getroottree().getroot().get('version')[0])
        else:
            self.version = int(version[0])

        if self.version < 8:
            self.feeds = self.stats_service_feeds
            # statistics-services WITH an 's'
            self.set_feeds(deviceconfig.find(
                'system/update-schedule/statistics-services'))
        else:
            self.feeds = self.telemetry_feeds
            # statistics-service WITHOUT an 's'
            self.set_feeds(deviceconfig.find(
                'system/update-schedule/statistics-service'))

    def set_feeds(self, base_el):
        if base_el is None:
            for feed in self.feeds:
                setattr(self, feed.replace('-', '_').split('/')[-1], False)
        else:
            for feed in self.feeds:
                # Feeds are DISABLED by default
                setattr(self, feed.replace('-', '_').split('/')
                        [-1], str_attr(base_el, feed, 'no') == 'yes')

    @property
    def telemetry_enabled_warn(self):
        target_feeds = [feed.split('/')[-1].replace('-', '_')
                        for feed in self.feeds]
        if self.version < 8:
            telemetry_type = 'Statistic Services'
        else:
            telemetry_type = 'Telemetry'
        missing_feeds = []
        for feed in target_feeds:
            if not getattr(self, feed):
                missing_feeds.append(feed)
        if missing_feeds:
            return BP_Check(
                197, 'Telemetry Data', 'warn', 'fail',
                'The following {telemetry_type} feeds are not enabled: {feeds}'.format(
                    telemetry_type=telemetry_type,
                    feeds=', '.join(missing_feeds))
            )
        else:
            return BP_Check(197, 'Telemetry Data', 'warn', 'pass', '')

    @property
    def record(self):
        # Telemetry settings only exist for NGFW or device templates
        if not self.panorama or hasattr(self, 'template_name'):
            configuration = {
                key: val for key, val in iteritems(self.__dict__)
                if key not in ['version', 'feeds', 'panorama']
            }

            return {'configuration': configuration,
                    'bp_check': self.get_bp_checks()}
