# -*- coding: utf-8 -*-
"""
Created on Tue Feb 07 08:34:53 2017

@author: anmendoza
"""
from collections import namedtuple

from ..warn_note import BP_Check
from ..base import Base


class SSLForwardProxy(object):
    """Decryption Profile > SSL Decryption > SSLForwardProxy Tab"""
    FIELDS = (
        'block-expired-certificate',
        'block-untrusted-issuer',
        'block-unknown-cert',
        'block-unsupported-version',
        'block-unsupported-cipher',
        'block-client-cert',
        'block-if-no-resource',
        'block-if-hsm-unavailable'
    )

    def __init__(self, el=None):
        if el is None:
            for field in self.FIELDS:
                attr = field.replace('-', '_')
                setattr(self, attr, False)
        else:
            assert el.tag == 'ssl-forward-proxy'
            for field in self.FIELDS:
                attr = field.replace('-', '_')
                setattr(self, attr, el.findtext(field, 'no') == 'yes')


class DecryptionProfile(Base):
    xpath = '//profiles/decryption/entry'

    def __init__(self, entry, panorama=False):
        super(DecryptionProfile, self).__init__(entry, panorama)
        self.name = entry.get('name')
        self.entry = entry
        self.ssl_forward_proxy = SSLForwardProxy(entry.find('ssl-forward-proxy'))

    @property
    def ssl_inbound_inspection(self):
        SSLInboundInspection = namedtuple(
            'SSLInboundInspection',
            ['block_unsupported_version', 'block_unsupported_cipher', 'block_if_no_resource', 'block_if_hsm_unavailable']
        )
        block_unsupported_version = self.entry.findtext('ssl-inbound-proxy/block-unsupported-version', 'no') == 'yes'
        block_unsupported_cipher = self.entry.findtext('ssl-inbound-proxy/block-unsupported-cipher', 'no') == 'yes'
        block_if_no_resource = self.entry.findtext('ssl-inbound-proxy/block-if-no-resource', 'no') == 'yes'
        block_if_hsm_unavailable = self.entry.findtext('ssl-inbound-proxy/block-if-hsm-unavailable', 'no') == 'yes'

        return SSLInboundInspection(
            block_unsupported_version, block_unsupported_cipher, block_if_no_resource, block_if_hsm_unavailable
        )

    @property
    def ssl_protocol_settings(self):
        SSLProtocolSettings = namedtuple('SSLProtocolSettings',
                                         ['min_version', 'enc_algo_3des', 'enc_algo_rc4', 'max_version',
                                          'enc_algo_aes_128_cbc', 'enc_algo_aes_256_cbc', 'enc_algo_aes_128_gcm',
                                          'enc_algo_aes_256_gcm', 'auth_algo_sha1', 'auth_algo_md5',
                                          'auth_algo_sha256', 'auth_algo_sha384'])
        attrib_lst = []
        for option in [option.replace('_', '-')
                       for option in SSLProtocolSettings._fields]:
            field_element = self.entry.find('ssl-protocol-settings/' + option)
            if 'version' in option and field_element is None:
                attrib_lst.append('Not Configured')
            elif field_element is not None and field_element.tag.endswith('-version'):
                attrib_lst.append(field_element.text)
            else:
                attrib_lst.append(
                    False if field_element is None else {'yes': True, 'no': False}[field_element.text])

        return SSLProtocolSettings(*attrib_lst)

    @property
    def no_decryption(self):
        NoDecryption = namedtuple('NoDecryption',
                                  ['block_expired_certificate', 'block_untrusted_issuer'])
        attrib_lst = []
        for option in [option.replace('_', '-')
                       for option in NoDecryption._fields]:
            field_element = self.entry.find('ssl-no-proxy/' + option)
            attrib_lst.append(
                False if field_element is None else {'yes': True, 'no': False}[field_element.text])

        return NoDecryption(*attrib_lst)

    @property
    def ssh_proxy(self):
        SSHProxy = namedtuple('SSHProxy',
                              ['block_unsupported_version', 'block_unsupported_alg',
                               'block_ssh_errors', 'block_if_no_resource'])
        attrib_lst = []
        for option in [option.replace('_', '-')
                       for option in SSHProxy._fields]:
            field_element = self.entry.find('ssh-proxy/' + option)
            attrib_lst.append(
                False if field_element is None else {'yes': True, 'no': False}[field_element.text])

        return SSHProxy(*attrib_lst)

    @property
    def ssl_forward_proxy_warn(self):
        message = []
        enabled = [
            'block_expired_certificate',
            'block_untrusted_issuer',
            'block_unknown_cert',
            'block_unsupported_version',
            'block_unsupported_cipher',
            'block_client_cert',
        ]
        disabled = ['block_if_no_resource', 'block_if_hsm_unavailable']

        not_enabled = [val for val in enabled if not getattr(self.ssl_forward_proxy, val)]
        not_disabled = [val for val in disabled if getattr(self.ssl_forward_proxy, val)]

        if not_enabled:
            message.append('The following options need to be ENABLED: {}'.format(', '.join(not_enabled)))
        if not_disabled:
            message.append('The following options need to be DISABLED: {}'.format(', '.join(not_disabled)))

        if message:
            return BP_Check(55, 'SSL Forward Proxy', 'warn', 'fail', '. '.join(message))
        else:
            return BP_Check(55, 'SSL Forward Proxy', 'warn', 'pass', '')

    @property
    def ssl_inbound_inspection_warn(self):
        message = []
        not_enabled = [
            x for x in ['block_unsupported_version', 'block_unsupported_cipher']
            if not getattr(self.ssl_inbound_inspection, x, False)
        ]
        not_disabled = [
            x for x in ['block_if_no_resource', 'block_if_hsm_unavailable']
            if getattr(self.ssl_inbound_inspection, x, False)
        ]

        if not_enabled:
            message.append('Enable the following options: {}.'.format(', '.join(not_enabled)))
        if not_disabled:
            message.append('Disable the following options: {}.'.format(', '.join(not_disabled)))

        if message:
            return BP_Check(56, 'SSL Inbound Inspection', 'warn', 'fail', ' '.join(message))
        else:
            return BP_Check(56, 'SSL Inbound Inspection', 'warn', 'pass', '')

    @property
    def ssl_protocol_settings_warn(self):
        warn_message_lst = []
        if self.ssl_protocol_settings.min_version != 'tls1-2':
            warn_message_lst.append('Min Version should be set to "TLSv1.2"')
        if self.ssl_protocol_settings.max_version != 'max':
            warn_message_lst.append('Max Version should be set to "Max"')

        old_auth_algos = []
        if self.ssl_protocol_settings.auth_algo_md5:
            old_auth_algos.append('MD5')
        if self.ssl_protocol_settings.auth_algo_sha1:
            old_auth_algos.append('SHA1')

        if old_auth_algos:
            warn_message_lst.append(
                '{} should not be used for Authentication Algorithm due to weak security'.format(
                    ' and '.join(old_auth_algos)))

        disabled_options = [field for field in self.ssl_protocol_settings._fields
                            if field not in
                            ('min_version', 'max_version', 'auth_algo_sha1', 'auth_algo_md5') and
                            not self.ssl_protocol_settings._asdict()[field]]
        if disabled_options:
            warn_message_lst.append(
                'The following need to be enabled: {}'.format(', '.join(disabled_options)))

        if warn_message_lst:
            return BP_Check(
                57, 'SSL Protocol Settings', 'warn', 'fail', ' AND '.join(warn_message_lst))
        else:
            return BP_Check(57, 'SSL Protocol Settings', 'warn', 'pass', '')

    @property
    def no_decryption_warn(self):
        disabled_options = [field for field in self.no_decryption._fields
                            if not self.no_decryption._asdict()[field]]
        if disabled_options:
            return BP_Check(
                58, 'No Decryption', 'warn', 'fail',
                'The following options need to be enabled: {}'.format(', '.join(disabled_options)))
        else:
            return BP_Check(58, 'No Decryption', 'warn', 'pass', '')

    @property
    def ssh_proxy_warn(self):
        disabled_options = [field for field in self.ssh_proxy._fields
                            if not self.ssh_proxy._asdict()[field]]
        if disabled_options:
            return BP_Check(
                59, 'SSH Proxy', 'warn', 'fail',
                'The following options need to be enabled: {}'.format(', '.join(disabled_options)))
        else:
            return BP_Check(59, 'SSH Proxy', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {'name': self.name, 'vsys': self.vsys}

        for tab in ['ssl_forward_proxy', 'ssl_inbound_inspection', 'ssl_protocol_settings', 'no_decryption', 'ssh_proxy']:
            obj = getattr(self, tab)
            if hasattr(obj, '__dict__'):
                configuration[tab] = obj.__dict__
            else:
                configuration[tab] = {}
                for option in getattr(self, tab)._fields:
                    configuration[tab][option] = getattr(self, tab)._asdict()[option]

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}
