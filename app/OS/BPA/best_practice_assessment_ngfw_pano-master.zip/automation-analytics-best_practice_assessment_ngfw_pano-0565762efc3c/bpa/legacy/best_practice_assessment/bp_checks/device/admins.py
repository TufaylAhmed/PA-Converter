# -*- coding: utf-8 -*-
"""
Created on Thu Feb 09 14:59:09 2017

@author: anmendoza
"""

# https://jira-hq.paloaltonetworks.local/browse/CST-25
import weakref

from bpa.models import query
from ..warn_note import BP_Check
from ..base import Base


class Administrators(object):
    xpath = '//config/mgt-config/users'

    def __init__(self, admins, xml_config, template_name=None):
        self._xml_config = weakref.ref(xml_config)
        self.admins = admins
        self.template_name = template_name

    @property
    def admin_password_profile_warn(self):
        """Fail if neither a password profile or an authentication profile are used."""
        if not self.admins:
            return None

        users_without_password_profile = [
            user.name for user in self.admins
            if user.password_profile is None and
            user.authentication_profile is None
        ]

        if users_without_password_profile:
            return BP_Check(
                153, 'Administrator Password Profile', 'warn', 'fail',
                'The following administrators are not using a password profile or an authentication profile: '
                '{}'.format(', '.join(users_without_password_profile))
            )
        else:
            return BP_Check(153, 'Administrator Password Profile', 'warn', 'pass', '')

    def pw_complexity_valid(self):
        """Retreives the relevant min pw complexity settings feature object.

        If no min password complexity settings found (e.g. for a template), it is not
        configured and therefor invalid.
        """
        try:
            pw_complexity_obj = next(
                m for m in self._xml_config().collector.get('min_pw_complexity')
                if getattr(m, 'template_name', None) == getattr(self, 'template_name', None)
            )
        except StopIteration:
            return False
        else:
            return pw_complexity_obj.valid()

    @property
    def admin_auth_on_device_warn(self):
        """Fail if min password complexity settings are invalid, local admin is not using a password profile, or
        the password profile does not have a password change period set to 90 days.

        Skip this check if no local admins are configured.
        """
        local_admins = [a for a in self.admins if a.is_local()]
        if not local_admins:
            return

        if not self.pw_complexity_valid():
            return BP_Check(
                202, 'Admin Authentication on Device', 'warn', 'fail',
                'Minimum Password Complexity Settings are not configured correctly.'
            )

        no_pw_prof, bad_change_period, message = [], [], []
        for admin in local_admins:
            if admin.password_profile is None:
                no_pw_prof.append(admin.name)
            elif admin.pw_prof_obj.password_change_period != '90':
                bad_change_period.append(admin.name)
        if no_pw_prof:
            message.append(f'The following local admins are not using a password profile: {", ".join(no_pw_prof)}.')
        if bad_change_period:
            message.append(
                'The following local admins as using a password profile with a Required Password Change Period '
                f'not set to 90 days: {", ".join(bad_change_period)}.'
            )
        if message:
            return BP_Check(202, 'Admin Authentication on Device', 'warn', 'fail', ' '.join(message))
        else:
            return BP_Check(202, 'Admin Authentication on Device', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {'users': [user.json() for user in self.admins]}
        if self.template_name is not None:
            configuration['template_name'] = self.template_name
        bp_check = [
            x._asdict() for x in [self.admin_password_profile_warn, self.admin_auth_on_device_warn]
            if x is not None
        ]
        return {'configuration': configuration, 'bp_check': bp_check}

    @classmethod
    def get_all(cls, xml_config):
        """Get all administrator records, partitioned between template and device.

        This method overrides get_all defined in Base class.

        NOTE: Administrator records are all created at the device / template level.
        """
        template_records, device_records = [], []
        admins = xml_config.collector.get('administrator')
        if xml_config.ngfw:
            device_records.append(cls(admins, xml_config).record)
        else:
            device_admins = [a for a in admins if not hasattr(a, 'template_name')]
            device_records.append(cls(device_admins, xml_config).record)

            for template_name in query.get_template_names(xml_config.tree):
                template_admins = [a for a in admins if getattr(a, 'template_name', None) == template_name]
                if template_admins:
                    template_records.append(cls(template_admins, xml_config, template_name).record)

        return template_records, device_records


class AdminRoles(Base):
    xpath = '//shared'

    def __init__(self, admin_role, panorama=False):
        super(AdminRoles, self).__init__(admin_role, panorama)
        self.custom_admin_roles = admin_role.xpath('admin-role/entry/@name')

    @property
    def custom_admin_roles_note(self):
        if not self.custom_admin_roles:
            return BP_Check(
                154, 'Custom Admin Roles', 'note', '',
                'It is recommended to create and use custom admin roles')

    @property
    def record(self):
        configuration = {'custom_admin_roles': self.custom_admin_roles}
        if hasattr(self, 'template_name'):
            configuration['template_name'] = self.template_name

        return {'configuration': configuration,
                'bp_check': self.get_bp_checks()}
