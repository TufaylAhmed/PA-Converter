# best_practice_assessment

Best Practice checks are located in `bp_checks`

There are several check categories being implemented at the moment:

- `device`
- `monitor`
- `network`
- `objects`
- `policies`

Common utilities exist to assist with retrieving attributes and other concerns.
