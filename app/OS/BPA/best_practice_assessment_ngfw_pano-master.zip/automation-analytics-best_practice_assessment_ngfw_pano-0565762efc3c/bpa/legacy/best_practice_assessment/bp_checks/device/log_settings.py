# -*- coding: utf-8 -*-
"""
Created on Tue Feb 14 13:31:02 2017

@author: nbitting
"""
from ..warn_note import BP_Check
from ..base import Base


class LogSettingsSystem(Base):
    xpath = '//config/shared/log-settings/system | //config/panorama/log-settings/system'

    def __init__(self, entry=None, version=None, template=None, panorama=False):
        default_values = {
            'log_send_to_info': set(),
            'log_send_to_low': set(),
            'log_send_to_medium': set(),
            'log_send_to_high': set(),
            'log_send_to_critical': set(),
            'log_send_to_all': set(),
            'critical_content_logs': set()
        }
        self.__dict__.update(default_values)

        if entry is None:
            self.version = version
            if template is not None:
                self.template_name = template
        else:
            super(LogSettingsSystem, self).__init__(entry, panorama)
            self.version = version if version is not None else int(entry.getroottree().getroot().get('version')[0])

            if self.version < 8:
                for match in entry.getchildren():
                    for child in match.getchildren():
                        if not child.tag.startswith('send'):
                            continue
                        elif child.tag == 'send-to-panorama' and child.text != 'yes':
                            continue
                        else:
                            send_to = child.tag

                        if match.tag == 'informational':
                            self.log_send_to_info.add(send_to)
                        elif match.tag == 'low':
                            self.log_send_to_low.add(send_to)
                        elif match.tag == 'medium':
                            self.log_send_to_medium.add(send_to)
                        elif match.tag == 'high':
                            self.log_send_to_high.add(send_to)
                        elif match.tag == 'critical':
                            self.log_send_to_critical.add(send_to)

            elif self.version >= 8:
                system_log_match_list = entry.xpath('match-list/entry')
                for match in system_log_match_list:
                    for child in match.getchildren():
                        if not child.tag.startswith('send'):
                            continue
                        elif child.tag == 'send-to-panorama' and child.text != 'yes':
                            continue
                        elif (
                                any(child.tag == t for t in ['send-syslog', 'send-snmptrap', 'send-email', 'send-http'])
                                and child.find('member') is None):
                            continue
                        else:
                            send_to = child.tag
                        if '(severity eq critical) and ( (description contains Content) or (description contains content) )' == match.find('filter').text:  # checks for exact text
                            self.critical_content_logs.add(send_to)
                        if '(severity eq informational)' in match.find('filter').text:
                            self.log_send_to_info.add(send_to)
                        if '(severity eq low)' in match.find('filter').text:
                            self.log_send_to_low.add(send_to)
                        if '(severity eq medium)' in match.find('filter').text:
                            self.log_send_to_medium.add(send_to)
                        if '(severity eq high)' in match.find('filter').text:
                            self.log_send_to_high.add(send_to)
                        if '(severity eq critical)' in match.find('filter').text:
                            self.log_send_to_critical.add(send_to)
                        if 'All Logs' in match.find('filter').text:
                            self.log_send_to_all.add(send_to)

    @property
    def log_send_to_info_warn(self):
        if not self.log_send_to_info and not self.log_send_to_all:
            return BP_Check(
                177, 'Log Settings > System > Severity: Informational', 'warn', 'fail',
                'A log setting has not been configured for the severity of "informational".')
        else:
            return BP_Check(
                177, 'Log Settings > System > Severity: Informational', 'warn', 'pass', '')

    @property
    def log_send_to_low_warn(self):
        if not self.log_send_to_low and not self.log_send_to_all:
            return BP_Check(
                178, 'Log Settings > System > Severity: Low', 'warn', 'fail',
                'A log setting has not been configured for the severity of "low".')
        else:
            return BP_Check(
                178, 'Log Settings > System > Severity: Low', 'warn', 'pass', '')

    @property
    def log_send_to_medium_warn(self):
        if not self.log_send_to_medium and not self.log_send_to_all:
            return BP_Check(
                179, 'Log Settings > System > Severity: Medium', 'warn', 'fail',
                'A log setting has not been configured for the severity of "medium".')
        else:
            return BP_Check(
                179, 'Log Settings > System > Severity: Medium', 'warn', 'pass', '')

    @property
    def log_send_to_high_warn(self):
        if not self.log_send_to_high and not self.log_send_to_all:
            return BP_Check(
                180, 'Log Settings > System > Severity: High', 'warn', 'fail',
                'A log setting has not been configured for the severity of "high".')
        else:
            return BP_Check(
                180, 'Log Settings > System > Severity: High', 'warn', 'pass', '')

    @property
    def log_send_to_critical_warn(self):
        if not self.log_send_to_critical and not self.log_send_to_all:
            return BP_Check(
                181, 'Log Settings > System > Severity: Critical', 'warn', 'fail',
                'A log setting has not been configured for the severity of "critical".')
        else:
            return BP_Check(
                181, 'Log Settings > System > Severity: Critical', 'warn', 'pass', '')

    @property
    def log_send_to_critical_content_description_warn(self):
        if self.version >= 8:
            if self.critical_content_logs:
                return BP_Check(
                    222, 'Content based critical system logs', 'warn', 'pass', '')
            else:
                return BP_Check(
                    222, 'Content based critical system logs', 'warn', 'fail',
                    'It is recommended to have a filter with syntax: (severity eq critical) and ( (description contains Content) or (description contains content) )')

    @property
    def record(self):
        bp_check = self.get_bp_checks()

        if self.version < 8:
            delattr(self, 'log_send_to_all')

        configuration = {}
        for attrib in dir(self):
            if (attrib.startswith('log_send_to_') or attrib.startswith('critical')) and not attrib.endswith('_warn'):
                configuration[attrib] = ', '.join(getattr(self, attrib))

        if hasattr(self, 'template_name'):
            configuration['template_name'] = self.template_name
        if hasattr(self, 'vsys'):
            configuration['vsys'] = self.vsys

        return {'configuration': configuration, 'bp_check': bp_check}

    @classmethod
    def get_objects(cls, xml, panorama=False):
        record_lst = []
        version = int(xml.getroot().get('version')[0])
        if panorama:
            panorama_system_settings = xml.find('panorama/log-settings/system')
            if panorama_system_settings is None:
                record_lst.append(cls(version=version, panorama=True))
            else:
                record_lst.append(
                    cls(entry=panorama_system_settings, panorama=True))
            all_templates = xml.findall('devices/entry/template/entry')
            for template in all_templates:
                template_system_settings = template.find(
                    'config/shared/log-settings/system')
                if template_system_settings is not None:
                    record_lst.append(
                        cls(entry=template_system_settings, panorama=True))
                else:
                    record_lst.append(
                        cls(version=version, template=template.get('name'), panorama=True))
        else:
            ngfw_system_settings = xml.find('shared/log-settings/system')
            if ngfw_system_settings is None:
                record_lst.append(cls(version=version))
            else:
                record_lst.append(cls(entry=ngfw_system_settings))

        return record_lst


class LogSettingsConfig(Base):
    xpath = '//config/shared/log-settings/config | //config/panorama/log-settings/config'

    def __init__(self, entry=None, version=None, template=None, panorama=False):
        default_values = {
            'config_logs_all': [],
            'config_logs_custom': []
        }
        self.__dict__.update(default_values)
        if entry is None:
            self.version = version
            if template is not None:
                self.template_name = template
        else:
            super(LogSettingsConfig, self).__init__(entry, panorama)
            self.version = version if version is not None else int(
                entry.getroottree().getroot().get('version')[0])

            if self.version < 8:
                for child in entry.find('any').getchildren():
                    if child.tag == 'send-to-panorama' and child.text == 'yes':
                        send_to = 'send-to-panorama'
                    else:
                        send_to = child.tag

                    if send_to not in self.config_logs_all:
                        self.config_logs_all.append(send_to)

            elif self.version >= 8:
                config_log_match_list = entry.xpath('match-list/entry')

                for match in config_log_match_list:
                    for child in match.getchildren():
                        if child.tag == 'send-to-panorama' and child.text == 'yes':
                            send_to = 'send-to-panorama'
                        elif (child.tag not in ['send-to-panorama', 'filter']
                                and child.find('member') is not None):
                            send_to = child.tag
                        else:
                            send_to = 'None'

                        if match.find('filter').text != 'All Logs':
                            if send_to not in self.config_logs_custom:
                                self.config_logs_custom.append(send_to)
                        elif match.find('filter').text == 'All Logs':
                            if send_to not in self.config_logs_all:
                                self.config_logs_all.append(send_to)

    @property
    def config_log_warn(self):
        if not self.config_logs_all and not self.config_logs_custom:
            return BP_Check(
                182, 'Log Settings > Config', 'warn', 'fail',
                'A log setting has not been configured for the "Config" logs.')
        else:
            return BP_Check(182, 'Log Settings > Config', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {}
        for attrib in dir(self):
            if attrib.startswith(
                    'config_logs_') and not attrib.endswith('_warn'):
                configuration[attrib] = ', '.join(getattr(self, attrib))
                if configuration[attrib] == '':
                    configuration[attrib] = 'None'
        if hasattr(self, 'template_name'):
            configuration['template_name'] = self.template_name

        return {'configuration': configuration,
                'bp_check': [self.config_log_warn._asdict()]}

    @classmethod
    def get_objects(cls, xml, panorama=False):
        record_lst = []
        version = int(xml.getroot().get('version')[0])
        if panorama:
            panorama_config_settings = xml.find('panorama/log-settings/config')
            if panorama_config_settings is None:
                record_lst.append(cls(version=version, panorama=True))
            else:
                record_lst.append(
                    cls(entry=panorama_config_settings, panorama=True))
            all_templates = xml.findall('devices/entry/template/entry')
            for template in all_templates:
                template_config_settings = template.find(
                    'config/shared/log-settings/config')
                if template_config_settings is not None:
                    record_lst.append(
                        cls(entry=template_config_settings, panorama=True))
                else:
                    record_lst.append(
                        cls(version=version, template=template.get('name'), panorama=True))
        else:
            ngfw_config_settings = xml.find('shared/log-settings/config')
            if ngfw_config_settings is None:
                record_lst.append(cls(version=version))
            else:
                record_lst.append(cls(entry=ngfw_config_settings))

        return record_lst
