# -*- coding: utf-8 -*-
"""
Created on Thu Feb 02 09:19:43 2017

@author: anmendoza
"""
import re

from ..warn_note import BP_Check
from ..base import Base


class MatchList(object):
    """Log Forwarding Profile Match List.

    Only applicable for PAN-OS 8.0+
    """

    FILTER_VALS = {
        'traffic': ('informational', 'low', 'medium', 'high', 'critical'),
        'threat': ('informational', 'low', 'medium', 'high', 'critical'),
        'wildfire': ('benign', 'grayware', 'malicious', 'phishing')
    }

    def __init__(self, entry):
        self._entry = entry
        self.syslog = entry.xpath('send-syslog/member/text()')
        self.snmp = entry.xpath('send-snmptrap/member/text()')
        self.http = entry.xpath('send-http/member/text()')
        self.email = entry.xpath('send-email/member/text()')
        self.panorama = entry.findtext('send-to-panorama', 'no') == 'yes'
        self.log_type = entry.findtext('log-type')
        self.filter = entry.findtext('filter')

    def forwarding_valid(self):
        """Check if forwarding configuration is valid.

        For Threat and WildFire, logs need to be forwarded to Panorama + 1 other location.
        Becase Traffic logs may have a lot of data, only require forwarding to one location.
        """
        if self.log_type != 'traffic':
            return self.panorama and any([self.syslog, self.snmp, self.http, self.email])
        else:
            return any([self.panorama, self.syslog, self.snmp, self.http, self.email])

    def parse_filter(self):
        """Logic for parsing filter string."""
        if self.filter == 'All Logs':
            return self.get_match_vals(self.filter)
        matches = [match for match, _ in re.findall(self.regex, self.filter)]
        match_set = set()
        for match in matches:
            match_set.update(self.get_match_vals(match))
        return match_set

    def get_match_vals(self, match):
        """Logic for extracing applicable severity or verdict values from a filter match."""
        if match == 'All Logs':
            return self.filter_vals

        negate = match.startswith('not ')
        attr, op, val = match.strip('not ()').split()
        if op == 'eq':
            return self.process_negate([val], negate)
        elif op == 'neq':
            return self.process_negate([v for v in self.filter_vals if v != val], negate)
        elif op == 'geq':
            return self.process_negate(self.filter_vals[self.filter_vals.index(val):], negate)
        elif op == 'leq':
            return self.process_negate(self.filter_vals[:self.filter_vals.index(val)], negate)
        else:
            raise ValueError(f'Invalid filter operator ({op}) found in match: {match}')

    @property
    def regex(self):
        """Helper for picking the correct regex query."""
        if self.log_type == 'wildfire':
            return r'((not )?\(verdict [a-z]{2,3} [a-z]+\))'
            return r'(not )?\(verdict [a-z]* [a-z]*\)'
        else:
            return r'((not )?\(severity [a-z]{2,3} [a-z]+\))'

    @property
    def filter_vals(self):
        """Helper to get the correct filter values."""
        return self.FILTER_VALS[self.log_type]

    def process_negate(self, vals, negate):
        """Helper method for processing negate match modifier."""
        if not negate:
            return vals
        return set(self.filter_vals) - set(vals)

    def json(self):
        """Helper for creating JSON serializable object."""
        return {key: val for key, val in self.__dict__.items() if not key.startswith('_')}


class Setting(object):
    """Log Forwarding setting.

    Applicable for PAN-OS < 8.0
    """
    TAG_MAP = {
        'alarm': 'threat',
        'traffic': 'traffic',
        'wildfire': 'wildfire',
    }

    def __init__(self, el):
        self._el = el
        self.log_type = self.TAG_MAP[el.tag]
        self.log_levels = {}
        for log_level in el.getchildren():
            self.log_levels[log_level.tag] = self.parse_log_level(log_level)

    def parse_log_level(self, log_level):
        """Parses a given log level element."""
        return {
            'panorama': log_level.findtext('send-to-panorama', 'no') == 'yes',
            'snmp': log_level.findtext('send-snmptrap/*') is not None,
            'email': log_level.findtext('send-email/*') is not None,
            'syslog': log_level.findtext('send-syslog/*') is not None,
        }

    def get_log_level(self, log_level):
        """Get forwarding configuration for a given log level."""
        try:
            target = self.log_levels[log_level]
        except KeyError:
            return {
                'panorama': False,
                'snmp': False,
                'email': False,
                'syslog': False,
            }
        else:
            return target

    def forwarding_valid(self, log_level):
        """Check if forwarding configuration is valid.

        For Threat and WildFire, logs need to be forwarded to Panorama + 1 other location.
        Becase Traffic logs may have a lot of data, only require forwarding to one location.
        """
        target = self.get_log_level(log_level)
        if self.log_type != 'traffic':
            return target['panorama'] and any([target['syslog'], target['snmp'], target['email']])
        else:
            return any([target['panorama'], target['syslog'], target['snmp'], target['email']])

    def json(self):
        """Helper for creating JSON serializable object."""
        return {key: val for key, val in self.__dict__.items() if not key.startswith('_')}


class LogForwardingProfile(Base):
    xpath = '//log-settings/profiles/entry'
    SEVERITIES = ('informational', 'low', 'medium', 'high', 'critical')
    VERDICTS = ('grayware', 'malicious', 'phishing')

    def __init__(self, entry, version, panorama=False):
        super(LogForwardingProfile, self).__init__(entry, panorama)
        self.name = entry.get('name')
        self._version = int(version[0])
        self._entry = entry
        self.settings = self.parse_settings()

    @property
    def verdicts(self):
        """Helper to exclude phishing from verdict options if PAN-OS < 8"""
        if self._version < 8:
            return self.VERDICTS[:-1]
        else:
            return self.VERDICTS

    def parse_settings(self):
        """Parses profile settings differently according to PAN-OS version.

        The XML for Log Forwarding Profile settings changes in PAN-OS 8.0 from predefined settings to match lists.
        """
        if self._version < 8:
            return [Setting(el) for el in self._entry.getchildren() if el.tag in Setting.TAG_MAP.keys()]
        else:
            return [MatchList(entry) for entry in self._entry.findall('match-list/entry')]

    @property
    def traffic_settings_warn(self):
        """Warn if all logs are not forwarded to at least one location."""

        def setting_passing():
            """Passing logic for PAN-OS < 8.0"""
            traffic_settings = next(iter(s for s in self.settings if s.log_type == 'traffic'), None)
            if traffic_settings is None:
                return False
            return traffic_settings.forwarding_valid('any')

        def match_list_passing():
            """Passing logic for PAN-OS 8.0+"""
            severity_collector = set()
            for s in self.settings:
                if s.log_type == 'traffic' and s.forwarding_valid():
                    if s.filter == 'All Logs':
                        return True
                    severity_collector.update(s.parse_filter())
            return set(self.SEVERITIES) == severity_collector

        if self._version < 8:
            passing = setting_passing()
        else:
            passing = match_list_passing()

        if passing:
            return BP_Check(51, 'Traffic Settings', 'warn', 'pass', '')
        else:
            return BP_Check(
                51, 'Traffic Settings', 'warn', 'fail',
                'It is recommended to forward all traffic logs to at least one location.'
            )

    @property
    def threat_settings_warn(self):
        """Fail if all logs are not filtered to Panorama and at least one other location."""

        def setting_passing():
            """Passing logic for PAN-OS < 8.0"""
            threat_settings = next(iter(s for s in self.settings if s.log_type == 'threat'), None)
            if threat_settings is None:
                return False
            return all(threat_settings.forwarding_valid(severity) for severity in self.SEVERITIES)

        def match_list_passing():
            """Passing logic for PAN-OS 8.0+"""
            severity_collector = set()
            for setting in self.settings:
                if setting.log_type == 'threat' and setting.forwarding_valid():
                    if setting.filter == 'All Logs':
                        return True
                    severity_collector.update(setting.parse_filter())
            return set(self.SEVERITIES) == severity_collector

        if self._version < 8:
            passing = setting_passing()
        else:
            passing = match_list_passing()

        if passing:
            return BP_Check(52, 'Threat Settings', 'warn', 'pass', '')
        else:
            return BP_Check(
                52, 'Threat Settings', 'warn', 'fail',
                'It is recommended to forward all threat logs to Panorama and at least one additional location.'
            )

    @property
    def wildfire_settings_warn(self):
        """Fail if grayware, malicious, and (if version >= 8) phishing logs are not filtered to
        Panorama and at least one other location.
        """

        def setting_passing():
            """Passing logic for PAN-OS < 8.0"""
            wildfire_settings = next(iter(s for s in self.settings if s.log_type == 'wildfire'), None)
            if wildfire_settings is None:
                return False
            return all(wildfire_settings.forwarding_valid(verdict) for verdict in self.verdicts)

        def match_list_passing():
            """Passing logic for PAN-OS 8.0+"""
            verdict_collector = set()
            for s in self.settings:
                if s.log_type == 'wildfire' and s.forwarding_valid():
                    if s.filter == 'All Logs':
                        return True
                    verdict_collector.update(s.parse_filter())
            return set(self.verdicts) == verdict_collector

        if self._version < 8:
            passing = setting_passing()
        else:
            passing = match_list_passing()

        if passing:
            return BP_Check(53, 'WildFire Settings', 'warn', 'pass', '')
        else:
            if self._version < 8:
                verdicts = 'grayware and malicious'
            else:
                verdicts = 'grayware, malicious, and phishing'
            return BP_Check(
                53, 'WildFire Settings', 'warn', 'fail',
                f'It is recommended to forward {verdicts} logs to Panorama and at least one additional location.'
            )

    @property
    def record(self):
        configuration = {
            'name': self.name,
            'settings': [s.json() for s in self.settings],
            'vsys': self.vsys
        }
        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}
