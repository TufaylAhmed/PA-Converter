# -*- coding: utf-8 -*-
"""
Created on Thu Feb 09 12:30:22 2017

@author: anmendoza
"""

# https://jira-hq.paloaltonetworks.local/browse/CST-36
from six import iteritems

from ..warn_note import BP_Check
from ..base import Base


class IPSecCryptoProfile(Base):
    xpath = '//config/devices/entry/network/ike/crypto-profiles/ipsec-crypto-profiles/entry'

    def __init__(self, entry, panorama=False):
        super(IPSecCryptoProfile, self).__init__(element=entry, panorama=panorama)

        self.name = entry.get('name')

        try:
            self.protocol = entry.xpath('esp|ah')[0].tag
        except BaseException:
            self.protocol = 'None'
            self.encryption_algorithms = []
            self.authenticaion_algorithms = []
        else:
            self.encryption_algorithms = entry.xpath('%s/encryption/member[text() != "null"]/text()' % self.protocol)
            self.authenticaion_algorithms = entry.xpath('%s/authentication/member[text() != "none"]/text()' % self.protocol)

    @property
    def protocol_warn(self):
        if self.protocol != 'esp':
            return BP_Check(
                82, 'IPSec Crypto Profile Protocol', 'warn', 'fail',
                'Recommended to set protocol to "ESP"')
        else:
            return BP_Check(82, 'IPSec Crypto Profile Protocol', 'warn', 'pass', '')

    @property
    def encryption_algorithms_warn(self):
        bad_encryption_algorithms = [
            algo for algo in self.encryption_algorithms
            if not algo.startswith('aes')
        ]
        if bad_encryption_algorithms:
            return BP_Check(
                83, 'IPSec Crypto Profile Encryption', 'warn', 'fail',
                'Recommended to only use AES for encryption. '
                'Please remove the following: {}'.format(', '.join(bad_encryption_algorithms)))
        else:
            return BP_Check(83, 'IPSec Crypto Profile Encryption', 'warn', 'pass', '')

    @property
    def authenticaion_algorithms_warn(self):
        message = ''
        if not self.authenticaion_algorithms:
            message = 'Recommended to use SHA for authentication.'
        else:
            bad_authenticaion_algorithms = [
                algo for algo in self.authenticaion_algorithms
                if algo not in ['sha256', 'sha384', 'sha512']
            ]
            if bad_authenticaion_algorithms:
                message = (
                    'Recommended to only use SHA256 or higher for authentication. '
                    'Please remove the following: {}'.format(', '.join(bad_authenticaion_algorithms))
                )
        if message:
            return BP_Check(84, 'IPSec Crypto Profile Authentication', 'warn', 'fail', message)
        return BP_Check(84, 'IPSec Crypto Profile Authentication', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {key: val for key, val in iteritems(self.__dict__) if key != 'panorama'}

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}
