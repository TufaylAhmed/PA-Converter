# -*- coding: utf-8 -*-
"""
Created on Tue Feb 07 13:53:10 2017

@author: anmendoza
"""
import os
import itertools
import json
from collections import namedtuple, defaultdict
from typing import List, Dict
from six import iteritems
from lxml import etree

from ...common import bool_attr, str_attr, tag_val
from ..base import Base
from ..warn_note import BP_Check


class SecurityProfile(Base):
    """Generic Security Profile class"""
    xpath = None
    dg_profile_groups = etree.XPath(
        '/config/devices/entry/device-group/entry[@name=$device_group]'
        '/profile-group/entry[*/member[text()=$profile_name]]/@name')

    def __init__(
            self, entry, security_rules_container, dg_descendants=None, panorama=False):
        super(SecurityProfile, self).__init__(entry, panorama)

        self.name = entry.get('name')
        self.entry = entry
        self.set_profile_groups(entry, dg_descendants)
        self.security_allow_rules = self.get_security_allow_rules(
            dg_descendants, security_rules_container)

    def set_profile_groups(self, xml, dg_descendants):
        """Returns the name(s) of the profile group(s) that the profile
        belongs to, otherwise returns an empty list.

        If profile is in shared, it can be included in any profile group.

        If profile is in a device group, it can only be included in profile groups in the current
        device group or a in device group that is a desendant of the current device group.

        If profile is in a vsys, it can only be included in profile groups in the same vsys.

        Args:
            xml: An etree element object
            dg_descendants: dictionary of lists with device group hierarchy
        """
        if self.vsys in ['shared', 'predefined']:
            self.profile_groups = xml.xpath(
                '//profile-group/entry[*/member[text()="{profile_name}"]]/@name'.format(
                    profile_name=self.name)
            )
        else:
            if self.panorama:
                # list comprehension generates a list of lists, so flatten using
                # itertools.chain.from_iterable
                self.profile_groups = list(itertools.chain.from_iterable(
                    [self.dg_profile_groups(xml, device_group=dg, profile_name=self.name) for dg
                     in dg_descendants[self.vsys]]))

            else:  # NGFW
                self.profile_groups = xml.xpath(
                    '/config/devices/entry/vsys/entry[@name="{vsys}"]/profile-group/'
                    'entry[*/member[text()="{profile_name}"]]/@name'.format(
                        vsys=self.vsys,
                        profile_name=self.name)
                )
        self.profile_groups = set(self.profile_groups)

    def get_security_allow_rules(self, dg_descendants, security_rules_container):
        """Returns count of security allow rules using the security profile.
        The rules could be using the security profile directly or through a
        profile group.

        If profile is in shared:
            - Targeted rules are any security allow rules that use the profile or use a profile
            group that the profile belongs to.

        If profile is in a device group:
            - Targeted rules are any security allow rules in the current device group or
            a descendant device group in the hierarchy that use the profile or use a profile
            group that the profile belongs to.

        If profile is in a vsys:
            - Targeted rules are any security allow rules in the current vsys that use
            the profile or use a profile group that the profile belongs to.
        """
        targeted_rule_count = 0
        profile_type = self.xpath.split('/')[-2]

        if self.vsys in ['shared', 'predefined']:
            for vsys in security_rules_container.profile_allow_rules.keys():
                targeted_rule_count += security_rules_container.profile_allow_rules[vsys][profile_type][self.name]

            for vsys in security_rules_container.profile_group_allow_rules.keys():
                for profile_group in self.profile_groups:
                    targeted_rule_count += security_rules_container.profile_group_allow_rules[vsys][profile_group]

        elif self.panorama:  # profile is in a device group
            for dg in dg_descendants[self.vsys]:
                targeted_rule_count += security_rules_container.profile_allow_rules[dg][profile_type][self.name]

                for profile_group in self.profile_groups:
                    targeted_rule_count += security_rules_container.profile_group_allow_rules[dg][profile_group]

        else:  # profile is in a vsys
            targeted_rule_count = security_rules_container.profile_allow_rules[self.vsys][profile_type][self.name]
            for profile_group in self.profile_groups:
                targeted_rule_count += security_rules_container.profile_group_allow_rules[self.vsys][profile_group]

        return targeted_rule_count

    @property
    def valid_profile(self) -> bool:
        """Returns True if no checks fail"""
        return all(check['result'] != 'fail' for check in self.record['bp_check'])

    @property
    def unused_security_profile_note(self):
        if self.security_allow_rules == 0:
            return BP_Check(
                221, 'Unused Security Profile', 'note', '',
                f'{self.name} is not being used by any rules. Check to see if the profile can be removed.'
            )

    def get_bp_checks(self) -> List[Dict]:
        """Returns a list of all best practice warnings and notes contained in the object.
        Assumes that checks end in _warn or _note.

        If there are no security allow rules using the profile, only check #221 will be
        included in the list.
        """
        bp_check = []
        if self.security_allow_rules == 0:
            return [self.unused_security_profile_note._asdict()]
        for name in dir(self):
            if name.endswith('_warn') or name.endswith('_note'):
                check = getattr(self, name)
                if check is not None:
                    bp_check.append(check._asdict())
        return bp_check


class WildFireProfile(SecurityProfile):
    xpath = '//profiles/wildfire-analysis/entry'

    def __init__(self, entry, security_rules_container,
                 dg_descendants=None, panorama=False):
        super(WildFireProfile, self).__init__(entry, security_rules_container,
                                              dg_descendants, panorama)

    @property
    def rules(self):
        """Returns a list of named tuples containing the WildFire profile rules"""
        rules_lst = []
        WildFireProfileRule = namedtuple('WildFireProfileRule',
                                         ['applications', 'file_types', 'direction', 'analysis'])
        for rule in self.entry.findall('rules/entry'):
            applications = [
                app.text for app in rule.findall('application/member')]
            file_types = [
                file_type.text for file_type in rule.findall('file-type/member')]
            direction = rule.findtext('direction', 'both')
            analysis = rule.findtext('analysis', 'public-cloud')
            rules_lst.append(
                WildFireProfileRule(
                    applications,
                    file_types,
                    direction,
                    analysis))
        return rules_lst

    @property
    def rules_warn(self):
        upload, download = False, False

        for rule in self.rules:
            if 'any' in rule.applications and 'any' in rule.file_types:
                if rule.direction == 'both':
                    upload, download = True, True
                elif rule.direction == 'upload':
                    upload = True
                elif rule.direction == 'download':
                    download = True

        if upload and download:
            return BP_Check(47, 'WildFire Profile', 'warn', 'pass', '')
        else:
            return BP_Check(
                47, 'WildFire Profile', 'warn', 'fail',
                'It is recommended to use "any" when configuring applications and file types in the WildFire Profile '
                'rulebase for both directions'
            )

    @property
    def record(self):
        configuration = {
            'name': self.name,
            'vsys': self.vsys,
            'Rules Using Profile': self.security_allow_rules,
            'rules': [rule._asdict() for rule in self.rules]
        }

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}


class URLFilteringProfile(SecurityProfile):
    xpath = '//profiles/url-filtering/entry'
    url_categories = json.load(open(os.path.join(os.path.dirname(__file__), 'url_categories.json')))

    def __init__(self, entry, security_rules_container, dg_descendants=None, urldb='paloaltonetworks', panorama=False):
        super(URLFilteringProfile, self).__init__(entry, security_rules_container, dg_descendants, panorama)
        self.urldb = urldb
        self.url_categories = set(URLFilteringProfile.url_categories[urldb])
        self.log_container_page_only_enabled = entry.findtext('log-container-page-only', 'yes') == 'yes'
        self.version = int(entry.getroottree().getroot().get('version')[0])
        self.site_access_categories = self.parse_category_actions(entry, 'site_access')
        self.set_credential_enforcement(entry)

    def parse_category_actions(self, el, action_type):
        """Parses URL categories by action

        Args:
            el: Parent element of the action nodes
            action_type: Either 'site_access' or 'user_credential_submission'

        Returns: A dictionary where keys are the actions and values are lists of associated URL categories.
        """
        actions = ['alert', 'block', 'continue', 'override']
        non_allow_categories = set()
        container = {}

        # user_credential_submission does not have override as an available action
        if action_type == 'user_credential_submission':
            actions = actions[:-1]

        for action in actions:
            action_categories = el.xpath('{}/member/text()'.format(action))
            non_allow_categories.update(action_categories)
            container[action] = action_categories
        container['allow'] = list(self.url_categories - non_allow_categories)

        return container

    def set_credential_enforcement(self, entry):
        if self.version < 8:
            return

        CredentialEnforcement = namedtuple(
            'CredentialEnforcement', ['mode', 'log_severity', 'categories']
        )

        credential_enforcement_el = entry.find('credential-enforcement')

        # Handle case when credential-enforcement child element is missing
        if credential_enforcement_el is None:
            categories = {'alert': [], 'block': [], 'continue': [], 'allow': list(self.url_categories)}
            self.credential_enforcement = CredentialEnforcement('disabled', 'medium', categories)
            return

        mode = entry.find('credential-enforcement/mode/*').tag
        log_severity = entry.findtext('credential-enforcement/log-severity')
        categories = self.parse_category_actions(entry.find('credential-enforcement'), 'user_credential_submission')

        self.credential_enforcement = CredentialEnforcement(mode, log_severity, categories)

    @property
    def allow_categories_warn(self):
        if self.site_access_categories['allow']:
            return BP_Check(
                196, 'URL Filtering Profile Allow Categories', 'warn', 'fail',
                'It is not recommended to have any URL categories with an action of "allow" '
                'and to instead set action to "alert" at a minimum.'
            )
        else:
            return BP_Check(196, 'URL Filtering Profile Allow Categories', 'warn', 'pass', '')

    @property
    def block_categories_warn(self):
        block_only_categories = {
            'paloaltonetworks': {
                'hacking', 'malware', 'phishing', 'proxy-avoidance-and-anonymizers',
                'command-and-control', 'unknown', 'dynamic-dns', 'extremism', 'copyright-infringement', 'parked'
            },
            'brightcloud': {
                'hacking', 'confirmed-spam-sources', 'unconfirmed-spam-sources', 'keyloggers-and-monitoring',
                'malware-sites', 'spam-urls', 'spyware-and-adware', 'phishing-and-other-frauds',
                'open-http-proxies', 'proxy-avoidance-and-anonymizers', 'cheating', 'gross',
                'violence', 'bot-nets', 'unknown', 'hate-and-racism', 'illegal', 'parked-domains', 'dead-sites'
            }
        }

        missing_block_categories = block_only_categories[self.urldb] - set(self.site_access_categories['block'])
        if missing_block_categories:
            return BP_Check(
                43, 'URL Profile Known Bad Categories', 'warn', 'fail',
                'The following categories should be blocked: {}.'.format(', '.join(missing_block_categories))
            )
        else:
            return BP_Check(43, 'URL Profile Known Bad Categories', 'warn', 'pass', '')

    @property
    def url_profile_settings_warn(self):

        if not self.log_container_page_only_enabled:
            return BP_Check(
                44, 'URL Profile Settings', 'warn', 'fail',
                'The "Log container page only" setting should be enabled.'
            )
        else:
            return BP_Check(44, 'URL Profile Settings', 'warn', 'pass', '')

    @property
    def credential_theft_warn(self):
        if self.version < 8:
            return

        if len(self.url_categories - set(self.site_access_categories['block'])) == 0:
            return BP_Check(
                207, 'Credential Theft', 'warn', 'pass',
                'All URL categories are blocked, so Credential Theft is not necessary.'
            )

        error_lst = []
        if self.credential_enforcement.categories['allow']:
            error_lst.append('No categories should have a User Credential Submission action of "Allow".')
        if self.credential_enforcement.mode == 'disabled':
            error_lst.append('User Credential Detection should be enabled.')
        if self.credential_enforcement.log_severity in ['low', 'informational']:
            error_lst.append('Log Severity should be set to medium, high, or critical.')

        if error_lst:
            return BP_Check(207, 'Credential Theft', 'warn', 'fail', ' '.join(error_lst))
        else:
            return BP_Check(207, 'Credential Theft', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {
            key: val for key, val in iteritems(self.__dict__)
            if key not in ['entry', 'panorama', 'urldb', 'version', 'url_categories', 'profile_groups']
        }

        configuration['Rules Using Profile'] = configuration.pop('security_allow_rules')

        if hasattr(self, 'credential_enforcement'):
            configuration['credential_enforcement'] = self.credential_enforcement._asdict()

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}


class AntivirusProfile(SecurityProfile):
    xpath = '//profiles/virus/entry'

    AV_Decoder = namedtuple('AV_Decoder', ['name', 'action', 'wildfire_action'])

    def __init__(self, entry, security_rules_container, dg_descendants=None, panorama=False):
        super(AntivirusProfile, self).__init__(entry, security_rules_container, dg_descendants, panorama)
        self.packet_capture_enabled = bool_attr(entry, 'packet-capture/text()')
        self.threat_exceptions = entry.xpath('threat-exception/entry/@name')
        self.application_exceptions = entry.xpath('application/entry/@name')
        self.entry = entry

    @property
    def decoders(self):
        defaults = {
            'ftp': 'reset-both',
            'http': 'reset-both',
            'imap': 'alert',
            'pop3': 'alert',
            'smb': 'reset-both',
            'smtp': 'alert'
        }

        decoder_lst = []
        for decoder_name, default_action in iteritems(defaults):
            decoder_element = self.entry.find('decoder/entry[@name="{}"]'.format(decoder_name))
            if decoder_element is not None:
                kwargs = {'name': decoder_name}
                for action_type in ['action', 'wildfire-action']:
                    try:
                        action_value = decoder_element.find(action_type).text
                    except AttributeError:
                        if action_type == 'wildfire-action':
                            action_value = 'allow'
                        else:
                            action_value = default_action
                    else:
                        if action_value == 'default':
                            action_value = default_action
                    finally:
                        kwargs.update({action_type.replace('-', '_'): action_value})
                decoder_lst.append(
                    self.AV_Decoder(**kwargs))

        return decoder_lst

    @property
    def threat_exceptions_warn(self):
        if self.threat_exceptions:
            return BP_Check(
                31, 'Antivirus Profile Threat Exceptions', 'note', 'warning',
                'Ensure you need threat exceptions. If there is a false positive, '
                'please open a support case with TAC to fix the issue.'
            )

    @property
    def application_exceptions_warn(self):
        if self.application_exceptions:
            return BP_Check(
                32, 'Antivirus Profile Application Exceptions', 'note', 'warning',
                'Ensure you need application exceptions. If there is a false positive, '
                'please open a support case with TAC to fix the issue.'
            )

    @property
    def decoders_action_warn(self):
        passing_actions = ['drop', 'reset-both', 'reset-client', 'reset-server']
        bad_decoders = [
            decoder.name for decoder in self.decoders
            if decoder.name not in ('imap', 'pop3')
            and decoder.action not in passing_actions
        ]

        if bad_decoders:
            passing_actions[-1] = 'or ' + passing_actions[-1]
            message = """
                The following decoder actions should be set to either {passing_actions}: {bad_decoders}
            """.format(passing_actions=', '.join(passing_actions), bad_decoders=', '.join(bad_decoders))

            return BP_Check(33, 'Antivirus Profile Decoder Actions', 'warn', 'fail', message)
        else:
            return BP_Check(33, 'Antivirus Profile Decoder Actions', 'warn', 'pass', '')

    @property
    def decoders_wildfire_action_warn(self):
        passing_actions = ['drop', 'reset-both', 'reset-client', 'reset-server']
        bad_decoders = [
            decoder.name for decoder in self.decoders
            if decoder.name not in ('imap', 'pop3')
            and decoder.wildfire_action not in passing_actions
        ]

        if bad_decoders:
            passing_actions[-1] = 'or ' + passing_actions[-1]
            message = """
                The following decoder WildFire actions should be set to either {passing_actions}: {bad_decoders}
            """.format(passing_actions=', '.join(passing_actions), bad_decoders=', '.join(bad_decoders))

            return BP_Check(34, 'Antivirus Profile Decoder WildFire Actions', 'warn', 'fail', message)
        else:
            return BP_Check(34, 'Antivirus Profile Decoder WildFire Actions', 'warn', 'pass', '')

    @property
    def packet_capture_warn(self):
        if self.packet_capture_enabled:
            return BP_Check(
                35, 'Antivirus Profile Packet Capture', 'warn', 'fail',
                'It is not recommended to have Packet Capture enabled. If this is a requirement, '
                'ensure there is sufficient log quota.'
            )
        else:
            return BP_Check(
                35, 'Antivirus Profile Packet Capture', 'warn', 'pass', '')

    @property
    def reset_action_note(self):
        if any(decoder for decoder in self.decoders if decoder.action in {'reset-client', 'reset-server'}):
            return BP_Check(
                206, 'Reset-Client / Reset-Server Actions', 'note', '',
                'It is recommended to only use "reset-client" or "reset-server" actions '
                'if there is a specific business case.'
            )

    @property
    def record(self):
        configuration = {
            'name': self.name,
            'vsys': self.vsys,
            'packet_capture_enabled': self.packet_capture_enabled,
            'threat_exceptions': self.threat_exceptions,
            'application_exceptions': self.application_exceptions,
            'Rules Using Profile': self.security_allow_rules,
            'decoders': [decoder._asdict() for decoder in self.decoders]
        }

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}


def get_threat_exceptions(entry):
    """Threat exceptions exist in mutiple security profile types (AV, AS, vuln, etc)."""
    exceptions = []
    for exception in entry.findall('threat-exception/entry'):
        exceptions.append(
            {'name': exception.get('name'), 'packet_capture': exception.findtext('packet-capture', 'disable')}
        )
    return exceptions


class AntiSpywareProfile(SecurityProfile):
    xpath = '//profiles/spyware/entry'

    AntiSpyware_Rule = namedtuple('AntiSpyware_Rule', ['name', 'severity', 'action', 'category', 'packet_capture'])

    def __init__(self, entry, security_rules_container, dg_descendants=None, panorama=False):
        super(AntiSpywareProfile, self).__init__(entry, security_rules_container, dg_descendants, panorama)
        self._version = int(entry.getroottree().getroot().get('version')[0])
        self.spyware_threat_exceptions = get_threat_exceptions(entry)
        self.botnet_threat_exceptions = entry.xpath('botnet-domains/threat-exception/entry/@name')
        self.dns_signature_packet_capture = entry.findtext('botnet-domains/packet-capture', 'disable')
        if self._version < 8:
            # Passive DNS Monitoring moves to Device Setup > Telemetry Settings in PAN OS 8.0
            self.passive_dns_monitoring_enabled = bool_attr(entry, 'botnet-domains/passive-dns/text()')
        else:
            # Sinkhole IPv4 added in PAN-OS 8.0
            self.sinkhole_ipv4 = entry.findtext('botnet-domains/sinkhole/ipv4-address')
        self._entry = entry
        self.edl_domains = self.get_edl_domains()

    def get_edl_domains(self):
        domains = []
        for entry in self._entry.findall('botnet-domains/lists/entry'):
            name = entry.get('name')
            action = entry.find('action/*').tag
            domains.append({'name': name, 'action': action})
        return domains

    @property
    def rules(self):
        rule_lst = []

        for rule in self._entry.findall('rules/entry'):
            name = rule.get('name')
            severity = rule.xpath('severity/member/text()')
            action = tag_val(rule, 'action/*', 'None')
            category = rule.findtext('category')
            packet_capture = rule.findtext('packet-capture')
            rule_lst.append(
                self.AntiSpyware_Rule(name, severity, action, category, packet_capture)
            )

        return rule_lst

    @property
    def spyware_threat_exceptions_warn(self):
        if self.spyware_threat_exceptions:
            return BP_Check(
                36, 'Anti-Spyware Profile Threat Exceptions', 'note', 'warning',
                'Ensure you need threat exceptions. If there is a false positive, '
                'please open a support case with TAC to fix the issue.'
            )

    @property
    def botnet_threat_exceptions_warn(self):
        if self.botnet_threat_exceptions:
            return BP_Check(
                37, 'Botnet Configuration', 'note', 'warning',
                'Ensure you need threat exceptions for DNS Signatures. If there is a false positive, '
                'please open a support case with TAC to fix the issue.'
            )

    @property
    def dns_sinkhole_enabled_warn(self):
        message = []
        bad_rules = [rule.name for rule in self.rules if rule.packet_capture == 'disable']
        if bad_rules:
            message.append(f'The following rules have Packet Capture disabled: {", ".join(bad_rules)}.')
        bad_edls = [d['name'] for d in self.edl_domains if d['action'] != 'sinkhole']
        if bad_edls:
            message.append(f'The following EDL Domains have an action other than "sinkhole": {", ".join(bad_edls)}.')
        if self.dns_signature_packet_capture == 'disable':
            message.append('The DNS Signature Packet Capture is set to "disable".')
        if getattr(self, 'sinkhole_ipv4', None) == '127.0.0.1':
            message.append('Sinkhole IPv4 is set to Loopback IP.')

        if message:
            return BP_Check(38, 'Anti-Spyware Profile Checks', 'warn', 'fail', ' '.join(message))
        else:
            return BP_Check(38, 'Anti-Spyware Profile Checks', 'warn', 'pass', '')

    @property
    def passive_dns_monitoring_enabled_warn(self):
        if hasattr(self, 'passive_dns_monitoring_enabled'):
            if not self.passive_dns_monitoring_enabled:
                return BP_Check(
                    39, 'Passive DNS Monitoring', 'warn', 'fail',
                    'It is recommended to have Passive DNS Monitoring enabled.')
            else:
                return BP_Check(
                    39, 'Passive DNS Monitoring', 'warn', 'pass', '')

    @property
    def strict_profile_warn(self):
        """Checks profile rules to see if critical, high, and medium severities have a "passing" action.
        Also checks that all threat exceptions are single-packet or extended-capture.
        """
        missing_rules = []
        passing_actions = ['drop', 'reset-both', 'reset-client', 'reset-server', 'block-ip']
        for severity in ['critical', 'high', 'medium']:
            if not any(
                    rule for rule in self.rules
                    if rule.action in passing_actions
                    and rule.category == 'any'
                    and (severity in rule.severity or 'any' in rule.severity)):
                missing_rules.append(severity)

        if missing_rules:
            passing_actions = [f"'{x}'" for x in passing_actions]
            passing_actions[-1] = 'or ' + passing_actions[-1]
            missing_rules = [f"'{x}'" for x in missing_rules]
            message = (
                "It is recommended to add the following rule severities "
                "with either a {passing_actions} action and 'any' category: {missing_rules}"
            ).format(passing_actions=', '.join(passing_actions), missing_rules=', '.join(missing_rules))

            return BP_Check(40, 'Anti-Spyware Strict Profile', 'warn', 'fail', message)
        else:
            return BP_Check(40, 'Anti-Spyware Strict Profile', 'warn', 'pass', '')

    @property
    def low_info_profile_warn(self):
        """Checks profile rules to see if there is a reset-both action on
        informational and low severities.

        Since the action is default, DO NOT consider rules with 'any' severity
        configured as passing.

        NOTE: Recommended action is 'default', but any of the passing actions below are acceptable.
        """
        passing_actions = ['default', 'drop', 'reset-both', 'reset-client', 'reset-server', 'block-ip']
        missing_rules = []
        for severity in ['informational', 'low']:
            if not any(
                    rule for rule in self.rules
                    if rule.action in passing_actions
                    and rule.category == 'any'
                    and severity in rule.severity):
                missing_rules.append(severity)

        if missing_rules:
            if len(missing_rules) == 1:
                severities = missing_rules[0] + ' severity has'
            else:
                severities = ' and '.join(missing_rules) + ' severities have'

            message = ('It is recommended that {} the action set to \'default\' for \'any\' category').format(severities)
            return BP_Check(201, 'Anti-Spyware Low/Informational Profile', 'warn', 'fail', message)
        else:
            return BP_Check(
                201, 'Anti-Spyware Low/Informational Profile', 'warn', 'pass', '')

    @property
    def reset_action_note(self):
        if any(rule for rule in self.rules if rule.action in {'reset-client', 'reset-server'}):
            return BP_Check(
                206, 'Reset-Client / Reset-Server Actions', 'note', '',
                'It is recommended to only use "reset-client" or "reset-server" actions '
                'if there is a specific business case.'
            )

    @property
    def record(self):
        configuration = {
            key: val for key, val in iteritems(self.__dict__)
            if key not in ['entry', 'panorama', 'rules', 'profile_groups'] and not key.startswith('_')
        }
        configuration['rules'] = [rule._asdict() for rule in self.rules]
        configuration['Rules Using Profile'] = configuration.pop('security_allow_rules')

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}


class VulnerabilityProtectionProfile(SecurityProfile):
    xpath = '//profiles/vulnerability/entry'

    Vulnerability_Protection_Rule = namedtuple(
        'Vulnerability_Protection_Rule',
        ['name', 'action', 'host_type', 'severities', 'cve', 'category', 'vendor_id', 'packet_capture', 'threat_name']
    )

    def __init__(self, entry, security_rules_container, dg_descendants=None, panorama=False):
        super(VulnerabilityProtectionProfile, self).__init__(entry, security_rules_container, dg_descendants, panorama)
        self.threat_exceptions = get_threat_exceptions(entry)
        self.profile_type = 'Vulnerability Protection Profile'

    @property
    def rules(self):
        rule_lst = []

        for rule in self.entry.findall('rules/entry'):
            name = rule.get('name')
            action = tag_val(rule, 'action/*', 'None')
            host_type = rule.findtext('host')
            severities = rule.xpath('severity/member/text()')
            cve = rule.xpath('cve/member/text()')
            category = rule.findtext('category')
            vendor_id = rule.xpath('vendor-id/member/text()')
            packet_capture = rule.findtext('packet-capture', 'disable')
            threat_name = rule.findtext('threat-name')

            rule_lst.append(
                self.Vulnerability_Protection_Rule(
                    name, action, host_type, severities, cve, category, vendor_id, packet_capture, threat_name
                )
            )

        return rule_lst

    @property
    def threat_exceptions_warn(self):
        if self.threat_exceptions:
            return BP_Check(
                41, 'Vulnerability Protection Profile Threat Exceptions', 'note', 'warning',
                'Ensure you need threat exceptions. If there is a false positive, '
                'please open a support case with TAC to fix the issue.'
            )

    @property
    def strict_profile_warn(self):
        """Checks profile rules to see if there is a "passing" action on
        critical, high, and medium severities for client and server host types.
        """
        passing_actions = ['drop', 'reset-both', 'reset-client', 'reset-server', 'block-ip']
        missing_rules = []

        for host_type in ['client', 'server']:
            for severity in ['critical', 'high', 'medium']:
                if not any(
                        rule for rule in self.rules
                        if rule.action in passing_actions
                        and rule.category == 'any'
                        and rule.cve[0] == 'any'
                        and rule.vendor_id[0] == 'any'
                        and rule.host_type in ['any', host_type]
                        and (severity in rule.severities or 'any' in rule.severities)
                        and rule.packet_capture in ['single-packet', 'extended-capture']):
                    missing_rules.append('{}/{}'.format(host_type, severity))

        if missing_rules:
            passing_actions[-1] = 'or ' + passing_actions[-1]
            message = (
                'It is recommended to add the following rule host '
                'type/severity combinations with either a {passing_actions} action, "any" category, '
                '"any" CVE signature, "any" Vendor ID, and Packet Capture enabled: {missing_rules}'
            ).format(passing_actions=', '.join(passing_actions), missing_rules=', '.join(missing_rules))

            return BP_Check(42, 'Vulnerability Protection Strict Profile', 'warn', 'fail', message)
        else:
            return BP_Check(42, 'Vulnerability Protection Strict Profile', 'warn', 'pass', '')

    @property
    def low_info_profile_warn(self):
        """Checks profile rules to see if there is a default action on
        informational and low severities for client and server host types.

        Since the action is default, DO NOT consider rules with 'any' severity
        configured as passing.

        NOTE: The recommended action is "default", but any of the passing actions below
        are also acceptable.
        """
        missing_rules = []
        using_extended_capture = False
        passing_actions = ['default', 'drop', 'reset-both', 'reset-client', 'reset-server', 'block-ip']

        for host_type in ['client', 'server']:
            for severity in ['informational', 'low']:
                for rule in self.rules:
                    if (
                            rule.action in passing_actions and
                            rule.threat_name == 'any' and
                            rule.packet_capture in ['single-packet', 'extended-capture'] and
                            rule.host_type in ['any', host_type] and
                            severity in rule.severities):
                        if rule.packet_capture == 'extended-capture':
                            using_extended_capture = True
                        break
                else:
                    # no rules matching criteria
                    missing_rules.append('{}/{}'.format(host_type, severity))

        if missing_rules:
            message = (
                'It is recommended to add the following rule host type/severity combinations '
                'with a "default" action, "any" threat name, and Packet Capture enabled: {}'
            ).format(', '.join(missing_rules))
            return BP_Check(200, 'Vulnerability Protection Low/Informational Profile', 'warn', 'fail', message)
        else:
            if using_extended_capture:
                message = 'Verify whether Extended Packet Capture is needed for the Threat IDs (Single Packet is sufficient)'
            else:
                message = ''
            return BP_Check(200, 'Vulnerability Protection Low/Informational Profile', 'warn', 'pass', message)

    @property
    def reset_action_note(self):
        if any(rule for rule in self.rules if rule.action in {'reset-client', 'reset-server'}):
            return BP_Check(
                206, 'Reset-Client / Reset-Server Actions', 'note', '',
                'It is recommended to only use "reset-client" or "reset-server" actions '
                'if there is a specific business case.'
            )

    @property
    def record(self):
        configuration = {
            'name': self.name,
            'vsys': self.vsys,
            'threat_exceptions': self.threat_exceptions,
            'Rules Using Profile': self.security_allow_rules,
            'rules': [rule._asdict() for rule in self.rules]
        }

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}


class FileBlockingProfile(SecurityProfile):
    xpath = '//profiles/file-blocking/entry'

    File_Blocking_Rule = namedtuple(
        'File_Blocking_Rule', ['applications',
                               'file_types', 'direction', 'action']
    )

    def __init__(
            self, entry, security_rules_container, dg_descendants=None, panorama=False):
        super(FileBlockingProfile, self).__init__(entry, security_rules_container,
                                                  dg_descendants, panorama)

        self.profile_type = 'File Blocking Profile'

    @property
    def rules(self):
        rule_lst = []
        for rule in self.entry.findall('rules/entry'):
            applications = rule.xpath('application/member/text()')
            file_types = rule.xpath('file-type/member/text()')
            direction = str_attr(rule, 'direction', 'None')
            action = str_attr(rule, 'action', 'None')
            rule_lst.append(
                self.File_Blocking_Rule(
                    applications,
                    file_types,
                    direction,
                    action))
        return rule_lst

    @property
    def alert_file_types_warn(self):
        strict_file_types = {
            '7z', 'bat', 'cab', 'chm', 'class', 'cpl', 'dll', 'exe', 'flash', 'hlp', 'hta', 'msi',
            'Multi-Level-Encoding', 'ocx', 'PE', 'pif', 'rar', 'scr', 'tar', 'torrent', 'vbe', 'wsf',
            'encrypted-rar', 'encrypted-zip'
        }
        correct_alert_rule = False
        message = []

        for rule in self.rules:
            if rule.direction == 'both' and 'any' in rule.applications:
                if rule.action == 'alert' and 'any' in rule.file_types:
                    correct_alert_rule = True
                elif rule.action == 'block':
                    strict_file_types -= set(rule.file_types)
                elif rule.action == 'continue':
                    # encrypted-rar and encrypted-zip can receive credit if action is continue
                    strict_file_types -= {ft for ft in rule.file_types if ft in {'encrypted-rar', 'encrypted-zip'}}

        if not correct_alert_rule:
            message.append(
                'It is recommended to have a rule in your File Blocking Profile that meets the '
                'following criteria: Applications=any, File Types=any, Direction=both, '
                'Action=alert.'
            )
        if strict_file_types:
            block_msg = (
                'It is recommended to add a rule to your File Blocking Profile that meets the '
                'following criteria: Applications=any, File Types={}, Direction=both, '
                'Action=block.'
            ).format(', '.join(strict_file_types))
            message.append(block_msg)

        if message:
            return BP_Check(
                45, 'File Blocking Strict Profile', 'warn', 'fail', ' '.join(message))
        else:
            return BP_Check(
                45, 'File Blocking Strict Profile', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {
            'name': self.name,
            'vsys': self.vsys,
            'Rules Using Profile': self.security_allow_rules,
            'rules': [rule._asdict() for rule in self.rules]
        }

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}


class SecurityProfiles(object):
    """Container class for all security profiles"""
    PROFILE_TYPES = {
        'wildfire_profiles': 'WildFire Profiles',
        'url_filtering_profiles': 'URL Filtering Profiles',
        'antivirus_profiles': 'Antivirus Profiles',
        'antispyware_profiles': 'Anti-Spyware Profiles',
        'vuln_protection_profiles': 'Vulnerability Protection Profiles',
        'file_blocking_profiles': 'File Blocking Profiles'
    }
    DISPLAY_ORDER = (
        'Profile Name',
        'Aligns to Best Practice',
        'Rules Using Profile')

    def __init__(self, xml, urldb, dg_descendants, security_rules_container, panorama=False):
        self.wildfire_profiles = WildFireProfile.get_objects(
            xml=xml, dg_descendants=dg_descendants,
            security_rules_container=security_rules_container, panorama=panorama)

        self.url_filtering_profiles = URLFilteringProfile.get_objects(
            xml=xml, dg_descendants=dg_descendants,
            security_rules_container=security_rules_container,
            panorama=panorama, urldb=urldb)

        self.antivirus_profiles = AntivirusProfile.get_objects(
            xml=xml, dg_descendants=dg_descendants,
            security_rules_container=security_rules_container, panorama=panorama)

        self.antispyware_profiles = AntiSpywareProfile.get_objects(
            xml=xml, dg_descendants=dg_descendants,
            security_rules_container=security_rules_container, panorama=panorama)

        self.vuln_protection_profiles = VulnerabilityProtectionProfile.get_objects(
            xml=xml, dg_descendants=dg_descendants,
            security_rules_container=security_rules_container, panorama=panorama)

        self.file_blocking_profiles = FileBlockingProfile.get_objects(
            xml=xml, dg_descendants=dg_descendants,
            security_rules_container=security_rules_container, panorama=panorama)

        self.best_practice_profile_usage = self.get_best_practice_profile_usage(panorama)

    def get_valid_profile_names(self, profile_type):
        """Returns a list of valid profile names of a given type"""
        valid_profile_names = {'default', 'strict'}
        for profile in getattr(self, profile_type):
            if profile.valid_profile:
                valid_profile_names.add(profile.name)
        return valid_profile_names

    @property
    def valid_profiles(self):
        """Returns a dictionary where key is the profile type and valid is a list of
        valid profile names.
        """
        valid_profiles_dict = {}
        for profile_type in self.PROFILE_TYPES.keys():
            valid_profiles_dict[profile_type] = self.get_valid_profile_names(profile_type)
        return valid_profiles_dict

    def get_profile_records(self, profile_type: str) -> List[Dict]:
        """Returns a list of records for a given profile type sorted in
        descending order by count of rules using profile.

        Only includes predefined profiles if they have been used by a rule.
        """
        records = []
        profiles = getattr(self, profile_type)
        for profile in profiles:
            record = profile.record
            if record['configuration']['vsys'] != 'predefined' or record['configuration']['Rules Using Profile'] >= 1:
                records.append(record)
        return sorted(records, key=lambda r: r['configuration']['Rules Using Profile'], reverse=True)

    def get_best_practice_profile_usage(self, panorama):
        """Returns a dictionary where keys are profile types and values are lists of
            dictionary records for best practice profile usage.
        """
        usage_dict = defaultdict(list)
        platform = 'Device Group' if panorama else 'Vsys'
        self.DISPLAY_ORDER = list(self.DISPLAY_ORDER)
        self.DISPLAY_ORDER.insert(1, platform)
        for profile_type in self.PROFILE_TYPES.keys():
            for profile in getattr(self, profile_type):
                usage_dict[profile_type].append(
                    {'Profile Name': profile.name,
                     platform: profile.vsys,
                     'Aligns to Best Practice': profile.valid_profile,
                     'Rules Using Profile': profile.security_allow_rules
                     }
                )
        return usage_dict


class FloodProtection(object):
    """DOS Protection Profile > FloodProtection tab and its sub-tabs."""
    FIELDS = (
        ('tcp-syn', 'SYN'),
        ('udp', 'UDP'),
        ('icmp', 'ICMP'),
        ('icmpv6', 'ICMPv6'),
        ('other-ip', 'Other IP'),
    )

    def __init__(self, el):
        if el is None:
            el = etree.fromstring('<flood></flood>')
        assert el.tag == 'flood'
        self.tabs = self.parse_tabs(el)

    def parse_tabs(self, el):
        """Returns parsed sub-tabs as a list of dictionaries."""
        tabs = []
        for tab_xpath, tab_name in self.FIELDS:
            # use * since the node tag changes depending on the action
            tab = {
                'type': tab_name,
                'alarm': int(el.findtext('{}/*/alarm-rate'.format(tab_xpath), 10000)),
                'activate': int(el.findtext('{}/*/activate-rate'.format(tab_xpath), 10000)),
                'maximal': int(el.findtext('{}/*/maximal-rate'.format(tab_xpath), 40000)),
                'block_duration': int(el.findtext('{}/*/block/duration'.format(tab_xpath), 300)),
                'enabled': el.findtext('{}/enable'.format(tab_xpath), 'no') == 'yes',
            }
            tabs.append(tab)
        return tabs


class DOSProtectionProfile(Base):
    xpath = '//profiles/dos-protection/entry'

    display_dict = {
        'tcp_syn': 'SYN',
        'udp': 'UDP',
        'icmp': 'ICMP',
        'icmpv6': 'ICMPv6',
        'other_ip': 'Other IP'
    }

    def __init__(self, entry, panorama=False):
        super(DOSProtectionProfile, self).__init__(entry, panorama)
        self.name = entry.get('name')
        self.type = entry.findtext('type')
        self.entry = entry
        self.flood_protection = FloodProtection(entry.find('flood'))

    @property
    def flood_protection_enabled_warn(self):
        disabled_tabs = [tab['type'] for tab in self.flood_protection.tabs if not tab['enabled']]
        if disabled_tabs:
            return BP_Check(
                49, 'DOS Protection Profile Flood Protection Enabled', 'warn', 'fail',
                'Please enable the following Flood Types: {}'.format(', '.join(disabled_tabs))
            )
        else:
            return BP_Check(49, 'DOS Protection Profile Flood Protection Enabled', 'warn', 'pass', '')

    @property
    def flood_protection_default_values_note(self):
        message = []
        bad_rates = []
        bad_block_duration = []
        default_vals = {'alarm': 10000, 'activate': 10000, 'maximal': 40000}
        for tab in self.flood_protection.tabs:
            if any(tab[val] == default_vals[val] for val in ['alarm', 'activate', 'maximal']):
                bad_rates.append(tab['type'])
            if tab['block_duration'] != 300:
                bad_block_duration.append(tab['type'])

        if bad_rates:
            msg = (
                'Change the following Flood Type(s) to non-default '
                'Alarm(10000) / Activate(10000) / Max(40000) Rates: {}.'
            ).format(', '.join(bad_rates))
            message.append(msg)
        if bad_block_duration:
            msg = 'Change the following Flood Type(s) so the Block Duration is 300.'
            message.append(msg)

        if message:
            return BP_Check(
                50, 'DOS Protection Profile Flood Protection Default Values', 'note', 'warning', ' '.join(message)
            )

    @property
    def record(self):
        configuration = {
            'name': self.name,
            'type': self.type,
            'vsys': self.vsys,
            'flood_protection': self.flood_protection.__dict__
        }

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}
