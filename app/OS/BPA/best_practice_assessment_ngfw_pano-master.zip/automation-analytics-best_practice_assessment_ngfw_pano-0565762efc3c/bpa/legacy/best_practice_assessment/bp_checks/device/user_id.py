# -*- coding: utf-8 -*-
"""
Created on Mon Feb 13 10:53:54 2017

@author: anmendoza
"""
# https://jira-hq.paloaltonetworks.local/browse/CST-27

from collections import namedtuple
from six import iteritems

from ...common import tag_val
from ..warn_note import BP_Check
from ..base import Base


class UserID(Base):
    """ Start with all vsys entries that have a user-id-collector node
    """
    xpath = '//config/devices/entry/vsys/entry[child::user-id-collector]'

    def __init__(self, entry, panorama=False):
        super(UserID, self).__init__(entry, panorama)
        self.vsys = entry.get('name')
        self.entry = entry
        collector = entry.find('user-id-collector')
        self.include_networks = collector.xpath('include-exclude-network/entry[child::discovery[text()="include"]]/@name')
        self.server_log_monitor_frequency = int(collector.findtext('setting/security-log-interval', 2))
        self.probing_enabled = collector.findtext('setting/enable-probing') == 'yes'
        self.user_id_timeout_enabled = collector.findtext('setting/enable-mapping-timeout', 'yes') == 'yes'
        self.user_id_timeout = int(collector.findtext('setting/ip-user-mapping-timeout', 45))
        self.server_monitors = collector.xpath('server-monitor/entry/@name')

    @property
    def group_mappings(self):
        Group_Mapping = namedtuple('Group_Mapping', ['name', 'enabled', 'included_groups_used'])
        group_mapping_lst = []

        for group_mapping_entry in self.entry.findall('group-mapping/entry'):
            name = group_mapping_entry.get('name')
            enabled = group_mapping_entry.findtext('disabled') != 'yes'
            included_groups_used = group_mapping_entry.find('group-include-list/member') is not None

            group_mapping_lst.append(
                Group_Mapping(name, enabled, included_groups_used)
            )

        return group_mapping_lst

    @property
    def captive_portal_settings(self):
        """ Only process captive portal settings if captive-portal node exists"""
        if self.entry.find('captive-portal') is None:
            return None
        Captive_Portal_Settings = namedtuple(
            'Captive_Portal_Settings',
            [
                'enabled',
                'mode',
                'session_cookie_enabled',
                'session_cookie_timeout',
                'ssl_tls_service_profile',
                'ssl_tls_service_profile_min_version',
                'auth_profile',
                'cert_profile'
            ]
        )
        enabled = self.entry.findtext('captive-portal/enable-captive-portal', 'yes') == 'yes'
        mode = tag_val(self.entry, 'captive-portal/mode/*', 'None')
        mode_path = 'captive-portal/mode/{}/session-cookie'.format(mode)
        session_cookie_enabled = self.entry.findtext(f'{mode_path}/enable', 'yes') == 'yes'
        session_cookie_timeout = int(self.entry.findtext(f'{mode_path}/timeout', 1440))
        ssl_tls_service_profile = self.entry.findtext('captive-portal/ssl-tls-service-profile', 'None')
        if ssl_tls_service_profile == 'None':
            ssl_tls_service_profile_min_version = 'N/A'
        else:
            min_version_xpath = '/config/shared/ssl-tls-service-profile/entry[@name="{}"]/protocol-settings/min-version/text()'
            min_version_el = self.entry.xpath(
                min_version_xpath.format(ssl_tls_service_profile))
            if not min_version_el:
                ssl_tls_service_profile_min_version = 'tls1-0'
            else:
                ssl_tls_service_profile_min_version = min_version_el[0]

        auth_profile = self.entry.findtext('captive-portal/authentication-profile', 'None')
        cert_profile = self.entry.findtext('captive-portal/certificate-profile', 'None')

        return Captive_Portal_Settings(
            enabled,
            mode,
            session_cookie_enabled,
            session_cookie_timeout,
            ssl_tls_service_profile,
            ssl_tls_service_profile_min_version,
            auth_profile,
            cert_profile
        )

    @property
    def included_networks_warn(self):
        if not self.include_networks:
            return BP_Check(
                161, 'Included Networks', 'warn', 'fail',
                'It is recommended to have at least one Include Network defined'
            )
        else:
            return BP_Check(
                161, 'Included Networks', 'warn', 'pass',
                'It is recommended to use a dedicated server account for user ID with minimal permissions necessary'
            )

    @property
    def user_id_note(self):
        return BP_Check(
            176, 'Dedicated Server Account', 'note', '',
            'Use a dedicated server account for user ID with minimal permissions necessary'
        )

    @property
    def server_log_monitor_frequency_warn(self):
        if not (2 <= self.server_log_monitor_frequency <= 30):
            return BP_Check(
                163, 'Server Log Monitor Frequency', 'warn', 'fail',
                'Server Log Monitor Frequency should be set to a value between 2 and 30 seconds'
            )
        else:
            return BP_Check(163, 'Server Log Monitor Frequency', 'warn', 'pass', '')

    @property
    def probing_enabled_warn(self):
        if self.probing_enabled:
            return BP_Check(164, 'User ID Probing', 'warn', 'fail', 'It is not recommended to enable probing')
        else:
            return BP_Check(164, 'User ID Probing', 'warn', 'pass', '')

    @property
    def user_id_timeout_enabled_warn(self):
        if not self.user_id_timeout_enabled:
            return BP_Check(
                165, 'User ID Timeout Enabled', 'warn', 'fail',
                'It is not recommended to disable User ID Timeout'
            )
        else:
            return BP_Check(165, 'User ID Timeout Enabled', 'warn', 'pass', '')

    @property
    def user_id_timeout_warn(self):
        if self.user_id_timeout < 60:
            return BP_Check(
                166, 'User ID Timeout', 'note', 'warning',
                'It is recommended to set User ID Timeout to a value greater than 60 minutes'
            )

    @property
    def user_id_timeout_note(self):
        if self.user_id_timeout_enabled:
            return BP_Check(
                210, 'User ID Timeout Value', 'note', '',
                'User ID Timeout should be set to the half-life of DHCP or the Kerberos ticket lifetime.'
            )

    @property
    def server_monitors_warn(self):
        if len(self.server_monitors) < 2:
            return BP_Check(167, 'Server Monitoring', 'warn', 'fail',
                            'It is recommended to have two or more User ID Monitored Servers defined.')
        else:
            return BP_Check(167, 'Server Monitoring', 'warn', 'pass', '')

    @property
    def included_groups_warn(self):
        missing_included_groups = [
            group_mapping.name for group_mapping in self.group_mappings if not group_mapping.included_groups_used]

        if missing_included_groups:
            return BP_Check(
                169, 'Group Mappings Included Groups', 'warn', 'fail',
                'The following Group Mappings are missing Included Groups: {}'.format(', '.join(missing_included_groups))
            )
        else:
            return BP_Check(169, 'Group Mappings Included Groups', 'warn', 'pass', '')

    @property
    def captive_portal_enabled_warn(self):
        if self.captive_portal_settings is None:
            return None

        if not self.captive_portal_settings.enabled:
            return BP_Check(
                171, 'Captive Portal Enabled', 'warn', 'fail',
                'Captive Portal should be enabled'
            )
        else:
            return BP_Check(171, 'Captive Portal Enabled', 'warn', 'pass', '')

    @property
    def captive_portal_mode_warn(self):
        if self.captive_portal_settings is None:
            return None
        if self.captive_portal_settings.mode != 'redirect':
            return BP_Check(172, 'Captive Portal Mode', 'warn', 'fail',
                            'Captive Portal Mode should be set to "Redirect"')
        else:
            return BP_Check(172, 'Captive Portal Mode', 'warn', 'pass', '')

    @property
    def captive_portal_session_cookie_timeout_warn(self):
        if self.captive_portal_settings is None or not self.captive_portal_settings.session_cookie_enabled:
            return None
        if self.captive_portal_settings.session_cookie_timeout > 480:
            return BP_Check(
                173, 'Captive Portal Session Cookie / Timeout', 'warn', 'fail',
                'It is not recommended to enable Captive Portal Session Cookie with a Timeout greater than 480'
            )
        else:
            return BP_Check(173, 'Captive Portal Session Cookie / Timeout', 'warn', 'pass', '')

    @property
    def captive_portal_ssl_tls_service_profile_warn(self):
        if self.captive_portal_settings is None:
            return None
        if self.captive_portal_settings.ssl_tls_service_profile_min_version != 'tls1-2':
            return BP_Check(174, 'Captive Portal SSL/TLS Service Profile Min Version', 'warn', 'fail',
                            'It is recommended for the SSL/TLS Service Profile to have a Min version of TLSv1.2')
        else:
            return BP_Check(
                174, 'Captive Portal SSL/TLS Service Profile Min Version', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {key: value for key, value in iteritems(self.__dict__) if key not in ['entry', 'panorama']}
        configuration['group_mappings'] = [dict(group_mapping._asdict()) for group_mapping in self.group_mappings]

        if self.captive_portal_settings is None:
            configuration['captive_portal_settings'] = 'None'
        else:
            configuration['captive_portal_settings'] = dict(self.captive_portal_settings._asdict())

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}
