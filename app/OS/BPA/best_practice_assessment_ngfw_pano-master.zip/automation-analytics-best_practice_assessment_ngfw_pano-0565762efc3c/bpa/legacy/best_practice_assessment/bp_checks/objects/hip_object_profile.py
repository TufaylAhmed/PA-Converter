# -*- coding: utf-8 -*-
"""
Created on Thu Feb 09 11:48:19 2017

@author: anmendoza

https://jira-hq.paloaltonetworks.local/browse/CST-18
"""
import re
from six import iteritems
from ..base import Base
from ..warn_note import BP_Check


class HIPProfiles(Base):
    xpath = '//profiles/hip-profiles/entry'

    def __init__(self, entry, security_rules_container, dg_descendants, panorama=False):
        super(HIPProfiles, self).__init__(entry, panorama)
        self.name = entry.get('name')

        # extract values between "" into list
        self.matches = re.findall('"([^"]*)"', entry.find('match').text)

        self.set_used_in_rules(security_rules_container, dg_descendants)

    def set_used_in_rules(self, security_rules_container, dg_descendants):
        """Sets the used_in_rules attribute.

        If shared, check all vsys instances / device groups.
        If panorama, check the device group where the HIP Profile was defined and any descendants.
        If NGFW, only check the vsys instance where the HIP Profile was defined.
        """
        if self.vsys == 'shared':
            self.used_in_rules = any(
                security_rules_container.hip_profile_used[vsys][self.name]
                for vsys in security_rules_container.hip_profile_used.keys()
            )
        elif self.panorama:
            self.used_in_rules = any(
                security_rules_container.hip_profile_used[dg][self.name]
                for dg in dg_descendants[self.vsys]
            )
        else:  # NGFW
            self.used_in_rules = security_rules_container.hip_profile_used[self.vsys][self.name]

    @property
    def hip_profiles_exist_warn(self):
        if not self.matches:
            return BP_Check(
                29, 'HIP Profile with Object', 'warn', 'fail',
                'It is recommended for HIP Profiles to use at least one HIP Object'
            )
        else:
            return BP_Check(29, 'HIP Profile with Object', 'warn', 'pass', '')

    @property
    def hip_profiles_not_in_rules_warn(self):
        if not self.used_in_rules:
            return BP_Check(
                30, 'HIP Profiles used in Rules', 'warn', 'fail',
                'HIP Profile is not used in any security policy rules')
        else:
            return BP_Check(30, 'HIP Profiles used in Rules', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {
            key: value
            for key, value in iteritems(self.__dict__)
            if key != 'panorama'
        }

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}

    @classmethod
    def get_all(cls, xml=None, panorama=False, template_device_split=True, exclude_none=False, **kwargs):
        """Overrides the inherited get_all method from Base class.

        If no HIP Profile records exist, create a single record with the HIP Profiles Not Configured note.
        """
        records = [hip_profile.record for hip_profile in cls.get_objects(xml, panorama, **kwargs)]

        if not records:
            bp_check = BP_Check(
                209, 'HIP Profiles Not Configured', 'note', '',
                'It is recommended to configure a HIP Profile'
            )._asdict()

            records = [{'configuration': {'configured': False}, 'bp_check': [bp_check, ]}]

        return records
