# -*- coding: utf-8 -*-
"""
Created on Thu Feb 02 09:23:56 2017

@author: anmendoza
"""
from ..warn_note import BP_Check
from ..base import Base


class AppOverride(Base):
    xpath = '//application-override/rules/entry'

    def __init__(self, entry, panorama=False):
        super(AppOverride, self).__init__(entry, panorama)
        self.name = entry.get('name')
        if panorama:
            self.rulebase = entry.getparent().getparent().getparent().tag

    @property
    def app_override_warn(self):
        return BP_Check(
            21, 'App Override Usage', 'warn', 'fail',
            'Verify that you need to use Application Override')

    @property
    def record(self):
        return {
            'configuration': self.__dict__,
            'bp_check': [self.app_override_warn._asdict()]
        }
