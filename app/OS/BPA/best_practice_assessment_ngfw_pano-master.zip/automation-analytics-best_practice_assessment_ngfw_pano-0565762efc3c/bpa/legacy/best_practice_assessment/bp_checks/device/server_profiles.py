# -*- coding: utf-8 -*-
"""
Created on Fri Feb 10 12:47:27 2017

@author: anmendoza
"""
# https://jira-hq.paloaltonetworks.local/browse/CST-30

from ..warn_note import BP_Check
from ..base import Base


class SNMPTrapServerProfile(Base):
    xpath = '//log-settings/snmptrap/entry'

    def __init__(self, entry, panorama=False):
        super(SNMPTrapServerProfile, self).__init__(entry, panorama)
        self.name = entry.get('name')
        self.version = entry.find('version/*').tag

        # Community is not an option with v3
        self.community = entry.findtext('version/v2c/server/entry/community', 'None')
        if self.community != 'None':
            self.community = self.community.strip().upper()

    @property
    def version_warn(self):
        if self.version == 'v2c':
            return BP_Check(
                183, 'SNMP Trap Server Profile Version', 'warn', 'fail',
                'It is recommended to set Version to "V3"')
        else:
            return BP_Check(
                183, 'SNMP Trap Server Profile Version', 'warn', 'pass', '')

    @property
    def community_warn(self):
        if self.community in ('PUBLIC', 'PRIVATE'):
            return BP_Check(
                184, 'SNMP Trap Server Profile Community', 'warn', 'fail',
                'It is not recommended to set Community to "PUBLIC" or "PRIVATE" when using Version "V2c"'
            )
        else:
            return BP_Check(184, 'SNMP Trap Server Profile Community', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {
            key: self.__dict__[key] for key in self.__dict__.keys()
            if key != 'panorama'}
        return {'configuration': configuration,
                'bp_check': self.get_bp_checks()}


class SyslogServerProfile(Base):
    xpath = '//log-settings/syslog/entry'

    def __init__(self, entry, panorama=False):
        super(SyslogServerProfile, self).__init__(entry, panorama)
        self.name = entry.get('name')
        self.transport = entry.findtext('server/entry/transport', 'None')

    @property
    def transport_warn(self):
        if self.transport != 'SSL':
            return BP_Check(
                185, 'Syslog Server Profile Transport', 'warn', 'fail',
                'It is recommended to set Transport to "SSL"'
            )
        else:
            return BP_Check(185, 'Syslog Server Profile Transport', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {
            key: self.__dict__[key] for key in list(
                self.__dict__.keys()) if key != 'panorama'}
        return {'configuration': configuration,
                'bp_check': [self.transport_warn._asdict()]}


class LDAPServerProfile(Base):
    xpath = '//server-profile/ldap/entry'

    def __init__(self, entry, panorama=False):
        super(LDAPServerProfile, self).__init__(entry, panorama)
        self.name = entry.get('name')
        self.server_list = entry.xpath('server/entry/@name')

        # enabled by default
        self.require_ssl_tls_secured_connection = entry.findtext('ssl', 'yes') == 'yes'

        # disabled by default
        self.verify_server_certificate_for_ssl_sessions = entry.findtext('verify-server-certificate', 'no') == 'yes'

    @property
    def require_ssl_tls_secured_connection_warn(self):
        if not self.require_ssl_tls_secured_connection:
            return BP_Check(
                186, 'LDAP Profile Require SSL/TLS secured connection', 'warn', 'fail',
                'It is recommended to enable "Require SSL/TLS secured connection"')
        else:
            return BP_Check(186, 'LDAP Profile Require SSL/TLS secured connection', 'warn', 'pass', '')

    @property
    def verify_server_certificate_for_ssl_sessions_warn(self):
        if not self.verify_server_certificate_for_ssl_sessions:
            return BP_Check(
                187, 'LDAP Profile Verify Server Certificate for SSL sessions', 'warn', 'fail',
                'It is recommended to enable "Verify Server Certificate for SSL sessions"')
        else:
            return BP_Check(
                187, 'LDAP Profile Verify Server Certificate for SSL sessions', 'warn', 'pass', '')

    @property
    def server_redundancy_warn(self):
        if len(self.server_list) < 2:
            return BP_Check(
                199, 'LDAP Server Redundancy', 'warn', 'fail',
                'It is recommended to have two or more servers in the server list')
        else:
            return BP_Check(199, 'LDAP Server Redundancy', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {
            key: self.__dict__[key] for key in list(
                self.__dict__.keys()) if key != 'panorama'}
        return {'configuration': configuration,
                'bp_check': self.get_bp_checks()}
