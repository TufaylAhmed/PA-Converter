# -*- coding: utf-8 -*-
"""
Created on Thu Feb 02 09:17:02 2017

@author: anmendoza
"""
from ...common import tag_val
from ..warn_note import BP_Check
from ..base import Base


class PolicyBasedForwardingRule(Base):
    xpath = '//pbf/rules/entry'

    def __init__(self, entry, panorama=False):
        super(PolicyBasedForwardingRule, self).__init__(entry, panorama)
        self.name = entry.get('name')
        self.action = tag_val(entry, 'action/*', 'no-action')
        self.monitor_enabled = entry.find('action/forward/monitor') is not None
        self.entry = entry
        if self.panorama:
            self.rulebase = entry.getparent().getparent().getparent().tag

    @property
    def monitoring_profile(self):
        profile = self.entry.find('action/forward/monitor/profile')
        return profile.text if profile is not None else None

    @property
    def ip_address(self):
        ip_address = self.entry.find('action/forward/monitor/ip-address')
        return ip_address.text if ip_address is not None else None

    @property
    def monitoring_warn(self):
        """Warn if monitor is disabled.

        Skip the check if action is no-pbf, since there is no option to enabled monitoring
        in that configuration.
        """
        if self.action == 'forward':
            if not self.monitor_enabled:
                return BP_Check(
                    17, 'Monitoring Enabled', 'warn', 'fail',
                    'If you have a PBF Rule, then monitoring should be enabled and a profile should be configured.'
                )
            else:
                return BP_Check(17, 'Monitoring Enabled', 'warn', 'pass', '')

    @property
    def forwarding_profile_ip_warn(self):
        """Warn if monitoring is enabled AND IP address is not configured.

        Skip the check if monitor is disabled.
        """
        if self.monitor_enabled:
            if self.ip_address is None:
                return BP_Check(
                    18, 'Monitoring IP Address', 'warn', 'fail',
                    'Monitoring is enabled, but an IP Address is not configured.'
                )
            else:
                return BP_Check(18, 'Monitoring IP Address', 'warn', 'pass', '')

    @property
    def non_forwarding_pbf_action_note(self):
        if self.action != 'forward':
            return BP_Check(
                218, 'Non Forwarding PBF Action', 'note', '',
                'PBF checks only apply when the Action is configured to "Forward"'
            )

    @property
    def record(self):
        configuration = {key: val for key, val in self.__dict__.items() if key not in ['entry', 'panorama']}
        configuration['monitoring_profile'] = self.monitoring_profile
        configuration['ip_address'] = self.ip_address
        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}
