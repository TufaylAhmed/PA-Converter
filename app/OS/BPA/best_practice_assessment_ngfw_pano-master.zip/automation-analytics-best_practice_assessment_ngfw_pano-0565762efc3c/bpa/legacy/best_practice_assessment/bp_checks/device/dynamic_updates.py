# -*- coding: utf-8 -*-
"""
Created on Thu Feb 02 09:22:11 2017

@author: anmendoza

https://jira-hq.paloaltonetworks.local/browse/CST-34
"""
import weakref

from ..warn_note import BP_Check
from ..base import Base


class DynamicUpdates(Base):
    xpath = '//config/devices/entry/deviceconfig/system/update-schedule'

    def __init__(self, update_schedule, xml_config, template_name=None):
        self.update_schedule = update_schedule
        self.xml_config = weakref.ref(xml_config)
        self.template_name = template_name

    @property
    def anti_virus(self):
        try:
            return self.update_schedule.update_types['anti-virus']
        except (AttributeError, KeyError):
            return None

    @property
    def apps_threats(self):
        try:
            return self.update_schedule.update_types['threats']
        except (AttributeError, KeyError):
            return None

    @property
    def wildfire(self):
        try:
            return self.update_schedule.update_types['wildfire']
        except (AttributeError, KeyError):
            return None

    @property
    def global_protect(self):
        try:
            return self.update_schedule.update_types['global-protect-datafile']
        except (AttributeError, KeyError):
            return None

    @property
    def gp_clientless_vpn(self):
        try:
            return self.update_schedule.update_types['global-protect-clientless-vpn']
        except (AttributeError, KeyError):
            return None

    @property
    def anti_virus_warn(self):
        if self.anti_virus is None:
            return BP_Check(188, 'Antivirus', 'warn', 'fail', 'AV update is not configured.')

        message_lst = []
        if self.anti_virus.recurrence != 'hourly':
            message_lst.append('AV update recurrence is not set to hourly.')
        if self.anti_virus.action != 'download-and-install':
            message_lst.append('AV update action is not set to "download-and-install".')
        if self.anti_virus.threshold != 0:
            message_lst.append('AV update should not have a threshold configured.')

        if message_lst:
            return BP_Check(188, 'Antivirus', 'warn', 'fail', ' '.join(message_lst))
        else:
            return BP_Check(188, 'Antivirus', 'warn', 'pass', '')

    @property
    def anti_virus_note(self):
        if self.anti_virus and self.anti_virus.sync_to_peer:
            return BP_Check(
                191, 'Antivirus Sync to Peer', 'note', '',
                'When using sync to peer, ensure that the minutes past the hour is not the same on the peer.'
            )

    @property
    def apps_threats_warn(self):
        if self.apps_threats is None:
            return BP_Check(189, 'Apps & Threats', 'warn', 'fail', 'Apps & Threats update is not configured.')

        message_lst = []
        if self.apps_threats.recurrence not in ['every-30-mins', 'hourly', 'daily']:
            message_lst.append('Apps & Threats update recurrence should be every 30 minutes, hourly or daily.')
        if self.apps_threats.action != 'download-and-install':
            message_lst.append('Apps & Threats update action is not set to "download-and-install".')
        if self.apps_threats.threshold > 48:
            message_lst.append('Apps & Threats update threshold is greater than 48 hours.')

        if message_lst:
            return BP_Check(189, 'Apps & Threats', 'warn', 'fail', ' '.join(message_lst))
        else:
            return BP_Check(189, 'Apps & Threats', 'warn', 'pass', '')

    @property
    def apps_threats_note(self):
        if self.apps_threats and self.apps_threats.sync_to_peer:
            return BP_Check(
                192, 'Apps & Threats Sync to Peer', 'note', '',
                'When using sync to peer, ensure that the minutes past the hour '
                'is not the same on the peer'
            )

    @property
    def wildfire_warn(self):
        if self.wildfire is None:
            return BP_Check(190, 'WildFire', 'warn', 'fail', 'WildFire update not configured.')

        message_lst = []
        if self.wildfire.recurrence != 'every-min':
            message_lst.append('WildFire update recurrence should be set to "every minute".')
        if self.wildfire.action != 'download-and-install':
            message_lst.append('WildFire update action is not set to "download-and-install".')

        if message_lst:
            return BP_Check(190, 'WildFire', 'warn', 'fail', ' '.join(message_lst))
        else:
            return BP_Check(190, 'WildFire', 'warn', 'pass', '')

    @property
    def global_protect_warn(self):
        """NOTE: GlobalProtect Dynamic Update is only applicable to NGFWs."""
        if self.xml_config().ngfw:
            if self.global_protect is None:
                return BP_Check(194, 'Global Protect', 'warn', 'fail', 'GlobalProtect update not configured.')

            message_lst = []
            if self.global_protect.recurrence != 'hourly':
                message_lst.append('GlobalProtect update recurrence should be hourly.')
            if self.global_protect.action != 'download-and-install':
                message_lst.append('GlobalProtect update action is not set to "download-and-install".')

            if message_lst:
                return BP_Check(194, 'Global Protect', 'warn', 'fail', ' '.join(message_lst))
            else:
                return BP_Check(194, 'Global Protect', 'warn', 'pass', '')

    @property
    def gp_clientless_vpn_warn(self):
        """NOTE: GlobalProtect Clientless VPN Dynamic Update is only applicable to NGFWs
        running PAN-OS 8.0+.
        """
        if self.xml_config().ngfw and self.xml_config().version >= 8:
            if self.gp_clientless_vpn is None:
                return BP_Check(
                    195, 'Clientless VPN', 'warn', 'fail',
                    'GlobalProtect Clientless VPN update not configured.'
                )

            message_lst = []
            if self.gp_clientless_vpn.recurrence != 'hourly':
                message_lst.append('GlobalProtect Clientless VPN update recurrence should be hourly.')
            if self.gp_clientless_vpn.action != 'download-and-install':
                message_lst.append('GlobalProtect Clientless VPN update action is not set to "download-and-install".')

            if message_lst:
                return BP_Check(195, 'Clientless VPN', 'warn', 'fail', ' '.join(message_lst))
            else:
                return BP_Check(195, 'Clientless VPN', 'warn', 'pass', '')

    @property
    def apps_and_threats_app_id_threshold_warn(self):
        # APP-ID threshold is only in PAN OS 8.1+
        if self.apps_threats is not None and self.apps_threats.version >= 8.1:
            message_lst = []
            if self.apps_threats.new_app_threshold == 0:
                message_lst.append('Apps & Threats New App-ID Threshold for updates should be set to ensure you '
                                   'have given sufficient time before New APP-IDs are installed in your network.')
            if message_lst:
                return BP_Check(219, 'Apps & Threats - New APP-ID Threshold', 'warn', 'fail', ' '.join(message_lst))
            else:
                return BP_Check(219, 'Apps & Threats - New APP-ID Threshold', 'warn', 'pass', '')

    @staticmethod
    def formatted_name(name: str) -> str:
        """Converts update type tag value to cleaner format for record configuration"""
        return {
            'anti-virus': 'Antivirus',
            'threats': 'Applications and Threats',
            'wildfire': 'WildFire',
            'global-protect-datafile': 'GlobalProtect Data File',
            'global-protect-clientless-vpn': 'GlobalProtect Clientless VPN',
        }[name]

    @property
    def record(self):
        configuration = {}
        if self.template_name is not None:
            configuration['template_name'] = self.template_name
        if self.update_schedule is not None:
            for name, update_type in self.update_schedule.update_types.items():
                configuration[self.formatted_name(name)] = update_type.json()
        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}

    @classmethod
    def get_all(cls, xml_config):
        """Return a list of dictionaries representing dynamic updates records."""
        records = []
        templates_with_dyn_updates = set()

        # Run checks on all dynamic updates configured in the XML
        for update_schedule in xml_config.collector.get('dynamic_updates'):
            template_name = getattr(update_schedule, 'template_name', None)
            templates_with_dyn_updates.add(template_name)
            records.append(DynamicUpdates(update_schedule, xml_config, template_name).record)

        # Run checks on any templates where dynamic updates NOT configured in the XML
        templates_missing_dyn_updates = set(xml_config.xpatheval('//template/entry/@name')) - templates_with_dyn_updates
        for template_name in templates_missing_dyn_updates:
            records.append(DynamicUpdates(None, xml_config, template_name).record)

        # Run checks on the device (NGFW or Panorama) if dynamic updates NOT configured in the XML
        if None not in templates_with_dyn_updates:
            records.append(DynamicUpdates(None, xml_config, None).record)

        return cls.template_device_split(records)
