# -*- coding: utf-8 -*-
"""
Created on Tue Feb 28 12:11:10 2017

@author: anmendoza
"""
from abc import ABCMeta
from lxml import etree


class Base(metaclass=ABCMeta):
    """Parent object to provide common attributes and methods"""
    bool_dict = {'yes': True, 'no': False}

    def __init__(self, element, panorama=False):
        self.panorama = True if panorama or element.xpath('/config/mgt-config/devices') else False

        location = self.find_ancestor_value(element, ['vsys', 'device-group', 'shared-gateway'], ['shared', 'predefined'])
        template_name = self.find_ancestor_value(element, ['template'])
        if location is not None:
            self.vsys = location
        if template_name is not None:
            self.template_name = template_name

    def __init_subclass__(cls):
        """Enfore xpath attribute in subclasses"""
        if not hasattr(cls, 'xpath'):
            raise NotImplementedError

    def find_ancestor_value(self, el, target_tags, value_tags=None):
        """Iterates through element ancestors to find a specific value.

        Args:
            el: lxml Element
            target_tags: list of parent tags when, if found, will result in returning the name attribute
            of the PRIOR element
            value_tags: option list of paretn tags when, if found, will result in returning the value of the CURRENT tag

        Returns:
            String of desired ancestor value or None
        """
        previous = el
        for parent in etree.AncestorsIterator(el):
            if parent.tag in target_tags:
                return previous.get('name')
            elif value_tags is not None and parent.tag in value_tags:
                return parent.tag
            else:
                previous = parent

    def get_bp_checks(self):
        """Returns a list of all best practice warnings and notes contained in the object.
        Assumes that checks end in _warn or _note."""
        bp_check = []
        for name in dir(self):
            if name.endswith('_warn') or name.endswith('_note'):
                check = getattr(self, name)
                if check is not None:
                    bp_check.append(check._asdict())
        return bp_check

    @classmethod
    def get_objects(cls, xml=None, panorama=False, **kwargs):
        """Return a list of all object instances"""
        return [cls(x, panorama=panorama, **kwargs)
                for x in xml.xpath(cls.xpath)]

    @classmethod
    def get_all(cls, xml=None, panorama=False, template_device_split=True,
                exclude_none=False, **kwargs):
        """Return a list of object records"""
        records = [x.record for x in cls.get_objects(xml, panorama, **kwargs)]

        if exclude_none:
            records = [record for record in records if record is not None]

        if template_device_split:
            return cls.template_device_split(records)
        else:
            return records

    @staticmethod
    def template_device_split(records):
        """Takes a list of records and splits them into two separate lists depending on
        whether the configuration dictionary contains a template_name value."""
        template_records, device_records = [], []

        for record in records:
            if 'template_name' in record['configuration']:
                template_records.append(record)
            else:
                device_records.append(record)
        return template_records, device_records

    @property
    def record(self):
        """Return a dictionary record containing configuration and bp_check items"""
        configuration = {key: val for key, val in self.__dict__.items() if not key.startswith('_')}
        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}
