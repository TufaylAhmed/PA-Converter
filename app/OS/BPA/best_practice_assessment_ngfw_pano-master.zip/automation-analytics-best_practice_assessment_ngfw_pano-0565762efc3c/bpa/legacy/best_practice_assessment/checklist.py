# -*- coding: utf-8 -*-
from collections import OrderedDict, defaultdict
from typing import List, Dict
import xlsxwriter
from io import BytesIO
import pandas as pd
import numpy as np


class Checklist(object):
    """Excel workbook containing failed Best Practice checks and documentation."""
    SHEETS = ('Policies', 'Objects', 'Network', 'Device', 'Panorama')
    COLUMNS = ('feature', 'vsys', 'template_name', 'name', 'check_id', 'check_name', 'message', 'complexity', 'Remediation Effort (Minutes)')
    WIDTHS = {
        'Message': 50,
        'Title': 50,
        'Description': 50,
        'Notes': 50,
        'Rationale': 50,
        'References': 50,
        'ID': 5,
        'Check ID': 10,
        'Remediation Effort (8 Hour Work Days)': 40
    }

    def __init__(self, data: Dict, is_panorama: bool, documentation: List = None):
        """Inits Checklist.

        Args:
            data: Flattened JSON data from a BestPracticeAssessment instance.
            is_panorama: Boolean indicating if data is for a Panorama device.

        Attributes:
            grand_total (dict): Contains 'Total' label, Failed Checks total Sum excel equation,
                                Remediation Effort (8 Hour Work Days) total Sum excel equation
                                and total length of Unique features to calculate row to write the totals equations.
        """
        if documentation is not None:
            self._documentation = [doc for doc in documentation if doc['active']]
        else:
            self._documentation = []
        self.output = BytesIO()
        self.is_panorama = is_panorama
        self._keys = set()
        self.workbook = xlsxwriter.Workbook(self.output, options={'strings_to_urls': False})
        self._link_format = self.workbook.add_format({'underline': 1, 'font_color': 'blue'})
        self._rows = defaultdict(list)
        self._data = {}
        self.parse_records(data)
        self.grand_total = {}
        self.check_doc_location = {}  # This variable stores the documentation sheet row indexes for all the check ids, for links

    def __del__(self):
        """Save data and close workbook upon deletion."""
        self.close()

    def get_sheet_names(self):
        """Extract sheet names from JSON keys."""
        sheets = list(self._keys)
        sheets.sort(key=lambda t: self.SHEETS.index(t))
        if self._documentation:
            sheets.append('Documentation')
        sheets.insert(0, 'Summary')
        return sheets

    def parse_records(self, data):
        """Extracts row data from JSON records."""
        for feature, records in data.items():
            for record in records:
                self.add_rows(feature, record)

    def add_rows(self, feature, record):
        """Adds rows from a given record for insertion into corresponding self._rows list.

        Args:
            feature: A string representing the feature the record belongs to.
            record: A dictionary containing the record.
        """
        feature_split = feature.split('.')
        sheet_name = feature_split[0].title()
        add_row = self._rows[sheet_name].append
        config = {key: val for key, val in record['configuration'].items() if key in ['name', 'template_name', 'vsys']}
        config['feature'] = ' > '.join(feature_split).replace('_', ' ').title()
        if config.get('name') is None:
            try:
                config['name'] = record['configuration']['rule_name']
            except KeyError:
                config['name'] = None

        for check in record['bp_check']:
            if check['result'] == 'fail':
                self._keys.add(sheet_name)
                check['check_name'] = check.pop('name')
                check['check_id'] = check.pop('id')
                try:
                    doc = next(doc for doc in self._documentation if doc['doc_id'] == check['check_id'])
                except StopIteration:
                    check['complexity'] = 'N/A'
                    check['Remediation Effort (Minutes)'] = 'N/A'
                else:
                    check['complexity'] = doc['complexity']
                    check['Remediation Effort (Minutes)'] = doc['effort']
                add_row({**config, **check})

    def get_data(self, sheet):
        """Retreives sheet data.

        If raw data has not yet been stored as a DataFrame, store the data before returning it.
        """
        try:
            data = self._data[sheet]
        except KeyError:
            self.store_data(sheet)
            data = self._data[sheet]
        finally:
            return data

    def store_data(self, sheet):
        """Factory function for storing worksheet data to self._data dictionary."""
        if sheet == 'Documentation':
            self.store_documentation_data()
        elif sheet == 'Summary':
            self.store_summary_data()
        else:
            self.store_worksheet_data(sheet)

    def store_summary_data(self):
        """This function loops through all sheets except Documentation and Summary to summarize all data then prepares/appends them to be
        stored in the 'Summary' worksheet tab. Creates a grand total of all sheet totals."""
        total_summary = pd.DataFrame()
        for sheet in self.get_sheet_names():
            if sheet not in ['Documentation', 'Summary']:
                # Read in each sheet except the above to add up totals
                sheet_data = pd.DataFrame(self._rows[sheet], columns=self.COLUMNS)
                # Add up the total minutes for each feature's Remediation Effort time using np.sum
                # Getting the length (len) of each complexity value gives us total failed checks for each feature
                sheet_data['Remediation Effort (Minutes)'] = pd.to_numeric(sheet_data['Remediation Effort (Minutes)'], errors='coerce')
                summary = sheet_data.groupby('feature').agg({'Remediation Effort (Minutes)': np.sum, 'complexity': len}).reset_index()
                summary['Remediation Effort (8 Hour Work Days)'] = summary['Remediation Effort (Minutes)'] / 480
                summary.drop('Remediation Effort (Minutes)', axis=1, inplace=True)
                summary.rename(columns={'feature': 'Feature', 'complexity': 'Failed Checks'}, inplace=True)
                summary = summary.round(2)
                total_summary = total_summary.append(summary)

        self.grand_total['Grand Total Label'] = 'Total'
        self.grand_total['Failed Checks Total'] = '=SUBTOTAL(9, Summary[Failed Checks])'
        self.grand_total['Remediation Total'] = '=SUBTOTAL(9, Summary[Remediation Effort (8 Hour Work Days)])'
        self.grand_total['Grand Total Row Number'] = total_summary.shape[0] + 1
        self._data['Summary'] = total_summary

    def store_worksheet_data(self, sheet):
        """Retreives and formats data for a given *normal* worksheet.

        Args:
            sheet: name of sheet to get data for.

        Returns:
            A cleaned pandas DataFrame.
        """
        sheet_data = pd.DataFrame(self._rows[sheet], columns=self.COLUMNS)
        sheet_data.dropna(axis='columns', how='all', inplace=True)
        sheet_data.rename(columns=self.format_column_names(sheet, sheet_data.columns), inplace=True)
        sheet_data['Status'] = 'Not Started'
        sheet_data['Notes'] = None
        self._data[sheet] = sheet_data.where((pd.notnull(sheet_data)), None)

    def store_documentation_data(self):
        """Retreives and organizes documentation data from Django model."""
        if not self._documentation:
            docs = pd.DataFrame()
        else:
            columns = OrderedDict({
                'doc_id': 'ID',
                'top_nav': 'Section',
                'left_nav': 'Sub Section',
                'doc_type': 'Type',
                'title': 'Title',
                'description': 'Description',
                'rationale': 'Rationale',
                'complexity': 'Complexity',
                'effort': 'Remediation Effort (Minutes)',
                'references': 'References',
            })
            docs = pd.DataFrame.from_records(
                data=self._documentation,
                columns=list(columns.keys()),
            )
            docs = docs.reindex(columns=columns.keys())
            docs.rename(columns=columns, inplace=True)
            docs.sort_values(by='ID', inplace=True)

        # Replace any null Documentation values with None
        self._data['Documentation'] = docs.where((pd.notnull(docs)), None)

    def write_data(self, sheet):
        """Writes data to a given worksheet."""
        sheet_data = self.get_data(sheet)

        if not sheet_data.empty:
            worksheet = self.workbook.add_worksheet(sheet)
            worksheet.add_table(
                first_row=0,
                first_col=0,
                last_row=sheet_data.shape[0],
                last_col=(sheet_data.shape[1] - 1),
                options={
                    'columns': [{'header': col} for col in sheet_data.columns],
                    'data': sheet_data.values,
                    'style': 'Table Style Light 9',
                    'name': sheet
                }
            )

    def set_column_widths(self, sheet):
        """Set column widths for a given worksheet."""
        worksheet = self.workbook.get_worksheet_by_name(sheet)
        sheet_data = self.get_data(sheet)

        for index, column in enumerate(sheet_data.columns):
            width = self.WIDTHS.get(column)
            if width is None:
                try:
                    width = sheet_data[column].str.len().max() + 5
                except AttributeError:
                    width = 20
            worksheet.set_column(index, index, width)

    def add_data_validation(self, sheet):
        """Add data validation to *Status* column of a given worksheet."""
        worksheet = self.workbook.get_worksheet_by_name(sheet)
        sheet_data = self.get_data(sheet)
        target_column = sheet_data.columns.get_loc('Status')
        worksheet.data_validation(
            first_row=1,
            first_col=target_column,
            last_row=sheet_data.shape[0],
            last_col=target_column,
            options={
                'validate': 'list',
                'source': ['Not Started', 'In Progress', 'Resolved', 'Planned', 'Not Applicable'],
                'error_title': 'Invalid Status!',
                'error_message': 'You must choose from one of the given statuses.'
            }
        )

    def add_check_links(self, sheet):
        """Link Check IDs in a given worksheet to the related row in the Documentation worksheet.

        Data in the Documentation worksheet is sorted by ID in ascending order, so we can link to
        the row in the Documentation worksheet with index of Check ID + 1.
        """
        worksheet = self.workbook.get_worksheet_by_name(sheet)
        sheet_data = self.get_data(sheet)   # Pandas Data Frame
        self.build_link_locations()
        self.get_documentation_url(worksheet, sheet_data)

    def build_link_locations(self):
        if not self.check_doc_location:  # If dictionary is empty, then build dictionary
            self.get_data('Documentation')
            self._data['Documentation'].reset_index(inplace=True, drop=True)
            for doc in self._documentation:
                try:
                    self.check_doc_location[doc['doc_id']] = self._data['Documentation'].loc[self._data['Documentation']['ID'] == doc['doc_id']].index[0] + 1   # Searches 'ID' column in Documentation sheet and adds 1 for header rows offset and builds a dictionary for self.check_doc_location
                except KeyError:
                    continue

    def get_documentation_url(self, worksheet, sheet_data):
        target_column = sheet_data.columns.get_loc('Check ID')
        for index, check_id in sheet_data['Check ID'].iteritems():
            try:
                doc_sheet_row = self.check_doc_location[check_id]  # Returns row of check ID in Documentation sheet by returning value from key (check ID)
            except KeyError:  # When local documentation DB not in-sync with production documenetation DB, you get key errors, just skip (continue)
                continue
            target_row = index + 1
            worksheet.write_url(
                row=target_row,
                col=target_column,
                url='internal:Documentation!A{}'.format(doc_sheet_row + 1),
                tip='View Documentation'
            )
            # Need to re-write the cell as a number to avoid *Number Stored as Text* error
            worksheet.write_number(row=target_row, col=target_column, number=check_id, cell_format=self._link_format)

    def write_grand_total_summary(self):
        """Writes totals row which should be last row in Summary Worksheet,applies formatting also."""
        summary_sheet = self.workbook.get_worksheet_by_name('Summary')
        cell_format = self.workbook.add_format({'bold': True, 'font_color': 'white', 'bg_color': '#4F80BD'})
        summary_sheet.write(self.grand_total['Grand Total Row Number'], 0, self.grand_total['Grand Total Label'], cell_format)
        summary_sheet.write(self.grand_total['Grand Total Row Number'], 1, self.grand_total['Failed Checks Total'], cell_format)
        summary_sheet.write(self.grand_total['Grand Total Row Number'], 2, self.grand_total['Remediation Total'], cell_format)

    def run(self):
        """Writes data, applies formatting, and closes the workbook."""
        for sheet in self.get_sheet_names():
            self.write_data(sheet)
            self.set_column_widths(sheet)
            if sheet not in ['Documentation', 'Summary']:
                self.add_data_validation(sheet)
                self.add_check_links(sheet)
        self.write_grand_total_summary()
        self.close()

    def close(self):
        """Helper function to close workbook."""
        self.workbook.close()

    def format_column_names(self, sheet, columns):
        """Helper function to format column names.

        Args:
            sheet (str): name of sheet to get data for.
            columns
        """
        new_columns = {col: col.replace('_', ' ').title() for col in columns}
        new_columns['check_id'] = 'Check ID'
        if self.is_panorama and sheet in ['Policies', 'Objects']:
            new_columns['vsys'] = 'Device Group'
        return new_columns

    @classmethod
    def from_bpat(cls, bpat, documentation=None):
        """Helper function to create an instance of Checklist class and run() main operations given a BPAT instance.

        Args:
            cls (Checklist class)
            bpat (bpat.BestPracticeAssessment object)
            documentation (Default=None)

        Attributes:
            checklist (Checklist object)
        """
        checklist = cls(bpat.json(flatten=True), bpat.panorama, documentation)
        checklist.run()
        return checklist
