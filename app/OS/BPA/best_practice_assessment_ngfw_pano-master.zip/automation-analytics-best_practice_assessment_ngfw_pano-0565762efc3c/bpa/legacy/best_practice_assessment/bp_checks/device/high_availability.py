# -*- coding: utf-8 -*-
"""
Created on Mon Feb 13 14:33:22 2017

@author: nbitting
"""
from ...common import bool_attr, str_attr, tag_val
from ..warn_note import BP_Check
from ..base import Base


class HighAvailabilityGeneral(Base):
    xpath = '//deviceconfig/high-availability'

    def __init__(self, entry, panorama=False):
        super(HighAvailabilityGeneral, self).__init__(entry, panorama)
        self.ha_enabled = entry.findtext('enabled', 'no') == 'yes'
        self.timers = tag_val(entry, 'group/entry/election-option/timers/*', 'recommended')

        # Templates: Peer IP AND Peer IP Backup NOT CONFIGURABLE
        # Panorama: Peer IP CONFIGURABLE
        # NGFW: Peer IP AND Peer IP Backup BOTH CONFIGURABLE
        if not hasattr(self, 'template_name'):  # Panorama or NGFW
            if self.panorama:
                self.peer_ip = entry.findtext('peer/ip-address', 'None')
            else:  # NGFW
                self.peer_ip = entry.findtext('group/entry/peer-ip', 'None')
                self.peer_ip_backup = entry.findtext('group/entry/peer-ip-backup', 'None')

        # HA on Panorama device only has a subset of configuration options
        if not self.panorama or hasattr(self, 'template_name'):
            # Default mode is active-passive on templates and None on NGFW
            self.mode = tag_val(
                entry,
                'group/entry/mode/*',
                'active-passive' if hasattr(self, 'template_name') else 'None'
            )
            self.passive_link_state = str_attr(
                entry, 'group/entry/mode/active-passive/passive-link-state', 'shutdown')
            self.heartbeat_backup_enabled = bool_attr(
                entry, 'group/entry/election-option/heartbeat-backup')

            # Preemptive is DISABLED by default for NGFW/templates
            # and does not show up in XML unless modified
            self.preemptive_enabled = entry.findtext('group/entry/election-option/preemptive', 'no') == 'yes'

            # Enable Config Sync does not exist on Panorama
            # but is enabled by default on NGFW / templates
            self.config_sync_enabled = entry.findtext(
                'group/entry/configuration-synchronization/enabled', 'yes') == 'yes'

            # HA1 / HA1 Backup / HA2 / HA2 Backup / HA3 do not exist on
            # Panorama device
            self.ha1_ip_address = str_attr(
                entry, 'interface/ha1/ip-address', 'None')
            self.ha1_port = str_attr(entry, 'interface/ha1/port', 'None')
            self.ha1_netmask = str_attr(entry, 'interface/ha1/netmask', 'None')
            self.ha1_gateway = str_attr(entry, 'interface/ha1/gateway', 'None')
            self.ha1_encryption_enabled = bool_attr(
                entry, 'interface/ha1/encryption/enabled/text()')
            self.ha1_backup_ip_address = str_attr(
                entry, 'interface/ha1-backup/ip-address', 'None')
            self.ha1_backup_port = str_attr(
                entry, 'interface/ha1-backup/port', 'None')
            self.ha1_backup_netmask = str_attr(
                entry, 'interface/ha1-backup/netmask', 'None')
            self.ha1_backup_gateway = str_attr(
                entry, 'interface/ha1-backup/gateway', 'None')

            self.ha2_session_sync_enabled = str_attr(
                entry, 'group/entry/state-synchronization/enabled', 'yes') == 'yes'
            self.ha2_keep_alive_enabled = bool_attr(
                entry, 'group/entry/state-synchronization/ha2-keep-alive/enabled/text()')
            self.ha2_action = str_attr(
                entry, 'group/entry/state-synchronization/ha2-keep-alive/action', 'log-only')
            self.ha2_backup_ip_address = str_attr(
                entry, 'interface/ha2-backup/ip-address', 'None')
            self.ha2_backup_port = str_attr(
                entry, 'interface/ha2-backup/port', 'None')
            self.ha2_backup_netmask = str_attr(
                entry, 'interface/ha2-backup/netmask', 'None')
            self.ha2_backup_gateway = str_attr(
                entry, 'interface/ha2-backup/gateway', 'None')

            self.ha3_interface = str_attr(entry, 'interface/ha3/port', 'None')
            if self.ha3_interface == 'None':
                self.ha3_session_owner_selection = 'None'
            else:
                self.ha3_session_owner_selection = tag_val(
                    entry,
                    'group/entry/mode/active-active/session-owner-selection/*',
                    'first-packet'
                )
        else:
            # Preemptive is ENABLED by default for Panorama
            # and does not show up in XML unless modified
            self.preemptive_enabled = entry.findtext('election-option/preemptive', 'yes') == 'yes'

    @property
    def config_sync_warn(self):
        if self.ha_enabled and hasattr(self, 'config_sync_enabled'):
            if not self.config_sync_enabled:
                return BP_Check(
                    136, 'Configuration Synchronization', 'warn', 'fail',
                    'If HA is enabled, it is recommended to also turn on "Enabled Config Sync".'
                )
            else:
                return BP_Check(
                    136, 'Configuration Synchronization', 'warn', 'pass', '')

    @property
    def peer_ip_backup_warn(self):
        if self.ha_enabled and hasattr(self, 'peer_ip_backup'):
            if self.peer_ip_backup == 'None':
                return BP_Check(
                    138, 'Peer IP Backup', 'warn', 'fail',
                    'If HA is enabled, it is recommended to configure a Peer IP Backup.'
                )
            else:
                return BP_Check(138, 'Peer IP Backup', 'warn', 'pass', '')

    @property
    def passive_link_state_warn(self):
        if self.ha_enabled and getattr(self, 'mode', None) == 'active-passive':
            if getattr(self, 'passive_link_state', None) == 'auto':
                return BP_Check(139, 'Passive Link State', 'warn', 'pass', '')
            else:
                return BP_Check(
                    139, 'Passive Link State', 'warn', 'fail',
                    'It is recommended to set the Passive Link State to "Auto".'
                )

    @property
    def preemptive_enabled_warn(self):
        if self.ha_enabled:
            if not self.preemptive_enabled:
                return BP_Check(
                    140, 'Preemptive', 'note', 'warning',
                    'Disabling Preemptive is good in environments that need minimal failover events or want to do '
                    'root cause analysis for failover event. If we want the primary device to resume '
                    'as active, Preemptive should be enabled.'
                )
            else:
                return BP_Check(
                    140, 'Preemptive', 'note', 'warning',
                    'Enabling Preemptive is good if we want the primary device to resume as active. '
                    'If we want minimal failover events or want to do root cause analysis for failover events, '
                    'Preemptive should be disabled.'
                )

    @property
    def heartbeat_backup_enabled_warn(self):
        """If HA1 and HA1-backup are configured with data plane ports -> Heartbeat backup is needed.
        If Mgmt port  is used as HA1 bkup -> Heartbeat backup is not needed.
        """
        if self.ha_enabled and hasattr(self, 'heartbeat_backup_enabled') and self.ha1_backup_port != 'management':
            if not self.heartbeat_backup_enabled:
                return BP_Check(
                    141, 'Heartbeat Backup', 'warn', 'fail',
                    'It is recommended to enable "Heartbeat Backup".'
                )
            else:
                return BP_Check(141, 'Heartbeat Backup', 'warn', 'pass', '')

    @property
    def timers_warn(self):
        if self.ha_enabled:
            if self.timers != 'recommended':
                return BP_Check(
                    142, 'HA Timer Settings', 'warn', 'fail',
                    'It is recommended to set "HA Timer Settings" to "Recommended".')
            else:
                return BP_Check(142, 'HA Timer Settings', 'warn', 'pass', '')

    @property
    def ha1_encryption_enabled_warn(self):
        if self.ha_enabled and hasattr(self, 'ha1_encryption_enabled'):
            if not self.ha1_encryption_enabled:
                return BP_Check(
                    143, 'HA1 Encryption', 'note', 'warning',
                    'HA1 encryption needed only if the HA pair firewalls are physically far apart OR '
                    'HA1 connection goes through a network device where the HA1 traffic '
                    'can be inspected or packet capture made.'
                )

    @property
    def ha2_session_sync_enabled_warn(self):
        if self.ha_enabled and hasattr(self, 'ha2_session_sync_enabled'):
            if not self.ha2_session_sync_enabled:
                return BP_Check(
                    144, 'HA2 Session Sycnronization', 'warn', 'fail',
                    'It is recommended to enable "Session Sycnronization".'
                )
            else:
                return BP_Check(144, 'HA2 Session Sycnronization', 'warn', 'pass', '')

    @property
    def ha2_keep_alive_enabled_warn(self):
        if self.ha_enabled and hasattr(self, 'ha2_keep_alive_enabled'):
            if not self.ha2_keep_alive_enabled:
                return BP_Check(
                    145, 'HA2 Keep-alive', 'warn', 'fail',
                    'It is recommended to enable "HA2 Keep-alive".'
                )
            else:
                return BP_Check(145, 'HA2 Keep-alive', 'warn', 'pass', '')

    @property
    def ha2_action_warn(self):
        if self.ha_enabled and hasattr(self, 'ha2_action'):
            if self.ha2_action != 'log-only':
                return BP_Check(
                    146, 'HA2 Keep-alive Action', 'warn', 'fail',
                    'It is recommended to set the "Keep-alive Action" to "log-only".')
            else:
                return BP_Check(146, 'HA2 Keep-alive Action', 'warn', 'pass', '')

    @property
    def ha3_interface_warn(self):
        if hasattr(self, 'mode') and self.mode == 'active-active':
            if self.ha3_interface == 'None':
                return BP_Check(
                    147, 'HA3 Interface', 'warn', 'fail',
                    'When using Active-Active mode, you must configure an HA3 interface.'
                )
            else:
                return BP_Check(147, 'HA3 Interface', 'warn', 'pass', '')

    # TODO(Andrew) Sync with Samshodh on the logic for this check
    @property
    def ha3_session_owner_selection_warn(self):
        if hasattr(self, 'mode') and self.mode == 'active-active':
            if self.ha3_session_owner_selection != 'primary-device':
                return BP_Check(
                    148, 'HA3 Session Owner Selection', 'warn', 'pass', '')
            else:
                return BP_Check(
                    148, 'HA3 Session Owner Selection', 'warn', 'fail',
                    'When using Active-Active mode, it is recommended to use "first-packet" '
                    'for the Session Owner Selection.'
                )

    @property
    def record(self):
        return {'configuration': self.__dict__, 'bp_check': self.get_bp_checks()}


class HighAvailabilityLinkPathMonitoring(Base):
    """
    Link Monitoring and Path Monitoring are ENABLED by default.
    Link Monitoring does not exist on Panorama.
    Values do not show up in XML unless modified from defaults.
    """
    xpath = '//deviceconfig/high-availability'

    def __init__(self, entry, panorama=False):
        super(
            HighAvailabilityLinkPathMonitoring,
            self).__init__(
            entry,
            panorama)
        self.ha_enabled = bool_attr(entry, 'enabled/text()')

        if self.panorama and not hasattr(self, 'template_name'):
            _path_monitoring_enabled = str_attr(
                entry, 'path-monitoring/enabled', 'yes')
            path_groups = entry.xpath('path-monitoring/path-group/entry[destination-ip/member]')
            self.ip_destination_set = False
            self.one_group_enabled = False
            for path in path_groups:
                _ip = path.findtext('destination-ip/member', 'None')
                _one_group_enabled = path.findtext('enabled', 'yes')

                if _ip != 'None':
                    self.ip_destination_set = True
                if _one_group_enabled == 'yes':
                    self.one_group_enabled = True
                # Checks that same line has enabled and ip destination set
                if self.ip_destination_set and self.one_group_enabled:
                    break
                else:
                    self.ip_destination_set = False
                    self.one_group_enabled = False

        else:  # NGFW or templates
            _path_monitoring_enabled = str_attr(
                entry, 'group/entry/monitoring/path-monitoring/enabled', 'yes')
            path_groups = entry.xpath('group/monitoring/path-monitoring/path-group/*/entry[destination-ip/member]')
            self.ip_destination_set = False
            self.ip_source_set = False
            self.one_group_enabled = False

            for path in path_groups:
                _ip_destination = path.findtext('destination-ip/member', 'None')
                _ip_source = path.findtext('source-ip', 'None')
                _one_group_enabled = path.findtext('enabled', 'yes')

                if _ip_destination != 'None':
                    self.ip_destination_set = True
                if _ip_source != 'None':
                    self.ip_source_set = True

                if _one_group_enabled == 'yes':
                    self.one_group_enabled = True
                # Checks that same line has enabled and ip destination set
                if self.ip_destination_set and self.ip_source_set and self.one_group_enabled:
                    break
                else:
                    self.ip_destination_set = False
                    self.ip_source_set = False
                    self.one_group_enabled = False

            self.link_monitoring_enabled = str_attr(
                entry, 'group/entry/monitoring/link-monitoring/enabled', 'yes') == 'yes'

            self.link_monitoring_groups = entry.xpath(
                'group/entry/monitoring/link-monitoring/link-group/entry[interface/member]/@name')

            # These can only be configured on NGFW and templates
            self.path_monitoring_groups_vrouter = entry.xpath(
                'group/entry/monitoring/path-monitoring/path-group/virtual-router'
                '/entry[destination-ip/member]/@name')
            self.path_monitoring_groups_vlan = entry.xpath(
                'group/entry/monitoring/path-monitoring/path-group/vlan'
                '/entry[destination-ip/member]/@name')
            self.path_monitoring_groups_vwire = entry.xpath(
                'group/entry/monitoring/path-monitoring/path-group/virtual-wire'
                '/entry[destination-ip/member]/@name')

        self.path_monitoring_enabled = _path_monitoring_enabled == 'yes'

    @property
    def link_path_monitoring_warn(self):
        if self.ha_enabled:
            if not any(
                    [
                        self.path_monitoring_enabled,
                        getattr(self, 'link_monitoring_enabled', None)
                    ]):
                return BP_Check(
                    149, 'Link / Path Monitoring', 'warn', 'fail',
                    'It is recommended to enable and configure Link Monitoring or Path Monitoring.'
                )
            else:
                return BP_Check(149, 'Link / Path Monitoring', 'warn', 'pass', '')

    @property
    def link_monitoring_groups_warn(self):
        if self.ha_enabled and getattr(self, 'link_monitoring_enabled', False):
            if not self.link_monitoring_groups:
                return BP_Check(
                    150, 'Link Monitoring', 'warn', 'fail',
                    'If Link Monitoring is enabled, it is recommended to configure '
                    'at least one Link Group.')
            else:
                return BP_Check(150, 'Link Monitoring', 'warn', 'pass', '')

    @property
    def path_monitoring_groups_warn(self):
        # If HA is disabled then Path monitoring is not needed to be checked or any check under HA should not be checked
        # If HA is enabled then all BP checks under HA settings should be applied for processing.
        message_lst = []
        if self.ha_enabled:
            if not self.path_monitoring_enabled:
                message_lst.append(
                    'If High Availability (HA) is enabled, it is recommended to enable Path Monitoring'
                )
            if not self.panorama:
                using_path_group = any(
                    [
                        self.path_monitoring_groups_vwire,
                        self.path_monitoring_groups_vlan,
                        self.path_monitoring_groups_vrouter
                    ]
                )
                if not using_path_group:
                    message_lst.append(
                        'If Path Monitoring is enabled, it is recommended to configure at least one of the following:'
                        'Path Monitoring Groups Vlan, Path Monitoring Groups Vwire or Path Monitoring Groups Vrouter'
                    )

                if not self.ip_destination_set:
                    message_lst.append(
                        'If Path Monitoring is enabled, it is recommended to configure and set Destination IP for at least one Path Group'
                    )

                if not self.one_group_enabled:
                    message_lst.append(
                        'If Path Monitoring is enabled, it is recommended to configure and enable at least one Path Group'
                    )
            else:
                if not self.ip_destination_set:
                    message_lst.append(
                        'If Path Monitoring is enabled, it is recommended to configure and set Destination IP for at least one Path Group'
                    )
                if not self.one_group_enabled:
                    message_lst.append(
                        'If Path Monitoring is enabled, it is recommended to configure and enable at least one Path Group'
                    )
            if message_lst:
                return BP_Check(
                    151, 'Path Monitoring', 'warn', 'fail', ' AND '.join(message_lst))
            else:
                return BP_Check(151, 'Path Monitoring', 'warn', 'pass', '')

    @property
    def record(self):
        return {'configuration': self.__dict__, 'bp_check': self.get_bp_checks()}
