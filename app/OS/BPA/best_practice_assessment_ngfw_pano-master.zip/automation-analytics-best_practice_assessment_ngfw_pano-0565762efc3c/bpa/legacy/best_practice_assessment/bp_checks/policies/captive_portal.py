# -*- coding: utf-8 -*-
"""
Created on Thu Feb 02 09:12:42 2017

@author: anmendoza
"""
import weakref

from bpa.models import device
from ..warn_note import BP_Check
from ..base import Base


class CaptivePortalRule(Base):
    # In PAN-OS 8.0, node tag changes from "captive-portal" to "authentication"
    xpath = '//*[name()="captive-portal" or name()="authentication"]/rules/entry'

    def __init__(self, entry, xml_config, panorama=False):
        self._xml_config = weakref.ref(xml_config)
        self.name = entry.get('name')
        self.source_zones = entry.xpath('from/member/text()')
        self.destination_zones = entry.xpath('to/member/text()')
        self.source_addresses = entry.xpath('source/member/text()')
        self.destination_addresses = entry.xpath('destination/member/text()')
        self.services = entry.xpath('service/member/text()')
        # In PAN-OS 8.0, node tag changes from "action" to "authentication-enforcement"
        self.action = entry.xpath('*[name()="action" or name()="authentication-enforcement"]/text()').pop()
        self.timeout = int(entry.findtext('timeout', 60))
        panorama = panorama or entry.find('mgt-config/devices') is not None
        if panorama:
            self.vsys = 'shared' if entry.xpath('ancestor::shared') else entry.xpath('ancestor::entry/@name').pop()
            self.rulebase = entry.getparent().getparent().getparent().tag

    def get_auth_object(self, auth_obj_name):
        """Get Auth Object with given name"""
        return next(obj for obj in self._xml_config().collector.get('authentication_object') if obj.name == auth_obj_name)

    def get_auth_prof_seq(self, auth_prof_name):
        """Get Auth Profile or Sequence with given name"""
        try:
            return next(prof for prof in self._xml_config().collector.get('authentication_profile') if prof.name == auth_prof_name)
        except StopIteration:
            return next(seq for seq in self._xml_config().collector.get('authentication_sequence') if seq.name == auth_prof_name)

    def _using_kerberos_auth_prof(self, auth_prof_name: str) -> bool:
        """Checks whether Auth Profile is using Kerberos as the method.
        If Auth Sequence, checks wehther ANY of the profiles are using Kerberos as the method.
        """
        auth_profile = self.get_auth_prof_seq(auth_prof_name)
        if isinstance(auth_profile, device.authentication_profile.AuthenticationProfile):
            return auth_profile.method == 'kerberos'
        elif isinstance(auth_profile, device.authentication_sequence.AuthenticationSequence):
            return any(prof.method == 'kerberos' for prof in auth_profile.auth_profile_objs())
        raise ValueError(f'{auth_prof_name} is not an Auth Profile or Sequence.')

    @property
    def internal_zones_warn(self):
        """Skip this check if action is no-captive-portal
        If default-browser-challenge > fail
        If default-web-form > pass
        If custom authentication enforcement with a method of web-form > pass
        If custom authentication enforcement with a method of browser-challenge and Kerberos auth profile > pass
        """

        if self.action.endswith('no-captive-portal'):
            return

        def passing():
            if self.action in ['web-form', 'default-web-form']:
                return True
            elif self.action in ['browser-challenge', 'default-browser-challenge']:
                return False
            else:
                # Custom Authentication Object is being used
                auth_object = self.get_auth_object(self.action)
                if auth_object.authentication_method == 'web-form':
                    return True
                return self._using_kerberos_auth_prof(auth_object.authentication_profile)

        if passing():
            return BP_Check(
                22, 'Internal Zones Pass Through Captive Portal', 'warn', 'pass',
                'Ensure Internal zones are included in captive portal policy to learn User ID'
            )
        else:
            return BP_Check(
                22, 'Internal Zones Pass Through Captive Portal', 'warn', 'fail',
                'Authentication Enforcement should be either default-web-form or '
                'browser-challenge using a Kerberos Authentication Profile.'
            )

    @property
    def services_warn(self):
        """Warn if services do not include both http and https."""
        if not all(service in self.services for service in ['service-http', 'service-https']):
            return BP_Check(
                23, 'Services Include http and https', 'warn', 'fail',
                'Services do not include both http and https'
            )
        else:
            return BP_Check(23, 'Services Include http and https', 'warn', 'pass', '')

    @property
    def action_note(self):
        """Warn if action is not either web-form or browser-challenge."""
        if self.action in ['web-form', 'default-web-form']:
            return BP_Check(
                25, 'Captive Portal Rule Action', 'note', '',
                'Action is currently set to web-form, but it is recommended to use browser-challenge'
            )

    @property
    def no_action_note(self):
        """Note whether policy with no-captive-portal action is required."""
        if self.action.endswith('no-captive-portal'):
            return BP_Check(
                198, 'Captive Portal Rule No Action', 'note', '',
                'Action is currently set to no-captive-portal, so check whether the policy is still needed'
            )

    @property
    def timeout_note(self):
        """Skip note if PAN-OS < 8.0 or using custom authentication enforecement."""
        if (
                self._xml_config().version < 8 or
                self.action in ['default-web-form', 'default-browser-challenge', 'no-captive-portal']):
            return
        if self.timeout > 480:
            return BP_Check(211, 'Captive Portal Rule Timeout', 'note', 'warning', 'Timeout should be <= 480 minutes.')
        else:
            return BP_Check(
                211, 'Captive Portal Rule Timeout', 'note', 'warning',
                'For DC or critical systems set low timeout values (60 mins). '
                'For perimeter access, set timeout up to 480 minutes.'
            )
