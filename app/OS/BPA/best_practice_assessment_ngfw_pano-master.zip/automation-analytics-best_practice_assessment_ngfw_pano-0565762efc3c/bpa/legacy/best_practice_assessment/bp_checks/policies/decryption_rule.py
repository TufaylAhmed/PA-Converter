# -*- coding: utf-8 -*-
"""
Created on Tue Feb 07 08:34:53 2017

@author: anmendoza
"""
from six import iteritems

from ..warn_note import BP_Check
from ..base import Base


class DecryptionRule(Base):
    top_nav_gui = 'Policies'
    xpath = '//decryption/rules/entry'

    def __init__(self, entry, panorama=False):
        super(DecryptionRule, self).__init__(entry, panorama)
        self.name = entry.get('name')
        self.action = entry.find('action').text
        self.type = entry.find('type/').tag
        self.decryption_profile = entry.findtext('profile', 'None')
        self.categories = entry.xpath('category/member/text()')
        if self.panorama:
            self.rulebase = entry.getparent().getparent().getparent().tag

    @property
    def profile_warn(self):
        if self.decryption_profile == 'None':
            return BP_Check(
                19, 'Decryption Profile', 'warn', 'fail',
                'It is recommended for a Decryption Profile to be configured'
            )
        else:
            return BP_Check(19, 'Decryption Profile', 'warn', 'pass', '')

    @property
    def record(self):
        return {'configuration': {key: value for key, value in iteritems(self.__dict__) if key != 'panorama'},
                'bp_check': [dict(check._asdict()) for check in [self.profile_warn]]}


class DecryptionRulebase(object):
    def __init__(self, xml, vsys, device_group_hierarchy=None,
                 hierarchy=None, panorama=False):
        self.vsys = vsys

        if panorama:
            platform = 'device-group'
            rulebase = '*[self::pre-rulebase or self::post-rulebase]'
            hierarchy = ['@name="{}"'.format(name) for name in hierarchy]
            hierarchy = ' or '.join(hierarchy)
            hierarchy = '[{}]'.format(hierarchy)
            query = device_group_hierarchy[vsys]
        else:  # NGFW
            platform = 'vsys'
            rulebase = 'rulebase'
            hierarchy = ''

        query = ('/config/shared/{rulebase}/decryption/rules/entry/type/ssh-proxy | '
                 '/config/devices/entry/{platform}/entry{hierarchy}/{rulebase}'
                 '/decryption/rules/entry/type/ssh-proxy').format(rulebase=rulebase,
                                                                  platform=platform,
                                                                  hierarchy=hierarchy)
        self.ssh_proxy_decrypt_rule_exists = bool(xml.xpath(query))

        rule_logic = 'security/rules/entry[application/member[text()="ssh"] and action[text()="allow"]]'
        query = ('/config/shared/{rulebase}/{rule_logic} | '
                 '/config/devices/entry/{platform}/entry{hierarchy}/{rulebase}/{rule_logic}')
        self.ssh_security_allow_rule_exists = not not xml.xpath(query.format(rulebase=rulebase,
                                                                             platform=platform,
                                                                             hierarchy=hierarchy,
                                                                             rule_logic=rule_logic))

        rule_logic = (
            'security/rules/entry[application/member[text()="ssh-tunnel"] '
            'and action[text()="deny"]]')
        query = (
            '/config/devices/entry/{platform}/entry{hierarchy}/{rulebase}/{rule_logic}')
        self.ssh_tunnel_security_deny_rule_exists = not not xml.xpath(
            query.format(
                rulebase=rulebase, platform=platform,
                hierarchy=hierarchy, rule_logic=rule_logic))

    @property
    def ssh_proxy_ssh_tunnel_warn(self):
        if not all([self.ssh_proxy_decrypt_rule_exists,
                    self.ssh_security_allow_rule_exists,
                    self.ssh_tunnel_security_deny_rule_exists]):
            return BP_Check(
                20, 'SSH Proxy / SSH Tunnel', 'warn', 'fail',
                'It is recommended to configure SSH Proxy to detect and block SSH Tunneling '
                'and to limit user access to SSH traffic'
            )
        else:
            return BP_Check(20, 'SSH Proxy / SSH Tunnel', 'warn', 'pass', '')

    @property
    def record(self):
        return {'configuration': self.__dict__,
                'bp_check': [dict(self.ssh_proxy_ssh_tunnel_warn._asdict())]
                }


class DecryptionRulebases(object):
    """Collector class for DecryptionRulebase objects"""

    def __init__(self, xml, dgs_with_devices,
                 device_group_hierarchy, panorama=False):
        self.panorama = panorama
        self.xml = xml
        self.dgs_with_devices = dgs_with_devices.keys()
        self.device_group_hierarchy = device_group_hierarchy

    @property
    def records(self):
        """Returns a list of DecryptionRulebase objects"""
        record_lst = []
        if self.panorama:
            for device_group in self.dgs_with_devices:
                hierarchy = self.device_group_hierarchy[device_group][:-1]
                record_lst.append(
                    DecryptionRulebase(
                        xml=self.xml, vsys=device_group, hierarchy=hierarchy,
                        device_group_hierarchy=self.device_group_hierarchy, panorama=True).record)
        else:  # NGFW
            for vsys in self.xml.xpath(
                    '/config/devices/entry/vsys/entry/@name'):
                record_lst.append(DecryptionRulebase(self.xml, vsys).record)
        return record_lst
