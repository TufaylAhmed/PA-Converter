from collections import namedtuple
from six import iteritems

from ...common import tag_val

from ..warn_note import BP_Check


class DOSProtectionRulebase(object):
    xpath = '//dos/rules/entry'

    def __init__(self, xml, dgs_with_devices, device_group_hierarchy, panorama=False):
        self.panorama = panorama
        self.rulebase_dict = {}

        # panorama logic
        # look at the device groups that actually have devices
        # iterate through shared and all dg parents to find rules that hit each device group
        # check each rulebase to see if it passes or fails

        # NGFW logic
        # iterate through each vsys and shared to find rules
        # check each rulebase to see if it passes or fails

        DOS_Protection_Rule = namedtuple('DOS_Protection_Rule', ['name', 'action'])

        shared_dos_rules = xml.xpath(
            ('/config/shared/*[self::rulebase | self::pre-rulebase | '
             'self::post-rulebase]/dos/rules/entry'))

        if panorama:
            for device_group_with_devices in dgs_with_devices.keys():
                # shared is always last in the list, so exclude sicne it has a
                # different xpath
                hierarchy = device_group_hierarchy[device_group_with_devices][:-1]

                # join device group and all of its ancestors into a single selector
                # for querying all rules in the hierarchy
                device_group_query = ' or '.join(
                    ['@name="{}"'.format(device_group) for device_group in hierarchy])
                device_group_dos_rules = xml.xpath(
                    ('/config/devices/entry/device-group/entry[{}]/*[self::pre-rulebase | '
                     'self::post-rulebase]/dos/rules/entry').format(device_group_query))
                self.rulebase_dict[device_group_with_devices] = (
                    [DOS_Protection_Rule(
                        entry.get('name'), tag_val(entry, 'action/*', 'No action'))
                        for entry in list(shared_dos_rules + device_group_dos_rules)])
        else:  # NGFW
            for vsys in xml.xpath('/config/devices/entry/vsys/entry/@name'):
                dos_protection_rules = xml.xpath(
                    '/config/devices/entry/vsys/entry[@name="{}"]'
                    '/rulebase/dos/rules/entry'.format(vsys))
                self.rulebase_dict[vsys] = (
                    [DOS_Protection_Rule(
                        entry.get('name'), tag_val(entry, 'action/*', 'No action'))
                        for entry in list(shared_dos_rules + dos_protection_rules)]
                )

    @staticmethod
    def protect_deny_rules_warn(rulebase):
        """
        Generates a BP_Check for a given rulebase
        """
        # TODO - build logic to check actual number of destination addresses on each rule.
        protect_rules = all(rule.action == 'protect' for rule in rulebase)
        if not protect_rules:
            return BP_Check(
                26, 'DOS Protection Rules', 'warn', 'fail',
                'Ensure that all DOS Protection Rules have an action of "Protect" '
                'and the number of Destination Addresses is limited.'
            )
        else:
            return BP_Check(
                26, 'DOS Protection Rules', 'warn', 'pass',
                'Ensure the number of Destination Addresses is limited.'
            )

    @property
    def records(self):
        # create a record for each rulebase and store in list
        record_lst = []

        # platform refers to device group or vsys
        for platform, rulebase in iteritems(self.rulebase_dict):
            if not rulebase:
                continue

            configuration = {
                'rules': [dict(rule._asdict()) for rule in rulebase]}
            configuration['vsys'] = platform
            bp_check = [
                dict(DOSProtectionRulebase.protect_deny_rules_warn(rulebase)._asdict())
            ]
            record_lst.append({'configuration': configuration, 'bp_check': bp_check})

        return record_lst
