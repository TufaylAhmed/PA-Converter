# -*- coding: utf-8 -*-
"""
Created on Thu Feb 02 09:24:48 2017

@author: anmendoza
"""
from collections import namedtuple

from ...common import bool_attr
from ..warn_note import BP_Check
from ..base import Base


class DNSProxy(Base):
    xpath = '//dns-proxy/entry'

    def __init__(self, entry):
        super(DNSProxy, self).__init__(entry)
        self.name = entry.get('name')
        self.enabled = entry.find('enabled') is not None
        self.cache = bool_attr(entry, 'cache/enabled/text()')
        self.interfaces = entry.find('interface') is not None
        self.entry = entry

    @property
    def rules(self):
        DNSProxyRule = namedtuple('DNSProxyRule', ['name', 'cacheable'])
        return [DNSProxyRule(rule.get('name'), rule.find('cacheable').text) for rule
                in self.entry.findall('domain-servers/entry')]

    @property
    def missing_rules_note(self):
        if not self.rules:
            return BP_Check(
                'DNS Proxy Rulebase', 'note', '',
                'Consider adding DNS Proxy rules to {}'.format(self.name))
        else:
            return None

    @property
    def rules_note(self):
        uncached_rules = [
            rule.name for rule in self.rules if rule.cacheable == 'no']
        if uncached_rules:
            return BP_Check(
                'DNS Proxy Rule Caching', 'note', '',
                'Turn on caching for the following DNS Proxy Rule(s): {}'.format(
                    ' AND '.join(uncached_rules)))
        else:
            return None

    @property
    def interfaces_note(self):
        if self.interfaces:
            return BP_Check(
                'Internal Interfaces', 'note', '',
                'Since you are using interfaces, note that they must all be internal')
        else:
            return None

    @property
    def cache_note(self):
        if not self.cache:
            return BP_Check(
                'DNS Proxy Caching', 'note', '',
                'If possible, you should enable cache for better performance')
        else:
            return None

    @property
    def record(self):
        rules = [{x.name: x.cacheable} for x in self.rules]
        configuration = {'name': self.name, 'enabled': self.enabled, 'cache': self.cache,
                         'interfaces': self.interfaces, 'rules': rules, 'vsys': self.vsys}
        if self.panorama:
            configuration['template_name'] = self.template_name

        return {'configuration': configuration,
                'bp_check': self.get_bp_checks()}
