# -*- coding: utf-8 -*-
"""
Created on Thu Feb 02 09:14:41 2017

@author: anmendoza
"""

from collections import namedtuple

BP_Check = namedtuple('BP_Check', ['id', 'name', 'type', 'result', 'message'])
