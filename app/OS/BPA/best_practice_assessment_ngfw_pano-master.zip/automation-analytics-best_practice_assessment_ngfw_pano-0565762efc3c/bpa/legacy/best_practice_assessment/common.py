import math


def validate_text_xpath(xpath):
    """Adds /text() to end of XPATH query if it is missing."""
    if not xpath.endswith('/text()'):
        xpath = '%s/text()' % xpath
    return xpath


def bool_attr(el, xpath, true_val='yes'):
    """Returns a boolean indicating whether the text node
    contains a specific value."""
    return true_val in el.xpath(validate_text_xpath(xpath))


def num_attr(el, xpath, default_val):
    """Returns an integer value stored in a text node.
    If the node does not exist, return the default value."""
    num = el.xpath('number(%s)' % validate_text_xpath(xpath))
    if math.isnan(num):
        return default_val
    else:
        # number() returns a float, so cast to int before returning
        return int(num)


def str_attr(el, xpath, default_val=''):
    """Returns a node's text value if it exists,
    otherwise returns the default value."""
    try:
        return el.find(xpath).text
    except AttributeError:
        return default_val


def tag_val(el, xpath, default_val, override_val=''):
    """Returns the value of an element's tag.

    If the element does not exist, or the tag matches the
    override_val, return the default_val."""
    try:
        tag = el.find(xpath).tag
    except BaseException:
        tag = default_val
    else:
        if tag == override_val:
            tag = default_val
    finally:
        return tag
