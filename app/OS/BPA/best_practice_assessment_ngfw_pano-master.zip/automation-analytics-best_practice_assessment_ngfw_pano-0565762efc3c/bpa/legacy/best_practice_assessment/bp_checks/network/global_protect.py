# -*- coding: utf-8 -*-
"""
Created on Tue Feb 14 09:41:28 2017

@author: anmendoza
"""
# https://jira-hq.paloaltonetworks.local/browse/CST-19
from __future__ import unicode_literals
from six import iteritems
from collections import namedtuple
import weakref

from ...common import bool_attr
from ..warn_note import BP_Check
from ..base import Base


class AuthClient(object):
    """GP Gateway / Portal > Authentication Client configuration."""
    def __init__(self, entry, xml_config):
        self._xml_config = xml_config
        self.name = entry.get('name')
        self.auth_prof = entry.findtext('authentication-profile')
        self.auth_profile_type = self.get_prof_type()

    def get_obj(self, feature_type, name):
        """Helper for getting an auth profile or auth sequence."""
        return next(
            f for f in self._xml_config().collector.get(feature_type)
            if f.name == name
        )

    def get_prof_type(self):
        """Get authentication type for a given auth profile name."""
        try:
            return self.get_obj('authentication_profiles', self.auth_prof).method
        except StopIteration:
            return 'sequence'

    def using_radius_saml(self):
        """Checks whether SAML or Radius authentication is used.

        For Auth Profiles, check that the Auth Type is either Radius or SAML.
        For Auth Sequences, check that each profile in the sequence has an Auth Type of
        either Radius or SAML.
        """
        if self.auth_profile_type == 'sequence':
            return self.get_obj('authentication_sequences', self.auth_prof).using_radius_saml()
        else:
            return self.auth_profile_type in ['radius', 'saml-idp']

    def json(self):
        """Return JSON-serializable object"""
        return {
            'name': self.name,
            'auth_profile': self.auth_prof,
            'auth_type': self.auth_profile_type,
        }

    @classmethod
    def get_auth_clients(cls, gp_parent):
        """Return a list of AuthClient objects"""
        # XPATH is different for GP Portal and GP Gateway
        if isinstance(gp_parent, GlobalProtectPortal):
            xpath = 'portal-config/client-auth/entry'
        else:
            xpath = 'client-auth/entry'
        return [cls(e, gp_parent._xml_config) for e in gp_parent.entry.findall(xpath)]


class GlobalProtectPortal(Base):
    xpath = '//global-protect/global-protect-portal/entry'

    def __init__(self, entry, xml_config, panorama=False):
        super(GlobalProtectPortal, self).__init__(entry, panorama)
        self._xml_config = weakref.ref(xml_config)
        self.entry = entry
        self.version = entry.getroottree().getroot().get('version')
        self.name = entry.get('name')
        self.satellite_trusted_root_ca = entry.xpath('satellite-config/root-ca/member/text()')
        self.agent_trusted_root_ca = entry.xpath('client-config/root-ca/entry/@name')
        self.ssl_tls_service_profile = entry.findtext('portal-config/ssl-tls-service-profile', 'None')

        if self.ssl_tls_service_profile == 'None':
            self.ssl_tls_service_profile_min_version = 'None'
        else:
            try:
                self.ssl_tls_service_profile_min_version = entry.xpath(
                    ('//ssl-tls-service-profile/entry[@name="{}"]/protocol-settings/min-version'
                     '/text()').format(self.ssl_tls_service_profile))[0]
            except BaseException:
                self.ssl_tls_service_profile_min_version = 'tls1-0'

        self.certificate_profile = entry.findtext('portal-config/certificate-profile', 'None')
        self.satellite_ocsp_responder = entry.findtext('satellite-config/client-certificate/local/ocsp-responder', 'None')
        self.auth_clients = AuthClient.get_auth_clients(self)

    # TODO(Andrew) Rewrite as class
    @property
    def agent_configs(self):
        agent_configs_lst = []
        Agent_Config = namedtuple('Agent_Config',
                                  ['name', 'save_user_credentials', 'two_factor_authentication',
                                   'internal_host_detection_enabled',
                                   'continue_with_invalid_portal_server_cert',
                                   'enforce_gp_connection_for_network_access', 'collect_hip_data_enabled',
                                   'external_gateway_ips', 'disable_timeout'])

        save_user_credentials_dict = {'0': 'No', '1': 'Yes', '2': 'Save Username Only'}

        for agent_config in self.entry.findall('client-config/configs/entry'):
            name = agent_config.get('name')
            save_user_credentials = save_user_credentials_dict[agent_config.findtext('save-user-credentials', '0')]
            two_factor_authentication = [
                two_factor.tag for two_factor in agent_config.getchildren()
                if two_factor.tag.endswith('-2fa')
            ]
            internal_host_detection_enabled = agent_config.find('internal-host-detection') is not None

            continue_with_invalid_portal_server_cert = (
                'Yes' if agent_config.xpath(
                    'gp-app-config/config/entry[@name="can-continue-if-portal-cert-invalid"]'
                    '/value/member[text()="yes"]') else 'No')

            enforce_gp_connection_for_network_access = (
                'Yes' if agent_config.xpath(
                    'gp-app-config/config/entry[@name="enforce-globalprotect"]'
                    '/value/member[text()="yes"]') else 'No')

            collect_hip_data_enabled = bool_attr(
                agent_config, 'hip-collection/collect-hip-data/text()')

            if int(self.version[0]) < 8:
                external_gateway_ips = agent_config.xpath(
                    'gateways/external/list/entry/@name')
            else:
                external_gateway_ips = agent_config.xpath(
                    'gateways/external/list/entry/ip/*[self::ipv4 or self::ipv6]/text()')

            disable_timeout = int(agent_config.findtext('agent-ui/agent-user-override-timeout', 0))

            agent_configs_lst.append(
                Agent_Config(
                    name, save_user_credentials, two_factor_authentication,
                    internal_host_detection_enabled,
                    continue_with_invalid_portal_server_cert,
                    enforce_gp_connection_for_network_access,
                    collect_hip_data_enabled, external_gateway_ips, disable_timeout))

        return agent_configs_lst

    @property
    def ssl_tls_service_profile_min_version_warn(self):
        if self.ssl_tls_service_profile_min_version != 'tls1-2':
            return BP_Check(
                63, 'GP Portal Server Authentication', 'warn', 'fail',
                'The SSL/TLS Server Profile you are using ({}) has a Min Version other than '
                'TLSv1.2'.format(self.ssl_tls_service_profile)
            )
        else:
            return BP_Check(63, 'GP Portal Server Authentication', 'warn', 'pass', '')

    @property
    def certificate_profile_warn(self):
        """Two ways for check to pass:

        1) GP Gateway > Authentication Tab > Client Authentication > Authentication Profiles all have Authentication Type of Radius or SAML
        2) GP Gateway > Authentication Tab > Client Authentication > Configured with auth profile of any type
            AND Certificate Profile is configured.
        """
        if self.certificate_profile != 'None':
            return BP_Check(64, 'GP Portal Client Authentication', 'warn', 'pass', '')
        if not self.auth_clients:
            return BP_Check(
                64, 'GP Portal Client Authentication', 'warn', 'fail',
                'It is recommended to utilize a Certificate Profile or have all '
                'Client Authentication configs use Radius or SAML for authentication'
            )
        bad_clients = [client.name for client in self.auth_clients if not client.using_radius_saml()]
        if bad_clients:
            return BP_Check(
                64, 'GP Portal Client Authentication', 'warn', 'fail',
                'The following Client Authentication configs are not '
                f'configured to use Radius or SAML: {", ".join(bad_clients)}'
            )
        return BP_Check(64, 'GP Portal Client Authentication', 'warn', 'pass', '')

    @property
    def agent_trusted_root_ca_warn(self):
        if not self.agent_trusted_root_ca:
            return BP_Check(
                65, 'GP Portal Agent Trusted Root CA', 'warn', 'fail',
                'It is recommended to utilize Agent Trusted Root CA')
        else:
            return BP_Check(
                65, 'GP Portal Agent Trusted Root CA', 'note', 'warning',
                'To have the endpoints trust the GP Portal and GP Gateway Server Certificate, '
                'they should have the Root/Intermediate Certificates installed '
                'that have signed the Server Certificates.'
            )

    @property
    def save_user_credentials_warn(self):
        """If PAN-OS < 8, check whether one of the GP Portal Agent Configs has Save User Credentials = YES

        If PAN-OS >= 8, check whether CP Portal > Authentication > Client Authentication are all using a
        valid Authentication Profile (i.e. type = RADIUS, server profile = valid RADIUS server profile)
        """
        saving_user_credentials = [config.name for config in self.agent_configs
                                   if config.save_user_credentials == 'Yes']
        if saving_user_credentials:
            return BP_Check(
                66, 'GP Portal Agent Config Save User Credentials', 'warn', 'fail',
                'It is not recommended save use credentials. Please change on the following '
                'Agent Configs: {}'.format(', '.join(saving_user_credentials)))
        else:
            return BP_Check(
                66, 'GP Portal Agent Config Save User Credentials', 'warn', 'pass', '')

    @property
    def two_factor_authentication_warn(self):
        no_two_factor_auth = [config.name for config in self.agent_configs
                              if not config.two_factor_authentication]
        if no_two_factor_auth:
            return BP_Check(
                67, 'GP Portal Agent Config Two-Factor Authentication', 'warn', 'fail',
                'It is recommended use some form of two-factor authentication. Please add to '
                'the following Agent Configs: {}'.format(', '.join(no_two_factor_auth)))
        else:
            return BP_Check(
                67, 'GP Portal Agent Config Two-Factor Authentication', 'warn', 'pass', '')

    @property
    def internal_host_detection_enabled_warn(self):
        no_internal_host_detection = [config.name for config in self.agent_configs
                                      if not config.internal_host_detection_enabled]
        if no_internal_host_detection:
            return BP_Check(
                68, 'GP Portal Agent Config Internal Host Detection', 'warn', 'fail',
                'It is recommended enable Internal Host Detection. Please add to the '
                'following Agent Configs: {}'.format(', '.join(no_internal_host_detection)))
        else:
            return BP_Check(
                68, 'GP Portal Agent Config Internal Host Detection', 'warn', 'pass', '')

    @property
    def using_disable_gp_app_warn(self):
        """Check passes if all disable timeout values are between 0 and 480 minutes.

        Value of 0 means unlimited timeout, so it should fail.
        """
        no_disable_timeout = [
            config.name for config in self.agent_configs
            if not 0 < config.disable_timeout < 480
        ]

        if no_disable_timeout:
            return BP_Check(
                69, 'GP Portal - Disable GlobalPortect App - Timeout', 'warn', 'fail',
                'It is recommended to set Disable Timeout to be less than 8 hours. '
                'Please adjust to the following Agent Configs: {}'.format(', '.join(no_disable_timeout))
            )
        else:
            return BP_Check(69, 'GP Portal - Disable GlobalPortect App - Timeout', 'warn', 'pass', '')

    @property
    def collect_hip_data_enabled_warn(self):
        collect_hip_data_disabled = [config.name for config in self.agent_configs
                                     if not config.collect_hip_data_enabled]
        if collect_hip_data_disabled:
            return BP_Check(
                72, 'GP Portal Agent Config Data Collection', 'warn', 'fail',
                'It is recommened to Collect HIP Data. Please enable on the following '
                'Agent Configs: {}'.format(', '.join(collect_hip_data_disabled)))
        else:
            return BP_Check(
                72, 'GP Portal Agent Config Data Collection', 'warn', 'pass', '')

    @property
    def satellite_ocsp_responder_warn(self):
        """If no satellites configed, skip the check,
        otherwise ensure GP portal has OCSP responder configured.
        """
        if self.entry.find('satellite-config/configs/entry') is None:
            return

        if self.satellite_ocsp_responder == 'None':
            return BP_Check(
                73, 'GP Portal Satellite OCSP Responder', 'warn', 'fail',
                'It is recommended to configure a Satellite OCSP Responder')
        else:
            return BP_Check(73, 'GP Portal Satellite OCSP Responder', 'warn', 'pass', '')

    @property
    def satellite_trusted_root_ca_warn(self):
        if not self.satellite_trusted_root_ca:
            return BP_Check(
                74, 'GP Portal Satellite Trusted Root CA', 'warn', 'fail',
                'It is recommended to utilize Satellite Trusted Root CA')
        else:
            return BP_Check(
                74, 'GP Portal Satellite Trusted Root CA', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {
            key: val for key, val in iteritems(self.__dict__)
            if key not in ('entry', 'version', 'panorama', 'agent_configs', 'auth_clients', '_xml_config')
        }
        configuration['agent_configs'] = [x._asdict() for x in self.agent_configs]
        configuration['auth_clients'] = [x.json() for x in self.auth_clients]

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}


class GlobalProtectGateway(Base):
    xpath = '//global-protect/global-protect-gateway/entry'

    def __init__(self, entry, xml_config, panorama=False):
        super(GlobalProtectGateway, self).__init__(entry, panorama)
        self._xml_config = weakref.ref(xml_config)
        self.entry = entry
        self.name = entry.get('name')
        self.tunnel_mode_enabled = entry.findtext('tunnel-mode', 'no') == 'yes'
        self.certificate_profile = entry.findtext('certificate-profile', 'None')
        self.ssl_tls_service_profile = entry.findtext('ssl-tls-service-profile', 'None')
        self.auth_clients = AuthClient.get_auth_clients(self)

        if self.ssl_tls_service_profile == 'None':
            self.ssl_tls_service_profile_min_version = 'None'
        else:
            try:
                self.ssl_tls_service_profile_min_version = entry.xpath(
                    '/config/shared/ssl-tls-service-profile/entry[@name="{}"]/protocol-settings'
                    '/min-version/text()'.format(self.ssl_tls_service_profile))[0]
            except IndexError:
                self.ssl_tls_service_profile_min_version = 'tls1-0'

        try:
            satellite_tunnel_settings = entry.xpath(
                '/config/devices/entry/network/tunnel/global-protect-site-to-site'
                '/entry[@name="{}-S"]/client'.format(self.name))[0]
        except IndexError:
            satellite_tunnel_settings = None
        finally:
            self.tunnel_configuration_enabled = satellite_tunnel_settings is not None

        # replay_attack_detection_enabled is enabled by default, so check for
        # the absence of elements
        if satellite_tunnel_settings is None:
            self.tunnel_monitoring_enabled = False
            self.replay_attack_detection_enabled = True
            self.ipsec_crypto_profile = 'default'
        else:
            self.tunnel_monitoring_enabled = 'no' not in satellite_tunnel_settings.xpath(
                'tunnel-monitor/enable/text()')
            self.replay_attack_detection_enabled = satellite_tunnel_settings.find(
                'anti-replay') is None
            self.ipsec_crypto_profile = satellite_tunnel_settings.find(
                'ipsec-crypto-profile').text

    @property
    def agent_configs(self):
        Agent_Config = namedtuple('Agent_Config', ['name', 'access_routes', 'no_direct_access_to_local_network'])
        agent_configs_lst = []
        for agent_config_entry in self.entry.findall('remote-user-tunnel-configs/entry'):
            name = agent_config_entry.get('name')
            access_routes = agent_config_entry.xpath('split-tunneling/access-route/member/text()')
            no_direct_access_to_local_network = agent_config_entry.findtext('no-direct-access-to-local-network', 'no') == 'yes'
            agent_configs_lst.append(Agent_Config(name, access_routes, no_direct_access_to_local_network))
        return agent_configs_lst

    @property
    def split_tunnel_warn(self):
        """Fail if any agent config doesn't have "No direct access to local network" enabled.

        Only applies when Tunnel Mode is enabled.
        """
        if not self.tunnel_mode_enabled:
            return
        bad_agents = [agent.name for agent in self.agent_configs if not agent.no_direct_access_to_local_network]
        if bad_agents:
            bad_agents = ', '.join(bad_agents)
            return BP_Check(
                71, 'GP Split Tunnel', 'warn', 'fail',
                f'The following Agent Configs do not have "No direct access to local network" enabled: {bad_agents}'
            )
        else:
            return BP_Check(71, 'GP Split Tunnel', 'warn', 'pass', '')

    @property
    def ssl_tls_service_profile_min_version_warn(self):
        if self.ssl_tls_service_profile_min_version != 'tls1-2':
            return BP_Check(
                76, 'GP Gateway Server Authentication', 'warn', 'fail',
                'The SSL/TLS Server Profile you are using ({}) has a Min Version '
                'other than TLSv1.2'.format(self.ssl_tls_service_profile))
        else:
            return BP_Check(76, 'GP Gateway Server Authentication', 'warn', 'pass', '')

    @property
    def certificate_profile_warn(self):
        """Two ways for check to pass:

        1) GP Gateway > Authentication Tab > Client Authentication > Authentication Profiles all have Authentication Type of Radius or SAML
        2) GP Gateway > Authentication Tab > Client Authentication > Configured with auth profile of any type
            AND Certificate Profile is configured.
        """
        if self.certificate_profile != 'None':
            return BP_Check(77, 'GP Gateway Client Authentication', 'warn', 'pass', '')
        if not self.auth_clients:
            return BP_Check(
                77, 'GP Gateway Client Authentication', 'warn', 'fail',
                'It is recommended to utilize a Certificate Profile or have all '
                'Client Authentication configs use Radius or SAML for authentication'
            )
        bad_clients = [client.name for client in self.auth_clients if not client.using_radius_saml()]
        if bad_clients:
            return BP_Check(
                77, 'GP Gateway Client Authentication', 'warn', 'fail',
                'The following Client Authentication configs are not '
                f'configured to use Radius or SAML: {", ".join(bad_clients)}'
            )
        return BP_Check(77, 'GP Gateway Client Authentication', 'warn', 'pass', '')

    @property
    def access_routes_warn(self):
        missing_routes = []
        for agent_config in self.agent_configs:
            if not any(route in agent_config.access_routes for route in ('0.0.0.0/0', '::/0')):
                missing_routes.append(agent_config.name)

        if missing_routes:
            return BP_Check(
                78, 'GP Gateway Agent Config Access Routes', 'warn', 'fail',
                'Please update the following agents so that their access routes '
                'include "0.0.0.0/0" and/or "::/0": {}'.format(', '.join(missing_routes)))
        else:
            return BP_Check(
                78, 'GP Gateway Agent Config Access Routes', 'warn', 'pass', '')

    @property
    def replay_attack_detection_warn(self):
        if self.tunnel_configuration_enabled and not self.replay_attack_detection_enabled:
            return BP_Check(
                79, 'GP Gateway Satellite Tunnel Configuration', 'warn', 'fail',
                'It is recommended to enable Replay attack detection when '
                'Tunnel Configuration is enabled'
            )
        else:
            return BP_Check(
                79, 'GP Gateway Satellite Tunnel Configuration', 'warn', 'pass', '')

    @property
    def tunnel_monitoring_warn(self):
        if self.tunnel_configuration_enabled and not self.tunnel_monitoring_enabled:
            return BP_Check(
                80, 'GP Gateway Satellite Tunnel Monitoring', 'warn', 'fail',
                'It is recommended to enable Tunnel Monitoring when '
                'Tunnel Configuration is enabled'
            )
        else:
            return BP_Check(80, 'GP Gateway Satellite Tunnel Monitoring', 'warn', 'pass', '')

    @property
    def record(self):
        configuration = {
            key: val for key, val in iteritems(self.__dict__)
            if key not in ('entry', 'agent_configs', '_xml_config', 'auth_clients')
        }
        configuration['agent_configs'] = [x._asdict() for x in self.agent_configs]
        configuration['auth_clients'] = [x.json() for x in self.auth_clients]

        return {'configuration': configuration, 'bp_check': self.get_bp_checks()}
