# -*- coding: utf-8 -*-
"""
Created on Mon Feb 13 12:59:33 2017

@author: nbitting
"""
from collections import defaultdict
from six import iteritems

from ..warn_note import BP_Check
from ..base import Base


class AuthProfile(Base):
    xpath = '//authentication-profile/entry'

    def __init__(self, entry, panorama=False):
        super(AuthProfile, self).__init__(entry, panorama)
        self.name = entry.get('name')
        self.method = entry.find('method/*').tag
        self.server_profile = entry.findtext('method/*/server-profile', 'Local')
        if self.server_profile == 'local-database':
            self.server_profile = 'Local'
        self.allow_list = entry.xpath('allow-list/member/text()')
        self.lockout_time = int(entry.findtext('lockout/lockout-time', 0))
        self.failed_attempts = int(entry.findtext('lockout/failed-attempts', 0))

    @property
    def lockout_time_warn(self):
        if 30 <= self.lockout_time <= 45:
            return BP_Check(156, 'Lockout Time', 'warn', 'pass', '')
        else:
            return BP_Check(
                156, 'Lockout Time', 'warn', 'fail',
                'It is recommended to configure lockout time to a value between 30 and 45 minutes.'
            )

    @property
    def failed_attempts_warn(self):
        if self.failed_attempts > 5:
            return BP_Check(
                157, 'Failed Attempts', 'warn', 'fail',
                'It is recommended to configure the number of failed attempts to 5 or fewer.'
            )
        else:
            return BP_Check(157, 'Failed Attempts', 'warn', 'pass', '')

    @property
    def allow_list_note(self):
        if 'all' in self.allow_list:
            return BP_Check(
                158, 'Allow List', 'note', '',
                'It is recommended to use specific users or user groups '
                'instead of "all" in the allow list.')

    @property
    def record(self):
        configuration = {'name': self.name,
                         'method': self.method,
                         'server_profile': self.server_profile,
                         'allow_list': ', '.join(self.allow_list),
                         'lockout_time': self.lockout_time,
                         'failed_attempts': self.failed_attempts}

        for possible_attribute in ['vsys', 'template_name']:
            if hasattr(self, possible_attribute):
                configuration[possible_attribute] = getattr(
                    self, possible_attribute)

        return {'configuration': configuration,
                'bp_check': self.get_bp_checks()}


class AuthProfiles(object):
    xpath = '//authentication-profile/entry'

    def __init__(self, xml, profiles, template=False, panorama=False):
        """
        Attributes:
            xml: ElementTree object representing the XML config
            profiles: List of AuthProfile records
            template: Boolean indicating whether the Auth Profiles are from templates
            panorama: Boolean indicating whether XML config is for a Panorama device
        """

        self.panorama = panorama
        self.template = template

        # if we are checking Auth Profiles in templates or a NGFW, store all
        # vsys and template (if applicable) values so we can create records
        # for vsys/template entries that do not contain an Auth Profile
        if template or not panorama:
            self.all_vsys = set()
            for vsys in xml.xpath('//config/devices/entry/vsys/entry'):
                try:
                    setting = vsys.xpath(
                        'ancestor::entry[parent::template]/@name')[0]
                except BaseException:
                    setting = 'DEVICE'
                finally:
                    self.all_vsys.add(
                        '{setting}**{vsys}'.format(setting=setting, vsys=vsys.get('name')))

        self.profiles = profiles

        if template:
            self.template_names = set(
                [profile['configuration']['template_name'] for profile in profiles])
            self.local_only_server_profile_templates = []
            for template in self.template_names:
                if all(profile['configuration']['server_profile'] ==
                       'Local' for profile in self.profiles if profile['configuration']['template_name'] == template):
                    self.local_only_server_profile_templates.append(template)

        # profile_dict will store Auth Profiles broken out by template/vsys
        self.profile_dict = defaultdict(list)
        for profile in profiles:
            # excluding shared from the record, as it will not have any devices
            if 'vsys' in profile['configuration'] and profile['configuration']['vsys'] != 'shared':
                # use template + vsys as a unique key
                # we will split on ** when creating the records
                if template:
                    self.profile_dict[profile['configuration']['template_name'] + '**' +
                                      profile['configuration']['vsys']].append(profile['configuration']['name'])
                else:
                    # NGFW, so use DEVICE in place of a template name
                    self.profile_dict['DEVICE**' + profile['configuration']
                                      ['vsys']].append(profile['configuration']['name'])
            elif panorama:
                # Panorama Auth Profiles are not in a template/vsys so use
                # PANORAMA as the key
                self.profile_dict['PANORAMA**PANORAMA'].append(
                    profile['configuration']['name'])

    def get_shared_auth_profiles(self, template_name=None):
        if template_name is None:
            return [profile['configuration']['name']
                    for profile in self.profiles if profile['configuration']['vsys'] == 'shared']
        else:
            return [profile['configuration']['name'] for profile in self.profiles if profile['configuration']
                    ['vsys'] == 'shared' and profile['configuration']['template_name'] == template_name]

    def get_no_external_auth_profiles(
            self, vsys=[], template_name=None, panorama=False):
        if panorama:
            return all(profile['configuration']['server_profile']
                       == 'Local' for profile in self.profiles)
        elif template_name is None:  # NGFW
            return all(profile['configuration']['server_profile'] ==
                       'Local' for profile in self.profiles if profile['configuration']['vsys'] in vsys + ['shared'])
        else:  # Template
            return all(profile['configuration']['server_profile'] == 'Local' for profile in self.profiles if profile['configuration']
                       ['vsys'] in vsys + ['shared'] and profile['configuration']['template_name'] == template_name)

    @property
    def records(self):
        # cache checks so they don't have to be created each iteration of the
        # loop
        bp_fail = BP_Check(
            155, 'External Admin Authentication', 'warn', 'fail',
            'At least one authentication profile should use external authentication')
        bp_pass = BP_Check(
            155, 'External Admin Authentication', 'warn', 'pass', '')

        record_lst = []

        # if panorama and no profiles exist, create a record
        if self.panorama and not self.template and not self.profiles:
            configuration = {'authentication_profiles': []}
            bp_check = bp_fail
            record_lst.append({'configuration': configuration,
                               'bp_check': [dict(bp_check._asdict())]})

        # create a record for each vsys/template missing an Auth Profile
        if hasattr(self, 'all_vsys'):
            for setting_vsys in self.all_vsys:
                if setting_vsys not in self.profile_dict:
                    setting, vsys = setting_vsys.split('**')
                    configuration = {'vsys': vsys}
                    # check in shared to see if any profiles exists that will
                    # pass
                    if setting == 'DEVICE':  # NGFW
                        shared_auth_profiles = self.get_shared_auth_profiles()
                        no_external_auth_profiles = self.get_no_external_auth_profiles(vsys=[
                                                                                       vsys])
                    else:  # Template
                        configuration['template_name'] = setting
                        shared_auth_profiles = self.get_shared_auth_profiles(
                            template_name=setting)
                        no_external_auth_profiles = self.get_no_external_auth_profiles(
                            vsys=[vsys], template_name=setting)

                    configuration['authentication_profiles'] = shared_auth_profiles

                    if no_external_auth_profiles:
                        bp_check = bp_fail
                    else:
                        bp_check = bp_pass

                    record_lst.append({'configuration': configuration,
                                       'bp_check': [dict(bp_check._asdict())]})

        # create a record for each vsys/template or Panorama that does have an
        # Auth Profile
        for setting_vsys, auth_profiles in iteritems(self.profile_dict):
            setting, vsys = setting_vsys.split('**')
            if setting != 'PANORAMA':
                configuration = {'vsys': vsys}
            else:
                configuration = {}

            if setting == 'PANORAMA':
                shared_auth_profiles = []
                no_external_auth_profiles = self.get_no_external_auth_profiles(
                    panorama=True)
            elif setting == 'DEVICE':  # NGFW
                shared_auth_profiles = self.get_shared_auth_profiles()
                no_external_auth_profiles = self.get_no_external_auth_profiles(vsys=[
                                                                               vsys])
            else:  # Template
                configuration['template_name'] = setting
                shared_auth_profiles = self.get_shared_auth_profiles(
                    template_name=setting)
                no_external_auth_profiles = self.get_no_external_auth_profiles(
                    vsys=[vsys], template_name=setting)

            configuration['authentication_profiles'] = shared_auth_profiles + auth_profiles

            if no_external_auth_profiles:
                bp_check = bp_fail
            else:
                bp_check = bp_pass

            record_lst.append({'configuration': configuration,
                               'bp_check': [bp_check._asdict()]})

        return record_lst


class AuthSequence(Base):
    xpath = '//authentication-sequence/entry'

    def __init__(self, entry, panorama=False):
        super(AuthSequence, self).__init__(entry, panorama)
        self.name = entry.get('name')
        self.auth_profiles = entry.xpath(
            'authentication-profiles/member/text()')

    @property
    def auth_profiles_note(self):
        if len(self.auth_profiles) < 2:
            # Local authentication cannot be configured on a Panorama device
            if self.panorama and not hasattr(self, 'template_name'):
                message = ''
            else:
                message = (
                    ' and to ensure an external authentication is used '
                    'before a local authentication in the sequence'
                )
            return BP_Check(
                160, 'Authentication Sequence', 'note', '',
                'It is recommended to use more than one authentication profile{}.'.format(
                    message)
            )

    @property
    def record(self):
        configuration = {
            'name': self.name,
            'authentication_sequence': ' > '.join(self.auth_profiles)
        }

        if hasattr(self, 'template_name'):
            configuration['template_name'] = self.template_name

        if hasattr(self, 'vsys'):
            configuration['vsys'] = self.vsys

        return {'configuration': configuration,
                'bp_check': self.get_bp_checks()}


class AuthSequences(object):
    xpath = '//authentication-sequence/entry'
    top_nav_gui = 'Device'
    left_nav_gui = 'Authentication Sequence'

    def __init__(self, xml, sequences, template=False, panorama=False):
        self.panorama = panorama
        self.template = template

        if template or not panorama:
            self.all_vsys = set()
            for vsys in xml.xpath('//config/devices/entry/vsys/entry'):
                try:
                    setting = vsys.xpath(
                        'ancestor::entry[parent::template]/@name')[0]
                except BaseException:
                    setting = 'DEVICE'
                finally:
                    self.all_vsys.add(
                        '{setting}**{vsys}'.format(setting=setting, vsys=vsys.get('name')))

        self.sequences = sequences

        self.sequence_dict = defaultdict(list)
        for sequence in sequences:
            # excluding shared from the record, as it will not have any devices
            if 'vsys' in sequence['configuration'] and sequence['configuration']['vsys'] != 'shared':
                # use template + vsys as a unique key
                # we will split on ** when creating the records
                if template:
                    self.sequence_dict[sequence['configuration']['template_name'] + '**' +
                                       sequence['configuration']['vsys']].append(sequence['configuration']['name'])
                else:
                    # NGFW, so use DEVICE in place of a template name
                    self.sequence_dict['DEVICE**' + sequence['configuration']['vsys']].append(
                        sequence['configuration']['name']
                    )
            elif panorama:
                # Panorama Auth Profiles are not in a template/vsys so use
                # PANORAMA as the key
                self.sequence_dict['PANORAMA**PANORAMA'].append(
                    sequence['configuration']['name'])

    def get_shared_auth_sequences(self, template_name=None):
        if template_name is None:
            return [
                sequence['configuration']['name'] for sequence in self.sequences
                if sequence['configuration']['vsys'] == 'shared'
            ]
        else:
            return [
                sequence['configuration']['name'] for sequence in self.sequences
                if sequence['configuration']['vsys'] == 'shared'
                and sequence['configuration']['template_name'] == template_name
            ]

    def get_no_multi_profile_auth_sequences(
            self, vsys=[], template_name=None, panorama=False):
        if panorama:
            return all(
                ' > ' not in sequence['configuration']['authentication_sequence']
                for sequence in self.sequences
            )
        elif template_name is None:  # NGFW
            return all(
                ' > ' not in sequence['configuration']['authentication_sequence']
                for sequence in self.sequences
                if sequence['configuration']['vsys'] in vsys + ['shared']
            )
        else:  # Template
            return all(
                ' > ' not in sequence['configuration']['authentication_sequence']
                for sequence in self.sequences
                if sequence['configuration']['vsys'] in vsys + ['shared']
                and sequence['configuration']['template_name'] == template_name
            )

    @property
    def records(self):
        bp_fail = BP_Check(
            159, 'Existence of Authentication Sequence', 'warn', 'fail',
            'At least one authentication sequence with two or more profiles should be defined')
        bp_pass = BP_Check(
            159, 'Existence of Authentication Sequence', 'warn', 'pass', '')

        # create a record for each template/vsys or Panorama
        record_lst = []

        # if panorama and no sequences exist, create a record
        if self.panorama and not self.template and not self.sequences:
            configuration = {'name': 'Aggregate Auth Sequence Check',
                             'auth_sequences': []}
            bp_check = bp_fail
            record_lst.append(
                {'configuration': configuration, 'bp_check': [dict(bp_check._asdict())]})

        # create a record for each template/vsys that does not have an Auth
        # Sequence
        if hasattr(self, 'all_vsys'):
            for setting_vsys in self.all_vsys:
                if setting_vsys not in self.sequence_dict:
                    setting, vsys = setting_vsys.split('**')
                    configuration = {'name': 'Aggregate Auth Sequence Check',
                                     'vsys': vsys}
                    # check in shared to see if any sequences exists that will
                    # pass
                    if setting == 'DEVICE':
                        shared_auth_sequences = self.get_shared_auth_sequences()
                        no_multi_profile_auth_sequences = self.get_no_multi_profile_auth_sequences(vsys=[
                                                                                                   vsys])
                    else:  # Template
                        configuration['template_name'] = setting
                        shared_auth_sequences = self.get_shared_auth_sequences(
                            template_name=setting)
                        no_multi_profile_auth_sequences = self.get_no_multi_profile_auth_sequences(
                            vsys=[vsys], template_name=setting)

                    configuration['authentication_sequences'] = shared_auth_sequences

                    if no_multi_profile_auth_sequences:
                        bp_check = bp_fail
                    else:
                        bp_check = bp_pass

                    record_lst.append({'configuration': configuration,
                                       'bp_check': [dict(bp_check._asdict())]})

        # create a record for each vsys/template or Panorama that does have an
        # Auth Sequence
        for setting_vsys, auth_sequences in iteritems(self.sequence_dict):
            setting, vsys = setting_vsys.split('**')
            if setting != 'PANORAMA':
                configuration = {'vsys': vsys}
            else:
                configuration = {}

            if setting == 'PANORAMA':
                shared_auth_sequences = []
                no_multi_profile_auth_sequences = self.get_no_multi_profile_auth_sequences(
                    panorama=True)
            elif setting == 'DEVICE':  # NGFW
                shared_auth_sequences = self.get_shared_auth_sequences()
                no_multi_profile_auth_sequences = self.get_no_multi_profile_auth_sequences(vsys=[
                                                                                           vsys])
            else:  # Template
                configuration['template_name'] = setting
                shared_auth_sequences = self.get_shared_auth_sequences(
                    template_name=setting)
                no_multi_profile_auth_sequences = self.get_no_multi_profile_auth_sequences(
                    vsys=[vsys], template_name=setting)

            configuration['authentication_sequences'] = shared_auth_sequences + auth_sequences

            if no_multi_profile_auth_sequences:
                bp_check = bp_fail
            else:
                bp_check = bp_pass

            record_lst.append({'configuration': configuration,
                               'bp_check': [dict(bp_check._asdict())]})

        return record_lst
