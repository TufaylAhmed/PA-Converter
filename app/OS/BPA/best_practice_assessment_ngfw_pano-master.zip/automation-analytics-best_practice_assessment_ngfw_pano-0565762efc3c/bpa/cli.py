import argparse
import logging
import json

import pandas as pd

from bpa.controller import Controller
from bpa.publishers.schemas.documentation import Documentation
from bpa.version import __version__
from bpa.utils.common import flatten_json


logging.basicConfig(level=logging.INFO, format="%(message)s")
LOG = logging.getLogger(__name__)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--version", action="version", version=f"{__version__}")

    subparsers = parser.add_subparsers(
        help="Desired publisher to execute", dest="action"
    )
    subparsers.required = True

    json_parser = subparsers.add_parser("publish-json")
    json_parser.add_argument(
        "mode",
        type=str,
        choices=("adoption", "best_practices"),
        help="Desired JSON output",
    )
    json_parser.add_argument(
        "-s", "--stdout", action="store_true", help="Flag for printing to STDOUT"
    )
    json_parser.add_argument(
        "-f", "--flatten", action="store_true", help="Flatten the JSON structure"
    )
    json_parser.set_defaults(func=publish_json)

    html_parser = subparsers.add_parser("publish-html")
    html_parser.set_defaults(func=publish_html)

    excel_parser = subparsers.add_parser("publish-excel")
    excel_parser.add_argument("-docs", type=str, help="Filepath for CSV docs")
    excel_parser.set_defaults(func=publish_excel)

    pdf_parser = subparsers.add_parser("publish-pdf")
    pdf_parser.set_defaults(func=publish_pdf)

    for cmd, sp in subparsers.choices.items():
        input_group = sp.add_mutually_exclusive_group(required=True)
        if cmd not in {"publish-html", "publish-pdf"}:
            input_group.add_argument(
                "-xml", type=str, help="Filepath for XML configuration"
            )
        input_group.add_argument(
            "-tsf", type=str, help="Filepath for Tech Support File"
        )
        sp.add_argument(
            "-out", type=str, help="Filepath for output data", required=True
        )

    return vars(parser.parse_args())


def init_controller(args):
    """Helper for initializing controller"""
    if args.get("xml") is not None:
        return Controller.from_xml(args["xml"])
    else:
        return Controller.from_tsf(args["tsf"])


def publish_json(args):
    """Publish JSON content"""
    controller = init_controller(args)
    output = controller.publisher_manager.get(args["mode"])
    if args["flatten"]:
        output = json.dumps(flatten_json(json.loads(output)))
    if args["stdout"]:
        print(output)
    else:
        if args["flatten"]:
            output = output.encode("utf-8")
        with open(args["out"], "wb") as f:
            f.write(output)


def publish_html(args):
    """Publish HTML content"""
    controller = init_controller(args)
    output = controller.publisher_manager.get("report")
    with open(args["out"], "wb") as f:
        f.write(output)


def publish_excel(args):
    """Publish Excel content"""
    controller = init_controller(args)
    if args["docs"]:
        with open(args["docs"]) as f:
            docs = Documentation.from_df(pd.read_csv(f))
    else:
        docs = []
    output = controller.publisher_manager.get("failed_checks", documentation=docs)
    with open(args["out"], "wb") as f:
        f.write(output)


def publish_pdf(args):
    """Publish PDF content"""
    controller = init_controller(args)
    output = controller.publisher_manager.get("executive_summary")
    with open(args["out"], "wb") as f:
        f.write(output)


def main():
    args = parse_args()
    args["func"](args)


if __name__ == "__main__":
    main()
