from lxml import etree


"""Contains common queries as etree.XPath classes."""


is_panorama = etree.XPath("boolean(/config/mgt-config/devices)")

get_vsys_names = etree.XPath("//config/devices/entry/vsys/entry/@name")

get_dg_names = etree.XPath("/config/devices/entry/device-group/entry/@name")

get_template_names = etree.XPath("/config/devices/entry/template/entry/@name")

get_dg_hierarchy = etree.XPath(
    '/config/readonly//*[name()="device-group" or name()="dginfo"]/entry'
)

get_dgs_with_devices = etree.XPath(
    "/config/devices/entry/device-group/entry[devices/entry]"
)

get_urldb = etree.XPath("/config/@urldb")

get_version = etree.XPath("/config/@version")

get_rules_zones = etree.XPath(
    '//security/rules/entry/*[self::from or self::to]/member[text() != "any"]'
)

get_location = etree.XPath(
    "ancestor::shared | ancestor::entry[parent::device-group or parent::vsys]"
)

in_template = etree.XPath("boolean(ancestor::template or ancestor::template-stack)")

using_zpp = etree.XPath(
    "boolean(//zone/entry[@name=$zone]/network/zone-protection-profile)"
)

clientless_vpn_enabled = etree.XPath("boolean(//clientless-vpn)")

managed_devices_count = etree.XPath("count(/config/mgt-config/devices/entry)")
