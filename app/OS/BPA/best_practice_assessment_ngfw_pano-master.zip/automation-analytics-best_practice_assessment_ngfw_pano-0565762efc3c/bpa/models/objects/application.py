# -*- coding: utf-8 -*-
from typing import List, Union

from dataclasses import dataclass
from lxml import etree

from bpa.models.default_value import DefaultValue
from bpa.models.utils.parsing import parse_int

from ..sub_model import SubModel
from ..base_model import BaseModel
from ..mixins import LocationMixin


@dataclass
class Signature(SubModel):
    name: str
    scope: str
    order_free: bool
    comment: str

    @classmethod
    def parse_entry(cls, el):
        attrs = {}
        attrs["name"] = el.get("name")
        attrs["scope"] = el.findtext("scope")
        attrs["order_free"] = el.findtext("order-free")
        attrs["comment"] = el.findtext("comment")
        return cls(**attrs)


@dataclass
class ApplicationModel(BaseModel, LocationMixin):
    xpath = "//application/entry"

    name: str
    timeout: Union[int, DefaultValue]
    tcp_timeout: Union[int, DefaultValue]
    tcp_half_closed_timeout: Union[int, DefaultValue]
    tcp_time_wait_timeout: Union[int, DefaultValue]
    defaults_configured: Union[bool, DefaultValue]
    signatures: Union[List[Signature], DefaultValue]

    @staticmethod
    def _get_name(el: etree._Element, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_timeout(el: etree._Element, model_manager) -> Union[int, DefaultValue]:
        return parse_int(el, "timeout", 0)

    @staticmethod
    def _get_tcp_timeout(el: etree._Element, model_manager) -> Union[int, DefaultValue]:
        return parse_int(el, "tcp-timeout", 0)

    @staticmethod
    def _get_tcp_half_closed_timeout(
        el: etree._Element, model_manager
    ) -> Union[int, DefaultValue]:
        return parse_int(el, "tcp-half-closed-timeout", 0)

    @staticmethod
    def _get_tcp_time_wait_timeout(
        el: etree._Element, model_manager
    ) -> Union[int, DefaultValue]:
        return parse_int(el, "tcp-time-wait-timeout", 0)

    @staticmethod
    def _get_defaults_configured(
        el: etree._Element, model_manager
    ) -> Union[bool, DefaultValue]:
        node = el.find("default")
        if node is None:
            return DefaultValue(False)
        return True

    @staticmethod
    def _get_signatures(
        el: etree._Element, model_manager
    ) -> Union[List[Signature], DefaultValue]:
        signatures = [Signature.parse_entry(_) for _ in el.xpath("signature/entry")]
        if len(signatures) > 0:
            return signatures
        return DefaultValue([])

    @property
    def timeouts_configured(self):
        for k, v in self.__dict__.items():
            if k.endswith("timeout"):
                if not isinstance(v, DefaultValue):
                    return True
        return False
