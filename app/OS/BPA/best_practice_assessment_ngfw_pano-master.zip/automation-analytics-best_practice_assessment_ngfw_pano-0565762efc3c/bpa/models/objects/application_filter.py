# -*- coding: utf-8 -*-
from typing import List
from dataclasses import dataclass

from ..base_model import BaseModel
from ..default_value import DefaultValue
from ..mixins import LocationMixin
from ..utils.parsing import parse_list, parse_match
from ..utils.searching import get_objects_from_descendants


@dataclass
class ApplicationFilterModel(BaseModel, LocationMixin):
    xpath = "//application-filter/entry"

    name: str
    categories: List[str] = DefaultValue([])
    new_app_id_enabled: bool = DefaultValue(False)

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_categories(el, model_manager):
        return parse_list(el, "category/member/text()", [])

    @staticmethod
    def _get_new_app_id_enabled(el, model_manager):
        return parse_match(el, "new-appid", "yes", False)

    @property
    def security_rule_count(self) -> int:
        """Retrieve # of rules using profile."""
        count = 0
        rule_ms = self.objects.get("security_rule")
        for rule in get_objects_from_descendants(self.objects, self.location, rule_ms):
            if self.name in rule.app_filters and rule.rule_enabled:
                count += 1
        return count
