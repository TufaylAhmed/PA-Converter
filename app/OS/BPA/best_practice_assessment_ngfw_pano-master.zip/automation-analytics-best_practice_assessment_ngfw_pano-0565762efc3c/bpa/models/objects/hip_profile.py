# -*- coding: utf-8 -*-
from lxml import etree
import re


from dataclasses import dataclass

from ..base_model import BaseModel
from ..mixins import LocationMixin


@dataclass
class HipProfileModel(BaseModel, LocationMixin):
    xpath = "//profiles/hip-profiles/entry"

    name: str
    matches: str

    @staticmethod
    def _get_name(el: etree._Element, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_matches(el: etree._Element, model_manager) -> str:
        return re.findall('"([^"]*)"', el.find("match").text)
