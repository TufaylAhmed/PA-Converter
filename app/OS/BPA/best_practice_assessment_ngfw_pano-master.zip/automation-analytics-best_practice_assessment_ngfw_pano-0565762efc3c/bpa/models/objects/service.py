from typing import Optional

from dataclasses import dataclass
from lxml import etree

from bpa.models.utils.parsing import parse_int

from ..base_model import BaseModel
from ..mixins import LocationMixin


@dataclass
class ServiceModel(BaseModel, LocationMixin):
    xpath = "//entry/service/entry"

    name: str
    timeout: Optional[int]
    halfclose_timeout: Optional[int]
    timewait_timeout: Optional[int]

    @staticmethod
    def _get_name(el: etree._Element, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_timeout(el: etree._Element, model_manager) -> Optional[int]:
        return parse_int(el, "protocol/tcp/override/yes/timeout")

    @staticmethod
    def _get_halfclose_timeout(el: etree._Element, model_manager) -> Optional[int]:
        return parse_int(el, "protocol/tcp/override/yes/halfclose-timeout")

    @staticmethod
    def _get_timewait_timeout(el: etree._Element, model_manager) -> Optional[int]:
        return parse_int(el, "protocol/tcp/override/yes/timewait-timeout")

    @property
    def timeouts_configured(self):
        for k, v in self.__dict__.items():
            if k.endswith("timeout"):
                if v is not None:
                    return True
        return False
