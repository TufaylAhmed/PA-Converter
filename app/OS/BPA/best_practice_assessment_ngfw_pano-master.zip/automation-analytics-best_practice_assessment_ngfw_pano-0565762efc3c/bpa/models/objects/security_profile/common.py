# -*- coding: utf-8 -*-
from abc import ABCMeta
from typing import List, Optional, Set

from lxml import etree
from dataclasses import dataclass

from bpa.models.sub_model import SubModel

from ...base_model import BaseModel
from ...mixins import LocationMixin


@dataclass
class SecurityProfileModel(BaseModel, LocationMixin, metaclass=ABCMeta):
    """Objects > Security Profiles

    Only applicable in PAN-OS 8.0+
    """

    xpath = None

    name: str

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")


@dataclass
class SecurityProfileGroupModel(BaseModel, LocationMixin):
    """Objects > Security Profile Groups

    Only applicable in PAN-OS 8.0+
    """

    xpath = "//profile-group/entry"

    name: str
    antivirus: Optional[str] = None
    anti_spyware: Optional[str] = None
    vulnerability_protection: Optional[str] = None
    url_filtering: Optional[str] = None
    file_blocking: Optional[str] = None
    wildfire_analysis: Optional[str] = None
    data_filtering: Optional[str] = None

    @classmethod
    def get_profile_keys(cls) -> Set[str]:
        return set(cls.__dataclass_fields__.keys()) - {
            "location",
            "name",
            "model_manager",
        }

    @staticmethod
    def get_field(key) -> str:
        """Map from dataclass attributes to Xpath queries

        Args:
            key: Dataclass field name.

        Returns:
            Xpath query as string.
        """
        return {
            "antivirus": "virus",
            "anti_spyware": "spyware",
            "vulnerability_protection": "vulnerability",
            "url_filtering": "url-filtering",
            "file_blocking": "file-blocking",
            "wildfire_analysis": "wildfire-analysis",
            "data_filtering": "data-filtering",
        }[key]

    @classmethod
    def get_fields(cls):
        fields = []
        for key in cls.get_profile_keys():
            fields.append(cls.get_field(key))
        return fields

    @classmethod
    def from_el(cls, el, model_manager):
        attrs = {}
        attrs["name"] = el.get("name")
        attrs["location"] = cls._get_location(el, model_manager)
        attrs["model_manager"] = model_manager
        for key in cls.get_profile_keys():
            attrs[key] = el.findtext(cls.get_field(key) + "/member")
        return cls(**attrs)

    @property
    def is_ips_profile_group(self):
        return any(
            [
                self.antivirus is not None,
                self.anti_spyware is not None,
                self.vulnerability_protection is not None,
            ]
        )


@dataclass
class ThreatException(SubModel):
    """Threat exceptions exist in mutiple security profile types (AV, AS, vuln, etc)."""

    name: str
    packet_capture: str

    @classmethod
    def parse_entry(cls, el: etree._Element):
        """Factory for parsing a threat exception element."""
        name = el.get("name")
        packet_capture = el.findtext("packet-capture", "disable")
        return cls(name, packet_capture)

    @classmethod
    def get_threat_exceptions(cls, entry: etree._Element) -> List["ThreatException"]:
        """Threat exceptions exist in mutiple security profile types (AV, AS, vuln, etc).

        Args:
            entry: a security profile entry element (i.e. //profiles/spyware/entry[0])
        """
        return [
            cls.parse_entry(threat_exception)
            for threat_exception in entry.findall("threat-exception/entry")
        ]
