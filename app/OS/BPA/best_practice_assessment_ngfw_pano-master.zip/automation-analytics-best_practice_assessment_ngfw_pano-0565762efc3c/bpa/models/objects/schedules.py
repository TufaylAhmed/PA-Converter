# -*- coding: utf-8 -*-
import logging
import weakref
from datetime import datetime
from typing import List


from dataclasses import dataclass
from lxml import etree

from ..base_model import BaseModel
from ..mixins import LocationMixin


LOG = logging.getLogger(__name__)


@dataclass
class SchedulesRange:

    start_time: datetime
    end_time: datetime

    pattern = "%Y/%m/%d@%H:%M"

    @property
    def expired(self):
        return datetime.now() > self.end_time

    @classmethod
    def parse_entry(cls, el):
        attrs = {}
        start, end = el.text.split("-")
        try:
            attrs["start_time"] = datetime.strptime(start, cls.pattern)
        except ValueError:
            LOG.warning("Start time was not parsed properly. Setting to min time.")
            attrs["start_time"] = datetime.min
        try:
            attrs["end_time"] = datetime.strptime(end, cls.pattern)
        except ValueError:
            LOG.warning("End time was not parsed properly. Setting to max time.")
            attrs["end_time"] = datetime.max
        return cls(**attrs)


@dataclass
class SchedulesModel(BaseModel, LocationMixin):
    xpath = "//schedule/entry"

    name: str
    recurring: bool
    schedule_ranges: List[SchedulesRange]

    @classmethod
    def from_el(cls, el: etree._Element, model_manager):
        attrs = {}

        attrs["name"] = el.get("name")
        attrs["location"] = cls._get_location(el, model_manager)
        attrs["model_manager"] = weakref.ref(model_manager)
        attrs["recurring"] = el.find("schedule-type/recurring") is not None

        attrs["schedule_ranges"] = []
        if not attrs["recurring"]:
            members = el.xpath("schedule-type/non-recurring/member")
            if members is not None:
                attrs["schedule_ranges"] = [
                    SchedulesRange.parse_entry(el) for el in members
                ]

        return cls(**attrs)
