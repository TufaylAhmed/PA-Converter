# -*- coding: utf-8 -*-
from dataclasses import dataclass
from lxml import etree
import re
from typing import List, Dict, Union

from ..base_model import BaseModel
from ..mixins import LocationMixin


@dataclass
class MatchList:

    syslog: str
    snmp: str
    http: str
    email: str
    panorama: str
    log_type: str
    filter: str

    FILTER_VALS = {
        "traffic": ("informational", "low", "medium", "high", "critical"),
        "threat": ("informational", "low", "medium", "high", "critical"),
        "wildfire": ("benign", "grayware", "malicious", "phishing"),
    }

    def forwarding_valid(self):
        """Check if forwarding configuration is valid.

        For Threat and WildFire, logs need to be forwarded to Panorama + 1 other location.
        Traffic logs may have a lot of data, only require forwarding to one location.
        URL logs are required to go to atleast 1 location
        Authentication logs are required to go to atleast 1 location
        """
        if self.log_type in {"threat", "wildfire"}:
            return any([self.syslog, self.snmp, self.http, self.email])
        else:
            return any([self.panorama, self.syslog, self.snmp, self.http, self.email])

    def parse_filter(self):
        """Logic for parsing filter string."""
        if self.filter == "All Logs":
            return self.get_match_vals(self.filter)
        matches = [match for match, _ in re.findall(self.regex, self.filter)]
        match_set = set()
        for match in matches:
            match_set.update(self.get_match_vals(match))
        return match_set

    def get_match_vals(self, match):
        """Logic for extracing applicable severity or verdict values from a filter match."""
        if match == "All Logs":
            return self.filter_vals

        negate = match.startswith("not ")
        attr, op, val = match.strip("not ()").split()
        if op == "eq":
            return self.process_negate([val], negate)
        elif op == "neq":
            return self.process_negate(
                [v for v in self.filter_vals if v != val], negate
            )
        elif op == "geq":
            return self.process_negate(
                self.filter_vals[self.filter_vals.index(val) :], negate
            )
        elif op == "leq":
            return self.process_negate(
                self.filter_vals[: self.filter_vals.index(val)], negate
            )
        else:
            raise ValueError(f"Invalid filter operator ({op}) found in match: {match}")

    @property
    def regex(self):
        """Helper for picking the correct regex query."""
        if self.log_type == "wildfire":
            return r"((not )?\(verdict [a-z]{2,3} [a-z]+\))"
            return r"(not )?\(verdict [a-z]* [a-z]*\)"
        else:
            return r"((not )?\(severity [a-z]{2,3} [a-z]+\))"

    @property
    def filter_vals(self):
        """Helper to get the correct filter values."""
        return self.FILTER_VALS[self.log_type]

    def process_negate(self, vals, negate):
        """Helper method for processing negate match modifier."""
        if not negate:
            return vals
        return set(self.filter_vals) - set(vals)

    @classmethod
    def parse_entry(cls, el: etree._Element):
        attrs = {
            "syslog": el.xpath("send-syslog/member/text()"),
            "snmp": el.xpath("send-snmptrap/member/text()"),
            "http": el.xpath("send-http/member/text()"),
            "email": el.xpath("send-email/member/text()"),
            "panorama": el.findtext("send-to-panorama", "no") == "yes",
            "log_type": el.findtext("log-type"),
            "filter": el.findtext("filter"),
        }
        return cls(**attrs)


@dataclass
class Setting:

    log_type: str
    log_levels: Dict[str, bool]

    TAG_MAP = {"alarm": "threat", "traffic": "traffic", "wildfire": "wildfire"}

    def forwarding_valid(self, log_level):
        """Check if forwarding configuration is valid.

        For Threat and WildFire, logs need to be forwarded to Panorama + 1 other location.
        Becase Traffic logs may have a lot of data, only require forwarding to one location.
        """
        target = self.get_log_level(log_level)
        if self.log_type != "traffic":
            return target["panorama"] and any(
                [target["syslog"], target["snmp"], target["email"]]
            )
        else:
            return any(
                [target["panorama"], target["syslog"], target["snmp"], target["email"]]
            )

    def get_log_level(self, log_level):
        """Get forwarding configuration for a given log level."""
        try:
            target = self.log_levels[log_level]
        except KeyError:
            return {"panorama": False, "snmp": False, "email": False, "syslog": False}
        else:
            return target

    @staticmethod
    def parse_log_level(log_level) -> Dict[str, bool]:
        """Parses a given log level element."""
        return {
            "panorama": log_level.findtext("send-to-panorama", "no") == "yes",
            "snmp": log_level.findtext("send-snmptrap/*") is not None,
            "email": log_level.findtext("send-email/*") is not None,
            "syslog": log_level.findtext("send-syslog/*") is not None,
        }

    @classmethod
    def parse_entry(cls, el: etree._Element):
        attrs = {}
        attrs["log_type"] = cls.TAG_MAP[el.tag]
        attrs["log_levels"] = {}
        for log_level in el.getchildren():
            attrs["log_levels"][log_level.tag] = cls.parse_log_level(log_level)
        return cls(**attrs)


@dataclass
class LogForwardingProfileModel(BaseModel, LocationMixin):
    xpath = "//log-settings/profiles/entry"
    SEVERITIES = ("informational", "low", "medium", "high", "critical")
    VERDICTS = ("grayware", "malicious", "phishing")

    name: str
    settings: List[Union[Setting, MatchList]]

    @property
    def verdicts(self):
        """Helper to exclude phishing from verdict options if PAN-OS < 8"""
        if self.objects.tree.version < 8:
            return self.VERDICTS[:-1]
        else:
            return self.VERDICTS

    @staticmethod
    def _get_name(el: etree._Element, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_settings(el: etree._Element, model_manager):
        if model_manager.tree.version < 8:
            return [
                Setting.parse_entry(e)
                for e in el.getchildren()
                if e.tag in Setting.TAG_MAP.keys()
            ]
        else:
            return [MatchList.parse_entry(e) for e in el.findall("match-list/entry")]
