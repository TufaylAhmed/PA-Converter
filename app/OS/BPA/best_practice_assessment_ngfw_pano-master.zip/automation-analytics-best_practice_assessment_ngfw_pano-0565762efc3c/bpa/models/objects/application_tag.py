# -*- coding: utf-8 -*-
from typing import List

from dataclasses import dataclass

from ..base_model import BaseModel
from ..mixins import LocationMixin


@dataclass
class ApplicationTagModel(BaseModel, LocationMixin):
    xpath = "//application-tag/entry"

    name: str
    tags: List[str]

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_tags(el, model_manager):
        return el.xpath("tag/member/text()")
