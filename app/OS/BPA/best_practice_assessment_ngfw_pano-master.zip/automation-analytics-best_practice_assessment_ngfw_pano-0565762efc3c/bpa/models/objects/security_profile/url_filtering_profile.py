from typing import List, Set, Dict, Optional

from dataclasses import dataclass
from lxml import etree

from bpa.models.sub_model import SubModel

from .common import SecurityProfileModel


def parse_category_actions(
    el: etree._Element, action_type: str, url_categories: Set
) -> Dict[str, List[str]]:
    """Parses URL categories by action

    Args:
        el: credential-enforcement element
        action_type: Either 'site_access' or 'user_credential_submission'

    Returns: A dictionary where keys are the actions and values are lists of associated URL categories.
    """
    non_allow_actions = ["alert", "block", "continue", "override"]
    non_allow_categories = set()
    container = {}

    # user_credential_submission does not have override as an available action
    if action_type == "user_credential_submission":
        non_allow_actions = non_allow_actions[:-1]

    for action in non_allow_actions:
        action_categories = el.xpath(f"{action}/member/text()")
        non_allow_categories.update(action_categories)
        container[action] = action_categories
    container["allow"] = list(url_categories - non_allow_categories)

    return container


@dataclass
class CredentialEnforcement(SubModel):
    mode: str
    log_severity: str
    categories: Dict[str, List[str]]

    @classmethod
    def parse_el(cls, el, model_manager) -> "CredentialEnforcement":
        mode = el.find("mode/*").tag
        log_severity = el.findtext("log-severity")
        categories = parse_category_actions(
            el, "user_credential_submission", model_manager.tree.url_categories
        )
        return cls(mode, log_severity, categories)

    @classmethod
    def no_cred_enforcement(cls, url_categories) -> "CredentialEnforcement":
        """Handle case when credential-enforcement child element is missing."""
        categories = {
            "alert": [],
            "block": [],
            "continue": [],
            "allow": list(url_categories),
        }
        return cls(mode="disabled", log_severity="medium", categories=categories)


@dataclass
class UrlFilteringProfileModel(SecurityProfileModel):
    """SecurityProfileModel > UrlFilteringProfileModel"""

    xpath = "//profiles/url-filtering/entry"

    log_container_page_only_enabled: bool
    site_access_categories: Dict[str, List[str]]
    credential_enforcement: Optional[CredentialEnforcement]

    @classmethod
    def build_model_key(cls):
        """NOTE: Ensure security rules can identify this profile"""
        return "url_filtering_profile"

    @staticmethod
    def _get_log_container_page_only_enabled(el, model_manager) -> bool:
        return el.findtext("log-container-page-only", "yes") == "yes"

    @staticmethod
    def _get_site_access_categories(el, model_manager):
        return parse_category_actions(
            el, "site_access", model_manager.tree.url_categories
        )

    @staticmethod
    def _get_credential_enforcement(
        el, model_manager
    ) -> Optional[CredentialEnforcement]:
        if model_manager.tree.version < 8:
            return

        credential_enforcement_el = el.find("credential-enforcement")

        # Handle case when credential-enforcement child element is missing
        if credential_enforcement_el is None:
            return CredentialEnforcement.no_cred_enforcement(
                model_manager.tree.url_categories
            )

        return CredentialEnforcement.parse_el(credential_enforcement_el, model_manager)
