from typing import List

from lxml import etree
from dataclasses import dataclass

from bpa.models.sub_model import SubModel

from .common import SecurityProfileModel
from ...constants import NONE


@dataclass
class DataFilteringRule(SubModel):
    data_pattern: str

    @classmethod
    def parse_entry(cls, el: etree._Element):
        data_pattern = el.findtext("data-object", NONE)
        return cls(data_pattern)


@dataclass
class DataFilteringProfileModel(SecurityProfileModel):
    """SecurityProfileModel > DataFilteringProfileModel"""

    xpath = "//profiles/data-filtering/entry"

    rules: List[DataFilteringRule]

    @classmethod
    def build_model_key(cls):
        """NOTE: Ensure security rules can identify this profile"""
        return "data_filtering_profile"

    @staticmethod
    def _get_rules(el, model_manager) -> List[DataFilteringRule]:
        return [
            DataFilteringRule.parse_entry(rule) for rule in el.findall("rules/entry")
        ]
