# -*- coding: utf-8 -*-
from lxml import etree

from dataclasses import dataclass

from ..base_model import BaseModel
from ..mixins import LocationMixin


@dataclass
class SSLForwardProxy:
    block_expired_certificate: bool
    block_untrusted_issuer: bool
    block_unknown_cert: bool
    block_unsupported_version: bool
    block_unsupported_cipher: bool
    block_client_cert: bool
    block_if_no_resource: bool
    block_if_hsm_unavailable: bool
    strip_alpn: bool

    @classmethod
    def parse_entry(cls, el: etree._Element):
        proxy = el.find("ssl-forward-proxy")
        attrs = {}
        for field in cls.__dataclass_fields__:
            e = field.replace("_", "-")
            attrs[field] = (proxy is not None) and (proxy.findtext(e, "no") == "yes")
        return cls(**attrs)


@dataclass
class SSLInboundInspection:
    block_unsupported_version: bool
    block_unsupported_cipher: bool
    block_if_no_resource: bool
    block_if_hsm_unavailable: bool

    @classmethod
    def parse_entry(cls, el: etree._Element):
        proxy = el.find("ssl-inbound-proxy")
        attrs = {}
        for field in cls.__dataclass_fields__:
            e = field.replace("_", "-")
            attrs[field] = (proxy is not None) and (proxy.findtext(e, "no") == "yes")
        return cls(**attrs)


@dataclass
class SSLProtocolSettings:

    min_version: str = "tls1-0"
    max_version: str = "max"
    enc_algo_3des: bool = True
    enc_algo_rc4: bool = True
    enc_algo_aes_128_cbc: bool = True
    enc_algo_aes_256_cbc: bool = True
    enc_algo_aes_128_gcm: bool = True
    enc_algo_aes_256_gcm: bool = True
    auth_algo_sha1: bool = True
    auth_algo_md5: bool = False
    auth_algo_sha256: bool = True
    auth_algo_sha384: bool = True
    keyxchg_algo_rsa: bool = True
    keyxchg_algo_dhe: bool = True
    keyxchg_algo_ecdhe: bool = True

    @classmethod
    def parse_entry(cls, el: etree._Element):
        proxy = el.find("ssl-protocol-settings")
        attrs = {}
        for name, value in cls.__dataclass_fields__.items():
            try:
                field_element = proxy.find(name.replace("_", "-"))
            except AttributeError:
                field_element = None
            if field_element is not None:
                if value.type is str:
                    attrs[name] = field_element.text
                else:
                    attrs[name] = field_element.text == "yes"
        return cls(**attrs)


@dataclass
class NoDecryption:

    block_expired_certificate: bool
    block_untrusted_issuer: bool

    @classmethod
    def parse_entry(cls, el: etree._Element):
        proxy = el.find("ssl-no-proxy")
        attrs = {}
        for field in cls.__dataclass_fields__:
            e = field.replace("_", "-")
            attrs[field] = (proxy is not None) and (proxy.findtext(e, "no") == "yes")
        return cls(**attrs)


@dataclass
class SSHProxy:
    block_unsupported_version: bool
    block_unsupported_alg: bool
    block_ssh_errors: bool
    block_if_no_resource: bool

    @classmethod
    def parse_entry(cls, el: etree._Element):
        proxy = el.find("ssh-proxy")
        attrs = {}
        for field in cls.__dataclass_fields__:
            e = field.replace("_", "-")
            attrs[field] = (proxy is not None) and (proxy.findtext(e, "no") == "yes")
        return cls(**attrs)


@dataclass
class DecryptionProfileModel(BaseModel, LocationMixin):
    """Objects > Decryption Profile"""

    xpath = "//profiles/decryption/entry"

    name: str
    ssl_forward_proxy: SSLForwardProxy
    ssl_inbound_inspection: SSLInboundInspection
    ssl_protocol_settings: SSLProtocolSettings
    no_decryption: NoDecryption
    ssh_proxy: SSHProxy

    @staticmethod
    def _get_name(el: etree._Element, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_ssl_forward_proxy(el: etree._Element, model_manager):
        return SSLForwardProxy.parse_entry(el)

    @staticmethod
    def _get_ssl_inbound_inspection(el: etree._Element, model_manager):
        return SSLInboundInspection.parse_entry(el)

    @staticmethod
    def _get_ssl_protocol_settings(el: etree._Element, model_manager):
        return SSLProtocolSettings.parse_entry(el)

    @staticmethod
    def _get_no_decryption(el: etree._Element, model_manager):
        return NoDecryption.parse_entry(el)

    @staticmethod
    def _get_ssh_proxy(el: etree._Element, model_manager):
        return SSHProxy.parse_entry(el)
