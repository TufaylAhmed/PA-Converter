from typing import List

from lxml import etree
from dataclasses import dataclass

from .common import SecurityProfileModel


@dataclass
class WildfireAnalysisProfileRule:
    applications: List[str]
    file_types: List[str]
    direction: str
    analysis: str

    @classmethod
    def parse_entry(cls, el: etree._Element):
        """Factory for parsing a WF rules entry element."""
        attrs = {}
        attrs["applications"] = el.xpath("application/member/text()")
        attrs["file_types"] = el.xpath("file-type/member/text()")
        attrs["direction"] = el.findtext("direction")
        attrs["analysis"] = el.findtext("analysis")
        return cls(**attrs)


@dataclass
class WildfireAnalysisProfileModel(SecurityProfileModel):
    """SecurityProfileModel > WildfireAnalysisProfileModel"""

    xpath = "//profiles/wildfire-analysis/entry"

    rules: List[WildfireAnalysisProfileRule]

    @classmethod
    def build_model_key(cls):
        """NOTE: Ensure security rules can identify this profile"""
        return "wildfire_analysis_profile"

    @staticmethod
    def _get_rules(el, model_manager) -> List[WildfireAnalysisProfileRule]:
        """Collect WildFire rules."""
        return [
            WildfireAnalysisProfileRule.parse_entry(el)
            for el in el.findall("rules/entry")
        ]
