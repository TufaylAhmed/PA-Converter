from typing import List

from lxml import etree
from dataclasses import dataclass

from bpa.models.sub_model import SubModel

from .common import SecurityProfileModel
from ...constants import NONE


@dataclass
class FileBlockingRule(SubModel):
    applications: List[str]
    file_types: List[str]
    direction: str
    action: str

    @classmethod
    def parse_entry(cls, el: etree._Element):
        applications = el.xpath("application/member/text()")
        file_types = el.xpath("file-type/member/text()")
        direction = el.findtext("direction", NONE)
        action = el.findtext("action", NONE)
        return cls(applications, file_types, direction, action)


@dataclass
class FileBlockingProfileModel(SecurityProfileModel):
    """SecurityProfileModel > FileBlockingProfileModel"""

    xpath = "//profiles/file-blocking/entry"

    rules: List[FileBlockingRule]

    @classmethod
    def build_model_key(cls):
        """NOTE: Ensure security rules can identify this profile"""
        return "file_blocking_profile"

    @staticmethod
    def _get_rules(el, model_manager) -> List[FileBlockingRule]:
        return [
            FileBlockingRule.parse_entry(rule) for rule in el.findall("rules/entry")
        ]
