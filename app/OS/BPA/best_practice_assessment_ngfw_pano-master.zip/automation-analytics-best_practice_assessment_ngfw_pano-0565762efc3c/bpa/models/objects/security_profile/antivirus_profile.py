from typing import List

from lxml import etree
from dataclasses import dataclass

from bpa.models.model_sets.antivirus_profile import AntivirusProfileModelSet
from bpa.models.sub_model import SubModel

from .common import SecurityProfileModel


@dataclass
class AntivirusDecoder(SubModel):
    """docstring for AntivirusDecoder"""

    DEFAULT_ACTIONS = {
        "ftp": "reset-both",
        "http": "reset-both",
        "http2": "reset-both",
        "imap": "alert",
        "pop3": "alert",
        "smb": "reset-both",
        "smtp": "alert",
    }

    name: str
    action: str
    wildfire_action: str

    @staticmethod
    def parse_action(decoder_el: etree._Element, action: str) -> str:
        """Parse Action or WildFire Action for an AV decoder.

        If value is set to "default" or missing, replace with the corresponding action for that
        AV decoder.
        """
        val = decoder_el.findtext(action)
        if val in ["default", None]:
            val = AntivirusDecoder.DEFAULT_ACTIONS[decoder_el.get("name")]
        return val

    @classmethod
    def parse_entry(cls, el: etree._Element) -> List["AntivirusDecoder"]:
        """Factory for parsing an AV decoder entry element."""
        attrs = {}
        attrs["name"] = el.get("name")
        attrs["action"] = cls.parse_action(el, "action")
        attrs["wildfire_action"] = cls.parse_action(el, "wildfire-action")
        return cls(**attrs)

    @classmethod
    def get_default_decoders(cls) -> List["AntivirusDecoder"]:
        """The 'default' profile sets all WildFire actions to 'Allow'."""
        return [
            cls(name, action, "allow") for name, action in cls.DEFAULT_ACTIONS.items()
        ]


@dataclass
class AntivirusProfileModel(SecurityProfileModel):
    """SecurityProfileModel > AntivirusProfileModel"""

    xpath = "//profiles/virus/entry"

    model_set = AntivirusProfileModelSet

    name: str
    packet_capture_enabled: bool
    threat_exceptions: List[str]
    application_exceptions: List[str]
    decoders: List[AntivirusDecoder]

    @classmethod
    def build_model_key(cls):
        """NOTE: Ensure security rules can identify this profile"""
        return "antivirus_profile"

    @staticmethod
    def _get_packet_capture_enabled(el, model_manager) -> bool:
        return el.findtext("packet-capture") == "yes"

    @staticmethod
    def _get_threat_exceptions(el, model_manager) -> List[str]:
        return el.xpath("threat-exception/entry/@name")

    @staticmethod
    def _get_application_exceptions(el, model_manager) -> List[str]:
        return el.xpath("application/entry/@name")

    @staticmethod
    def _get_decoders(el, model_manager) -> List[AntivirusDecoder]:
        """Collect AV decoders."""
        decoders = [
            AntivirusDecoder.parse_entry(_) for _ in el.findall("decoder/entry")
        ]
        # The "http2" decoder was added in PAN-OS 9.0 and does not appear in the XML unless the default is modified.
        missing_decoder = "http2"
        if model_manager.tree.version >= 9.0 and missing_decoder not in decoders:
            action = AntivirusDecoder.DEFAULT_ACTIONS[missing_decoder]
            decoders.append(
                AntivirusDecoder(
                    name=missing_decoder, action=action, wildfire_action=action
                )
            )
        return decoders
