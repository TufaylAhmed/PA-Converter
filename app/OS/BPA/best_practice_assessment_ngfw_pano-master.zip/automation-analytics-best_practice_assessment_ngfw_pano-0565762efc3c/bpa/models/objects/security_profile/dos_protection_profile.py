from typing import Optional, List

from lxml import etree
from dataclasses import dataclass

from bpa.models.sub_model import SubModel

from .common import SecurityProfileModel


@dataclass
class FloodProtection(SubModel):
    """DoS Protection Profile > FloodProtection tab and its sub-tabs."""

    FIELDS = (
        ("tcp-syn", "SYN"),
        ("udp", "UDP"),
        ("icmp", "ICMP"),
        ("icmpv6", "ICMPv6"),
        ("other-ip", "Other IP"),
    )

    flood_type: str
    alarm: int = 10000
    activate: int = 10000
    maximal: int = 40000
    block_duration: int = 300
    enabled: bool = False

    @classmethod
    def parse_flood_el(cls, el: Optional[etree._Element]) -> List["FloodProtection"]:
        tabs = []
        for tab_xpath, tab_name in cls.FIELDS:
            if el is None:
                tabs.append(cls(flood_type=tab_name))
            else:
                # use * since the node tag changes depending on the action (red vs syn-cookies)
                attrs = {
                    "flood_type": tab_name,
                    "alarm": int(
                        el.findtext("{}/*/alarm-rate".format(tab_xpath), 10000)
                    ),
                    "activate": int(
                        el.findtext("{}/*/activate-rate".format(tab_xpath), 10000)
                    ),
                    "maximal": int(
                        el.findtext("{}/*/maximal-rate".format(tab_xpath), 40000)
                    ),
                    "block_duration": int(
                        el.findtext("{}/*/block/duration".format(tab_xpath), 300)
                    ),
                    "enabled": el.findtext("{}/enable".format(tab_xpath), "no")
                    == "yes",
                }
                tabs.append(cls(**attrs))
        return tabs


@dataclass
class DosProtectionProfileModel(SecurityProfileModel):
    """SecurityProfileModel > DosProtectionProfileModel"""

    xpath = "//profiles/dos-protection/entry"

    coverage_type: str
    flood_protections: List[FloodProtection]

    @classmethod
    def build_model_key(cls):
        """NOTE: Ensure security rules can identify this profile"""
        return "dos_protection_profile"

    @staticmethod
    def _get_coverage_type(el, model_manager) -> str:
        return el.findtext("type")

    @staticmethod
    def _get_flood_protections(el, model_manager) -> List["FloodProtection"]:
        return FloodProtection.parse_flood_el(el.find("flood"))
