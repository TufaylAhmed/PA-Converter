from typing import List, Optional, Set

from lxml import etree
from dataclasses import dataclass

from bpa.models.default_value import DefaultValue
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import parse_tag

from .common import SecurityProfileModel, ThreatException
from ...constants import NONE


@dataclass
class EDLDomain(SubModel):
    name: str
    action: str

    @classmethod
    def parse_entry(cls, el: etree._Element):
        name = el.get("name")
        action = el.find("action/*").tag
        return cls(name, action)


@dataclass
class AntiSpywareRule(SubModel):
    name: str
    severity: List[str]
    action: str
    category: str
    packet_capture: str

    SEVERITY_CHOICES = ("critical", "high", "medium", "low", "informational")

    @classmethod
    def parse_entry(cls, el: etree._Element):
        name = el.get("name")
        severity = el.xpath("severity/member/text()")
        action = parse_tag(el, "action/*", default=NONE)
        category = el.findtext("category")
        packet_capture = el.findtext("packet-capture")
        return cls(name, severity, action, category, packet_capture)

    def get_severities(self) -> Set[str]:
        severities = set(self.severity)
        if "any" in severities:
            severities = {*severities, *self.SEVERITY_CHOICES}
        return severities


@dataclass
class DnsSignature(SubModel):
    """Applicable for PAN-OS 9.0+"""

    name: str
    action: str
    packet_capture: str

    SEVERITY_CHOICES = ("critical", "high", "medium", "low", "informational")

    @classmethod
    def parse_entry(cls, el: etree._Element):
        name = el.get("name")
        action = parse_tag(el, "action/*", default=NONE)
        packet_capture = el.findtext("packet-capture", "single-packet")
        return cls(name, action, packet_capture)


@dataclass
class AntiSpywareProfileModel(SecurityProfileModel):
    """SecurityProfileModel > AntiSpywareProfileModel"""

    xpath = "//profiles/spyware/entry"

    dns_signature_packet_capture: str
    passive_dns_monitoring_enabled: bool
    dns_sinkhole: bool
    sinkhole_ipv4: str
    spyware_threat_exceptions: List[ThreatException] = DefaultValue([])
    edl_domains: List[EDLDomain] = DefaultValue([])
    rules: List[AntiSpywareRule] = DefaultValue([])
    botnet_threat_exceptions: List[str] = DefaultValue([])
    dns_signatures: List[DnsSignature] = DefaultValue([])

    mask_attrs = {"sinkhole_ipv4": ["ipv4"]}

    @classmethod
    def build_model_key(cls):
        """NOTE: Ensure security rules can identify this profile"""
        return "anti_spyware_profile"

    @staticmethod
    def _get_botnet_threat_exceptions(el, model_manager) -> List[str]:
        return el.xpath("botnet-domains/threat-exception/entry/@name")

    @staticmethod
    def _get_dns_signature_packet_capture(el, model_manager) -> str:
        return el.findtext("botnet-domains/packet-capture", "disable")

    @staticmethod
    def _get_dns_signatures(el, model_manager) -> str:
        nodes = el.findall("botnet-domains/lists/entry")
        if not nodes:
            return DefaultValue([])
        return [DnsSignature.parse_entry(el) for el in nodes]

    @staticmethod
    def _get_passive_dns_monitoring_enabled(el, model_manager) -> Optional[bool]:
        return el.findtext("botnet-domains/passive-dns") == "yes"

    @staticmethod
    def _get_dns_sinkhole(el, model_manager) -> Optional[bool]:
        return el.xpath(
            "boolean(botnet-domains/action/sinkhole | botnet-domains/sinkhole)"
        )

    @staticmethod
    def _get_sinkhole_ipv4(el, model_manager) -> Optional[str]:
        return el.findtext("botnet-domains/sinkhole/ipv4-address")

    @staticmethod
    def _get_spyware_threat_exceptions(el, model_manager) -> List[ThreatException]:
        return ThreatException.get_threat_exceptions(el)

    @staticmethod
    def _get_edl_domains(el, model_manager) -> List[EDLDomain]:
        nodes = el.findall("botnet-domains/lists/entry")
        if not nodes:
            return DefaultValue([])
        return [EDLDomain.parse_entry(domain) for domain in nodes]

    @staticmethod
    def _get_rules(el, model_manager) -> List[AntiSpywareRule]:
        nodes = el.findall("rules/entry")
        if not nodes:
            return DefaultValue([])
        return [AntiSpywareRule.parse_entry(rule) for rule in nodes]
