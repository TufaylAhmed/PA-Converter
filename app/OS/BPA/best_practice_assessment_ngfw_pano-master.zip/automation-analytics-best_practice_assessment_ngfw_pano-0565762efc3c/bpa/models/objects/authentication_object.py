# -*- coding: utf-8 -*-
from dataclasses import dataclass
from lxml import etree

from ..base_model import BaseModel
from ..mixins import LocationMixin


@dataclass
class AuthenticationObjectModel(BaseModel, LocationMixin):
    """Objects > Authentication

    Only applicable in PAN-OS 8.0+
    """

    xpath = "//authentication-object/entry"

    name: str
    authentication_method: str
    authentication_profile: str

    @staticmethod
    def _get_name(el: etree._Element, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_authentication_method(el: etree._Element, model_manager) -> str:
        return el.findtext("authentication-method")

    @staticmethod
    def _get_authentication_profile(el: etree._Element, model_manager) -> str:
        return el.findtext("authentication-profile")
