class DefaultValue:
    """Default value wrapper.

    An abstraction to determine whether a value is default
    or not. Use isinstance to check whether the wrapped
    value is default or not.

    Running bool on this object simply returns the boolean
    representation of the value.

    Doing equality comparisons between DefaultValue and
    other objects would invoke __eq__.

    Attributes:
        value: Any valid Python object.
    """

    def __init__(self, val):
        self.value = val

    def __bool__(self):
        return bool(self.value)

    def __eq__(self, val):
        return self.value == val


class NameValue:
    """Name value wrapper.

    An abstraction to determine whether a list item
    should be resolved differently during the composite
    phase.

    Attributes:
        name: A string representing the name of the entity.
    """

    def __init__(self, name):
        self.name = name
