from __future__ import annotations
import typing
import logging

from collections import UserDict
from dataclasses import dataclass, asdict
from datetime import datetime

LOG = logging.getLogger(__name__)


@dataclass
class RuleUsageModel:
    rule_uuid: str
    rule_base_type: str
    rule_name: str
    hit_count: int
    last_hit_ts: int

    def __init__(self, **kwargs):
        """
       This will create instance of RuleUsageModel filtering out only values that are only required in RuleUsageModel
       as kwargs is expected to have more values than the required values.

       Also it will convert values to be in sync with the type hinting
       eg. hit_count is parsed as str but needs to be an int for further processing

        Args:
            **kwargs: All the params to create the instance

        Raises:
            KeyError: If required attribute is not in kwargs
            ValueError: If there is an invalid literal during type conversion
        """

        # Getting a list of tuples of (attribute in RuleUsageModel, type hinting assigned to that attribute)
        for attr, type_hint in typing.get_type_hints(self).items():

            # Getting the attribute value from the kwargs
            attr_value = kwargs[attr]

            # Converting the value to the type defined in the type hinting eg. "1" to 1
            if type(attr_value) != type_hint:
                attr_value = type_hint(attr_value)

            # Setting an attribute and its value to the instance
            setattr(self, attr, attr_value)

    @property
    def last_hit_datetime(self) -> datetime:
        try:
            return self._last_hit_datetime
        except AttributeError:
            setattr(
                self, "_last_hit_datetime", datetime.fromtimestamp(self.last_hit_ts)
            )
            return self._last_hit_datetime

    @property
    def last_hit_str(self) -> str:
        """

        Returns:
            A string of the date in the format: Nov 18, 2019 or never
        """
        return (
            self.last_hit_datetime.strftime("%b %d, %Y")
            if self.last_hit_ts != 0
            else "never"
        )

    @property
    def traffic_hit(self) -> bool:
        """
        Will tell if any traffic ever hit the rule
        Returns:
            boolean
        """
        return self.hit_count > 0

    def calculate_traffic_hit_within_time_frame(
        self, tsf_generated_date: str, time_frame_days: int = 90
    ) -> bool:
        """
        If last hit is greater than X days then traffic is not passing through this rule
        Args:
            tsf_generated_date: Time of generation of the tsf that is got from the model manager.
            time_frame_days: Number of days with which the rule was last hit. Defaults to 90

        Returns:
            boolean: If the difference in days between the tsf_generation_date and rule's last hit time
                is less than or equal to the time_frame_days
        """
        if type(tsf_generated_date) == str:
            tsf_generated_date = datetime.strptime(
                tsf_generated_date, "%Y-%m-%d %H:%M:%S"
            )
        return (tsf_generated_date - self.last_hit_datetime).days <= time_frame_days

    def traffic_hit_days(self, tsf_generated_date: str) -> int:
        """
        Calculates the number of days since the rule was last hit
        Args:
            tsf_generated_date: Time of generation of the tsf that is got from the model manager.

        Returns:
            -1: If rule was never hit
            >= 0 : Days the has been calculated since tsf_generated_date
        """
        if self.last_hit_ts == 0:
            return -1
        if type(tsf_generated_date) == str:
            tsf_generated_date = datetime.strptime(
                tsf_generated_date, "%Y-%m-%d %H:%M:%S"
            )
        return (tsf_generated_date - self.last_hit_datetime).days


class RuleUsageInfo(UserDict):
    """
    Using UserDict as its better than just using dict while overriding internal functions
    https://docs.python.org/3/library/collections.html#collections.UserDict

    This model is a UserDict with key: str and item: RuleUsageModel
    """

    def __setitem__(self, key: str, item: RuleUsageModel):

        # Adding additional logic to ensure strict key, value type
        # as consumers depend on values being this type
        if not isinstance(key, str):
            raise TypeError("key must be a str")
        if not isinstance(item, RuleUsageModel):
            raise TypeError("value must be a RuleUsageModel")

        super().__setitem__(key, item)

    @property
    def is_available(self) -> bool:
        return len(self.keys()) > 0

    def to_json(self) -> dict:
        return {k: asdict(v) for k, v in self.items()}

    @classmethod
    def from_json(cls, json: typing.Dict[str, typing.Dict]) -> RuleUsageInfo:
        rule_usage_info = cls()
        for k, v in json.items():
            try:
                rule_usage_info[k] = RuleUsageModel(**v)
            except (KeyError, ValueError, TypeError) as e:
                LOG.error(f"Exception occurred: {e} for key: {k} values: {v}")
        return rule_usage_info
