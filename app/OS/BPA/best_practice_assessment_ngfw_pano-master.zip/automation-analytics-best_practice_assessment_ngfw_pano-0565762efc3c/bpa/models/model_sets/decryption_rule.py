import logging
from collections import defaultdict

from bpa.models.model_set import ModelSet
from bpa.models.utils.immutable import ImmutableCache
from bpa.models.utils.searching import get_cached_from_ancestors


LOG = logging.getLogger(__name__)


class DecryptionRuleModelSet(ModelSet):
    """Decryption rule model set"""

    def __init__(self):
        super().__init__()
        self.decrypt_profiles_with_rules = defaultdict(list)
        self._decrypt_profile_cache = ImmutableCache()

    def add(self, rule_model):
        self._cache_location_lookups(rule_model)
        super().add(rule_model)

    def _cache_location_lookups(self, rule_model):
        model_manager = rule_model.objects
        self._decrypt_profile_cache.fill_name(model_manager, "decryption_profile")

    def get_add_operations(self):
        return super().get_add_operations() + [self._store_decrypt_profiles_with_rules]

    def _store_decrypt_profiles_with_rules(self, rule_model):
        model_manager = rule_model.objects
        decrypt_ms = model_manager.get("decryption_profile")
        if len(decrypt_ms) == 0:
            LOG.debug("No decryption profiles found in model set")
        else:
            target = rule_model.decryption_profile
            profiles = get_cached_from_ancestors(
                model_manager, rule_model.location, self._decrypt_profile_cache
            )
            for prof in profiles:
                if prof.name == target:
                    key = (prof.location, prof.name)
                    self.decrypt_profiles_with_rules[key].append(rule_model)
