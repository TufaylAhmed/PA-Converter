import logging
from collections import defaultdict
from typing import List, Iterable

from bpa.models.model_set import ModelSet
from bpa.models.objects.security_profile.common import SecurityProfileGroupModel
from bpa.models.utils.immutable import ImmutableCache
from bpa.models.utils.searching import get_cached_from_ancestors

LOG = logging.getLogger(__name__)


class SecurityRuleModelSet(ModelSet):
    """Security rule model set.

    Custom model set to help with analyzers that involve aggregates.

    NOTE: sec_profiles_with_allow_rules pertains to individual security profiles.

    NOTE: _*_profile_cache is used to avoid excessive findall calls on model sets.

    Attributes:
        sec_profiles_with_allow_rules: (prof_loc, prof_name, prof_type): [rulename1, rulename2, rulename3]
        hip_profiles_with_rules: (prof_loc, prof_name): [rulename1, rulename2, rulename3]
        log_profiles_with_rules: (prof_loc, prof_name): [rulename1, rulename2, rulename3]
        app_filters_with_rules: (filter_loc, filter_name): [rulename1, rulename2, rulename3]
    """

    categories = SecurityProfileGroupModel.get_profile_keys() - {"data_filtering"}

    def __init__(self):
        super().__init__()
        self.sec_profiles_with_allow_rules = defaultdict(list)
        self.hip_profiles_with_rules = defaultdict(list)
        self.log_profiles_with_rules = defaultdict(list)
        self.app_filters_with_rules = defaultdict(list)
        self._hip_profile_cache = ImmutableCache()
        self._sec_profile_cache = ImmutableCache()
        self._log_profile_cache = ImmutableCache()
        self._app_filter_cache = ImmutableCache()
        self.using_threat_prevention = False
        self.using_url_filtering = False

    """Declare lifecycle for add() API"""

    def add(self, rule_model):
        self._cache_location_lookups(rule_model)
        super().add(rule_model)

    def _cache_location_lookups(self, rule_model):
        """Cache location lookups for profiles.

        NOTE: `findall` calls are expensive for model sets, and would
        need to be called every time a rule model was added.
        A `group_by` call can be used once instead upon the first
        rule model that is added, and achieve the same effect.
        """
        model_manager = rule_model.objects
        self._hip_profile_cache.fill_name(model_manager, "hip_profile")
        profile_types = [c + "_profile" for c in self.categories]
        self._sec_profile_cache.fill_names(model_manager, profile_types)
        self._log_profile_cache.fill_name(model_manager, "log_forwarding_profile")
        self._app_filter_cache.fill_name(model_manager, "application_filter")

    def get_add_operations(self) -> List:
        add_ops = super().get_add_operations()
        add_ops.extend(
            [
                self._store_hip_profiles_with_rules,
                self._store_sec_profiles_with_allow_rules,
                self._store_log_profiles_with_rules,
                self._store_app_filters_with_rules,
                self._store_using_threat_prevention,
                self._store_using_url_filtering,
            ]
        )
        return add_ops

    def _store_using_threat_prevention(self, rule_model):
        """Check if at least one enabled rule is using IPS"""
        if not self.using_threat_prevention:
            self.using_threat_prevention = (
                rule_model.rule_enabled and rule_model.using_ips_profile
            )

    def _store_using_url_filtering(self, rule_model):
        """Check if at least one enabled rule is using IPS"""
        if not self.using_url_filtering:
            self.using_url_filtering = (
                rule_model.rule_enabled and rule_model.profile_url_filtering is not None
            )

    def _store_hip_profiles_with_rules(self, rule_model):
        """Store hip profiles for given security rule model"""
        model_manager = rule_model.objects

        # Iterate through hip profiles
        hip_ms = model_manager.get("hip_profile")
        if len(hip_ms) == 0:
            LOG.debug("No hip profiles found in model set")
        else:
            hip_profile_names = getattr(rule_model, "hip_profiles")
            targets = get_cached_from_ancestors(
                model_manager, rule_model.location, self._hip_profile_cache
            )
            for hip_profile in targets:
                for hip_profile_name in hip_profile_names:
                    if hip_profile_name == hip_profile.name:
                        key = (hip_profile.location, hip_profile.name)
                        self.hip_profiles_with_rules[key].append(rule_model)
                        break

    def _store_sec_profiles_with_allow_rules(self, rule_model):
        """Add the closest security profile for each of the
        following profile types: antivirus, antispyware, etc. Iterates
        through the closest ancestors up to shared.

        Once a profile for a profile type is found, then don't search
        for that type anymore. The code terminates when there
        are no more ancestors to query.
        """
        if rule_model.action != "allow":
            return

        model_manager = rule_model.objects
        # Iterate through individual profiles
        for profile_category in self.categories:
            profile_type = profile_category + "_profile"
            profile_ms = model_manager.get(profile_type)
            if len(profile_ms) == 0:
                LOG.debug(f"No profiles found in '{profile_type}' model set")
                continue
            target = getattr(rule_model, "profile_" + profile_category)
            profiles = get_cached_from_ancestors(
                model_manager,
                rule_model.location,
                self._sec_profile_cache[profile_type],
            )
            for profile in profiles:
                if target == profile.name:
                    key = (profile.location, profile.name, profile_type)
                    self.sec_profiles_with_allow_rules[key].append(rule_model)
                    break

    def _store_log_profiles_with_rules(self, rule_model):
        model_manager = rule_model.objects

        # Iterate through log profiles
        log_ms = model_manager.get("log_forwarding_profile")
        if len(log_ms) == 0:
            LOG.debug("No log profiles found in model set")
        else:
            target = getattr(rule_model, "log_forwarding_profile")
            log_profiles = get_cached_from_ancestors(
                model_manager, rule_model.location, self._log_profile_cache
            )
            for log_profile in log_profiles:
                if target == log_profile.name:
                    key = (log_profile.location, log_profile.name)
                    self.log_profiles_with_rules[key].append(rule_model)
                    break

    def _store_app_filters_with_rules(self, rule_model):
        if not rule_model.rule_enabled:
            return
        model_manager = rule_model.objects
        filter_ms = model_manager.get("application_filter")
        if len(filter_ms) == 0:
            LOG.debug("No app filters found in model set")
            return
        filters = get_cached_from_ancestors(
            model_manager, rule_model.location, self._app_filter_cache
        )
        for filt in filters:
            good_filter = any(filt.name == f.name for f in rule_model.app_filters)
            good_rule = rule_model.rule_enabled
            if good_filter and good_rule:
                key = (filt.location, filt.name)
                self.app_filters_with_rules[key].append(rule_model)
                break

    # Magic / Special Method

    def __iter__(self) -> Iterable:
        """

        Returns: list of SecurityRuleModel where for each location pre-rulebase comes before post-rulebase.

        """
        # override default iter method to solve a bug related to ordering of pre-rulebase and post-rulebase

        data = list(super().__iter__())

        result = defaultdict(
            lambda: defaultdict(
                list,
                {
                    "pre-rulebase": [],
                    "post-rulebase": [],
                    "rulebase": [],
                    "default-security-rules": [],
                },
            )
        )
        for location_data in data:
            result[location_data.location][location_data.rulebase].append(location_data)

        container = []
        for key, value in result.items():
            ####### FOR PANORAMA ONLY #######
            container.extend(value.get("pre-rulebase"))
            container.extend(value.get("post-rulebase"))
            ####### FOR NGFW ONLY #######
            container.extend(value.get("rulebase"))
            container.extend(value.get("default-security-rules"))
        return iter(container)
