import logging
from typing import List

from bpa.models.model_set import ModelSet


LOG = logging.getLogger(__name__)


class AntivirusProfileModelSet(ModelSet):
    """Antivirus profile model set.

    Custom model set to help with license analyzers.
    """

    def __init__(self):
        super().__init__()
        self.using_wildfire = False

    def get_add_operations(self) -> List:
        add_ops = super().get_add_operations()
        add_ops.extend([self._store_using_wildfire])
        return add_ops

    def _store_using_wildfire(self, av_prof_model):
        """Check if at least one enabled rule is using WF with file types other than PE"""
        if not self.using_wildfire:
            self.using_wildfire = any(
                decoder.wildfire_action not in ["allow", "alert"]
                for decoder in av_prof_model.decoders
            )
