import logging
from collections import defaultdict

from bpa.models.model_set import ModelSet
from bpa.models.utils.immutable import ImmutableCache
from bpa.models.utils.searching import get_cached_from_ancestors


LOG = logging.getLogger(__name__)


class DosProtectionRuleModelSet(ModelSet):
    """DoS protection rule model set

    Attributes:
        dos_profiles_with_rules: (dos_loc, dos_name): [rulename1, rulename2]
        _dos_profile_cache: Avoid excessive findall calls
    """

    def __init__(self):
        super().__init__()
        self.dos_profiles_with_rules = defaultdict(list)
        self._dos_profile_cache = ImmutableCache()

    def add(self, rule_model):
        self._cache_location_lookups(rule_model)
        super().add(rule_model)

    def _cache_location_lookups(self, rule_model):
        model_manager = rule_model.objects
        self._dos_profile_cache.fill_name(model_manager, "dos_protection_profile")

    def get_add_operations(self):
        return super().get_add_operations() + [self._store_dos_profiles_with_rules]

    def _store_dos_profiles_with_rules(self, rule_model):
        model_manager = rule_model.objects
        dos_ms = model_manager.get("dos_protection_profile")
        if len(dos_ms) == 0:
            LOG.debug("No dos protection profiles found in model set")
        else:
            target = rule_model.dos_protection_profile
            profiles = get_cached_from_ancestors(
                model_manager, rule_model.location, self._dos_profile_cache
            )
            for prof in profiles:
                if prof.name == target:
                    key = (prof.location, prof.name)
                    self.dos_profiles_with_rules[key].append(rule_model)
