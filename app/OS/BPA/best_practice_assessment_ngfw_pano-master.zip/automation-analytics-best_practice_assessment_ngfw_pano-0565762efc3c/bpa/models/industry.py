from __future__ import annotations

from typing import Optional
from dataclasses import dataclass, asdict


@dataclass
class IndustryInfo:

    industry_name: str = "Other"
    industry_sum: Optional[IndustrySum] = None


@dataclass
class IndustrySum:

    total_rule_count: int
    allow_rule_count: int
    deny_rule_count: int

    wildfire_enabled: int
    zone_protection_profile_enabled: int
    log_forwarding_enabled: int
    log_end: int
    service_port_configured: int
    app_id_enabled: int
    user_id_enabled: int
    data_filtering_enabled: int
    file_blocking_enabled: int
    credential_theft_enabled: int
    url_filtering_enabled: int
    vulnerability_enabled: int
    antivirus_enabled: int
    dns_sinkhole_enabled: int
    antispyware_enabled: int

    # BP Mode
    wildfire_enabled_strict: int
    file_blocking_enabled_strict: int
    credential_theft_enabled_strict: int
    url_filtering_enabled_strict: int
    vulnerability_enabled_strict: int
    antivirus_enabled_strict: int
    dns_sinkhole_enabled_strict: int
    antispyware_enabled_strict: int

    @property
    def as_dict(self):
        """This will return the model values as a dictionary
        key: attribute
        value: summed up value
        """
        return asdict(self)

    @classmethod
    def from_dataframe(cls, data_frame):
        """Helper function to create an instance of this class from a data frame"""
        records = data_frame.to_dict(orient="record")
        if records:
            return cls(**records[0])
        return None
