import logging
from dataclasses import dataclass
from typing import List
from lxml import etree

from ..base_model import BaseModel
from ..mixins import TemplateMixin
from bpa.models.model_set import ModelSet

LOG = logging.getLogger(__name__)


@dataclass
class DeviceConfigModel(BaseModel, TemplateMixin):
    xpath = "//config[child::shared or child::devices or child::mgt-config]"

    locations: List[str]

    @classmethod
    def build_index(cls):
        return ["template_name"]

    @classmethod
    def parse(cls, model_manager) -> ModelSet:
        """Creates a list of instantiated objects for the target class.

        We are looking for config elements with shared, devices, or mgt-config child elements.
        """
        try:
            return super().parse(model_manager)
        except etree.XPathEvalError as e:
            LOG.info(
                f"Encountered {e.__class__.__name__} while parsing {cls.__name__}. Switching to back up logic"
            )
            model_set = cls.model_set()
            target_children = ("shared", "devices", "mgt-config")
            for el in model_manager.tree.xpatheval("//config"):
                if next(el.iterchildren(*target_children), None) is not None:
                    try:
                        model = cls.from_el(el, model_manager)
                        model_set.add(model)
                    except Exception as e:
                        LOG.exception(
                            f"Encountered {e.__class__.__name__} while parsing {cls.__name__}"
                        )
            return model_set

    @staticmethod
    def _get_locations(el, model_manager) -> List[str]:
        """Find all locations nested under the config element.

        This will include shared and all vsys entries.
        """
        locations = []
        for location_el in el.xpath("shared|devices/entry/vsys"):
            if location_el.tag == "shared":
                locations.append("shared")
            else:
                locations.extend(location_el.xpath("entry/@name"))
        return locations
