from .mixins import ModelMixin


class SubModel(ModelMixin):
    """Represents non-BaseModel dataclasses in BPA source code"""

    pass
