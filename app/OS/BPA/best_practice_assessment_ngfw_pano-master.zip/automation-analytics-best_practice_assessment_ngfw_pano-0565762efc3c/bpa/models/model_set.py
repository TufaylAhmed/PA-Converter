import logging

from collections import defaultdict
from typing import DefaultDict, Iterable, List, Optional, Tuple, Union

from .utils.lookup import build_signature_with_model, build_signature_with_kwargs

LOG = logging.getLogger(__name__)


class ModelSet:
    """Model set implementation.

    Model set provides users with the ability to retrieve model
    instances. By default, it uses a dictionary for its internal
    storage due to its efficient lookup.

    If a more sophisticated collection model is needed, then
    the __init__ and the add routine would need to be modified.

    Attributes:
        model_attrs: Model attributes that can be queried against.
        model_kls: Model class reference. Useful for building index.
    """

    def __init__(self):
        self._dict = dict()
        self.model_attrs = None
        self.model_kls = None

    """Declare lifecycle for add() API"""

    def get_add_operations(self) -> List:
        """API for retrieving order of add lifecycle.

        Order DOES matter in declaring add operations. The first
        entry in the list will be executed, followed by the next
        operation in the list, etc.

        Do NOT overwrite this function unless you know what
        you're doing. Rather, extend this function by calling
        the super() equivalent in the subclasses.
        """
        return [self._set_model_attrs]

    def _set_model_attrs(self, model):
        """Set model attributes.

        Populates model_kls and model_attrs if the model argument
        is the first BaseModel instance added.

        Args:
            model: BaseModel instance.

        Raises:
            TypeError if invalid BaseModel was provided.
        """
        if self.model_kls is None:
            self.model_kls = model.__class__
            self.model_attrs = set(model.__dict__.keys())
        elif not isinstance(model, self.model_kls):
            raise TypeError(
                f"ModelSet must contain {self.model_kls.__name__} instances."
            )
        self._dict[build_signature_with_model(model)] = model

    """Consumer APIs"""

    def add(self, model):
        """Add a model to the model sets.

        This is a mutable operation. In other words, this operation
        does not have a return value. If an exception is not thrown
        after running this method, one can assume that the API was
        executed successfully.

        Args:
            model: BaseModel instance.
        """
        for add_op in self.get_add_operations():
            add_op(model)

    def group_by(
        self, *fields: Union[Tuple[str], str]
    ) -> DefaultDict[Tuple[str], List]:
        """Group models by a field attribute.

        Sample return values::

            modelset.group_by('location') ->
            {
                ('shared',): [<Model 1>, <Model 2>],
                ('vsys1',): [<Model 3>, <Model 4>],
            }

            modelset.group_by('location', 'name') ->
            {
                ('shared', 'name1'): [<Model 1>, <Model 2>],
                ('vsys1', 'name2'): [<Model 3>, <Model 4>],
            }

        Args:
            fields: A tuple of model fields used for grouping by.

        Returns:
            A dictionary where keys are tuples of fields and values are lists of model instances "grouped by" those fields.

        Raises:
            AttributeError if any fields do not exist within any of the models.
            TypeError if any of the fields passed in are not strings.
        """
        agg = defaultdict(list)
        for model in self:
            signature = tuple(getattr(model, field) for field in fields)
            agg[signature].append(model)
        return agg

    def find(self, **criteria) -> Optional:
        """Find single model entry based on criteria.

        The criteria DOES have to fall within the model's signature.

        Args:
            criteria: Keyword arguments for criteria.

        Returns:
            Single model entry based on full criteria or None if not found.

        Raises:
            KeyError if criteria passed in is insufficient to build
            model signature.
        """
        if self.model_kls is None:
            LOG.debug("No models exist within the model set")
            return None
        LOG.debug(f"find {self.model_kls.__name__} with criteria: {criteria}")
        signature = build_signature_with_kwargs(self.model_kls, **criteria)
        try:
            return self._dict[signature]
        except KeyError:
            LOG.debug(f"No result was found with criteria: {criteria}")
            return None

    def findall(self, **criteria) -> List:
        """Find multiple model entries based on criteria.

        The criteria DOES NOT have to fall within the model's signature.

        Args:
            criteria: Keyword arguments for criteria.

        Returns:
            List of model entries based on partial/full criteria.

        Raises:
            AttributeError if any criteria passed in do not match model attributes.
        """
        results = []
        if self.model_kls is None:
            LOG.debug("No models exist within the model set")
            return results
        kls_name = self.model_kls.__name__
        LOG.debug(f"findall {kls_name} with criteria: {criteria}")
        leftover = set(criteria.keys()) - set(self.model_attrs)
        if leftover:
            raise AttributeError(
                f'Criteria do not fit within {kls_name} attributes: {",".join(leftover)}'
            )

        for model in self:
            # http://book.pythontips.com/en/latest/for_-_else.html#else-clause
            for attr, val in criteria.items():
                if getattr(model, attr) != val:
                    break
            else:
                results.append(model)

        if len(results) == 0:
            LOG.debug(f"No results were found with criteria: {criteria}")

        return results

    def findany(self, **criteria) -> Optional:
        """Find any entry from multiple results."""
        results = self.findall(**criteria)
        if len(results) > 0:
            return results[0]

    def extend(self, iterable):
        """Extend existing model set with iterable.

        Args:
            iterable: Collection of BaseModel instances.
        """
        for item in iterable:
            self.add(item)

    def has(self, model) -> bool:
        """Check for existence of model.

        NOTE: Convenient alias for the __contains__ magic
        method. Looks more human readable too.

        Args:
            model: BaseModel instance.

        Returns:
            Whether the BaseModel instance exists in the model set.
        """
        return build_signature_with_model(model) in self

    def device_group_with_policies_configured_for_security_rule(
        self, excluded_shared=False
    ) -> DefaultDict[Tuple[str], List]:
        """

        Args:
            excluded_shared: accepts boolean value. by default it is False. oif you want to count shared as device group leave it false, if you want to exclude it change it to True.

        Returns:
            defaultdict(list) containing list of unique locations of device group.
        """
        if excluded_shared:
            return defaultdict(
                list,
                {
                    key: value
                    for (key, value) in self.group_by("location").items()
                    if "shared" not in key
                },
            )
        return self.group_by("location")

    """Magic methods"""

    def __iter__(self) -> Iterable:
        """Provide ModelSet as an iterable."""
        return iter(self._dict.values())

    def __len__(self) -> int:
        """Retrieve size of ModelSet."""
        return len(self._dict)

    def __getitem__(self, signature: Tuple):
        """Retrieve item from ModelSet given signature lookup."""
        return self._dict[signature]

    def __contains__(self, signature: Tuple):
        """Check whether model set contains a given signature."""
        return signature in self._dict
