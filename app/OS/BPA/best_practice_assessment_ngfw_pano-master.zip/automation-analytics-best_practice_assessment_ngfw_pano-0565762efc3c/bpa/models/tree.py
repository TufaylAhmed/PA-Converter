import os
import json
from collections import defaultdict
from typing import DefaultDict, List, Optional, Set

from lxml import etree

from bpa import data_path

from . import query


class Tree:
    """Tree model.

    Attributes:
        tree: A lxml.etree._ElementTree representing the device XML config.
        xpatheval: XPath evaluator.
        version: Version of the codebase.
        urldb: Location of URL database.
        panorama: Boolean flag for Panorama/firewall.
        ancestors: Ancestors of each node in the XML.
        descendants: Descendants of each node in the XML.
        dgs_with_devices: Device groups with devices.
        parser: XML parser from lxml.
    """

    url_categories = json.load(open(os.path.join(data_path, "url_categories.json")))

    def __init__(self, tree: etree._ElementTree):
        self.tree = tree
        self.xpatheval = etree.XPathEvaluator(tree)
        self._version: str = next(iter(query.get_version(self.tree)), "0.0.0")
        self.urldb = next(iter(query.get_urldb(self.tree)), "paloaltonetworks")
        self.url_categories = set(Tree.url_categories[self.urldb])
        self.panorama = query.is_panorama(self.tree)
        self.ancestors = self.parse_ancestors()
        self.descendants = self.parse_descendants()
        self.descendants_tree, self.tree_dict = self.make_tree()
        self.clean_xml()
        self.add_predefined()
        self.dgs_with_devices = self.parse_dgs_with_devices()
        self.vsys_names = self.parse_vsys_names()
        self.clientless_vpn_enabled = query.clientless_vpn_enabled(tree)

    @property
    def version(self) -> float:
        return float(self._version[:3])

    @property
    def ngfw(self) -> bool:
        """Retrieve the inverse of panorama attribute."""
        return not self.panorama

    @property
    def locations(self) -> Set:
        """Retrieve locations depending on PAN-OS device type."""
        if self.panorama:
            return {dg for dg, devices in self.dgs_with_devices.items() if devices}
        else:
            return set(self.vsys_names)

    def get_managed_device_count(self) -> Optional[int]:
        if self.ngfw:
            return None
        return query.managed_devices_count(self.tree)

    def parse_ancestors(self) -> DefaultDict[str, List]:
        """Parses location (vsys or device group) ancestors."""
        ancestors = defaultdict(list)
        ancestors["shared"] = ["shared", "predefined"]
        ancestors["predefined"] = ["predefined"]
        ancestors.update(
            {
                vsys: [vsys, "shared", "predefined"]
                for vsys in set(query.get_vsys_names(self.tree))
            }
        )
        if self.panorama:
            hierarchy = query.get_dg_hierarchy(self.tree)
            if hierarchy:
                for entry in hierarchy:
                    target_dg = entry.get("name")
                    ancestors[target_dg].append(target_dg)
                    parent_name = entry.findtext("parent-dg")
                    while parent_name is not None:
                        ancestors[target_dg].append(parent_name)
                        try:
                            parent_entry = next(
                                entry
                                for entry in hierarchy
                                if entry.get("name") == parent_name
                            )
                        except StopIteration:
                            parent_name = None
                        else:
                            parent_name = parent_entry.findtext("parent-dg")
                    ancestors[target_dg].extend(["shared", "predefined"])
            else:
                # Some older versions do not have the device group hierarchy,
                # so the parent for each device group will be 'shared'.
                ancestors.update(
                    {
                        dg: [dg, "shared", "predefined"]
                        for dg in query.get_dg_names(self.tree)
                    }
                )
        return ancestors

    def parse_descendants(self):
        """Parses location (vsys or device group) descendants."""
        #  Used ordered set instead of set since order was random.
        descendants = defaultdict(set)
        descendants["shared"].add("shared")
        descendants["predefined"].update(["predefined", "shared"])
        if self.ngfw:
            vsys_names = query.get_vsys_names(self.tree)
            descendants["shared"].update(vsys_names)
            descendants["predefined"].update(vsys_names)
            descendants.update({vsys: {vsys} for vsys in vsys_names})
        else:
            dg_names = query.get_dg_names(self.tree)
            descendants["shared"].update(dg_names)
            descendants["predefined"].update(dg_names)
            descendants.update({dg: {dg} for dg in dg_names})
            for hierarchy in self.ancestors.values():
                # everything except the last item (shared), reversed
                targets = hierarchy[-2::-1]
                for i, target in enumerate(targets):
                    descendants[target].update(targets[i:])
        return descendants

    def parse_dgs_with_devices(self):
        """Parses all device groups that contain devices.

        Returns a dictiory where keys are device groups and values are the
        associated serial number/vsys combinations.
        """
        dgs_with_devices = defaultdict(list)
        for device_group in query.get_dgs_with_devices(self.tree):
            dg_name = device_group.get("name")
            for device in device_group.findall("devices/entry"):
                serial_number = device.get("name")
                try:
                    vsys = device.find("vsys/entry").get("name")
                except AttributeError:
                    vsys = "no-vsys"
                dgs_with_devices[dg_name].append((serial_number, vsys))
        return dgs_with_devices

    def parse_vsys_names(self):
        """Parses all vsys names for NGFW device."""
        return query.get_vsys_names(self.tree)

    def clean_xml(self):
        """Remove unneeded elements from the ElementTree.

        Skip parsing template stacks for versions below 8.1.
        Remove the readonly element to simplify XPATH queries.
        """
        if self.version < 8.1:
            skip_parsing = ["devices/entry/template-stack", "readonly"]
        else:
            skip_parsing = ["readonly"]
        for xpath in skip_parsing:
            try:
                el = self.tree.find(xpath)
                el.getparent().remove(el)
            except AttributeError:
                pass

    def add_predefined(self) -> None:
        """Predefined profiles do not exist in the XML, so insert them manually.

        Location will be:
        /config/predefined/profiles/...
        """
        predefined = etree.fromstring(
            open(os.path.join(data_path, "predefined.xml")).read()
        )
        self.tree.getroot().insert(0, predefined)

    def make_tree(self):
        # establish a root node
        root = Node("root")
        #  dictionary to save us from dfs and considering scenario there is all unique(dg name) name only.
        container = {}
        for key, hierarchy in self.ancestors.items():
            # reverse it so predefined always comes first
            targets = hierarchy[::-1]
            self.helper_func_to_make_tree(root, targets, container)

        return root, container

    def helper_func_to_make_tree(self, node, list_of_val, container):
        val = list_of_val[0]
        is_child_exists, existing_child = node.has_child(val)
        #  create child node
        if not is_child_exists:
            child_node = Node(str(val))
            node.add_child(child_node)
            #  adding values to dictionary so at any time we can have access of any node. and we don't need to
            # iterate through tree.
            container[str(val)] = child_node
            if len(list_of_val) != 1:
                self.helper_func_to_make_tree(child_node, list_of_val[1:], container)
        else:
            #  when we already created child. Like predefined comes always in list_of_val since it's ancestor of everything.
            #  to handle that scenario write next lines.
            if len(list_of_val) != 1:
                self.helper_func_to_make_tree(
                    existing_child, list_of_val[1:], container
                )
        return node


class Node:
    """
    Tree data structure especially to store descendants.
    """

    def __init__(self, val):
        self.val = val
        self.children = []

    def add_child(self, child):
        self.children.append(child)

    def update_child(self, list_of_child):
        self.children.extend(list_of_child)

    def has_child(self, val):
        for child in self.children:
            if child.val == val:
                return True, child
        return False, None

    def __repr__(self):
        return self.val
