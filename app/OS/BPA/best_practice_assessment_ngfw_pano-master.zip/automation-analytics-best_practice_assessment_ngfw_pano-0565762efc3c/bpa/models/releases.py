import datetime
import logging
import os
from typing import Dict

import requests
from dateutil.parser import parse

LOG = logging.getLogger(__name__)


def get_release_dates() -> Dict[str, datetime.date]:
    url = "https://content-prod.paloaltonetworks.com/reader/api/v1/getcontent"
    try:
        key = os.environ["CONTENT_API_KEY"]
    except KeyError:
        LOG.error("Missing CONTENT_API_KEY environment variable")
        return {}
    headers = {"Content-Type": "application/json", "apikey": key}
    body = {
        "contentType": "software",
        "queryFilters": [
            {"filterName": "product", "filterType": "equals", "filterValue": "panos"},
            {
                "filterName": "versionNumber",
                "filterType": "Greaterorequal",
                "filterValue": "7.1.0",
            },
        ],
    }
    req = requests.post(url, headers=headers, json=body)
    try:
        req.raise_for_status()
    except requests.exceptions.HTTPError:
        LOG.error("Error connecting to Content Updates API", exc_info=True)
        return {}
    releases = {}
    for record in req.json()["data"]:
        release_date = parse(record["releaseDate"]).date()
        releases[record["versionNumber"]] = release_date
    return releases
