import logging
from dataclasses import dataclass
from typing import Optional

from lxml import etree

from .default_value import DefaultValue, NameValue
from .utils.lookup import find_ancestor_value
from .utils.masking import mask_general, mask_ipv4


LOG = logging.getLogger(__name__)


@dataclass
class LocationMixin:
    """Mixin for location attribute.

    Used to dynamically add `location` attribute to BaseModel classes.
    Also used in the default `build_index` routine of BaseModel.

    Attributes:
        location: Refers to vsys or device group, depending on the PAN-OS device.
    """

    location: str

    @staticmethod
    def _get_location(el: etree._Element, model_manager) -> Optional[str]:
        """Get location."""
        return find_ancestor_value(
            el,
            {"vsys", "device-group", "shared-gateway"},
            {"shared", "predefined", "panorama"},
        )


@dataclass
class TemplateMixin:
    """Mixin for template_name attribute.

    Used to dynamically add `template_name` attribute to BaseModel classes.
    Also used in the default `build_index` routine of BaseModel.

    Attributes:
        template_name: Template name.
    """

    template_name: str

    @staticmethod
    def _get_template_name(el: etree._Element, model_manager) -> Optional[str]:
        """Get template name."""
        return find_ancestor_value(el, ["template", "template-stack"])


class DefaultMixin:
    """Mixin for parsing DefaultValue objects"""

    def __getattribute__(self, attr):
        """Handle literal attributes from the object"""
        aval = super().__getattribute__(attr)
        atype = type(aval)
        if atype is DefaultValue:
            return aval.value
        # NOTE: Lists of NameValue objects should not have other object types
        elif atype is list and aval and type(aval[0]) is NameValue:
            return [_.name for _ in aval]
        else:
            return aval


class MaskMixin:
    """Mixin for masking values.

    NOTE: mask_attr fields have a list of fallback algorithm keys.
    In other words, if algo[ak1] fails then run algo[ak2], then
    run algo[ak3], etc.

    Attributes:
        mask_attrs: {field1: [ak1, ak2], field2: [ak2], field3: [ak1]}
    """

    # NOTE: Override in sub-models and base-models
    mask_attrs = {}

    # NOTE: Each key is linked to a masking algorithm
    mask_algos = {
        "ipv4": mask_ipv4,
        "ipv6": mask_general,
        "name": mask_general,
        "fqdn": mask_general,
        "default": mask_general,
    }

    def maskable(self, attr_key: str) -> bool:
        """Determine whether attribute name is maskable."""
        return attr_key in self.mask_attrs

    def mask(self, attr_key: str) -> str:
        """Mask with object attribute."""
        attr_val = getattr(self, attr_key)
        return self.maskv(attr_key, attr_val)

    def maskv(self, attr_key: str, attr_val: str) -> str:
        """Mask with arbitrary value."""
        for algo in self.mask_attrs[attr_key] + ["default"]:
            try:
                return self.mask_algos[algo](attr_val)
            except Exception:
                continue
        else:
            raise ValueError(f"Masking failed with {attr_key}")


class DictMixin:
    """Mixin for building sanitized dictionary"""

    # NOTE: Works because MaskMixin exists
    def _getv(self, key, val):
        if isinstance(val, DictMixin):
            return val.to_dict()
        elif self.maskable(key):
            return self.maskv(key, val)
        return val

    def to_dict(self):
        """Convert Model instance to a dictionary.

        NOTE: Excludes model_manager attribute from dataclass fields as it has
        some attributes that are not pickleable. Add further processing to this
        routine if specific items in the BaseModel instances are not pickleable.

        NOTE: The main hunch is that most dataclass fields are pickleable.
        Otherwise, the test utilities would error out (i.e. build_models
        and build_skeleton).
        """
        result = {}
        for pk in self.__dict__:
            if pk in {"model_manager", "template_vars"}:
                continue
            pv = getattr(self, pk)
            if isinstance(pv, dict):
                result[pk] = {sk: self._getv(sk, sv) for sk, sv in pv.items()}
            elif isinstance(pv, list):
                result[pk] = [self._getv(pk, i) for i in pv]
            elif isinstance(pv, set):
                result[pk] = {self._getv(pk, i) for i in pv}
            else:
                result[pk] = self._getv(pk, pv)
        return result


class TemplateVariableMixin:
    """Mixin for resolving template variables"""

    def _resolve_template_var(self, mgr, fname: str, tname: str, attr: str) -> str:
        """Resolve a single template variable.

        NOTE: We resolve template variables multiple times because
        variables are not static per-se. They are highly dependent on
        the template/stack that they live under. Thus, we do a combination
        of eager resolution and eventual resolution. The breadcrumbs from
        template_vars helps with resolving variables accurately in real-time.

        Args:
            mgr: ModelManager instance.
            fname: Field name.
            tname: Template name.
            attr: Field value.

        Returns:
            Modified/resolved OR raw field value.
        """
        # NOTE: Use breadcrumbs if resolved before
        if fname in self.template_vars["fields"]:
            attr = self.template_vars["fields"][fname]
        elif not attr.startswith("$"):
            return attr

        def lookup(mgr, feature: str) -> Optional[str]:
            """Helper function for looking up variables."""
            model_set = mgr.get(feature)
            model = model_set.find(name=tname)
            if model:
                val = model.variables.get(attr)
                if val:
                    self.template_vars["fields"][fname] = attr
                    self.template_vars["vars"][attr] = val
                    return val

        sval = lookup(mgr, "template_stack")
        if sval:
            return sval

        tval = lookup(mgr, "template")
        if tval:
            return tval

        # NOTE: Use breadcrumbs if resolved before
        if attr in self.template_vars["vars"]:
            return self.template_vars["vars"][attr]

        return attr

    def resolve_from_base(self):
        """Wrapper for BaseModel instances to run resolve_template_vars."""
        self.resolve_template_vars(self.objects, self.template_name)

    def resolve_template_vars(self, mgr, tname: str):
        """Resolve template variables for a base/sub model.

        NOTE: resolve_template_vars is an expensive operation as it involves
        recursing through BaseModel and SubModel instances, resolving
        any strings that start with the '$' signal.

        Attributes:
            mgr: Instance of model manager to query templates from.
            tname: Template name to query for.
        """
        if tname is None:
            return
        LOG.debug(f"Resolving {type(self).__name__} instance...")
        for k, v in self.__dict__.items():
            if k in {
                "name",
                "template_name",
                "location",
                "model_manager",
                "template_vars",
            }:
                continue
            if isinstance(v, str):
                setattr(self, k, self._resolve_template_var(mgr, k, tname, v))
            elif isinstance(v, ModelMixin):
                v.resolve_template_vars(mgr, tname)
            elif isinstance(v, list) and all(isinstance(_, str) for _ in v):
                for index, item in enumerate(v):
                    # Combining key + index so that the field name is unique
                    # and does not cause premature caching.
                    v[index] = self._resolve_template_var(mgr, f"{k}{index}", tname, item)


@dataclass
class ModelMixin(DefaultMixin, MaskMixin, DictMixin, TemplateVariableMixin):
    """Composite mixin for models.

    NOTE: Instead of stuffing all possible methods in here, we make use of
    Python's multiple inheritence to build a mixin that is usable for
    traversing and interacting with the attributes and state of
    BaseModel and SubModel instances. To learn more, please read the
    code and docstrings of each inherited mixin.

    NOTE: template_vars is essentially breadcrumbs for tracking template
    variable resolution history while model attributes are resolved/combined via
    templates. The 'fields' key of template_vars represents key-value pairs
    s.t. the model's dataclass field names map directly to the template variable
    names that were previously resolved under that field. The 'vars' key of
    template_vars represents key-value pairs s.t. the template variables names
    map directly to the template variable values. template_vars is NOT
    meant to be used as a permanent attribute so it must be popped off the
    __dict__ before running a constructor again. To learn more about
    template_vars usage, see code for template stack resolution and
    code for template variable resolution.
    """

    def __post_init__(self):
        """Triggers a post-constructor lifecycle for all models.

        NOTE: Setting template_vars at this stage is fine as the
        this happens after the validation for constructor params has
        been made.

        NOTE: There's a way to incur the cost of this processing ONLY at
        the beginning and end of the template stack resolution process.
        It's by checking whether the cached model set has the model signature
        already. That's because the first time the model signature is created,
        there are one of two possibilities: a) the model set does not exist
        OR b) the model signature does not exist in the cached
        model set. By the time that template stack resolution occurs,
        partially composed model(s) would have a duplicate model
        signature which can easily be found in the model set.
        """
        self.template_vars = {"fields": {}, "vars": {}}
        if not isinstance(self, TemplateMixin):
            return
        mk = type(self).build_model_key()
        ms = self.objects.get(mk, lazy=False)
        if ms and ms.has(self):
            return
        self.resolve_from_base()

    @classmethod
    def from_cleanup(cls, **attrs):
        """Create model from clean attributes.

        NOTE: Useful for cases where the dataclass/constructor
        attributes already have a default value configured.
        """
        new_attrs = {k: v for k, v in attrs.items() if v is not None}
        return cls(**new_attrs)
