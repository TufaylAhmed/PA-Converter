# -*- coding: utf-8 -*-
from typing import List

from dataclasses import dataclass

from ...base_model import BaseModel


@dataclass
class PdfReportGroupModel(BaseModel):
    xpath = "/config/shared/report-group/entry[custom-widget]"
    name: str
    reports: List[str]

    @staticmethod
    def _get_name(el, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_reports(el, model_manager) -> str:
        return [el.text for el in el.findall("custom-widget/entry/predefined-report")]
