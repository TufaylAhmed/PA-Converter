# -*- coding: utf-8 -*-
from typing import List

from dataclasses import dataclass

from ...base_model import BaseModel


@dataclass
class PdfSummaryReportModel(BaseModel):
    xpath = "/config/shared/pdf-summary-report/entry"
    name: str
    reports: List[str]

    @staticmethod
    def _get_name(el, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_reports(el, model_manager) -> str:
        return [el.attrib["name"] for el in el.findall("predefined-widget/entry")]
