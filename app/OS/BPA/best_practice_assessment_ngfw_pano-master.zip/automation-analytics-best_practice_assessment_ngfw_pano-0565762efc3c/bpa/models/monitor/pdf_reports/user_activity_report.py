# -*- coding: utf-8 -*-
from dataclasses import dataclass

from ...base_model import BaseModel
from ...mixins import LocationMixin


@dataclass
class UserActivityReportModel(BaseModel, LocationMixin):
    xpath = "//report-group/entry[predefined]"

    name: str
    report_type: str

    @staticmethod
    def _get_name(el, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_report_type(el, model_manager) -> str:
        return el.findtext("predefined")
