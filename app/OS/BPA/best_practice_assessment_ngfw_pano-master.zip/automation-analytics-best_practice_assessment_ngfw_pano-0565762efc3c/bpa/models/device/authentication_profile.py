from typing import List, Optional, Union

from dataclasses import dataclass

from bpa.models.base_model import BaseModel
from bpa.models.constants import NONE_LOWER
from bpa.models.default_value import DefaultValue
from bpa.models.mixins import LocationMixin, TemplateMixin
from bpa.models.utils.parsing import parse_int, parse_list, parse_text

from .server_profiles import ServerProfileModel


@dataclass
class AuthenticationProfileModel(BaseModel, LocationMixin, TemplateMixin):
    """Device / Panorama > Authentication Profile."""

    xpath = "//authentication-profile/entry"

    name: str
    method: str
    server_profile: Optional[str]
    allow_list: Union[List[str], DefaultValue]
    lockout_time: Union[int, DefaultValue]
    failed_attempts: Union[int, DefaultValue]

    mask_attrs = {"allow_list": ["name"]}

    def using_radius_saml(self):
        """Checks whether profile is using Radius or SAML as the authentication type."""
        return self.method in {"radius", "saml"}

    def using_local_authentication(self) -> bool:
        return self.method in {NONE_LOWER, "local-database"}

    @property
    def external_method(self):
        return self.method not in {NONE_LOWER, "local-database"}

    @property
    def svr_prof_obj(self) -> Optional[ServerProfileModel]:
        custom = {"snmptrap": "snmp_trap", "tacplus": "tac_plus"}
        model_key_pre = custom.get(self.method, self.method)
        model_key = f"{model_key_pre}_server_profile"
        return self.objects.get(model_key).find(
            location=self.location,
            template_name=self.template_name,
            name=self.server_profile,
        )

    @staticmethod
    def _get_name(el, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_method(el, model_manager) -> str:
        return el.find("method/*").tag

    @staticmethod
    def _get_server_profile(el, model_manager) -> Optional[str]:
        return parse_text(el, "method/*/server-profile")

    @staticmethod
    def _get_allow_list(el, model_manager) -> Union[List[str], DefaultValue]:
        return parse_list(el, "allow-list/member/text()", [])

    @staticmethod
    def _get_lockout_time(el, model_manager) -> Union[int, DefaultValue]:
        return parse_int(el, "lockout/lockout-time", 0)

    @staticmethod
    def _get_failed_attempts(el, model_manager) -> Union[int, DefaultValue]:
        return parse_int(el, "lockout/failed-attempts", 0)
