from dataclasses import dataclass
from lxml import etree

from bpa.models.base_model import BaseModel
from bpa.models.mixins import TemplateMixin


@dataclass
class UserIdHubModel(BaseModel, TemplateMixin):
    xpath = "//user-id-hub"

    name: str

    @staticmethod
    def _get_name(el: etree._Element, model_manager):
        return el.findtext(".")
