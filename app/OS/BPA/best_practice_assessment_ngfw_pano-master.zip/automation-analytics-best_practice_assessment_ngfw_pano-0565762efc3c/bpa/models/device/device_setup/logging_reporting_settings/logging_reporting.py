from typing import Optional, Union

from dataclasses import dataclass
from lxml import etree

from bpa.models.default_value import DefaultValue
from bpa.models.query import in_template
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import parse_match


@dataclass
class LoggingReportingSettings(SubModel):
    """Device Setup > Logging Reporting Settings

    Panorama has Buffered Log Forwarding from Device configuration option (log_forwarding_from_device_enabled),
    whereas NGFWs / device templates have Log on High DP Load configuration option (log_on_high_dp_load_enabled)
    """

    log_forwarding_from_device_enabled: Optional[Union[bool, DefaultValue]] = None
    log_on_high_dp_load_enabled: Optional[Union[bool, DefaultValue]] = None

    base = "devices/entry/deviceconfig/setting/management"

    @classmethod
    def parse_entry(cls, el: etree._Element, panorama: bool):
        attrs = {}
        if not panorama or in_template(el):
            attrs["log_on_high_dp_load_enabled"] = parse_match(
                el, f"{cls.base}/enable-log-high-dp-load", "yes", False
            )
        else:
            attrs["log_forwarding_from_device_enabled"] = parse_match(
                el, f"{cls.base}/log-forwarding-from-device/buffered", "yes", True
            )
        return cls(**attrs)
