from typing import List, Union

from dataclasses import dataclass
from lxml import etree

from bpa.models.sub_model import SubModel
from bpa.models.default_value import DefaultValue
from bpa.models.utils.parsing import parse_match


@dataclass
class ContentIdSettings(SubModel):
    """Device Setup > Content ID Settings"""

    use_x_forwarded_for_enabled: Union[bool, DefaultValue] = DefaultValue(False)
    strip_x_forwarded_for_enabled: Union[bool, DefaultValue] = DefaultValue(False)
    exceed_tcp_queue_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    exceed_udp_queue_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    exceed_appID_queue_enabled: Union[bool, DefaultValue] = DefaultValue(False)
    vsys_not_forwarding_decrypted_content: Union[
        List[str], DefaultValue
    ] = DefaultValue([])
    allow_http_range: Union[bool, DefaultValue, None] = None
    skip_block_http_range: Union[bool, DefaultValue, None] = None

    base = "devices/entry/deviceconfig/setting"

    @property
    def http_partial_enabled(self):
        return self.allow_http_range or self.skip_block_http_range

    @property
    def http_partial_name(self):
        if self.allow_http_range is not None:
            return "Allow HTTP partial response"
        else:
            return "Allow HTTP header range option"

    @classmethod
    def parse_vsys_with_decryption(cls, el) -> Union[List, None]:
        vsys_with_decryption_policies = el.xpath(
            'entry/vsys/entry[rulebase/decryption/rules/entry/action[text()="decrypt"]]'
        )
        bad_vsys = []
        for vsys in vsys_with_decryption_policies:
            try:
                if (
                    vsys.find(
                        "setting/ssl-decrypt/allow-forward-decrypted-content"
                    ).text
                    != "yes"
                ):
                    bad_vsys.append(vsys.get("name"))
            # allow-forward-decrypted-content is DISABLED by default and does not show up in XML
            except AttributeError:
                bad_vsys.append(vsys.get("name"))
        if len(bad_vsys) > 0:
            return None
        else:
            return bad_vsys

    @classmethod
    def parse_entry(
        cls, el: etree._Element, panorama: bool, version: float
    ) -> "ContentIdSettings":
        attrs = {}
        attrs["use_x_forwarded_for_enabled"] = parse_match(
            el, f"{cls.base}/ctd/x-forwarded-for", "yes"
        )
        attrs["strip_x_forwarded_for_enabled"] = parse_match(
            el, f"{cls.base}/ctd/strip-x-fwd-for", "yes"
        )
        attrs["exceed_tcp_queue_enabled"] = parse_match(
            el, f"{cls.base}/ctd/tcp-bypass-exceed-queue", "yes"
        )
        attrs["exceed_udp_queue_enabled"] = parse_match(
            el, f"{cls.base}/ctd/udp-bypass-exceed-queue", "yes"
        )
        attrs["exceed_appID_queue_enabled"] = parse_match(
            el, f"{cls.base}/application/bypass-exceed-queue", "yes"
        )

        if version >= 8.1:
            result = parse_match(el, f"{cls.base}/ctd/allow-http-range", "yes", True)
            if result is not None:
                attrs["allow_http_range"] = result
            else:
                attrs["allow_http_range"] = DefaultValue(True)
        else:
            result = parse_match(
                el, f"{cls.base}/ctd/skip-block-http-range", "yes", True
            )

        if not panorama:
            attrs[
                "vsys_not_forwarding_decrypted_content"
            ] = cls.parse_vsys_with_decryption(el)
        return cls.from_cleanup(**attrs)

    def to_dict(self):
        """Custom to_dict to rename attributes."""

        def sanitize(field):
            if field == "allow_http_range":
                return "allow_http_partial_response"
            elif field == "skip_block_http_range":
                return "allow_http_header_range_option"
            else:
                return field

        return {sanitize(k): v for k, v in super().to_dict().items() if v is not None}
