import datetime
from typing import Optional
from dataclasses import dataclass

from bpa.models.base_model import BaseModel
from bpa.models.mixins import TemplateMixin


# TODO: Sync with Samshodh on whether LocationMixin is needed
@dataclass
class CertificateModel(BaseModel, TemplateMixin):
    """Certificate configuration"""

    xpath = "//certificate/entry"
    forward_trust_certificates_xpath = (
        "/config/shared/ssl-decrypt/forward-trust-certificate/child::*/text()"
    )
    forward_untrust_certificates_xpath = (
        "/config/shared/ssl-decrypt/forward-untrust-certificate/child::*/text()"
    )

    name: str
    issuer_hash: Optional[str]
    subject_hash: Optional[str]
    forward_trust_certificate: bool
    forward_untrust_certificate: bool
    expiry: datetime.datetime

    @classmethod
    def _get_name(cls, el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_issuer_hash(el, model_manager):
        return el.findtext("issuer-hash")

    @staticmethod
    def _get_subject_hash(el, model_manager):
        return el.findtext("subject-hash")

    @staticmethod
    def _get_expiry(el, model_manager):
        return el.findtext("not-valid-after")

    @classmethod
    def _get_forward_trust_certificate(cls, el, model_manager):
        certificate_name = cls._get_name(el, model_manager)
        forward_trust_certificates_list = model_manager.tree.xpatheval(
            cls.forward_trust_certificates_xpath
        )
        return certificate_name in forward_trust_certificates_list

    @classmethod
    def _get_forward_untrust_certificate(cls, el, model_manager):
        certificate_name = cls._get_name(el, model_manager)
        forward_untrust_certificates_list = model_manager.tree.xpatheval(
            cls.forward_untrust_certificates_xpath
        )
        return certificate_name in forward_untrust_certificates_list
