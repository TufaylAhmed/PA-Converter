from typing import List, Optional, Union

from dataclasses import dataclass
from lxml import etree

from bpa.models.sub_model import SubModel
from bpa.models.default_value import DefaultValue
from bpa.models.utils.parsing import parse_match


class TelemetryBase(SubModel):
    def disabled_feeds(self) -> List[str]:
        return [
            key.replace("_", " ").title()
            for key, val in self.__dict__.items()
            if val is False
        ]


@dataclass
class StatsServicesSettings(TelemetryBase):
    """Device Setup > Statistic Services Settings

    Statistic Services was renamed to Telemetry in PAN OS 8.0.
    """

    application_usage: bool = False
    attackers: bool = False
    attacking_countries: bool = False
    unknown_applications_by_destination_ports: bool = False
    unknown_applications_by_destination_addresses: bool = False
    unknown_categories_by_url: bool = False
    malware_categories_by_url: bool = False
    dataplane_cache_url: bool = False
    software_crash_info: bool = False

    @classmethod
    def parse_entry(cls, el: Optional[etree._Element]) -> "StatsServicesSettings":
        """
        Args:
            el: config element
        """
        stats_service_el = el.find(
            "devices/entry/deviceconfig/system/update-schedule/statistics-service"
        )
        if stats_service_el is None:
            return cls()
        attrs = {}
        attrs["application_usage"] = (
            stats_service_el.findtext(
                "application-and-threat-reports/application-usage", "no"
            )
            == "yes"
        )
        attrs["attackers"] = (
            stats_service_el.findtext("application-and-threat-reports/attackers", "no")
            == "yes"
        )
        attrs["attacking_countries"] = (
            stats_service_el.findtext(
                "application-and-threat-reports/attacking-countries", "no"
            )
            == "yes"
        )
        attrs["unknown_applications_by_destination_ports"] = (
            stats_service_el.findtext(
                "unknown-application-reports/unknown-applications-by-destination-ports",
                "no",
            )
            == "yes"
        )
        attrs["unknown_applications_by_destination_addresses"] = (
            stats_service_el.findtext(
                "unknown-application-reports/unknown-applications-by-destination-addresses",
                "no",
            )
            == "yes"
        )
        attrs["unknown_categories_by_url"] = (
            stats_service_el.findtext("url-reports/unknown-categories-by-url", "no")
            == "yes"
        )
        attrs["malware_categories_by_url"] = (
            stats_service_el.findtext("url-reports/malware-categories-by-url", "no")
            == "yes"
        )
        attrs["dataplane_cache_url"] = (
            stats_service_el.findtext("url-reports/dataplane-cache-url", "no") == "yes"
        )
        attrs["software_crash_info"] = (
            stats_service_el.findtext("device/software-crash-info", "no") == "yes"
        )
        return cls(**attrs)


@dataclass
class TelemetrySettings(TelemetryBase):
    """Device Setup > Telemetry Settings

    Statistic Services was renamed to Telemetry in PAN OS 8.0.
    """

    application_reports: Union[bool, DefaultValue] = DefaultValue(False)
    threat_prevention_reports: Union[bool, DefaultValue] = DefaultValue(False)
    threat_prevention_pcap: Union[bool, DefaultValue] = DefaultValue(False)
    threat_prevention_information: Union[bool, DefaultValue] = DefaultValue(False)
    passive_dns_monitoring: Union[bool, DefaultValue] = DefaultValue(False)
    url_reports: Union[bool, DefaultValue] = DefaultValue(False)
    health_performance_reports: Union[bool, DefaultValue] = DefaultValue(False)
    file_identification_reports: Union[bool, DefaultValue] = DefaultValue(False)

    @classmethod
    def parse_entry(cls, el: Optional[etree._Element]) -> "TelemetrySettings":
        """
        Args:
            el: config element
        """
        stats_service_el = el.find(
            "devices/entry/deviceconfig/system/update-schedule/statistics-service"
        )
        if stats_service_el is None:
            return cls()
        attrs = {}
        attrs["application_reports"] = parse_match(
            stats_service_el, "application-reports", "yes"
        )
        attrs["threat_prevention_reports"] = parse_match(
            stats_service_el, "threat-prevention-reports", "yes"
        )
        attrs["threat_prevention_pcap"] = parse_match(
            stats_service_el, "threat-prevention-pcap", "yes"
        )
        attrs["threat_prevention_information"] = parse_match(
            stats_service_el, "threat-prevention-information", "yes"
        )
        attrs["passive_dns_monitoring"] = parse_match(
            stats_service_el, "passive-dns-monitoring", "yes"
        )
        attrs["url_reports"] = parse_match(stats_service_el, "url-reports", "yes")
        attrs["health_performance_reports"] = parse_match(
            stats_service_el, "health-performance-reports", "yes"
        )
        attrs["file_identification_reports"] = parse_match(
            stats_service_el, "file-identification-reports", "yes"
        )
        return cls.from_cleanup(**attrs)
