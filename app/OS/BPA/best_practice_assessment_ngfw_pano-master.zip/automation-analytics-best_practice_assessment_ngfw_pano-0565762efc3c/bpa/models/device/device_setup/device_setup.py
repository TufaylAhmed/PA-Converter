import logging

from typing import List, Optional, Union

from dataclasses import dataclass
from lxml import etree

from bpa.models.base_model import BaseModel
from bpa.models.mixins import TemplateMixin
from bpa.models.query import in_template
from bpa.models.model_set import ModelSet

from .authentication import AuthenticationSettings
from .content_id import ContentIdSettings
from .general import GeneralSettings
from .logging_reporting_settings.logging_reporting import LoggingReportingSettings
from .logging_reporting_settings.predefined_reports import PredefinedReports
from .management_interface import ManagementInterfaceSettings
from .min_password_complexity import MinimumPasswordComplexitySettings
from .panorama import PanoramaSettings
from .policy_rulebase import PolicyRulebase
from .secure_comm import SecureCommSettings
from .services import ServicesSettings
from .session import SessionSettings
from .telemetry import StatsServicesSettings, TelemetrySettings
from .wildfire import WildFireSettings

LOG = logging.getLogger(__name__)


@dataclass
class DeviceSetupModel(BaseModel, TemplateMixin):
    """Settings for Panorama/NGFW device setup."""

    xpath = "//config[descendant::devices or descendant::mgt-config]"

    general: GeneralSettings
    authentication: AuthenticationSettings
    logging_reporting: LoggingReportingSettings
    predefined_reports: PredefinedReports
    management_interface: ManagementInterfaceSettings
    services: ServicesSettings
    content_id: ContentIdSettings
    wildfire: WildFireSettings
    min_password_complexity: MinimumPasswordComplexitySettings
    session: Optional[SessionSettings]
    telemetry: Union[StatsServicesSettings, TelemetrySettings]
    panorama: Optional[PanoramaSettings]
    policy_rulebase: Optional[PolicyRulebase]
    secure_comm: SecureCommSettings

    @classmethod
    def build_index(cls) -> List[str]:
        """Device setup has no name attribute, so just return the template name"""
        return ["template_name"]

    @classmethod
    def parse(cls, model_manager) -> ModelSet:
        """Creates a list of instantiated objects for the target class.

        We are looking for config elements with a devices or mgt-config ancestor element.
        """
        try:
            return super().parse(model_manager)
        except etree.XPathEvalError as e:
            LOG.info(
                f"Encountered {e.__class__.__name__} while parsing {cls.__name__}. Switching to back up logic"
            )
            model_set = cls.model_set()
            target_descendants = ("devices", "mgt-config")
            for el in model_manager.tree.xpatheval("//config"):
                if next(el.iterdescendants(*target_descendants), None) is not None:
                    try:
                        model = cls.from_el(el, model_manager)
                        model_set.add(model)
                    except Exception as e:
                        LOG.exception(
                            f"Encountered {e.__class__.__name__} while parsing {cls.__name__}"
                        )
            return model_set

    @staticmethod
    def _get_general(el, model_manager):
        return GeneralSettings.parse_entry(el, model_manager.tree.panorama)

    @staticmethod
    def _get_authentication(el, model_manager):
        return AuthenticationSettings.parse_entry(el)

    @staticmethod
    def _get_logging_reporting(el, model_manager):
        return LoggingReportingSettings.parse_entry(el, model_manager.tree.panorama)

    @staticmethod
    def _get_predefined_reports(el, model_manager):
        return PredefinedReports.parse_entry(el, model_manager.tree.panorama)

    @staticmethod
    def _get_management_interface(el, model_manager):
        return ManagementInterfaceSettings.parse_entry(el)

    @staticmethod
    def _get_services(el, model_manager):
        return ServicesSettings.parse_entry(el)

    @staticmethod
    def _get_content_id(el, model_manager):
        return ContentIdSettings.parse_entry(
            el, model_manager.tree.panorama, model_manager.tree.version
        )

    @staticmethod
    def _get_wildfire(el, model_manager):
        return WildFireSettings.parse_entry(el, model_manager.tree.version)

    @staticmethod
    def _get_min_password_complexity(el, model_manager):
        return MinimumPasswordComplexitySettings.parse_entry(
            el.find("mgt-config/password-complexity")
        )

    @staticmethod
    def _get_session(el, model_manager) -> Optional[SessionSettings]:
        # Session Settings are only configurable for NGFW / device templates, NOT Panorama
        if model_manager.tree.panorama and not in_template(el):
            return
        return SessionSettings.parse_entry(el, model_manager.tree.version)

    @staticmethod
    def _get_telemetry(
        el, model_manager
    ) -> Union[StatsServicesSettings, TelemetrySettings]:
        if model_manager.tree.version < 8:
            return StatsServicesSettings.parse_entry(el)
        return TelemetrySettings.parse_entry(el)

    @staticmethod
    def _get_panorama(el, model_manager) -> Optional[PanoramaSettings]:
        """NOTE: Does not apply to Panorama device (only NGFWs and device templates)."""
        if model_manager.tree.panorama and not in_template(el):
            return
        return PanoramaSettings.parse_entry(el.find("devices/entry"))

    @staticmethod
    def _get_policy_rulebase(el, model_manager) -> Optional[PolicyRulebase]:
        """NOTE: Does not apply to < PAN-OS 9.x."""
        if model_manager.tree.version < 9.0:
            return
        return PolicyRulebase.parse_entry(el)

    @staticmethod
    def _get_secure_comm(el, model_manager) -> SecureCommSettings:
        return SecureCommSettings.parse_entry(el, model_manager)
