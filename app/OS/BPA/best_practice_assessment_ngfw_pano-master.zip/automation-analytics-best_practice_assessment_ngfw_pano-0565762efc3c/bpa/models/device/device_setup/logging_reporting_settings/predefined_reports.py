from typing import List

from dataclasses import dataclass
from lxml import etree

from bpa.models.sub_model import SubModel


@dataclass
class PredefinedReports(SubModel):
    """Device Setup > Logging Reporting Settings > Pre-Defined Reports

    Both Panorama's and NGFW's have a list of checkboxes to enable pre-defined reports.
    The role of this model is to parse the list of which reports are enabled.
    Panorama's specifically have a checkbox which enable the pre-defined report functionality.
    """

    enabled_predefined_reports: List[str]
    base = "devices/entry/deviceconfig/setting/management"
    all_predefined_reports = {
        "top-applications",
        "top-application-categories",
        "top-technology-categories",
        "top-http-applications",
        "top-denied-applications",
        "risk-trend",
        "bandwidth-trend",
        "SaaS Application Usage",
        "top-rules",
        "top-sources",
        "top-source-countries",
        "top-destinations",
        "top-destination-countries",
        "top-connections",
        "top-ingress-zones",
        "top-egress-zones",
        "top-ingress-interfaces",
        "top-egress-interfaces",
        "top-denied-sources",
        "top-denied-destinations",
        "unknown-tcp-connections",
        "unknown-udp-connections",
        "risky-users",
        "top-attacks",
        "threat-trend",
        "top-attacker-sources",
        "top-attacker-destinations",
        "top-attackers-by-source-countries",
        "top-attackers-by-destination-countries",
        "top-victim-sources",
        "top-victim-destinations",
        "top-victims-by-source-countries",
        "top-victims-by-destination-countries",
        "top-viruses",
        "top-spyware-threats",
        "top-vulnerabilities",
        "spyware-infected-hosts",
        "top-users",
        "wildfire-file-digests",
        "top-url-categories",
        "top-url-users",
        "top-url-user-behavior",
        "top-websites",
        "top-blocked-url-categories",
        "top-blocked-url-users",
        "top-blocked-url-user-behavior",
        "top-blocked-websites",
        "blocked-credential-post",
    }

    @classmethod
    def parse_entry(cls, el: etree._Element, panorama: bool):
        attrs = {}
        disabled_predefined_reports_xml = el.findall(
            f"{cls.base}/disable-predefined-reports/member"
        )
        disabled_predefined_reports = [
            el.text for el in disabled_predefined_reports_xml
        ]
        attrs["enabled_predefined_reports"] = [
            report
            for report in cls.all_predefined_reports
            if report not in disabled_predefined_reports
        ]
        return cls(**attrs)
