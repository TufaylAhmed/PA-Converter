import logging
from typing import List, Union

from dataclasses import dataclass

from bpa.models.base_model import BaseModel
from bpa.models.default_value import DefaultValue
from bpa.models.mixins import LocationMixin, TemplateMixin
from bpa.models.utils.parsing import parse_list

from .authentication_profile import AuthenticationProfileModel


LOG = logging.getLogger(__name__)


@dataclass
class AuthenticationSequenceModel(BaseModel, LocationMixin, TemplateMixin):
    """Device / Panorama > Authentication Sequence."""

    xpath = "//authentication-sequence/entry"

    name: str
    auth_profiles: Union[List[str], DefaultValue]

    @staticmethod
    def _get_name(el, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_auth_profiles(el, model_manager) -> Union[List[str], DefaultValue]:
        return parse_list(el, "authentication-profiles/member/text()", [])

    def __len__(self) -> int:
        return len(self.auth_profiles)

    @property
    def auth_profile_objs(self) -> List[AuthenticationProfileModel]:
        """Return a list of Authentication Profile models."""
        auth_profiles = self.objects.get("authentication_profile")
        profiles = []
        ancestors = self.objects.tree.ancestors[self.location][:]
        if self.objects.tree.panorama:
            ancestors.append("panorama")
        for profile_name in self.auth_profiles:
            for location in ancestors:
                model = auth_profiles.find(
                    name=profile_name,
                    template_name=self.template_name,
                    location=location,
                )
                if model is not None:
                    profiles.append(model)
                    break
            else:
                raise ValueError(
                    f"No auth profile found with name={profile_name}, template_name={self.template_name}, "
                    f"and ancestor hierarchy {ancestors}"
                )
        return profiles

    def using_radius_saml(self):
        """Checks whether all profiles in the sequence are using Radius or SAML as the authentication type."""
        return all(prof.using_radius_saml() for prof in self.auth_profile_objs())

    def using_local_authentication(self) -> bool:
        """Checks whether any profile in the sequence is using a local authtication method.

        NOTE: Also returns True if there are no auth profiles in the sequence.
        """
        if not self.auth_profiles:
            return True
        return any(prof.using_local_authentication() for prof in self.auth_profile_objs)
