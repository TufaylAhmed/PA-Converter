from dataclasses import replace

from bpa.models.model_set import ModelSet
from bpa.models.utils.combine import combine_models
from bpa.models.utils.lookup import (
    build_partial_signature_with_model as build_partial_sig,
)

from .base_resolver import BaseResolver


class ReplaceResolver(BaseResolver):
    """Resolve model conflicts with replace"""

    def resolve(self):
        result_ms = ModelSet()
        tmpl_models = {}
        stck_models = {}
        final_models = {}

        # Step 1: Resolve models in templates
        for tmpl_name in reversed(self.priority):
            for model in self.mapping[(tmpl_name,)]:
                partial_sig = build_partial_sig(model, excludes={"template_name"})
                tmpl_models[partial_sig] = replace(model, template_name=self.stack_name)
                composed_model = tmpl_models[partial_sig]
                composed_model.resolve_from_base()

        # Step 2: Establish models in stack
        for model in self.mapping[(self.stack_name,)]:
            partial_sig = build_partial_sig(model, excludes={"template_name"})
            stck_models[partial_sig] = model

        # Step 3: Identify common model signatures
        tmpl_keys = set(tmpl_models.keys())
        stck_keys = set(stck_models.keys())
        common_keys = tmpl_keys.intersection(stck_keys)

        # Step 4: Run composite on template models and stack models
        for key in common_keys:
            models = [stck_models[key], tmpl_models[key]]
            final_models[key] = combine_models(models)

        for key in tmpl_keys.difference(common_keys):
            final_models[key] = tmpl_models[key]

        for key in stck_keys.difference(common_keys):
            final_models[key] = stck_models[key]

        # Step 5: Build final model set
        for model in final_models.values():
            result_ms.add(model)

        return result_ms
