from typing import Optional, Union

from dataclasses import dataclass
from lxml import etree

from bpa.models.constants import NONE
from bpa.models.default_value import DefaultValue
from bpa.models.query import in_template
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import parse_match


@dataclass
class GeneralSettings(SubModel):
    """Device Setup > General Settings"""

    login_banner: str = NONE
    auto_acquire_commit_lock_enabled: Union[bool, DefaultValue] = DefaultValue(False)
    ssl_tls_service_profile: Optional[str] = None
    hostname: Optional[str] = None
    cert_expiration_check_enabled: Optional[Union[bool, DefaultValue]] = None

    base = "devices/entry/deviceconfig"

    @classmethod
    def parse_login_banner(cls, el, xpath):
        val = el.findtext(xpath)
        if val and len(val) > 20:
            return val[:20] + "..."
        return val

    @classmethod
    def parse_entry(cls, el: etree._Element, panorama: bool) -> "GeneralSettings":
        attrs = {}
        attrs["login_banner"] = cls.parse_login_banner(
            el, f"{cls.base}/system/login-banner"
        )
        attrs["auto_acquire_commit_lock_enabled"] = parse_match(
            el, f"{cls.base}/setting/management/auto-acquire-commit-lock", "yes"
        )
        attrs["ssl_tls_service_profile"] = el.findtext(
            f"{cls.base}/system/ssl-tls-service-profile"
        )

        # NOTE: Hostname is not configurable on device templates
        attrs["hostname"] = el.findtext(f"{cls.base}/system/hostname")

        # Certificate Expiration Check is not configurable on Panorama.
        # Certificate Expiration Check is DISABLED by default on NGFW / templates
        if not panorama or in_template(el):
            attrs["cert_expiration_check_enabled"] = parse_match(
                el,
                f"{cls.base}/setting/management/enable-certificate-expiration-check",
                "yes",
            )
        return cls.from_cleanup(**attrs)

    @property
    def login_banner_enabled(self):
        return self.login_banner != NONE and self.login_banner != ""
