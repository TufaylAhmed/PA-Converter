from dataclasses import dataclass
from lxml import etree

from bpa.models.default_value import DefaultValue
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import parse_match


@dataclass
class PolicyRulebase(SubModel):
    """Device Setup > Policy Rulebase

    This sub-model only applies to PAN-OS 9.0+
    """

    rule_require_tag: bool = DefaultValue(False)
    rule_require_description: bool = DefaultValue(False)
    rule_require_audit_comment: bool = DefaultValue(False)
    rule_fail_commit: bool = DefaultValue(False)
    rule_hit_count: bool = DefaultValue(True)
    appusage_policy: bool = DefaultValue(True)

    xpath_pre = "devices/entry/deviceconfig/setting/management"

    @classmethod
    def parse_entry(cls, el: etree._Element) -> "PolicyRulebase":
        attrs = {}
        for k, v in cls.__dataclass_fields__.items():
            query = cls.xpath_pre + "/" + k.replace("_", "-")
            attrs[k] = parse_match(el, query, "yes", v.default.value)
        return cls.from_cleanup(**attrs)
