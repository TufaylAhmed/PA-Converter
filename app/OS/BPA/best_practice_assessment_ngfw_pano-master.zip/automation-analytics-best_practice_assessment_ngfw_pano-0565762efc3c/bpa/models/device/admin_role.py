from dataclasses import dataclass
from lxml import etree

from bpa.models.base_model import BaseModel
from bpa.models.mixins import TemplateMixin


@dataclass
class AdminRoleModel(BaseModel, TemplateMixin):
    xpath = "//shared/admin-role/entry"

    name: str

    @staticmethod
    def _get_name(el: etree._Element, model_manager) -> str:
        """Get admin role name."""
        return el.get("name")
