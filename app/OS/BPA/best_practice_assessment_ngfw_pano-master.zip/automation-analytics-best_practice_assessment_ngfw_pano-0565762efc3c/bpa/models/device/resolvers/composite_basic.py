from bpa.models.model_set import ModelSet
from bpa.models.utils.combine import combine_models

from .base_resolver import BaseResolver


class CompositeBasicResolver(BaseResolver):
    """Resolve model conflicts with basic composite"""

    def resolve(self):
        result_ms = ModelSet()
        models = []
        for pr in (self.stack_name, *self.priority):
            for model in self.mapping[(pr,)]:
                models.append(model)
        if len(models) > 0:
            composed_model = combine_models(models)
            composed_model.template_name = self.stack_name
            composed_model.resolve_from_base()
            result_ms.add(composed_model)
        return result_ms
