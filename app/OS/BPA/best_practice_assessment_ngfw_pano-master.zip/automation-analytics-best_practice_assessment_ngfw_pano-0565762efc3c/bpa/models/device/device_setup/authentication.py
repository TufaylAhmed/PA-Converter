from typing import Optional, Union

from dataclasses import dataclass

from bpa.models.default_value import DefaultValue
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import parse_int


@dataclass
class AuthenticationSettings(SubModel):
    """Device Setup > Authn Settings"""

    authentication_profile: Optional[str] = None
    certificate_profile: Optional[str] = None
    idle_timeout: Union[int, DefaultValue] = DefaultValue(60)
    failed_attempts: Union[int, DefaultValue] = DefaultValue(0)
    lockout_time: Union[int, DefaultValue] = DefaultValue(0)
    api_key_lifetime: Union[int, DefaultValue] = DefaultValue(0)

    @classmethod
    def parse_entry(cls, el):
        attrs = {}
        sys_prefix = "devices/entry/deviceconfig/system"
        for prof in ("authentication", "certificate"):
            attrs[f"{prof}_profile"] = el.findtext(f"{sys_prefix}/{prof}-profile")
        mgmt_prefix = "devices/entry/deviceconfig/setting/management"
        lock_prefix = f"{mgmt_prefix}/admin-lockout"
        attrs["idle_timeout"] = parse_int(el, f"{mgmt_prefix}/idle-timeout")
        attrs["failed_attempts"] = parse_int(el, f"{lock_prefix}/failed-attempts")
        attrs["lockout_time"] = parse_int(el, f"{lock_prefix}/lockout-time")
        attrs["api_key_lifetime"] = parse_int(el, f"{mgmt_prefix}/api/key/lifetime")
        return cls.from_cleanup(**attrs)
