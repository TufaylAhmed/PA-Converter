from .base_resolver import BaseResolver
from .composite_basic import CompositeBasicResolver
from .composite_location import CompositeLocationResolver
from .replace import ReplaceResolver


def composite_basic(model_kls) -> bool:
    return set(model_kls.build_index()) == {"template_name"}


def composite_location(model_kls) -> bool:
    return set(model_kls.build_index()) == {"template_name", "location"}


def get_resolver(model_kls, model_set, **kwargs) -> BaseResolver:
    """Get proper resolver strategy.

    Args:
        model_kls: Model class with a template mixin.
        model_set: Model set to group by.
        kwargs: Keyword arguments passed into resolver constructor.

    Returns:
        Proper instance of the Resolver class.
    """
    if composite_basic(model_kls):
        return CompositeBasicResolver(
            mapping=model_set.group_by("template_name"), **kwargs
        )
    elif composite_location(model_kls):
        locations = {m.location for m in model_set}
        return CompositeLocationResolver(
            mapping=model_set.group_by("template_name", "location"),
            metadata={"locations": locations},
            **kwargs
        )
    else:
        return ReplaceResolver(mapping=model_set.group_by("template_name"), **kwargs)
