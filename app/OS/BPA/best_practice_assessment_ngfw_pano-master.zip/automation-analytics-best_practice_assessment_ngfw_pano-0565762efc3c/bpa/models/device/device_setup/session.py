from typing import List, Optional, Union

from dataclasses import dataclass
from lxml import etree

from bpa.models.default_value import DefaultValue
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import parse_match


@dataclass
class SessionTimeoutSettings(SubModel):
    default: Union[int, DefaultValue] = DefaultValue(30)  # noqa
    discard_default: Union[int, DefaultValue] = DefaultValue(60)
    discard_tcp: Union[int, DefaultValue] = DefaultValue(90)
    discard_udp: Union[int, DefaultValue] = DefaultValue(60)
    icmp: Union[int, DefaultValue] = DefaultValue(6)
    scan: Union[int, DefaultValue] = DefaultValue(10)
    tcp: Union[int, DefaultValue] = DefaultValue(3600)
    tcp_handshake: Union[int, DefaultValue] = DefaultValue(10)
    tcp_init: Union[int, DefaultValue] = DefaultValue(5)
    tcp_half_closed: Union[int, DefaultValue] = DefaultValue(120)
    tcp_time_wait: Union[int, DefaultValue] = DefaultValue(15)
    unverified_rst: Union[int, DefaultValue] = DefaultValue(30)
    udp: Union[int, DefaultValue] = DefaultValue(30)
    captive_portal: Union[int, DefaultValue] = DefaultValue(30)

    @classmethod
    def parse_el(cls, el: Optional[etree._Element]):
        if el is None:
            return
        attrs = {}
        attrs["default"] = el.findtext("timeout-default")
        attrs["discard_default"] = el.findtext("timeout-discard-default")
        attrs["discard_tcp"] = el.findtext("timeout-discard-tcp")
        attrs["discard_udp"] = el.findtext("timeout-discard-udp")
        attrs["icmp"] = el.findtext("timeout-icmp")
        attrs["scan"] = el.findtext("timeout-scan")
        attrs["tcp"] = el.findtext("timeout-tcp")
        attrs["tcp_handshake"] = el.findtext("timeout-tcphandshake")
        attrs["tcp_init"] = el.findtext("timeout-tcpinit")
        attrs["tcp_half_closed"] = el.findtext("timeout-tcp-half-closed")
        attrs["tcp_time_wait"] = el.findtext("timeout-tcp-time-wait")
        attrs["unverified_rst"] = el.findtext("timeout-tcp-unverified-rst")
        attrs["udp"] = el.findtext("timeout-udp")
        attrs["captive_portal"] = el.findtext("timeout-captive-portal")

        attrs = {key: int(val) for key, val in attrs.items() if val is not None}
        return cls(**attrs)


@dataclass
class PacketBufferProtection(SubModel):

    enabled: Union[bool, DefaultValue] = DefaultValue(False)
    alert: Union[int, DefaultValue] = DefaultValue(50)
    activate: Union[int, DefaultValue] = DefaultValue(50)
    block_hold_time: Union[int, DefaultValue] = DefaultValue(60)
    block_duration: Union[int, DefaultValue] = DefaultValue(3600)

    @classmethod
    def parse_entry(cls, el: Optional[etree._Element]):
        if el is None:
            return
        attrs = {}

        attrs["alert"] = el.findtext("packet-buffer-protection-alert")
        attrs["activate"] = el.findtext("packet-buffer-protection-activate")
        attrs["block_hold_time"] = el.findtext(
            "packet-buffer-protection-block-hold-time"
        )
        attrs["block_duration"] = el.findtext(
            "packet-buffer-protection-block-duration-time"
        )
        attrs = {key: int(val) for key, val in attrs.items() if val is not None}

        attrs["enabled"] = parse_match(el, "packet-buffer-protection-enable", "yes")

        return cls.from_cleanup(**attrs)

    def zero_settings(self) -> List[str]:
        return [
            key.replace("_", " ").title()
            for key, val in self.__dict__.items()
            if val == 0
        ]


@dataclass
class SessionSettings(SubModel):
    """NOTE: Session Settings are only configurable for NGFW / device templates."""

    rematch_sessions_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    exceed_tcp_out_of_order_queue_enabled: Union[bool, DefaultValue] = DefaultValue(
        False
    )
    accelerated_aging_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    timeout_settings: Union[SessionTimeoutSettings, DefaultValue] = DefaultValue(
        SessionTimeoutSettings()
    )
    packet_buffer_protection: Optional[PacketBufferProtection] = None

    common_xpath = "devices/entry/deviceconfig/setting"

    @classmethod
    def parse_entry(cls, el, version: float) -> "SessionSettings":
        attrs = {}
        attrs["rematch_sessions_enabled"] = parse_match(
            el, f"{cls.common_xpath}/config/rematch", "yes"
        )
        attrs["exceed_tcp_out_of_order_queue_enabled"] = parse_match(
            el, f"{cls.common_xpath}/tcp/bypass-exceed-oo-queue", "yes"
        )
        attrs["accelerated_aging_enabled"] = parse_match(
            el, f"{cls.common_xpath}/session/accelerated-aging-enable", "yes"
        )

        session_el = el.find(f"{cls.common_xpath}/session")
        attrs["timeout_settings"] = SessionTimeoutSettings.parse_el(session_el)
        if version >= 8:
            attrs["packet_buffer_protection"] = PacketBufferProtection.parse_entry(
                session_el
            )
        return cls.from_cleanup(**attrs)
