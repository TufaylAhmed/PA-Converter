from typing import List

from dataclasses import dataclass
from lxml import etree

from bpa.models.base_model import BaseModel
from bpa.models.device.resolvers.factory import get_resolver
from bpa.models.utils.parsing import ParseVariableMixin


@dataclass
class TemplateStackModel(BaseModel, ParseVariableMixin):
    xpath = "//config/devices/entry/template-stack/entry"
    name: str
    templates: List[str]
    devices: List[str]

    def __post_init__(self):
        self.stack_lookup = {}

    @staticmethod
    def _get_name(el: etree._Element, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_templates(el: etree._Element, model_manager) -> List[str]:
        return el.xpath("templates/member/text()")

    @staticmethod
    def _get_devices(el: etree._Element, model_manager) -> List[str]:
        return el.xpath("devices/entry/@name")

    @property
    def tree(self):
        """Tree property to maintain backward compatability."""
        return self.objects.tree

    def get(self, feature: str, lazy: bool = True):
        """Get subset of models that are related to template stack.

        NOTE: Assume that ONLY analyzers, models with template mixins
        and integration tests will call this get routine. Any other
        use of this get routine should be considered malicious.

        Args:
            feature: Name of feature.
            lazy: Boolean flag on whether we lazily evaluate lookup data.

        Returns:
            Iterable of resolved models that either match the
            template names or the template stack name.
        """
        if feature in self.stack_lookup:
            return self.stack_lookup[feature]
        elif lazy is False:
            return self.stack_lookup.get(feature)

        model_kls = self.objects.model_lookup[feature]
        model_set = self.objects.get(feature)

        # NOTE: This only happens when we resolve template variables
        if "template_name" not in model_kls.build_index():
            return model_set

        resolver = get_resolver(
            model_kls, model_set, priority=self.templates, stack_name=self.name
        )

        result = resolver.resolve()
        self.stack_lookup[feature] = result
        return result

    def to_dict(self):
        """Custom to_dict to remove lookup."""
        result = {
            k: v
            for k, v in super().to_dict().items()
            if k in self.__dataclass_fields__.keys()
        }
        return result
