from typing import Optional, Set, Tuple, Union

from lxml import etree
from dataclasses import dataclass

from bpa.models.constants import NONE_LOWER
from bpa.models.default_value import DefaultValue
from bpa.models.query import in_template
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import parse_match, parse_tag


@dataclass
class CustomizeCommunication(SubModel):
    """Device Setup > Secure Communication Settings > Secure Client Communication > Customize Communication"""

    def enabled_disabled_options(self) -> Tuple[Set[str], Set[str]]:
        all_options = set(self.to_dict().keys())
        enabled_options = {attr for attr, val in self.to_dict().items() if val is True}
        return (enabled_options, (all_options - enabled_options))


@dataclass
class DeviceCustomizeCommunication(CustomizeCommunication):
    """Device Setup > Secure Communication Settings > Secure Client Communication > Customize Communication"""

    panorama: Union[bool, DefaultValue] = DefaultValue(False)
    pan_db: Union[bool, DefaultValue] = DefaultValue(False)
    wildfire: Union[bool, DefaultValue] = DefaultValue(False)
    log_collector: Union[bool, DefaultValue] = DefaultValue(False)

    @classmethod
    def parse_entry(cls, el):
        attrs = {}
        attrs["panorama"] = parse_match(
            el, "enable-secure-panorama-communication", "yes"
        )
        attrs["pan_db"] = parse_match(el, "enable-secure-pandb-communication", "yes")
        attrs["wildfire"] = parse_match(
            el, "enable-secure-wildfire-communication", "yes"
        )
        attrs["log_collector"] = parse_match(
            el, "enable-secure-lc-communication", "yes"
        )
        return cls.from_cleanup(**attrs)


@dataclass
class PanoramaCustomizeCommunication(CustomizeCommunication):
    """Device Setup > Secure Communication Settings > Secure Client Communication > Customize Communication"""

    high_availability: Union[bool, DefaultValue] = DefaultValue(False)
    wildfire: Union[bool, DefaultValue] = DefaultValue(False)

    @classmethod
    def parse_entry(cls, el):
        attrs = {}
        attrs["high_availability"] = parse_match(
            el, "enable-secure-ha-communication", "yes"
        )
        attrs["wildfire"] = parse_match(
            el, "enable-secure-wildfire-communication", "yes"
        )
        return cls(**attrs)


@dataclass
class SecureClientComms(SubModel):
    """Device Setup > Secure Client Communications

    Expects a secure-conn-client element.
    """

    customize_communication: Union[
        DeviceCustomizeCommunication, PanoramaCustomizeCommunication
    ]
    certificate_type: Union[str, DefaultValue] = DefaultValue("predefined")
    certificate: Optional[str] = None
    scep_profile: Optional[str] = None
    certificate_profile: Optional[str] = None

    @staticmethod
    def customize_communication_class(
        el: etree._Element, panorama: bool
    ) -> Union[DeviceCustomizeCommunication, PanoramaCustomizeCommunication]:
        if panorama and not in_template(el):
            return PanoramaCustomizeCommunication
        else:
            return DeviceCustomizeCommunication

    @classmethod
    def parse_entry(cls, el: etree._Element, panorama: bool):
        """
        Args:
            el: devices/entry/deviceconfig/setting/management/secure-conn-client element
            panorama: whether or not assessed device is a Panorama
        """
        # Customize Communication attributes are different for Panorama vs NGFW / device templates
        TargetCustomizeCommunication = cls.customize_communication_class(el, panorama)
        target = el.find(
            "devices/entry/deviceconfig/setting/management/secure-conn-client"
        )
        if target is None:
            return cls(customize_communication=TargetCustomizeCommunication())
        attrs = {}
        attrs["certificate_type"] = parse_tag(
            target, "certificate-type/*", default="predefined", override=NONE_LOWER
        )
        attrs["certificate"] = target.findtext("certificate-type/local/certificate")
        attrs["scep_profile"] = target.findtext("certificate-type/scep/scep-profile")
        attrs["certificate_profile"] = target.findtext(
            "certificate-type/*/certificate-profile"
        )
        attrs["customize_communication"] = TargetCustomizeCommunication.parse_entry(
            target
        )
        return cls(**attrs)


@dataclass
class SecureServerComms(SubModel):
    """Device Setup > Secure Server Communications"""

    ssl_tls_service_profile: Optional[str] = None
    certificate_profile: Optional[str] = None
    allow_custom_certificate_only: Union[bool, DefaultValue] = DefaultValue(False)

    @classmethod
    def parse_entry(cls, el: etree._Element) -> "SecureServerComms":
        target = el.find(
            "devices/entry/deviceconfig/setting/management/secure-conn-server"
        )
        if target is None:
            return cls()
        ssl_tls_service_profile = target.findtext("ssl-tls-service-profile")
        certificate_profile = target.findtext("certificate-profile")
        allow_custom_certificate_only = parse_match(
            target, "disable-pre-defined-cert", "yes", False
        )
        return cls(
            ssl_tls_service_profile, certificate_profile, allow_custom_certificate_only
        )


@dataclass
class SecureCommSettings(SubModel):
    """Device Setup > Secure Communication Settings

    NOTES:
        PAN-OS == 8.0:
            Secure Communication Settings was nested within Panorama Settings and only includes
            Secure SERVER Communication for Panorama devices and Secure CLIENT Communication for NGFWs
        PAN-OS >= 8.1:
            Secure Communication Settings is a standalone feature and includes both
            Secure SERVER Communication and Secure CLIENT Communication for Panorama devices and
            Secure CLIENT Communication for NGFWs
    """

    client: Optional[SecureClientComms] = None
    server: Optional[SecureServerComms] = None

    @classmethod
    def parse_entry(cls, el: etree._Element, model_manager) -> "SecureCommSettings":
        attrs = {}
        panorama = model_manager.tree.panorama
        if model_manager.tree.ngfw or model_manager.tree.version >= 8.1:
            attrs["client"] = SecureClientComms.parse_entry(el, panorama)
        if panorama:
            attrs["server"] = SecureServerComms.parse_entry(el)
        return cls(**attrs)
