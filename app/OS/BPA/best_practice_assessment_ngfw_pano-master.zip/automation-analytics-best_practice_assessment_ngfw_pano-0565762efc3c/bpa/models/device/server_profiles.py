from typing import List, Union

from dataclasses import dataclass

from bpa.models.base_model import BaseModel
from bpa.models.constants import NONE
from bpa.models.default_value import DefaultValue
from bpa.models.mixins import TemplateMixin, LocationMixin
from bpa.models.utils.parsing import parse_match, parse_tag, parse_text


@dataclass
class ServerProfileModel(BaseModel, TemplateMixin, LocationMixin):
    """Apply to any server profile model"""

    xpath = None


@dataclass
class RadiusServerProfileModel(ServerProfileModel):
    """Radius Server Profile configuration"""

    xpath = "//server-profile/radius/entry"

    name: str
    server_ip_configured: Union[bool, DefaultValue]
    protocol: Union[str, DefaultValue]

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_server_ip_configured(el, model_manager):
        matches_none = parse_match(el, "server/entry/ip-address", NONE)
        if matches_none is None:
            return DefaultValue(False)
        return not matches_none

    @staticmethod
    def _get_protocol(el, model_manager) -> Union[str, DefaultValue]:
        return parse_tag(el, "protocol/*", default="PEAP-MSCHAPv2")


@dataclass
class SnmpTrapServerProfileModel(ServerProfileModel):
    """SNMP Trap Server Profile configuration"""

    xpath = "//log-settings/snmptrap/entry"

    name: str
    version: str
    community: str

    mask_attrs = {"community": ["name"]}

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_version(el, model_manager):
        return el.find("version/*").tag

    @staticmethod
    def _get_community(el, model_manager):
        # Community is not an option with v3
        community = el.findtext("version/v2c/server/entry/community")
        return community.strip().upper() if community else NONE


@dataclass
class SyslogServerProfileModel(BaseModel, TemplateMixin, LocationMixin):
    """Syslog Server Profile configuration"""

    xpath = "//log-settings/syslog/entry"

    name: str
    transport: str

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_transport(el, model_manager):
        return el.findtext("server/entry/transport", NONE)


@dataclass
class LdapServerProfileModel(ServerProfileModel):
    """LDAP Server Profile configuration"""

    xpath = "//server-profile/ldap/entry"

    name: str
    server_list: Union[List[str], DefaultValue]
    require_ssl_tls_secured_connection: Union[bool, DefaultValue]
    verify_server_certificate_for_ssl_sessions: Union[bool, DefaultValue]

    mask_attrs = {"server_list": ["name"]}

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_server_list(el, model_manager):
        result = el.xpath("server/entry/@name")
        if len(result) > 0:
            return result
        return DefaultValue([])

    @staticmethod
    def _get_require_ssl_tls_secured_connection(el, model_manager):
        # enabled by default
        return parse_match(el, "ssl", "yes", True)

    @staticmethod
    def _get_verify_server_certificate_for_ssl_sessions(el, model_manager):
        # disabled by default
        return parse_match(el, "verify-server-certificate", "yes", False)


@dataclass
class TacPlusServerProfileModel(ServerProfileModel):
    """TACACS+ Server Profile configuration"""

    xpath = "//server-profile/tacplus/entry"

    name: str
    server_list: Union[List[str], DefaultValue]
    protocol: Union[str, DefaultValue]

    mask_attrs = {"secret": [], "server_list": ["name"]}

    @staticmethod
    def _get_name(el, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_server_list(el, model_manager) -> Union[List[str], DefaultValue]:
        result = el.xpath("server/entry/@name")
        if len(result) > 0:
            return result
        return DefaultValue([])

    @staticmethod
    def _get_protocol(el, model_manager) -> Union[str, DefaultValue]:
        return parse_text(el, "protocol", default="PEAP-MSCHAPv2")
