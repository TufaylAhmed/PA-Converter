from typing import Optional, Union

from dataclasses import dataclass
from lxml import etree

from bpa.models.default_value import DefaultValue
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import parse_match, parse_int


@dataclass
class MinimumPasswordComplexitySettings(SubModel):
    """Device Setup > Minimum Password Complexity Settings"""

    enabled: Union[bool, DefaultValue] = DefaultValue(False)
    block_username_inclusion: Union[bool, DefaultValue] = DefaultValue(False)
    minimum_length: Union[int, DefaultValue] = DefaultValue(0)
    minimum_uppercase_letters: Union[int, DefaultValue] = DefaultValue(0)
    minimum_lowercase_letters: Union[int, DefaultValue] = DefaultValue(0)

    def valid(self):
        """Returns whether minimum password complexity settings are configured correctly."""
        return (
            self.enabled
            and self.block_username_inclusion
            and self.minimum_length == 8
            and self.minimum_uppercase_letters == 1
            and self.minimum_lowercase_letters == 1
        )

    @classmethod
    def parse_entry(
        cls, el: Optional[etree._Element]
    ) -> "MinimumPasswordComplexitySettings":
        """
        Args:
            el: password-complexity element
        """
        if el is None:
            return cls()
        attrs = {}
        attrs["enabled"] = parse_match(el, "enabled", "yes")
        attrs["block_username_inclusion"] = parse_match(
            el, "block-username-inclusion", "yes"
        )
        attrs["minimum_length"] = parse_int(el, "minimum-length")
        attrs["minimum_uppercase_letters"] = parse_int(el, "minimum-uppercase-letters")
        attrs["minimum_lowercase_letters"] = parse_int(el, "minimum-lowercase-letters")
        return cls.from_cleanup(**attrs)
