import weakref
from typing import List, Optional, Union

from dataclasses import dataclass

from bpa.models.base_model import BaseModel
from bpa.models.constants import NONE
from bpa.models.default_value import DefaultValue
from bpa.models.mixins import TemplateMixin
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import parse_exists, parse_match, parse_tag, parse_text


def get_group_prefix(version: float) -> str:
    """Take care of group prefix for xpath queries."""
    if version < 8.1:
        return "group/entry"
    else:
        return "group"


@dataclass
class Ha1Config(SubModel):
    """HighAvailability > GeneralConfig > Ha1Config"""

    netmask: str
    ip_address: str
    port: str
    gateway: str
    encryption_enabled: bool
    backup_ip_address: str
    backup_port: str
    backup_netmask: str
    backup_gateway: str

    mask_attrs = {
        "netmask": ["ipv4"],
        "ip_address": ["ipv4"],
        "gateway": ["ipv4", "fqdn"],
        "backup_netmask": ["ipv4"],
        "backup_ip_address": ["ipv4"],
        "backup_gateway": ["ipv4", "fqdn"],
    }

    @classmethod
    def parse_entry(cls, el, panorama, version):
        attrs = {}
        attrs["ip_address"] = parse_text(el, "interface/ha1/ip-address", NONE)
        attrs["port"] = parse_text(el, "interface/ha1/port", NONE)
        attrs["netmask"] = parse_text(el, "interface/ha1/netmask", NONE)
        attrs["gateway"] = parse_text(el, "interface/ha1/gateway", NONE)
        attrs["encryption_enabled"] = parse_exists(
            el, "interface/ha1/encryption/enabled/text()"
        )
        attrs["backup_ip_address"] = parse_text(
            el, "interface/ha1-backup/ip-address", NONE
        )
        attrs["backup_port"] = parse_text(el, "interface/ha1-backup/port", NONE)
        attrs["backup_netmask"] = parse_text(el, "interface/ha1-backup/netmask", NONE)
        attrs["backup_gateway"] = parse_text(el, "interface/ha1-backup/gateway", NONE)
        return cls(**attrs)


@dataclass
class Ha2Config(SubModel):
    """HighAvailability > GeneralConfig > Ha2Config"""

    session_sync_enabled: bool
    keep_alive_enabled: bool
    action: str
    backup_ip_address: str
    backup_port: str
    backup_netmask: str
    backup_gateway: str

    mask_attrs = {
        "backup_netmask": ["ipv4"],
        "backup_ip_address": ["ipv4"],
        "backup_gateway": ["ipv4", "fqdn"],
    }

    @classmethod
    def parse_entry(cls, el, panorama, version):
        attrs = {}
        group_prefix = get_group_prefix(version)
        attrs["session_sync_enabled"] = parse_match(
            el, f"{group_prefix}/state-synchronization/enabled", "yes", True
        )
        attrs["keep_alive_enabled"] = parse_exists(
            el, f"{group_prefix}/state-synchronization/ha2-keep-alive/enabled/text()"
        )
        attrs["action"] = parse_text(
            el,
            f"{group_prefix}/state-synchronization/ha2-keep-alive/action",
            "log-only",
        )
        attrs["backup_ip_address"] = el.findtext(
            "interface/ha2-backup/ip-address", NONE
        )
        attrs["backup_port"] = el.findtext("interface/ha2-backup/port", NONE)
        attrs["backup_netmask"] = el.findtext("interface/ha2-backup/netmask", NONE)
        attrs["backup_gateway"] = el.findtext("interface/ha2-backup/gateway", NONE)
        return cls(**attrs)


@dataclass
class Ha3Config(SubModel):
    """HighAvailability > GeneralConfig > Ha3Config"""

    interface: str = NONE
    session_owner_selection: str = NONE

    @classmethod
    def parse_entry(cls, el, panorama, version):
        attrs = {}
        group_prefix = get_group_prefix(version)
        attrs["interface"] = el.findtext("interface/ha3/port", NONE)
        if attrs["interface"] == NONE:
            attrs["session_owner_selection"] = NONE
        else:
            attrs["session_owner_selection"] = parse_tag(
                el,
                xpath=f"{group_prefix}/entry/mode/active-active/session-owner-selection/*",
                default="first-packet",
            )
        return cls(**attrs)


@dataclass
class GeneralConfig(SubModel):
    """HighAvailability > GeneralConfig"""

    timers: str
    preemptive_enabled: bool

    peer_ip: Optional[str] = DefaultValue(NONE)
    peer_ip_backup: Optional[str] = DefaultValue(NONE)
    mode: Optional[str] = DefaultValue(NONE)
    config_sync_enabled: Optional[bool] = None
    passive_link_state: Optional[str] = DefaultValue(NONE)
    heartbeat_backup_enabled: Optional[bool] = DefaultValue(False)

    ha1_config: Optional[Ha1Config] = None
    ha2_config: Optional[Ha2Config] = None
    ha3_config: Optional[Ha3Config] = None

    mask_attrs = {"peer_ip": ["ipv4", "ipv6"], "peer_ip_backup": ["ipv4", "ipv6"]}

    @classmethod
    def parse_entry(cls, el, template_name, panorama, version):
        attrs = {}
        group_prefix = get_group_prefix(version)
        attrs["timers"] = parse_tag(
            el, f"{group_prefix}/election-option/timers/*", default="recommended"
        )

        # Templates + Panorama + Version 8.1+: Peer IP AND Peer IP Backup BOTH CONFIGURABLE
        # Templates + NGFW: Peer IP AND Peer IP Backup NOT CONFIGURABLE
        # NOT Templates + Panorama: Peer IP CONFIGURABLE
        # NOT Templates + NGFW: Peer IP AND Peer IP Backup BOTH CONFIGURABLE
        has_template_name = template_name is not None
        if has_template_name:
            if panorama and version >= 8.1:
                attrs["peer_ip"] = parse_text(el, f"{group_prefix}/peer-ip", NONE)
                attrs["peer_ip_backup"] = parse_text(
                    el, f"{group_prefix}/peer-ip-backup", NONE
                )
        else:
            if panorama:
                attrs["peer_ip"] = parse_text(el, "peer/ip-address", NONE)
            else:  # NGFW
                attrs["peer_ip"] = parse_text(el, f"{group_prefix}/peer-ip", NONE)
                attrs["peer_ip_backup"] = parse_text(
                    el, f"{group_prefix}/peer-ip-backup", NONE
                )

        # HA on Panorama device only has a subset of configuration options
        if not panorama or has_template_name:
            # Default mode is active-passive on templates and None on NGFW
            attrs["mode"] = parse_tag(
                el,
                xpath=f"{group_prefix}/mode/*",
                default=("active-passive" if has_template_name else NONE),
            )
            attrs["passive_link_state"] = parse_text(
                el, f"{group_prefix}/mode/active-passive/passive-link-state", "shutdown"
            )
            attrs["heartbeat_backup_enabled"] = parse_exists(
                el, f"{group_prefix}/election-option/heartbeat-backup"
            )

            # Preemptive is DISABLED by default for NGFW/templates
            # and does not show up in XML unless modified
            attrs["preemptive_enabled"] = parse_match(
                el, f"{group_prefix}/election-option/preemptive", "yes", False
            )

            # Enable Config Sync does not exist on Panorama
            # but is ENABLED by default on NGFW / templates
            attrs["config_sync_enabled"] = parse_match(
                el, f"{group_prefix}/configuration-synchronization/enabled", "yes", True
            )

            attrs["ha1_config"] = Ha1Config.parse_entry(el, panorama, version)
            attrs["ha2_config"] = Ha2Config.parse_entry(el, panorama, version)
            attrs["ha3_config"] = Ha3Config.parse_entry(el, panorama, version)
        else:
            # Preemptive is ENABLED by default for Panorama
            # and does not show up in XML unless modified
            attrs["preemptive_enabled"] = parse_match(
                el, f"{group_prefix}/election-option/preemptive", "yes", True
            )
        return cls(**attrs)


@dataclass
class LinkGroup(SubModel):
    name: str
    group_enabled: Union[bool, DefaultValue] = DefaultValue(True)

    @classmethod
    def parse_entry(cls, el):
        attrs = {}
        attrs["name"] = el.get("name")
        attrs["group_enabled"] = parse_match(el, "enabled", "yes", True)
        return cls(**attrs)


@dataclass
class PathGroup(SubModel):
    name: str
    group_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    group_type: Optional[str] = None
    group_source_ip: Union[str, DefaultValue, None] = None
    group_destination_ip: Union[str, DefaultValue] = DefaultValue(NONE)

    mask_attrs = {"group_source_ip": ["ipv4"], "group_destination_ip": ["ipv4"]}

    @property
    def group_source_ip_set(self) -> bool:
        return (
            self.group_enabled
            and self.group_source_ip is not None
            and self.group_source_ip != NONE
        )

    @property
    def group_destination_ip_set(self) -> bool:
        return self.group_enabled and self.group_destination_ip != NONE

    @classmethod
    def parse_entry(cls, el, panorama: bool, group_type: Optional[str] = None):
        attrs = {}
        attrs["name"] = el.get("name")
        attrs["group_type"] = group_type
        attrs["group_enabled"] = parse_match(el, "enabled", "yes", True)
        if not panorama:
            attrs["group_source_ip"] = parse_text(el, "source-ip", NONE)
        else:
            attrs["group_source_ip"] = None
        attrs["group_destination_ip"] = parse_text(el, "destination-ip/member", NONE)
        return cls(**attrs)


@dataclass
class LinkPathMonitoringConfig(SubModel):
    """HighAvailability > LinkPathMonitoringConfig"""

    path_monitoring_enabled: Union[bool, DefaultValue]
    link_monitoring_enabled: Union[bool, DefaultValue, None]
    path_monitoring_groups: List[PathGroup] = DefaultValue([])
    link_monitoring_groups: List[LinkGroup] = DefaultValue([])

    @property
    def one_group_enabled(self) -> bool:
        return any(_.group_enabled for _ in self.path_monitoring_groups)

    @property
    def destination_ip_set(self) -> bool:
        return any(_.group_destination_ip_set for _ in self.path_monitoring_groups)

    @property
    def source_ip_set(self) -> bool:
        return any(_.group_source_ip_set for _ in self.path_monitoring_groups)

    @classmethod
    def parse_entry(cls, el, template_name, panorama, version):
        attrs = {}
        has_template_name = template_name is not None
        group_prefix = get_group_prefix(version)
        if panorama and not has_template_name:
            attrs["path_monitoring_enabled"] = parse_match(
                el, "path-monitoring/enabled", "yes", True
            )
            matches = el.xpath(
                "path-monitoring/path-group/entry[destination-ip/member]"
            )
            if len(matches) > 0:
                attrs["path_monitoring_groups"] = [
                    PathGroup.parse_entry(e, panorama=panorama) for e in matches
                ]
            attrs["link_monitoring_enabled"] = None
        else:  # NGFW or templates
            attrs["path_monitoring_enabled"] = parse_match(
                el, f"{group_prefix}/monitoring/path-monitoring/enabled", "yes", True
            )

            mapping = {
                "vrouter": "virtual-router",
                "vlan": "vlan",
                "vwire": "virtual-wire",
            }

            path_groups = []
            for k, v in mapping.items():
                path_group_xpath = f"{group_prefix}/monitoring/path-monitoring/path-group/{v}/entry[destination-ip/member]"
                matches = el.xpath(path_group_xpath)
                if len(matches) > 0:
                    path_groups.extend(
                        [
                            PathGroup.parse_entry(e, panorama=panorama, group_type=k)
                            for e in matches
                        ]
                    )

            if len(path_groups) > 0:
                attrs["path_monitoring_groups"] = path_groups

            attrs["link_monitoring_enabled"] = parse_match(
                el, f"{group_prefix}/monitoring/link-monitoring/enabled", "yes", True
            )
            matches = el.xpath(
                f"{group_prefix}/monitoring/link-monitoring/link-group/entry[interface/member]"
            )
            if len(matches) > 0:
                attrs["link_monitoring_groups"] = [
                    LinkGroup.parse_entry(e) for e in matches
                ]

        return cls(**attrs)


@dataclass
class HighAvailabilityModel(BaseModel, TemplateMixin):
    xpath = "//deviceconfig/high-availability"

    ha_enabled: bool
    general_config: GeneralConfig
    link_path_monitoring_config: LinkPathMonitoringConfig

    @classmethod
    def build_index(cls) -> List[str]:
        """High availbility has no name attribute, so just return the template name"""
        return ["template_name"]

    @classmethod
    def from_el(cls, el, model_manager):
        attrs = {}

        # Base model
        attrs["model_manager"] = weakref.ref(model_manager)

        # Mixin
        attrs["template_name"] = cls._get_template_name(el, model_manager)

        # Global
        attrs["ha_enabled"] = parse_match(el, "enabled", "yes", False)

        # General logic
        attrs["general_config"] = GeneralConfig.parse_entry(
            el,
            attrs["template_name"],
            model_manager.tree.panorama,
            model_manager.tree.version,
        )

        # Link path monitoring logic
        attrs["link_path_monitoring_config"] = LinkPathMonitoringConfig.parse_entry(
            el,
            attrs["template_name"],
            model_manager.tree.panorama,
            model_manager.tree.version,
        )

        return cls(**attrs)
