from typing import List, Optional, Union

from dataclasses import dataclass
from iptools import IpRangeList
from iptools.ipv4 import cidr2block
from lxml import etree

from bpa.models.default_value import DefaultValue
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import parse_match, parse_list


@dataclass
class ManagementInterfaceSettings(SubModel):
    """Device Setup > Management Interface Settings"""

    speed: Union[str, DefaultValue] = DefaultValue("auto-negotiate")
    telnet_disabled: Union[bool, DefaultValue] = DefaultValue(True)
    http_disabled: Union[bool, DefaultValue] = DefaultValue(True)
    management_ip_address: Optional[str] = None
    permitted_ip_addresses: Union[List[str], DefaultValue] = DefaultValue([])

    mask_attrs = {
        "management_ip_address": ["ipv4", "ipv6"],
        "permitted_ip_addresses": ["ipv4", "ipv6"],
    }

    @classmethod
    def parse_entry(cls, el: etree._Element) -> "ManagementInterfaceSettings":
        attrs = {}
        attrs["management_ip_address"] = el.findtext(
            "devices/entry/deviceconfig/system/ip-address"
        )
        attrs["permitted_ip_addresses"] = parse_list(
            el, "devices/entry/deviceconfig/system/permitted-ip/entry/@name"
        )
        attrs["speed"] = el.findtext("devices/entry/deviceconfig/system/speed-duplex")

        # HTTP and Telnet are disabled by default in templates and NGFWs that have been pushed a template,
        # BUT 'disable-telnet' and 'disable-http' not included in the XML.
        # Assume the services are disabled if they are missing.
        attrs["telnet_disabled"] = parse_match(
            el, "devices/entry/deviceconfig/system/service/disable-telnet", "yes"
        )
        attrs["http_disabled"] = parse_match(
            el, "devices/entry/deviceconfig/system/service/disable-http", "yes"
        )
        return cls.from_cleanup(**attrs)

    @staticmethod
    def is_private_ip(ip_address: str) -> bool:
        """Returns True if given IP address is private."""
        private_ips = IpRangeList("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16")
        # TODO(Samshodh) Investigate how to handle IPv6 addresses / variables
        if ip_address.startswith("$") or ":" in ip_address:
            return None
        elif "/" in ip_address:
            # If the IP is using CIDR notation address format, check the network block start and end addresses
            return all(ip in private_ips for ip in cidr2block(ip_address))
        else:
            return ip_address in private_ips
