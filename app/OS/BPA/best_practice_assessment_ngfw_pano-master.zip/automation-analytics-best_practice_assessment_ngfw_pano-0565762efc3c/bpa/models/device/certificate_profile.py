from dataclasses import dataclass

from bpa.models.base_model import BaseModel
from bpa.models.mixins import TemplateMixin


# TODO: Sync with Samshodh on whether LocationMixin is needed
@dataclass
class CertificateProfileModel(BaseModel, TemplateMixin):
    xpath = "//certificate-profile/entry"

    name: str
    use_crl: bool
    use_ocsp: bool

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_use_crl(el, model_manager):
        return el.findtext("use-crl", "no") == "yes"

    @staticmethod
    def _get_use_ocsp(el, model_manager):
        return el.findtext("use-ocsp", "no") == "yes"
