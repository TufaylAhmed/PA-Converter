from typing import List

from dataclasses import dataclass
from lxml import etree

from bpa.models.sub_model import SubModel


@dataclass
class PanoramaSettings(SubModel):
    """Device Setup > Panorama Settings

    For NGFWs and device templates, collect the primary and secondary panorama servers.
    """

    panorama_servers: List[str]

    @classmethod
    def parse_entry(cls, el: etree._Element):
        servers = []
        if el is None:
            return None
        for tag in ["panorama-server", "panorama-server-2"]:
            server = el.findtext(f"devices/entry/deviceconfig/system/{tag}")
            if server is not None:
                servers.append(server)
        return cls(servers)
