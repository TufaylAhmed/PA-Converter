import re
from typing import Dict, List, Optional, Union

from lxml import etree
from dataclasses import dataclass

from bpa.models.default_value import DefaultValue
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import parse_match


class SizeLimits(dict):
    """Size limits"""

    @staticmethod
    def get_expected_limits() -> Dict[str, int]:
        sizes = {
            "pe": 10,
            "apk": 30,
            "pdf": 1000,
            "ms-office": 2000,
            "jar": 5,
            "flash": 5,
            "MacOSX": 1,
            "archive": 10,
            "linux": 2,
            "script": 20,
        }
        return sizes

    @staticmethod
    def get_default_sizes(version: float) -> Dict[str, int]:
        """NOTE:
        7.0 - DOES NOT support macosx, linux, or archive file types
        7.1 - DOES NOT support linux file types
        """
        sizes = {
            "pe": 10,
            "apk": 10,
            "pdf": 500,
            "ms-office": 500,
            "jar": 1,
            "flash": 5,
            "email-link": 0,
        }
        if version >= 7.1:
            sizes.update({"MacOSX": 1, "archive": 10})
        if version >= 8:
            sizes.update({"linux": 2})
        if version >= 8.1:
            sizes.update({"script": 20})
        if version >= 9:
            sizes.update(
                {
                    "pe": 16,
                    "pdf": 3072,
                    "ms-office": 16384,
                    "jar": 5,
                    "MacOSX": 10,
                    "archive": 50,
                    "linux": 50,
                    "email-link": 0,
                }
            )
        return sizes

    @staticmethod
    def to_numeric(string_num: str) -> Union[float, int]:
        """Coerce string to int if possible, otherwise coerce to float."""
        clean_string = re.search(r"[0-9.]*", string_num).group()
        try:
            return int(clean_string)
        except ValueError:
            return float(clean_string)

    def compare_to_default(self, version: float, key: str) -> int:
        """Helper method for comparing current values to default values."""
        defaults = self.get_default_sizes(version)
        dvalue = defaults.get(key, 0)
        svalue = self.get(key, 0)
        return self.compare_helper(current_value=svalue, expected_value=dvalue)

    @classmethod
    def compare_helper(cls, current_value: int, expected_value: int) -> int:
        """Helper method to return a value after comparison"""
        if current_value < expected_value:
            return -1
        elif current_value == expected_value:
            return 0
        else:
            return 1

    def get_default_size(self, version: float, key: str) -> int:
        """Helper method for getting a single default value for key."""
        defaults = self.get_default_sizes(version)
        return defaults.get(key, 0)

    @classmethod
    def parse_limits(cls, el: Optional[etree._Element], version: float) -> "SizeLimits":
        """
        Args:
            el: devices/entry/deviceconfig/setting/wildfire/file-size-limit element
        """
        defaults = cls.get_default_sizes(version)
        if el is None:
            return DefaultValue(cls(defaults))
        custom = {}
        for entry in el.iterchildren():
            file_type = entry.get("name")
            size_text = entry.findtext("size-limit")
            if size_text:
                size_limit = cls.to_numeric(size_text)
                custom[file_type] = size_limit
        limits = {**defaults, **custom}
        return cls(limits)


@dataclass
class SessionInfo(SubModel):
    """Session Information settings attributes.

    NOTE: Session Information settings are ENABLED by default and do not show up in
    the config unless modified.
    """

    source_ip_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    source_port_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    destination_ip_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    destination_port_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    virtual_system_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    application_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    user_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    url_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    file_name_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    email_sender_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    email_recipient_enabled: Union[bool, DefaultValue] = DefaultValue(True)
    email_subject_enabled: Union[bool, DefaultValue] = DefaultValue(True)

    def get_disabled_settings(self) -> List[str]:
        return [
            key.replace("_enabled", "")
            for key, value in self.__dict__.items()
            if bool(value) is False
        ]

    @classmethod
    def parse_entry(cls, el: Optional[etree._Element]):
        """
        Args:
            el: devices/entry/deviceconfig/setting/wildfire/session-info-select element
        """
        if el is None:
            return cls()
        attrs = {}
        attrs["source_ip_enabled"] = parse_match(el, "exclude-src-ip", "no")
        attrs["source_port_enabled"] = parse_match(el, "exclude-src-port", "no")
        attrs["destination_ip_enabled"] = parse_match(el, "exclude-dest-ip", "no")
        attrs["destination_port_enabled"] = parse_match(el, "exclude-dest-port", "no")
        attrs["virtual_system_enabled"] = parse_match(el, "exclude-vsys-id", "no")
        attrs["application_enabled"] = parse_match(el, "exclude-app-name", "no")
        attrs["user_enabled"] = parse_match(el, "exclude-username", "no")
        attrs["url_enabled"] = parse_match(el, "exclude-url", "no")
        attrs["file_name_enabled"] = parse_match(el, "exclude-filename", "no")
        attrs["email_sender_enabled"] = parse_match(el, "exclude-email-sender", "no")
        attrs["email_recipient_enabled"] = parse_match(
            el, "exclude-email-recipient", "no"
        )
        attrs["email_subject_enabled"] = parse_match(el, "exclude-email-subject", "no")
        return cls.from_cleanup(**attrs)


@dataclass
class WildFireSettings(SubModel):
    """Device Setup > Wildfire Settings"""

    size_limits: Union[SizeLimits, DefaultValue]
    session_info: Union[SessionInfo, DefaultValue]
    timezone: Optional[str] = None
    wildfire_public_cloud: Union[str, DefaultValue] = DefaultValue(
        "wildfire.paloaltonetworks.com"
    )
    report_grayware_files_enabled: Union[bool, DefaultValue] = DefaultValue(False)

    mask_attrs = {"wildfire_public_cloud": ["ipv4", "ipv6", "fqdn"]}

    @classmethod
    def parse_entry(cls, el: etree._Element, version: float):
        attrs = {}
        attrs["size_limits"] = SizeLimits.parse_limits(
            el.find("devices/entry/deviceconfig/setting/wildfire/file-size-limit"),
            version,
        )
        attrs["session_info"] = SessionInfo.parse_entry(
            el.find("devices/entry/deviceconfig/setting/wildfire/session-info-select")
        )
        attrs["timezone"] = el.findtext("devices/entry/deviceconfig/system/timezone")
        attrs["wildfire_public_cloud"] = el.findtext(
            "devices/entry/deviceconfig/setting/wildfire/public-cloud-server"
        )
        attrs["report_grayware_files_enabled"] = parse_match(
            el,
            "devices/entry/deviceconfig/setting/wildfire/report-grayware-file",
            "yes",
        )
        return cls.from_cleanup(**attrs)
