from dataclasses import dataclass

from bpa.models.base_model import BaseModel
from bpa.models.mixins import TemplateMixin


@dataclass
class ScheduledConfigExportModel(BaseModel, TemplateMixin):
    """Scheduled Config Export configuration"""

    xpath = "//config-bundle-export-schedule/entry"

    name: str
    scheduled_export_start_time: str
    host_name: str
    port: str
    enable: bool

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_scheduled_export_start_time(el, model_manager):
        return el.findtext("start-time")

    @staticmethod
    def _get_host_name(el, model_manager):
        return el.findtext("protocol/scp/hostname")

    @staticmethod
    def _get_port(el, model_manager):
        return el.findtext("protocol/scp/port")

    @staticmethod
    def _get_enable(el, model_manager):
        return el.findtext("enable")
