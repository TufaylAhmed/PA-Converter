from typing import Optional

from dataclasses import dataclass

from bpa.models.base_model import BaseModel
from bpa.models.mixins import TemplateMixin, LocationMixin


@dataclass
class SslTlsServiceProfileModel(BaseModel, TemplateMixin, LocationMixin):
    """SSL TLS Service Profile configuration"""

    xpath = "//ssl-tls-service-profile/entry"

    name: str
    certificate: Optional[str]
    min_version: str

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_certificate(el, model_manager):
        return el.findtext("certificate")

    @staticmethod
    def _get_min_version(el, model_manager):
        return el.findtext("protocol-settings/min-version", "tls1-0")
