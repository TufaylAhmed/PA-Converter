import weakref
from typing import List, Set

from dataclasses import dataclass

from bpa.models.base_model import BaseModel
from bpa.models.constants import NONE
from bpa.models.mixins import TemplateMixin


@dataclass
class LogSettingsSystemModel(BaseModel, TemplateMixin):
    # NOTE: Templates won't always have shared/log-settings/config,
    # so we need to stop at //template/entry/config
    xpath = (
        "//template/entry/config | "
        "/config/shared/log-settings/system | "
        "/config/panorama/log-settings/system"
    )

    log_send_to_info: Set[str]
    log_send_to_low: Set[str]
    log_send_to_medium: Set[str]
    log_send_to_high: Set[str]
    log_send_to_critical: Set[str]
    log_send_to_all: Set[str]
    critical_content_logs: Set[str]

    @classmethod
    def build_index(cls) -> List[str]:
        """Log settings system has no name attribute, so just return the template name"""
        return ["template_name"]

    @classmethod
    def from_el(cls, el, model_manager):
        attrs = {
            "log_send_to_info": set(),
            "log_send_to_low": set(),
            "log_send_to_medium": set(),
            "log_send_to_high": set(),
            "log_send_to_critical": set(),
            "log_send_to_all": set(),
            "critical_content_logs": set(),
            "model_manager": weakref.ref(model_manager),
            "template_name": cls._get_template_name(el, model_manager),
        }
        settings = cls(**attrs)

        if attrs["template_name"] is not None:
            el = el.find("shared/log-settings/system")

        if el is None:
            return settings

        # NOTE: LogSettingsSystem setup
        if model_manager.tree.version < 8:
            for match in el.getchildren():
                for child in match.getchildren():
                    if not child.tag.startswith("send"):
                        continue
                    elif child.tag == "send-to-panorama" and child.text != "yes":
                        continue
                    else:
                        send_to = child.tag

                    if match.tag == "informational":
                        settings.log_send_to_info.add(send_to)
                    elif match.tag == "low":
                        settings.log_send_to_low.add(send_to)
                    elif match.tag == "medium":
                        settings.log_send_to_medium.add(send_to)
                    elif match.tag == "high":
                        settings.log_send_to_high.add(send_to)
                    elif match.tag == "critical":
                        settings.log_send_to_critical.add(send_to)
        else:
            system_log_match_list = el.xpath("match-list/entry")
            for match in system_log_match_list:
                for child in match.getchildren():
                    if not child.tag.startswith("send"):
                        continue
                    elif child.tag == "send-to-panorama" and child.text != "yes":
                        continue
                    elif (
                        any(
                            child.tag == t
                            for t in [
                                "send-syslog",
                                "send-snmptrap",
                                "send-email",
                                "send-http",
                            ]
                        )
                        and child.find("member") is None
                    ):
                        continue
                    else:
                        send_to = child.tag
                    if (
                        "(severity eq critical) and ( (description contains Content) or (description contains content) )"
                        == match.find("filter").text
                    ):  # checks for exact text
                        settings.critical_content_logs.add(send_to)
                    if "(severity eq informational)" in match.find("filter").text:
                        settings.log_send_to_info.add(send_to)
                    if "(severity eq low)" in match.find("filter").text:
                        settings.log_send_to_low.add(send_to)
                    if "(severity eq medium)" in match.find("filter").text:
                        settings.log_send_to_medium.add(send_to)
                    if "(severity eq high)" in match.find("filter").text:
                        settings.log_send_to_high.add(send_to)
                    if "(severity eq critical)" in match.find("filter").text:
                        settings.log_send_to_critical.add(send_to)
                    if "All Logs" in match.find("filter").text:
                        settings.log_send_to_all.add(send_to)

        return settings


@dataclass
class LogSettingsConfigModel(BaseModel, TemplateMixin):
    # NOTE: Templates won't always have shared/log-settings/config,
    # so we need to stop at //template/entry/config
    xpath = (
        "//template/entry/config | "
        "/config/shared/log-settings/config | "
        "/config/panorama/log-settings/config"
    )

    config_logs_all: List[str]
    config_logs_custom: List[str]

    @classmethod
    def build_index(cls) -> List[str]:
        """Log settings config has no name attribute, so just return the template name"""
        return ["template_name"]

    @classmethod
    def from_el(cls, el, model_manager):
        attrs = {
            "config_logs_all": set(),
            "config_logs_custom": set(),
            "model_manager": weakref.ref(model_manager),
            "template_name": cls._get_template_name(el, model_manager),
        }

        settings = cls(**attrs)

        if attrs["template_name"] is not None:
            el = el.find("shared/log-settings/config")

        if el is None:
            return settings

        if model_manager.tree.version < 8:
            if el.find("any") is not None:
                for child in el.find("any").getchildren():
                    if child.tag == "send-to-panorama" and child.text == "yes":
                        send_to = "send-to-panorama"
                    else:
                        send_to = child.tag

                    if send_to not in settings.config_logs_all:
                        settings.config_logs_all.add(send_to)
        else:
            config_log_match_list = el.xpath("match-list/entry")
            for match in config_log_match_list:
                for child in match.getchildren():
                    if child.tag == "send-to-panorama" and child.text == "yes":
                        send_to = "send-to-panorama"
                    elif (
                        child.tag not in ["send-to-panorama", "filter"]
                        and child.find("member") is not None
                    ):
                        send_to = child.tag
                    else:
                        send_to = NONE

                    if send_to == NONE:
                        continue

                    if match.find("filter").text != "All Logs":
                        if send_to not in settings.config_logs_custom:
                            settings.config_logs_custom.add(send_to)
                    elif match.find("filter").text == "All Logs":
                        if send_to not in settings.config_logs_all:
                            settings.config_logs_all.add(send_to)
        return settings
