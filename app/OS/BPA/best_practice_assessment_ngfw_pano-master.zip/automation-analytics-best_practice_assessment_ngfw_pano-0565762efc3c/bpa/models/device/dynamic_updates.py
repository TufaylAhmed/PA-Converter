from typing import Dict, Iterable, List, Union

from dataclasses import dataclass

from bpa.models.base_model import BaseModel
from bpa.models.default_value import DefaultValue
from bpa.models.mixins import TemplateMixin
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import parse_match, parse_int


@dataclass
class UpdateType(SubModel):
    """Individual update schedule within Dynamic Updates (e.g. Antivirus or WildFire)."""

    FREQUENCIES = (
        "weekly",
        "daily",
        "hourly",
        "every-hour",
        "every-30-mins",
        "every-15-mins",
        "every-min",
    )

    recurrence: Union[str, DefaultValue]
    action: Union[str, DefaultValue]
    sync_to_peer: Union[bool, DefaultValue, None] = DefaultValue(None)
    threshold: Union[int, DefaultValue, None] = DefaultValue(None)
    new_app_threshold: Union[int, DefaultValue, None] = DefaultValue(None)
    disable_new_content: Union[bool, DefaultValue] = DefaultValue(False)

    @classmethod
    def parse_entry(cls, el, model_manager):
        attrs = {}

        category = el.tag
        recurrence = next(el.iterdescendants(*cls.FREQUENCIES), DefaultValue(None))
        attrs["recurrence"] = getattr(recurrence, "tag", DefaultValue(None))
        attrs["action"] = el.findtext("recurring/*/action", DefaultValue(None))

        # NOTE: Sync to peer is only applicable to Antivirus, Apps & Threats, and WildFire
        if category in {"anti-virus", "threats", "wildfire"}:
            attrs["sync_to_peer"] = parse_match(
                el, "recurring/sync-to-peer", "yes", False
            )

        # NOTE: Threshold is only applicable to Antivirus and Apps & Threats
        if category in {"anti-virus", "threats"}:
            attrs["threshold"] = parse_int(el, "recurring/threshold", 0)

        # NOTE: New App Threshold is only applicable to Apps & Threats
        if category == "threats" and model_manager.tree.version >= 8.1:
            attrs["new_app_threshold"] = parse_int(el, "recurring/new-app-threshold", 0)

        # NOTE: Disable New Content is applicable to PAN-OS 8.1+
        if model_manager.tree.version >= 8.1:
            attrs["disable_new_content"] = parse_match(
                el, f"recurring/*/disable-new-content", "yes", False
            )

        return cls(**attrs)


@dataclass
class DynamicUpdatesModel(BaseModel, TemplateMixin):
    """
    Notes:
        Panorama devices / templates cannot be configured for Global Protect or GP Clientless VPN.
        GP Clientless VPN was added in PAN-OS 8.0
    """

    xpath = "//config/devices/entry"

    UPDATE_TYPE_TAGS = (
        "anti-virus",
        "threats",
        "wildfire",
        "global-protect-datafile",
        "global-protect-clientless-vpn",
    )

    update_types: Union[Dict[str, UpdateType], DefaultValue]

    def get_relevant_update_types(self) -> Iterable[str]:
        """For NGFWs, need to check license info to see what updates types are relevant."""
        if self.objects.tree.ngfw:
            keys = []
            license_info = self.objects.license_info
            if license_info.has_active_license("WildFire License"):
                keys.append("wildfire")
            if license_info.has_active_license("Threat Prevention"):
                keys.extend(["anti-virus", "threats"])
            if license_info.has_active_gp_license():
                keys.extend(
                    ["global-protect-datafile", "global-protect-clientless-vpn"]
                )
            return keys
        return self.update_types.keys()

    def to_dict(self) -> Dict:
        keys = self.get_relevant_update_types()
        data = {"update_types": [], "template_name": self.template_name}
        for key, val in self.update_types.items():
            if val is None or key not in keys:
                continue
            data["update_types"].append({**{"update_type": key}, **val.to_dict()})
        return data

    @classmethod
    def build_index(cls) -> List[str]:
        """Dynamic updates has no name attribute, so just return the template name"""
        return ["template_name"]

    @classmethod
    def _get_update_types(
        cls, el, model_manager
    ) -> Union[Dict[str, UpdateType], DefaultValue]:
        update_types = {_: None for _ in cls.UPDATE_TYPE_TAGS}
        target_el = el.find("deviceconfig/system/update-schedule")
        if target_el is not None:
            for update_type_el in target_el.iterchildren(*cls.UPDATE_TYPE_TAGS):
                update_types[update_type_el.tag] = UpdateType.parse_entry(
                    update_type_el, model_manager
                )
            return update_types
        return DefaultValue(update_types)


@dataclass
class UpdateSchedule(SubModel):
    type: str
    recurrence: str
    action: str

    @classmethod
    def parse_entry(cls, el):
        attrs = {"type": el.tag}
        attrs["recurrence"] = el.find("recurring/*").tag
        attrs["action"] = el.find("recurring/*/action/*").tag
        return cls(**attrs)


@dataclass
class DeviceDeploymentDynamicUpdatesModel(BaseModel):
    xpath = "//deployment-update-schedule/entry"

    UPDATE_TYPE_TAGS = (
        "app",
        "anti-virus",
        "app-and-threat",
        "wildfire",
        "url-database",
        "wf-content",
    )

    name: str
    schedule: UpdateSchedule
    enabled: bool = True

    @classmethod
    def build_index(cls) -> List[str]:
        """Dynamic updates has no name attribute, so just return the template name"""
        return ["name"]

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_enabled(el, model_manager):
        return el.findtext("disabled", "no") == "no"

    @classmethod
    def _get_schedule(cls, el, model_manager):
        """Since device deployment dynamic updates have only one type each,
        filter out the None values.
        """
        for update_type_el in el.iterchildren(*cls.UPDATE_TYPE_TAGS):
            return UpdateSchedule.parse_entry(update_type_el)
        else:
            raise ValueError(f"No tags matching {cls.UPDATE_TYPE_TAGS}")
