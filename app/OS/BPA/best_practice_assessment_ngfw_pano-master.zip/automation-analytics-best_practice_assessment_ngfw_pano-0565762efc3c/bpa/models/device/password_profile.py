from dataclasses import dataclass

from bpa.models.base_model import BaseModel
from bpa.models.mixins import TemplateMixin


@dataclass
class PasswordProfileModel(BaseModel, TemplateMixin):
    xpath = "//config/mgt-config/password-profile/entry"

    name: str
    password_change_period: str

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_password_change_period(el, model_manager):
        return el.findtext("password-change/expiration-period")
