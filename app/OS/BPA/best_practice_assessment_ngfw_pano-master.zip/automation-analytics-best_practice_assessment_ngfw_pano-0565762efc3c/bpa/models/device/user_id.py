from typing import List, Optional, Union

from dataclasses import dataclass

from bpa.models.base_model import BaseModel
from bpa.models.constants import NONE
from bpa.models.default_value import DefaultValue, NameValue
from bpa.models.mixins import TemplateMixin, LocationMixin
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import (
    parse_match,
    parse_not_match,
    parse_int,
    parse_list,
    parse_tag,
    parse_text,
)


@dataclass
class CustomGroup(SubModel):
    """UserID > GroupMapping > CustomGroup"""

    name: str
    ldap_filter: str

    @classmethod
    def parse_entry(cls, el):
        attrs = {}
        attrs["name"] = el.get("name")
        attrs["ldap_filter"] = el.findtext("ldap-filter")
        return cls(**attrs)


@dataclass
class GroupMapping(SubModel):
    """GroupMapping within UserID model"""

    name: str
    enabled: Union[bool, DefaultValue] = DefaultValue(True)
    included_groups_used: Union[bool, DefaultValue] = DefaultValue(False)
    custom_groups: Union[List[CustomGroup], DefaultValue] = DefaultValue([])

    @classmethod
    def parse_entry(cls, el):
        name = el.get("name")
        enabled = parse_not_match(el, "disabled", "yes", True)
        included_list = el.find("group-include-list/member")
        if included_list is None:
            included_groups_used = DefaultValue(False)
        else:
            included_groups_used = True

        custom_group_res = el.xpath("custom-group/entry")
        if len(custom_group_res) > 0:
            custom_groups = [CustomGroup.parse_entry(e) for e in custom_group_res]
        else:
            custom_groups = DefaultValue([])

        return cls(name, enabled, included_groups_used, custom_groups)


@dataclass
class CaptivePortalSetting(SubModel):
    """CaptivePortalSetting within UserID model"""

    enabled: Union[bool, DefaultValue]
    mode: str
    session_cookie_enabled: Union[bool, DefaultValue]
    session_cookie_timeout: Union[int, DefaultValue]
    ssl_tls_service_profile: str
    ssl_tls_service_profile_min_version: Union[str, DefaultValue]
    auth_profile: str
    cert_profile: str

    @classmethod
    def parse_entry(cls, el):
        attrs = {}
        attrs["enabled"] = parse_match(
            el, "captive-portal/enable-captive-portal", "yes", True
        )
        attrs["mode"] = parse_tag(el, "captive-portal/mode/*", default=NONE)
        mode_path = "captive-portal/mode/{}/session-cookie".format(attrs["mode"])
        attrs["session_cookie_enabled"] = parse_match(
            el, f"{mode_path}/enable", "yes", True
        )
        attrs["session_cookie_timeout"] = parse_int(el, f"{mode_path}/timeout", 1440)
        attrs["ssl_tls_service_profile"] = el.findtext(
            "captive-portal/ssl-tls-service-profile", NONE
        )
        if attrs["ssl_tls_service_profile"] == NONE:
            attrs["ssl_tls_service_profile_min_version"] = DefaultValue("N/A")
        else:
            minv_name = '/ssl-tls-service-profile/entry[@name="{profile}"]'.format(
                profile=attrs["ssl_tls_service_profile"]
            )
            minv_suffix = minv_name + "/protocol-settings/min-version/text()"
            minv_x1 = "/config/shared" + minv_suffix
            minv_x2 = (
                "/config/devices/entry/template/entry/config/devices/entry/vsys/entry"
                + minv_suffix
            )
            minv_result = el.xpath(minv_x1) + el.xpath(minv_x2)
            if not minv_result:
                attrs["ssl_tls_service_profile_min_version"] = DefaultValue("tls1-0")
            else:
                attrs["ssl_tls_service_profile_min_version"] = minv_result[0]

        attrs["auth_profile"] = el.findtext(
            "captive-portal/authentication-profile", NONE
        )
        attrs["cert_profile"] = el.findtext("captive-portal/certificate-profile", NONE)

        return cls(**attrs)


@dataclass
class UserIdAgent(SubModel):
    name: str
    enabled: Union[bool, DefaultValue] = DefaultValue(True)
    serial_number: Optional[str] = None

    @classmethod
    def parse_entry(cls, el):
        attrs = {}
        attrs["name"] = el.get("name")
        attrs["serial_number"] = el.findtext("serial-number")
        attrs["enabled"] = parse_not_match(el, "disabled", "yes", True)
        return cls(**attrs)


@dataclass
class TerminalServicesAgent(SubModel):
    name: str
    host: str
    port: str
    enabled: Union[bool, DefaultValue] = DefaultValue(True)

    mask_attrs = {"host": ["ipv4", "fqdn"]}

    @classmethod
    def parse_entry(cls, el):
        attrs = {}
        attrs["name"] = el.get("name")
        attrs["host"] = el.findtext("host")
        attrs["port"] = el.findtext("port")
        attrs["enabled"] = parse_not_match(el, "disabled", "yes", True)
        return cls(**attrs)


@dataclass
class ServerMonitor(SubModel):
    name: str
    enabled: bool = DefaultValue(True)
    transport_protocol: str = DefaultValue("WMI")

    @classmethod
    def parse_entry(cls, el):
        attrs = {}
        attrs["name"] = el.get("name")
        attrs["enabled"] = parse_not_match(el, "disabled", "yes", True)
        attrs["transport_protocol"] = parse_text(el, "*/type", "WMI")
        return cls(**attrs)


@dataclass
class UserIdModel(BaseModel, TemplateMixin, LocationMixin):
    """ Start with all vsys entries that have a user-id-collector node
    """

    # Updated xpath to only consider data when there is any child exists.
    # https://stackoverflow.com/questions/1143864/xpath-to-select-only-nodes-where-child-elements-exist
    xpath = "//config/devices/entry/vsys/entry[child::user-id-collector[*]]"

    include_networks: Union[List[str], DefaultValue]
    server_log_monitor_frequency: Union[int, DefaultValue]
    probing_enabled: Union[bool, DefaultValue]
    user_id_timeout_enabled: Union[bool, DefaultValue]
    user_id_timeout: Union[int, DefaultValue]
    server_monitors: Union[List[ServerMonitor], DefaultValue]
    group_mappings: Union[List[GroupMapping], DefaultValue]
    captive_portal_setting: Optional[CaptivePortalSetting]
    user_id_agents: Union[List[UserIdAgent], DefaultValue]
    terminal_services_agents: Union[List[TerminalServicesAgent], DefaultValue]
    connection_security_profile: Optional[str]

    mask_attrs = {"include_networks": ["ipv4", "ipv6"]}

    @classmethod
    def build_index(cls):
        return ["template_name", "location"]

    @staticmethod
    def _get_include_networks(el, model_manager) -> List[str]:
        return parse_list(
            el,
            'user-id-collector/include-exclude-network/entry[child::discovery[text()="include"]]/@name',
            [],
        )

    @staticmethod
    def _get_server_log_monitor_frequency(el, model_manager) -> int:
        return parse_int(el, "user-id-collector/setting/security-log-interval", 2)

    @staticmethod
    def _get_probing_enabled(el, model_manager) -> bool:
        return parse_match(el, "user-id-collector/setting/enable-probing", "yes", False)

    @staticmethod
    def _get_user_id_timeout_enabled(el, model_manager) -> bool:
        return parse_match(
            el, "user-id-collector/setting/enable-mapping-timeout", "yes", True
        )

    @staticmethod
    def _get_user_id_timeout(el, model_manager) -> int:
        return parse_int(el, "user-id-collector/setting/ip-user-mapping-timeout", 45)

    @staticmethod
    def _get_server_monitors(el, model_manager) -> List[NameValue]:
        result = parse_list(el, "user-id-collector/server-monitor/entry", [])
        if not isinstance(result, DefaultValue):
            return [ServerMonitor.parse_entry(_) for _ in result]
        else:
            return result

    @staticmethod
    def _get_group_mappings(
        el, model_manager
    ) -> Union[List[GroupMapping], DefaultValue]:
        return [
            GroupMapping.parse_entry(mapping)
            for mapping in el.findall("group-mapping/entry")
        ] or DefaultValue([])

    @staticmethod
    def _get_captive_portal_setting(
        el, model_manager
    ) -> Optional[CaptivePortalSetting]:
        if el.find("captive-portal") is None:
            return
        return CaptivePortalSetting.parse_entry(el)

    @staticmethod
    def _get_user_id_agents(
        el, model_manager
    ) -> Union[List[UserIdAgent], DefaultValue]:
        return [
            UserIdAgent.parse_entry(_) for _ in el.findall("user-id-agent/entry")
        ] or DefaultValue([])

    @staticmethod
    def _get_terminal_services_agents(
        el, model_manager
    ) -> Union[List[TerminalServicesAgent], DefaultValue]:
        return [
            TerminalServicesAgent.parse_entry(_) for _ in el.findall("ts-agent/entry")
        ] or DefaultValue([])

    @staticmethod
    def _get_connection_security_profile(el, model_manager) -> Optional[str]:
        return el.findtext("user-id-ssl-auth/certificate-profile")

    @property
    def connection_security_configured(self) -> bool:
        return self.connection_security_profile is not None
