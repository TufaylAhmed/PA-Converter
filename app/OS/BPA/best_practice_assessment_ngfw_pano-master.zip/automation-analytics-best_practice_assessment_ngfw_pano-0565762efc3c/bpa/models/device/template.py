from typing import List

from dataclasses import dataclass
from lxml import etree

from bpa.models.base_model import BaseModel
from bpa.models.utils.parsing import ParseVariableMixin


@dataclass
class TemplateModel(BaseModel, ParseVariableMixin):
    xpath = "//config/devices/entry/template/entry"
    name: str
    vsys: List[str]
    devices: List[str]

    @staticmethod
    def _get_name(el: etree._Element, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_vsys(el: etree._Element, model_manager) -> List[str]:
        vsys = [x.get("name") for x in el.xpath("config/devices/entry/vsys/entry")]
        return vsys

    @staticmethod
    def _get_devices(el: etree._Element, model_manager) -> List[str]:
        return el.xpath("devices/entry/@name")
