from abc import ABCMeta, abstractmethod

from bpa.models.model_set import ModelSet


class BaseResolver(metaclass=ABCMeta):
    """Resolution for models from template stacks.

    Attributes:
        priority: List of priority from highest to lowest.
        mapping: Model set mapping.
        stack_name: Template stack name.
        metadata: Additional data needed for processing.
    """

    def __init__(self, priority, mapping, stack_name, metadata=None):
        self.priority = priority
        self.mapping = mapping
        self.stack_name = stack_name
        if metadata is None:
            self.metadata = {}
        else:
            self.metadata = metadata

    @abstractmethod
    def resolve(self) -> ModelSet:
        """Resolve models from template stack perspective."""
        pass
