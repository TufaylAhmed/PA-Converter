from typing import Optional, Union

from dataclasses import dataclass
from lxml import etree

from bpa.models.constants import NONE_LOWER
from bpa.models.default_value import DefaultValue
from bpa.models.sub_model import SubModel
from bpa.models.utils.parsing import parse_match, parse_tag, parse_int


@dataclass
class ServicesSettings(SubModel):
    """Device Setup > Services Settings"""

    verify_update_server_identity_enabled: Union[bool, DefaultValue]
    primary_ntp_server_address: Optional[str]
    secondary_ntp_server_address: Optional[str]
    primary_ntp_server_auth_type: Optional[str]
    secondary_ntp_server_auth_type: Optional[str]
    fqdn_refresh_time: int = DefaultValue(30)

    mask_attrs = {
        "primary_ntp_server_address": ["ipv4", "ipv6"],
        "secondary_ntp_server_address": ["ipv4", "ipv6"],
    }

    @classmethod
    def parse_entry(cls, el: etree._Element) -> "ServicesSettings":
        attrs = {
            "verify_update_server_identity_enabled": DefaultValue(True),
            "primary_ntp_server_address": None,
            "secondary_ntp_server_address": None,
            "primary_ntp_server_auth_type": None,
            "secondary_ntp_server_auth_type": None,
        }
        system_el = el.find("devices/entry/deviceconfig/system")
        if system_el is not None:
            attrs["verify_update_server_identity_enabled"] = parse_match(
                system_el, "server-verification", "yes", True
            )
            attrs["primary_ntp_server_address"] = system_el.findtext(
                "ntp-servers/primary-ntp-server/ntp-server-address"
            )
            attrs["secondary_ntp_server_address"] = system_el.findtext(
                "ntp-servers/secondary-ntp-server/ntp-server-address"
            )
            attrs["primary_ntp_server_auth_type"] = parse_tag(
                system_el,
                "ntp-servers/primary-ntp-server/authentication-type/*",
                default=None,
                override=NONE_LOWER,
            )
            attrs["secondary_ntp_server_auth_type"] = parse_tag(
                system_el,
                "ntp-servers/secondary-ntp-server/authentication-type/*",
                default=None,
                override=NONE_LOWER,
            )
            attrs["fqdn_refresh_time"] = parse_int(system_el, "fqdn-refresh-time", 30)
        return cls(**attrs)
