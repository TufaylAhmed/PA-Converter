from dataclasses import dataclass
from lxml import etree

from bpa.models.base_model import BaseModel
from bpa.models.mixins import TemplateMixin


@dataclass
class VirtualSystemModel(BaseModel, TemplateMixin):
    #  added [@name] to fix issue of one customer.
    xpath = "//devices/entry/vsys/entry[@name]"
    name: str

    @staticmethod
    def _get_name(el: etree._Element, model_manager):
        return el.get("name")
