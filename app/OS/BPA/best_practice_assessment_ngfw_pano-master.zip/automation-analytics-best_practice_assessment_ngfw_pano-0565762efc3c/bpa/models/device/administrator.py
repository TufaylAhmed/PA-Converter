import logging
from typing import Optional

from dataclasses import dataclass
from lxml import etree

from bpa.models.base_model import BaseModel
from bpa.models.constants import NONE
from bpa.models.mixins import TemplateMixin

from .authentication_profile import AuthenticationProfileModel
from .password_profile import PasswordProfileModel


LOG = logging.getLogger(__name__)


@dataclass
class AdministratorModel(BaseModel, TemplateMixin):
    xpath = "//config/mgt-config/users/entry"

    name: str
    role: str
    password_profile: Optional[str] = None
    authentication_profile: Optional[str] = None

    mask_attrs = {"name": ["name"]}

    def is_local(self) -> bool:
        """Helper to determine whether admin is local or external.

        External users will have an auth profile configured.
        """
        return self.authentication_profile is None

    def using_local_authentication(self) -> bool:
        """Returns whether a local authentication method is being used by the auth profile or auth sequence."""
        if self.authentication_profile is None:
            return False

        # Administrators can only use Authentication Profiles/Sequences in the 'panorama' location for Panorama devices
        # or the 'shared' location for NGFWs / device templates
        if self.objects.tree.panorama and self.template_name is None:
            location = "panorama"
        else:
            location = "shared"
        LOG.debug(f"Using location: {location}")

        def find_target(model_key) -> Optional:
            return self.objects.get(model_key).find(
                name=self.authentication_profile,
                template_name=self.template_name,
                location=location,
            )

        for key in ("authentication_profile", "authentication_sequence"):
            auth_prof_seq = find_target(key)
            if auth_prof_seq is not None:
                return auth_prof_seq.using_local_authentication()

        raise ValueError(
            "Cannot find matching authentication profile or sequence with"
            f" name={self.authentication_profile}"
            f", template_name={self.template_name}"
            f", and location={location}"
        )

    @property
    def pw_prof_obj(self) -> Optional[PasswordProfileModel]:
        """Retrieves the password profile object."""
        if self.password_profile is None:
            return
        return self.objects.get("password_profile").find(
            template_name=self.template_name, name=self.password_profile
        )

    @property
    def auth_prof_obj(self) -> Optional[AuthenticationProfileModel]:
        """Retrieves the authentication profile object."""
        if self.authentication_profile is None:
            return
        return self.objects.get("authentication_profile").findany(
            template_name=self.template_name, name=self.authentication_profile
        )

    @staticmethod
    def _get_role(el: etree._Element, model_manager) -> str:
        """Get user role."""
        role = el.xpath("name(permissions/role-based/*[1])")
        if not role:
            role = el.findtext("permissions/role-based/custom/profile", NONE)
        return role

    @staticmethod
    def _get_name(el: etree._Element, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_password_profile(el: etree._Element, model_manager) -> str:
        return el.findtext("password-profile")

    @staticmethod
    def _get_authentication_profile(el: etree._Element, model_manager) -> str:
        return el.findtext("authentication-profile")
