"""Utilities related to NGFW or Panorama Tech Support Files."""
import datetime
import logging
import re
import tarfile
from io import BytesIO, TextIOWrapper
from typing import Dict, Optional, Union

import pendulum
from dateutil import parser
from lxml import etree
from pendulum.tz.zoneinfo.exceptions import InvalidTimezone

from .constants import TIMEZONES
from .license import LicenseInfo, License
from .system import SystemInfo
from .rule_usage import RuleUsageModel, RuleUsageInfo


LOG = logging.getLogger(__name__)


class TechSupportFile(object):
    """Tech Support File for a NGFW or Panorama device.

    Attributes:
        _tsf: Private variable for TSF.
        _cli: Private CLI instance.
        _config_location: Private configuration location.
        tsf_generated_date: TSF generated date.
    """

    def __init__(self, tsf):
        LOG.debug(f"{self.__class__.__name__} initializing")
        self._tsf = tsf
        self._sdb = self.parse_sdb()
        self._cli = self.find_cli()
        self._config_location = self.get_config_location()
        self.tsf_generated_date = self.parse_tsf_generated_date()
        self._system_info = None
        self._system_time = None

    @property
    def system_info(self):
        if self._system_info is None:
            self._system_info = self.get_system_info()
        return self._system_info

    def parse_sdb(self) -> Dict:
        """Parses the sdb.txt file for specific attributes of interest."""
        targets = {
            "sys.s1.info.serial",
            "cfg.platform.serial",
            "cfg-old.platform.serial",
            "local.model",
            "cfg-old.platform.model",
            "cfg.platform.model",
            "sys.s1.info.model",
            "cfg.sw-version",
            "cfg.app-version",
            "cfg.hostname",
            "sys.time.datetime",
            "peer.sys.time.datetime",
            "cfg.sys.time.zone",
            "peer.cfg.sys.time.zone",
            "peer.cfg.platform.serial",
        }

        try:
            sdb_fl = self._tsf.extractfile("./tmp/cli/logs/sdb.txt")
        except KeyError:
            raise TSFError("SDB file not found")

        sdb = {}
        for line in sdb_fl:
            try:
                key, val = line.decode().strip().split(": ", maxsplit=1)
            except ValueError:
                continue
            if key in targets:
                sdb[key] = val
        return sdb

    def get_cli_clock(self) -> Optional[pendulum.DateTime]:
        self.cli.seek(0)
        found = False
        clock = None
        for line in self.cli:
            if found:
                line = line.decode().strip()
                if line.startswith(">"):
                    break
                if line:
                    clock = pendulum.instance(parser.parse(line, tzinfos=TIMEZONES))
            elif line.startswith(b"> show clock"):
                found = True
        return clock

    @property
    def system_time(self) -> pendulum.DateTime:
        """Check multiple locations for device system time.

        Order of priority:
        1) CLI file "show clock" command
        2) sdb.txt file sys.time.datetime value
        3) running-config.xml mtime value
        """
        if self._system_time is None:
            clock = self.get_cli_clock()
            if clock is not None:
                LOG.debug("Taking system time from 'show clock' output in CLI file.")
                self._system_time = clock
            else:
                dt = self._sdb.get("sys.time.datetime") or self._sdb.get(
                    "peer.sys.time.datetime"
                )
                if dt is not None:
                    LOG.debug("Taking system time data from sdb.txt file.")
                    dt = pendulum.instance(parser.parse(dt))
                else:
                    LOG.debug("Taking system time from running-config.xml mtime value.")
                    dt = pendulum.instance(
                        datetime.datetime.fromtimestamp(self._config_location.mtime)
                    )

                tz = self._sdb.get("cfg.sys.time.zone") or self._sdb.get(
                    "peer.cfg.sys.time.zone"
                )
                if tz is not None:
                    try:
                        dt = dt.set(tz=tz)
                    except InvalidTimezone:
                        LOG.error(
                            f"Unable to handle timezone value {tz}. Defaulting to UTC."
                        )
                else:
                    LOG.debug(
                        "Could not find timezone data in sdb.txt file. Defaulting to UTC."
                    )

                self._system_time = dt

        return self._system_time

    @property
    def system_tz(self) -> str:
        """System timezone as derived from sdb.txt file."""
        try:
            return self._sdb["cfg.sys.time.zone"]
        except KeyError:
            raise TSFError("'cfg.sys.time.zone' missing from sdb.txt file")

    @property
    def cli(self):
        LOG.debug(f'CLI file is {"not " if self._cli else ""}None')
        return self._cli or BytesIO()

    def get_config_location(self):
        """Gets the running configuration location.

        Prefer the .merged-running-config.xml file if present.

        Returns:
            A TarInfo object.

        Raises:
            tarfile.ReadError if the TSF is corrupt. Must be handled
            by the consumer of this library.
        """
        try:
            config = self._tsf.getmember(
                "./opt/pancfg/mgmt/saved-configs/.merged-running-config.xml"
            )
            LOG.debug("Using .merged-running-config.xml")
        except KeyError:
            try:
                config = self._tsf.getmember(
                    "./opt/pancfg/mgmt/saved-configs/running-config.xml"
                )
                LOG.debug("Using running-config.xml")
            except KeyError:
                raise TSFError("XML config file not found")
        return config

    def get_running_config(self) -> etree._ElementTree:
        """Extracts and parse running configuration.

        Returns:
            An lxml.etree._ElementTree of the running config.
        """
        return etree.parse(self._tsf.extractfile(self._config_location))

    def get_rule_hit_count_db(self) -> Optional[tarfile.ExFileObject]:
        """Extracts the rule-hit-count-db. This file is only available in 9.0+

        Returns:
            Bytes of the read file or None
        """
        try:
            return self._tsf.extractfile(
                "./opt/pancfg/mgmt/devices/localhost.localdomain/rule-hit-count-db.txt"
            )
        except KeyError:
            LOG.debug("Rule Hit Count DB file not found")

    def parse_tsf_generated_date(self, fmt="%Y-%m-%d %H:%M:%S") -> str:
        """Extracts the TSF generated date.

        Since timestamps can vary slightly on files in the TSF,
        use the XML config timestamp to be backwards compatible with
        prior versions of the BPA / Customer Success Site.

        Args:
            fmt: Desired string format of TSF generated date.

        Returns:
            A string of the TSF generated date.
        """
        return datetime.datetime.fromtimestamp(self._config_location.mtime).strftime(
            fmt
        )

    def find_cli(self) -> Optional[tarfile.TarInfo]:
        """Extracts the CLI file from the Tech Support File."""
        try:
            cli_file = self._tsf.extractfile(
                next(
                    iter(
                        m
                        for m in self._tsf.getmembers()
                        if m.name.startswith("./tmp/cli/techsupport_")
                    )
                )
            )
            return cli_file
        except StopIteration:
            LOG.warning("CLI file not found")
            return None

    def get_system_info(self) -> Dict:
        """First attempt to parse system info from CLI file.

        If CLI file is missing, fall back to parsing serial number out of sdb.txt file.
        """
        if self._cli is not None:
            LOG.debug("Getting system info from CLI output")
            _sys_info = self._parse_sys_info_cli()
        else:
            LOG.debug("Getting system info from sdb.txt")
            _sys_info = self._parse_sys_info_sdb()

        _sys_info.update(self._parse_ha_peer_serial_sdb())
        return _sys_info

    def _parse_ha_peer_serial_sdb(self) -> Dict:
        return {"ha-peer-serial": self._sdb.get("peer.cfg.platform.serial")}

    def _parse_sys_info_sdb(self) -> SystemInfo:
        """Serial number and other values typically found in the CLI dump can also be found in
        ./tmp/cli/logs/sdb.txt
        """
        system_info = {}
        targets = ["serial", "model", "sw-version", "app-version", "hostname"]
        for key, val in self._sdb.items():
            key_base = key.split(".")[-1]
            if key_base in targets:
                system_info[key_base] = val
        if not system_info:
            raise TSFError("No data found in sdb.txt")
        return SystemInfo(system_info)

    # TODO: Consider refactoring to leverage finite-state-machine
    # https://en.wikipedia.org/wiki/Finite-state_machine
    def _parse_sys_info_cli(self) -> SystemInfo:
        """Extracts system info from CLI."""
        self.cli.seek(0)
        system_info = {}
        sys_flag_absolute = ["logdb-quota-split", "ha-local", "ha-peer"]
        sys_flag_prefixes = ["system-info", "user-id", "logdb-quota", "ha"]
        sys_flags = {k: False for k in sys_flag_absolute}
        for pre in sys_flag_prefixes:
            sys_flags[f"{pre}-start"] = False
            sys_flags[f"{pre}-end"] = False

        # https://stackoverflow.com/questions/19859282/check-if-a-string-contains-a-number
        def has_digits(s: str) -> bool:
            return any(48 <= ord(c) <= 57 for c in s)

        for line in self.cli:
            # Terminate when all parsing logic is resolved
            if all({v for k, v in sys_flags.items() if k.endswith("end")}):
                break

            # Clear line of trailing whitespace
            line = line.strip(b" \n")

            # NOTE: Parse system information
            if line == b"> show system info":
                sys_flags["system-info-start"] = True
            elif sys_flags["system-info-start"]:
                sys_flags["system-info-end"] = line.startswith(b">")
                sys_flags["system-info-start"] = not sys_flags["system-info-end"]
                key_val = line.decode(errors="replace").strip().split(": ")
                try:
                    system_info_key = key_val[0]
                    system_info[system_info_key] = key_val[1]
                except IndexError:
                    continue

            # NOTE: Parse count from ip-user-mapping (NGFW only)
            if line == b"> show user ip-user-mapping all option count":
                sys_flags["user-id-start"] = True
            elif sys_flags["user-id-start"]:
                sys_flags["user-id-end"] = line.startswith(b">")
                sys_flags["user-id-start"] = not sys_flags["user-id-end"]
                key_val = line.decode(errors="replace").strip().split(": ")
                try:
                    system_info["user-id-count"] = key_val[1]
                except IndexError:
                    continue

            # NOTE: Parse log rentention
            if line == b"> show system logdb-quota":
                sys_flags["logdb-quota-start"] = True
            elif sys_flags["logdb-quota-start"]:
                sys_flags["logdb-quota-end"] = line.startswith(b">")
                sys_flags["logdb-quota-start"] = not sys_flags["logdb-quota-end"]
                if line == b"Disk usage:":
                    sys_flags["logdb-quota-split"] = True
                elif sys_flags["logdb-quota-split"]:
                    data = line.decode(errors="replace").strip().split(": ")
                    try:
                        if data[0] in {"traffic", "threat", "system", "config"}:
                            system_info[f"log-retention-{data[0]}"] = data[3]
                    except IndexError:
                        continue

            # NOTE: Parse high availability
            if line == b"> show high-availability all":
                sys_flags["ha-start"] = True
            elif sys_flags["ha-start"]:
                sys_flags["ha-end"] = line.startswith(b">")
                sys_flags["ha-start"] = not sys_flags["ha-end"]
                if line == b"Local Information:":
                    sys_flags["ha-local"] = True
                    sys_flags["ha-peer"] = False
                elif line == b"Peer Information:":
                    sys_flags["ha-peer"] = True
                    sys_flags["ha-local"] = False
                elif sys_flags["ha-local"] or sys_flags["ha-peer"]:
                    data = line.decode(errors="replace").strip().split(": ")
                    try:
                        key_suffix, val = data
                        key_suffix = key_suffix.lower().replace(" ", "-")
                        if ";" in key_suffix or ";" in val or has_digits(key_suffix):
                            continue
                        key_prefix = "ha-local" if sys_flags["ha-local"] else "ha-peer"
                        system_info[f"{key_prefix}-{key_suffix}"] = val
                    except (IndexError, ValueError):
                        continue

        return SystemInfo(system_info)

    def get_license_info(self) -> LicenseInfo:
        """Extracts license info from CLI."""
        self.cli.seek(0)
        lines = self.cli.readlines()
        found_section = False
        license_info = LicenseInfo()
        for i, line in enumerate(lines):
            if line.startswith(b"License entry:"):
                found_section = True
                start = i + 1
                # look 10 lines out to be safe
                end = i + 10
                sublist = lines[start:end]
                attrs = {}
                for row in sublist:
                    row = row.decode().strip()
                    # check for a colon + space + non-whitespace pattern
                    if bool(re.search(r": \S", row)):
                        key, val = row.split(": ", maxsplit=1)
                        attrs[key] = val
                    # end of license entry found
                    if len(row) == 0:
                        # skip adding the license if the entry is malformed
                        try:
                            license = License.from_tsf(attrs)
                            license_info.add(license)
                        except (KeyError, ValueError):
                            LOG.warning("Skip current license as it is corrupt")
                        break
            # exit condition when moving on the the next section in the CLI file
            # so we don't need to continue iterating through the entire file
            if line.startswith(b">") and found_section:
                break
        return license_info

    def __del__(self):
        """Close the TSF when object is deleted."""
        self._tsf.close()

    @classmethod
    def read_tsf(cls, *args, **kwargs):
        """Light wrapper around tarfile.open method.

        Returns:
            An instantiated TechSupportFile object.
        """

        try:
            tsf = tarfile.open(*args, **kwargs)
        except tarfile.ReadError:
            raise TSFError("File could not be read")
        return cls(tsf)

    @classmethod
    def parse_rule_hit_count_db(
        cls, rhc_db_file: Union[tarfile.ExFileObject, TextIOWrapper, None]
    ) -> RuleUsageInfo:
        """This will parse the rule-hit-db.txt file to a RuleUsageInfo model"""
        rule_usage_info = RuleUsageInfo()
        if rhc_db_file:
            # Order of the fields is important as it is the order data is in every line.
            fields = [
                "rule_uuid",
                "vsys_id",
                "rule_base_type",
                "rule_name",
                "hit_count",
                "last_hit_ts",
                "last_rest_ts",
                "first_hit_ts",
                "rule_create_ts",
                "rule_modify_ts",
                "md5sum",
                "vsys_name",
            ]
            for line in rhc_db_file.readlines():
                # if line is in bytes format we need to decode it to string
                if isinstance(line, bytes):
                    line = line.decode("utf-8")

                # Removing trailing \n
                line = str(line).rstrip("\n")

                try:
                    # Splitting line into a list of values
                    values = line.split("|")

                    # Creating a dict with key: element from fields and value: element from values
                    attrs = dict(zip(fields, values))
                    rule_usage_info[attrs["rule_uuid"]] = RuleUsageModel(**attrs)
                except (KeyError, ValueError, TypeError) as e:
                    LOG.error(f"Exception occurred: {e} for line: {line}")
        return rule_usage_info


class TSFError(Exception):
    """Generic error for exceptions related to Tech Support File."""

    pass
