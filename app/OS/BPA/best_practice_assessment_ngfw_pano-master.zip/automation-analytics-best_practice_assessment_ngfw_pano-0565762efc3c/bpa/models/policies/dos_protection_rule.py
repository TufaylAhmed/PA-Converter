from dataclasses import dataclass

from bpa.models.utils.parsing import parse_tag, parse_text

from ..base_model import BaseModel
from ..constants import NONE
from ..mixins import LocationMixin
from bpa.models.mixins import MaskMixin
from ..model_sets.dos_protection_rule import DosProtectionRuleModelSet


@dataclass
class DosProtectionRuleModel(BaseModel, LocationMixin, MaskMixin):
    xpath = "//dos/rules/entry"

    name: str
    action: str
    dos_protection_profile: str
    rule_enabled: bool
    destination_address: str
    source_zone: str
    destination_zone: str
    service: str

    model_set = DosProtectionRuleModelSet
    mask_attrs = {"destination_address": []}

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_dos_protection_profile(el, model_manager):
        return parse_text(el, "protection/classified/profile", NONE)

    @staticmethod
    def _get_action(el, model_manager):
        return parse_tag(el, "action/*", default="No action")

    @staticmethod
    def _get_rule_enabled(el, model_manager):
        return el.findtext("disabled") != "yes"

    @staticmethod
    def _get_destination_address(el, model_manager):
        return el.findtext("destination/member")

    @staticmethod
    def _get_source_zone(el, model_manager):
        return el.findtext("from/zone/member")

    @staticmethod
    def _get_destination_zone(el, model_manager):
        return el.findtext("to/zone/member")

    @staticmethod
    def _get_service(el, model_manager):
        return el.findtext("service/member")
