from typing import Optional

from dataclasses import dataclass

from bpa.models.utils.parsing import parse_text

from ..base_model import BaseModel
from ..mixins import LocationMixin


@dataclass
class AppOverrideModel(BaseModel, LocationMixin):
    xpath = "//application-override/rules/entry"

    name: str
    rulebase: str
    application: Optional[str]

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_rulebase(el, model_manager):
        return next(el.iterancestors("rulebase", "pre-rulebase", "post-rulebase")).tag

    @staticmethod
    def _get_application(el, model_manager):
        return parse_text(el, "application")

    @property
    def custom_app(self):
        if self.application:
            app_ms = self.objects.get("application")
            return app_ms.find(
                name=self.application, location=self.location
            ) or app_ms.find(name=self.application, location="shared")
