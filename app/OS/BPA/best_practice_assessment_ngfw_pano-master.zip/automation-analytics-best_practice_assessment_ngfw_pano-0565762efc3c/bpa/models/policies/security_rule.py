import itertools
import weakref
from typing import List, Optional, Tuple

from dataclasses import dataclass
from lxml import etree

from ..base_model import BaseModel
from ..constants import NONE, NONE_LOWER
from ..mixins import LocationMixin
from ..model_sets.security_rule import SecurityRuleModelSet
from ..objects.security_profile.common import SecurityProfileGroupModel
from ..utils.parsing import parse_match, parse_rule_type, parse_text
from ..utils.searching import get_object_from_ancestors


@dataclass
class SecurityRuleModel(BaseModel, LocationMixin):
    # xpath = "//*[self::security or self::default-security-rules]/rules/entry"
    xpath = "//security/rules/entry | //default-security-rules/rules/entry"

    # Create XPath classes for the longer / more complex queries
    #  added last 2 values in rulebase_type to handle cases for NGFW.
    rulebase_type = etree.XPath(
        "name(ancestor::pre-rulebase | ancestor::post-rulebase | ancestor::rulebase | ancestor::default-security-rules)"
    )
    server_response_inspect_disabled = etree.XPath(
        "option/disable-server-response-inspection/text()"
    )

    model_set = SecurityRuleModelSet

    # Rule configuration
    rule_enabled: bool
    rule_name: str
    rule_uuid: str
    rule_type: str
    rulebase: str

    # Singular metadata
    action: str
    description: str
    schedule: str
    disable_server_response_inspection_enabled: bool

    # List metadata
    applications: List[str]
    hip_profiles: List[str]
    services: List[str]
    url_categories: List[str]
    tags: List[str]
    targets: List[str]

    # Log configuration
    log_end_enabled: bool
    log_forwarding_profile: str
    log_start_enabled: bool

    # Source configuration
    source_addresses: List[str]
    source_users: List[str]
    source_zones: List[str]

    # Destination configuration
    dest_addresses: List[str]
    dest_zones: List[str]

    # Profile configuration
    profile_antivirus: Optional[str] = None
    profile_anti_spyware: Optional[str] = None
    profile_vulnerability_protection: Optional[str] = None
    profile_url_filtering: Optional[str] = None
    profile_file_blocking: Optional[str] = None
    profile_wildfire_analysis: Optional[str] = None
    profile_data_filtering: Optional[str] = None

    # Profile group configuration
    profile_group: Optional[str] = None

    @property
    def using_ips_profile(self) -> bool:
        """Check whether IPS profile is being used."""
        return any(
            [
                self.profile_antivirus is not None,
                self.profile_anti_spyware is not None,
                self.profile_vulnerability_protection is not None,
            ]
        )

    @property
    def app_filters(self) -> List:
        """Identify filters from applications."""
        filter_ms = self.objects.get("application_filter")
        result = []
        for app in self.applications:
            match = get_object_from_ancestors(
                self.objects, self.location, filter_ms, name=app
            )
            if match:
                result.append(match)
        return result

    @property
    def is_intrazone(self) -> bool:
        if self.rule_type == "intrazone":
            return True
        if self.rule_type == "universal" and self.source_zones == self.dest_zones:
            return True
        return False

    @property
    def is_log_forwarding_enabled(self) -> bool:
        if self.log_forwarding_profile:
            return True
        return False

    def address_configured(self, address_type: str) -> bool:
        """Checks whether source/dest addresses are configured."""
        valid = ["source", "dest"]
        if address_type not in valid:
            raise ValueError(f'address_type must be either {" or ".join(valid)}')
        target = getattr(self, f"{address_type}_addresses")
        return target != ["any"]

    def user_id_configured(self) -> bool:
        return self.source_users != ["any"]

    @classmethod
    def build_index(cls):
        return ["location", "rule_name"]

    @classmethod
    def from_el(cls, el, model_manager):
        attrs = {}

        # Base model
        attrs["model_manager"] = weakref.ref(model_manager)
        rule_location = attrs["location"] = cls._get_location(el, model_manager)

        # Helpful for other attributes
        entry_eval = etree.XPathEvaluator(el)

        attrs["rule_enabled"] = "yes" not in entry_eval("disabled/text()")
        attrs["rule_name"] = el.get("name")
        attrs["rule_uuid"] = el.get("uuid")
        attrs["rule_type"] = parse_rule_type(el, attrs["rule_name"])
        attrs["rulebase"] = cls.rulebase_type(el)

        attrs["action"] = "".join(entry_eval("action/text()"))
        attrs["description"] = "".join(entry_eval("description/text()"))
        attrs["schedule"] = "".join(entry_eval("schedule/text()"))
        attrs[
            "disable_server_response_inspection_enabled"
        ] = "yes" in cls.server_response_inspect_disabled(el)

        attrs["applications"] = entry_eval("application/member/text()") or ["any"]
        attrs["hip_profiles"] = entry_eval("hip-profiles/member/text()") or ["any"]
        attrs["services"] = entry_eval("service/member/text()") or ["any"]
        attrs["url_categories"] = entry_eval("category/member/text()") or ["any"]
        attrs["tags"] = entry_eval("tag/member/text()")

        def create_query(member):
            return "profile-setting/profiles/" + member + "/member"

        # Register attributes for profile groups
        rule_group = attrs["profile_group"] = el.findtext(
            "profile-setting/group/member"
        )
        if rule_group is not None:
            profile_group_ms = model_manager.get("security_profile_group")
            profile_group = get_object_from_ancestors(
                model_manager, rule_location, profile_group_ms, name=rule_group
            )
            if profile_group is not None:
                for profile_key in profile_group.get_profile_keys():
                    attrs["profile_" + profile_key] = getattr(
                        profile_group, profile_key
                    )
        # Register attributes for individual profiles
        else:
            for profile_key in SecurityProfileGroupModel.get_profile_keys():
                attrs["profile_" + profile_key] = el.findtext(
                    create_query(SecurityProfileGroupModel.get_field(profile_key))
                )

        attrs["log_end_enabled"] = parse_match(el, "log-end", "yes", True)
        attrs["log_forwarding_profile"] = parse_text(el, "log-setting", NONE_LOWER)
        attrs["log_start_enabled"] = parse_match(el, "log-start", "yes", False)

        attrs["source_addresses"] = entry_eval("source/member/text()") or ["any"]
        attrs["source_users"] = entry_eval("source-user/member/text()") or ["any"]
        attrs["source_zones"] = entry_eval("from/member/text()") or ["any"]

        attrs["dest_addresses"] = entry_eval("destination/member/text()") or ["any"]
        attrs["dest_zones"] = entry_eval("to/member/text()") or ["any"]

        attrs["targets"] = cls.get_targets(el, model_manager, attrs["location"])

        return cls(**attrs)

    @classmethod
    def get_targets(cls, el, model_manager, location) -> List:
        """Returns a concatenated string of the devices targets.

        Args:
            xml: lxml Element for the security rule entry.

        Retruns:
            A list of target device/vsys combinations.
        """
        if model_manager.tree.ngfw:
            try:
                serial_number = model_manager.system_info["serial"]
            except (TypeError, KeyError):
                serial_number = NONE
            if location == "shared":
                target_devices = [(serial_number, "no-vsys")]
            else:
                target_devices = [(serial_number, location)]

        else:  # Panorama
            target_devices_el = el.find("target/devices")

            if target_devices_el is not None:
                target_devices = cls.create_devices_records(target_devices_el)
            else:
                # Target device are not listed on rule, so use the devices attached to
                # the device group and any of its descendants.
                target_devices = cls.get_device_group_targeted_devices(
                    model_manager, location
                )

            # Check if target negated
            if el.findtext("target/negate", "no") == "yes":
                device_group_targeted_devices = cls.get_device_group_targeted_devices(
                    model_manager, location
                )
                target_devices = [
                    x for x in device_group_targeted_devices if x not in target_devices
                ]

        return [":".join(record) for record in sorted(target_devices)]

    @staticmethod
    def get_device_group_targeted_devices(model_manager, location) -> List[str]:
        """Looks up the devices targeted by a given device group.
        This includes any descendant device groups.
        """
        targeted_devices = [
            model_manager.tree.dgs_with_devices[dg]
            for dg in model_manager.tree.descendants[location]
        ]
        # Return a flattened list
        return list(itertools.chain.from_iterable(targeted_devices))

    @staticmethod
    def create_devices_records(devices: etree._Element) -> List[Tuple[str, str]]:
        """Creates a list of tuples where the first item is
        the device serial number and the second item is a vsys if applicable.

        For instance, this devices element:
            <devices>
              <entry name="007901000280">
                <vsys>
                  <entry name="vsys1" />
                </vsys>
              </entry>
            </devices>

        would return :
        [('007901000280', 'vsys1')]
        """
        device_lst = []
        for entry in devices.findall("entry"):
            serial_number = entry.get("name")
            try:
                vsys = entry.find("vsys/entry").get("name")
            except AttributeError:
                vsys = "no-vsys"
            device_lst.append((serial_number, vsys))

        return device_lst
