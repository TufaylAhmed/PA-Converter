from dataclasses import dataclass
from typing import List, Optional

from ..base_model import BaseModel
from ..default_value import DefaultValue
from ..mixins import LocationMixin
from ..utils.parsing import parse_text


@dataclass
class TunnelInspectionModel(BaseModel, LocationMixin):
    xpath = "//tunnel-inspect/rules/entry"

    name: str
    tunnel_protocols: List[str] = DefaultValue([])
    tunnel_source_zone: Optional[str] = DefaultValue(None)
    tunnel_dest_zone: Optional[str] = DefaultValue(None)

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_tunnel_protocols(el, model_manager):
        results = el.xpath("application/member/text()")
        if len(results) == 0:
            return DefaultValue([])
        return results

    @staticmethod
    def _get_tunnel_source_zone(el, model_manager):
        return parse_text(el, "zone-assign/source/member")

    @staticmethod
    def _get_tunnel_dest_zone(el, model_manager):
        return parse_text(el, "zone-assign/destination/member")

    @property
    def security_options_enabled(self):
        return self.tunnel_source_zone is not None and self.tunnel_dest_zone is not None
