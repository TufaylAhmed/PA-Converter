from typing import List, Optional

from dataclasses import dataclass

from ..base_model import BaseModel
from ..constants import NONE
from ..mixins import LocationMixin
from ..model_sets.decryption_rule import DecryptionRuleModelSet


@dataclass
class DecryptionRuleModel(BaseModel, LocationMixin):
    xpath = "//decryption/rules/entry"

    name: str
    action: str
    rule_type: str
    decryption_profile: str
    categories: List[str]
    rule_enabled: bool
    rulebase: Optional[str] = None

    model_set = DecryptionRuleModelSet

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_action(el, model_manager):
        return el.find("action").text

    @staticmethod
    def _get_rule_type(el, model_manager):
        return el.find("type/").tag

    @staticmethod
    def _get_decryption_profile(el, model_manager):
        return el.findtext("profile", NONE)

    @staticmethod
    def _get_categories(el, model_manager):
        return el.xpath("category/member/text()")

    @staticmethod
    def _get_rule_enabled(el, model_manager):
        return el.findtext("disabled") != "yes"

    @staticmethod
    def _get_rulebase(el, model_manager):
        if model_manager.tree.panorama:
            return el.getparent().getparent().getparent().tag
        return None
