from typing import List, Optional

from dataclasses import dataclass

from ..base_model import BaseModel
from ..mixins import LocationMixin


@dataclass
class CaptivePortalRuleModel(BaseModel, LocationMixin):
    # In PAN-OS 8.0, node tag changes from "captive-portal" to "authentication"
    # xpath = '//*[name()="captive-portal" or name()="authentication"]/rules/entry'
    xpath = "//captive-portal/rules/entry | //authentication/rules/entry"

    name: str
    source_users: List[str]
    source_zones: List[str]
    destination_zones: List[str]
    source_addresses: List[str]
    destination_addresses: List[str]
    services: List[str]
    action: str
    timeout: int
    rulebase: Optional[str] = None
    vsys: Optional[str] = None

    mask_attrs = {
        "source_addresses": ["ipv4", "ipv6"],
        "destination_addresses": ["ipv4", "ipv6"],
        "source_users": ["name"],
    }

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_source_users(el, model_manager):
        source_users = el.xpath("source-user/member/text()")
        if source_users == []:
            source_users = ["any"]
        return source_users

    @staticmethod
    def _get_source_zones(el, model_manager):
        return el.xpath("from/member/text()")

    @staticmethod
    def _get_destination_zones(el, model_manager):
        return el.xpath("to/member/text()")

    @staticmethod
    def _get_source_addresses(el, model_manager):
        return el.xpath("source/member/text()")

    @staticmethod
    def _get_destination_addresses(el, model_manager):
        return el.xpath("destination/member/text()")

    @staticmethod
    def _get_services(el, model_manager):
        return el.xpath("service/member/text()")

    @staticmethod
    def _get_action(el, model_manager):
        return el.xpath(
            '*[name()="action" or name()="authentication-enforcement"]/text()'
        ).pop()

    @staticmethod
    def _get_timeout(el, model_manager):
        return int(el.findtext("timeout", 60))

    @staticmethod
    def _get_vsys(el, model_manager):
        panorama = (
            model_manager.tree.panorama or el.find("mgt-config/devices") is not None
        )
        if panorama:
            if el.xpath("ancestor::shared") is not None:
                return "shared"
            else:
                return el.xpath("ancestor::entry/@name").pop()
        return None

    @staticmethod
    def _get_rulebase(el, model_manager):
        panorama = (
            model_manager.tree.panorama or el.find("mgt-config/devices") is not None
        )
        if panorama:
            return el.getparent().getparent().getparent().tag
        return None
