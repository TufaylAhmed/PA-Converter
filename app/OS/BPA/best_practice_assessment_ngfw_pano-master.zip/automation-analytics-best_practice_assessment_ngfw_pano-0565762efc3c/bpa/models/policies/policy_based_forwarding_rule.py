from dataclasses import dataclass
from typing import Optional

from ..base_model import BaseModel
from ..mixins import LocationMixin
from ..utils.parsing import parse_tag


@dataclass
class PolicyBasedForwardingRuleModel(BaseModel, LocationMixin):
    xpath = "//pbf/rules/entry"

    name: str
    action: str
    monitor_enabled: bool
    rulebase: Optional[str] = None
    monitoring_profile: Optional[str] = None
    ip_address: Optional[str] = None

    mask_attrs = {"ip_address": ["ipv4", "ipv6"]}

    @staticmethod
    def _get_name(el, model_manager):
        return el.get("name")

    @staticmethod
    def _get_action(el, model_manager):
        return parse_tag(el, "action/*", default="no-action")

    @staticmethod
    def _get_monitor_enabled(el, model_manager):
        return el.find("action/forward/monitor") is not None

    @staticmethod
    def _get_rulebase(el, model_manager):
        if model_manager.tree.panorama:
            return next(
                el.iterancestors("rulebase", "pre-rulebase", "post-rulebase")
            ).tag
        return None

    @staticmethod
    def _get_monitoring_profile(el, model_manager):
        profile = el.find("action/forward/monitor/profile")
        return profile.text if profile is not None else None

    @staticmethod
    def _get_ip_address(el, model_manager):
        ip_address = el.find("action/forward/monitor/ip-address")
        return ip_address.text if ip_address is not None else None
