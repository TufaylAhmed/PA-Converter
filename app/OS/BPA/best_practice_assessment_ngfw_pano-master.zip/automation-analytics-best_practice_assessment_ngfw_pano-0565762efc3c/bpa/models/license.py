import datetime
import logging
from typing import Any, Dict, Union, Optional

from dataclasses import dataclass

from bpa.models.mixins import MaskMixin

LOG = logging.getLogger(__name__)


@dataclass
class License(MaskMixin):
    """Represents a license entry.

    Attributes:
        feature: License feature.
        description: License description.
        serial_number: License serial number or None
        issue_date: Date when license was issued or None
        expire_date: Date when license will expire.
    """

    feature: str
    description: str
    serial_number: Optional[str]
    issue_date: Optional[datetime.date]
    expire_date: datetime.date

    mask_attrs = {"serial_number": []}

    @property
    def expired(self) -> bool:
        """Flag for expiration."""
        return datetime.date.today() > self.expire_date

    def to_json(self) -> Dict[str, Dict]:
        """JSON conversion."""
        return {
            self.feature: {
                "Description": self.description,
                "Serial": self.maskv("serial_number", self.serial_number),
                "Issued": self.serialize_date(self.issue_date),
                "Expires": self.serialize_date(self.expire_date),
                "Expired?": self.expired,
            }
        }

    @staticmethod
    def serialize_date(date_: datetime.date) -> str:
        """Helper for serializing dates."""
        if date_ is None:
            return ""
        if date_ == datetime.date.max:
            return "Never"
        return date_.strftime("%B %d, %Y")

    @staticmethod
    def parse_date(date_string: str) -> Optional[datetime.date]:
        """Helper for parsing license entry dates."""
        if date_string is None:
            return None
        if date_string == "Never":
            return datetime.date.max
        return datetime.datetime.strptime(date_string, "%B %d, %Y").date()

    @classmethod
    def from_tsf(cls, attrs: Dict) -> Union["License", None]:
        """Factory for creating instance from entry parsed from CLI file in TSF."""

        # Mandatory Fields
        feature = attrs["Feature"]
        description = attrs["Description"]
        try:
            expire_date = cls.parse_date(attrs["Expires"])
        except ValueError:
            LOG.warning("Received license dates were invalid - abort from_tsf")
            return None

        # Optional Fields
        try:
            serial_number = attrs["Serial"]
        except KeyError:
            LOG.warning("Received license Serial is invalid. Serial is set to None.")
            serial_number = None

        try:
            issue_date = cls.parse_date(attrs["Issued"])
        except (ValueError, KeyError):
            LOG.warning(
                "Received license Issued Date is invalid. Issue Date is set to None."
            )
            issue_date = None

        return cls(feature, description, serial_number, issue_date, expire_date)


class LicenseInfo:
    """Represents a collection of licenses.

    Attributes:
        _licenses: Private mapping of feature to licenses.
    """

    def __init__(self):
        self._licenses = {}

    def add(self, license: License) -> None:
        """Adds a license to the collection."""
        self.validate_license(license)
        self._licenses[license.feature] = license

    def __getitem__(self, feature: str) -> License:
        """Return a single license given a feature name."""
        return self._licenses[feature]

    def __contains__(self, feature: str) -> bool:
        """Determine whether license exists for a given feature."""
        return feature in self._licenses.keys()

    def __len__(self):
        """Returns the size of the _licenses dictionary."""
        return len(self._licenses)

    def to_json(self) -> Dict[str, Dict]:
        """Calls the to_json method on each of the licenses."""
        data = {}
        for license in self._licenses.values():
            data.update(license.to_json())
        return data

    def is_license_found_from_tsf(self, feature: str) -> bool:
        """Helper to check whether license is in found from tsf."""
        return self._licenses.get(feature) is not None

    def has_active_license(self, feature: str) -> bool:
        """Helper to check whether an active license exists."""
        try:
            license = self[feature]
        except KeyError:
            return False
        return not license.expired

    def has_active_gp_license(self) -> bool:
        """Helper to check whether either GlobalProtect Portal or GlobalProtect Gateway is present."""
        return self.has_active_license(
            "GlobalProtect Portal"
        ) or self.has_active_license("GlobalProtect Gateway")

    @staticmethod
    def validate_license(license: Any) -> None:
        """Validate whether license is a valid License instance."""
        if not isinstance(license, License):
            raise ValueError(
                f"Expecting a License type, not {license.__class__.__name__}"
            )

    @classmethod
    def from_json(cls, data: Dict[str, Dict]) -> "LicenseInfo":
        """Deserializes LicenseInfo JSON.

        Restructures the data so it can be used with License.from_tsf method.
        """
        license_info = cls()
        for feature, attrs in data.items():
            attrs["Feature"] = feature
            license = License.from_tsf(attrs)
            if license is not None:
                license_info.add(license)
        return license_info
