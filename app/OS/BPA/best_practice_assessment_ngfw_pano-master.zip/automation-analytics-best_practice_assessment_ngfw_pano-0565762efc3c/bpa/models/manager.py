# -*- coding: utf-8 -*-
import logging
from typing import Dict, Optional, List, Union
from dataclasses import dataclass

import pendulum
from lxml import etree

from bpa.models.rule_usage import RuleUsageInfo
from bpa.publishers.schemas.documentation import Documentation
from bpa.models.industry import IndustryInfo
from .. import models
from ..utils.common import find_classes
from .base_model import BaseModel
from .tsf import TechSupportFile
from .tree import Tree
from .model_set import ModelSet
from .utils.software import is_eol_version

LOG = logging.getLogger(__name__)


@dataclass
class ModelManagerMetadata:
    managed_device_count: Optional[int] = None

    def __post_init__(self):
        # Making sure managed_device_count is int
        if self.managed_device_count is not None:
            self.managed_device_count = int(self.managed_device_count)


class ModelManager:
    """Container class for lazily parsing features from XML config.

    Attributes:
        model_lookup: Model lookup.
        model_set_lookup: Model set lookup.
        tree: ElementTree instance.
        system_info: System information.
        license_info: License information.
    """

    def __init__(self):
        LOG.debug(f"{self.__class__.__name__} initializing")
        self.model_lookup = self.find_models()
        self.model_set_lookup = {}

    def _register_model_set(self, name):
        """Register and get model data dynamically.

        Provides a convenient public API for controller components
        to fetch information from related models. The ModelManager
        can then be seen as a cache that gets computed whenever data
        is needed.

        One implementation detail to note is that TargetClass.parse
        returns a list of the TargetClass objects that match a given
        xpath query. Modifying the xpath of a given TargetClass is the
        best way to filter/expand the results that one may desire.
        """
        try:
            TargetClass = self.model_lookup[name]
            self.model_set_lookup[name] = TargetClass.model_set()
            val = self.model_set_lookup[name] = TargetClass.parse(self)
            return val
        except KeyError:
            raise AttributeError(f"No class found for parsing {name}")

    def register_tsf(self, tsf: TechSupportFile, release_dates: Dict):
        """Register TSF and core metadata."""
        tree = tsf.get_running_config()
        system_info = tsf.get_system_info()
        system_info["Tech Support File Generated Date"] = tsf.tsf_generated_date
        license_info = tsf.get_license_info()
        system_time = tsf.system_time
        rule_usage_info = TechSupportFile.parse_rule_hit_count_db(
            rhc_db_file=tsf.get_rule_hit_count_db()
        )
        self.register_core(
            tree, system_info, license_info, system_time, rule_usage_info, release_dates
        )

    def register_core(
        self,
        tree: etree._ElementTree,
        system_info,
        license_info,
        system_time: pendulum.DateTime,
        rule_usage_info: RuleUsageInfo,
        release_dates: Dict,
    ):
        """Register core metadata."""
        self.tree = Tree(tree)
        self.license_info = license_info
        self.system_info = system_info
        if system_time.tz is None:
            raise ValueError("System time must be timezone-aware")
        self.system_time = system_time
        self.system_tz = system_time.tz
        self.is_eol = is_eol_version(self.tree.version, self.system_time)
        self.rule_usage_info = rule_usage_info
        self.release_dates = release_dates

        # Creating the metadata
        self.metadata = ModelManagerMetadata(
            managed_device_count=self.tree.get_managed_device_count()
        )

        # Setting Industry Info to empty initially as it will be optionally set after core has been set
        self.industry_info = IndustryInfo()

        # Object of documentation. Contain list of documentation class from documentation.py
        self.documentation = []

    def register_documentation_info(
        self, documentation: Union[List[Documentation], List]
    ):
        """This will register the documentation that has been externally fetched (ideally at the Django level)
        and make it available in the library at the model manager level"""

        if len(documentation) < 1:
            LOG.error(
                f"TypeError: Expected type of documentation is List of Documentations but got {type(documentation)}"
            )
            return

        self.documentation = documentation

    def register_industry_info(self, industry_info: IndustryInfo):
        """This will register the industry info that has been externally fetched (ideally at the Django level)
        and make it available in the library at the model manager level"""

        if type(industry_info) != IndustryInfo:
            LOG.error(
                f"TypeError: Expected type of industry_info IndustryInfo but got {type(industry_info)}"
            )
            return

        self.industry_info = industry_info

    def get(self, model_key: str, lazy: bool = True) -> ModelSet:
        """Lazily parse models from XML.

        Arguments:
            model_key: Name of feature.
            lazy: Boolean flag on whether we lazily evaluate lookup data.

        Returns:
            Newly build OR cached instance of ModelSet.
        """
        LOG.debug(f"Retrieving model set from {model_key}")
        model_set = self.model_set_lookup.get(model_key)
        if model_set is None and lazy:
            model_set = self._register_model_set(model_key)
            if model_set is None:
                LOG.debug(f"Could not find model set using {model_key}")
        return model_set

    def find(self, feature, **terms):
        """Find features that match specific terms

        Args:
            feature: name or requested feature.
            terms: search terms.

        Returns:
            A generator object with the feature results.
        """
        return (
            item
            for item in self.get(feature)
            if len(set(terms.items()) - set(item.__dict__.items())) == 0
        )

    @staticmethod
    def find_models() -> Dict:
        return find_classes(models, BaseModel, "build_model_key")

    @classmethod
    def from_tsf(cls, *args, **kwargs):
        """Instantiates XMLConfig from a Tech Support File."""
        tsf = TechSupportFile.read_tsf(*args, **kwargs)
        tree = tsf.get_running_config()
        system_info = tsf.get_system_info()
        system_info["Tech Support File Generated Date"] = tsf.tsf_generated_date
        license_info = tsf.get_license_info()

        # Creating the metadata
        metadata = ModelManagerMetadata(
            managed_device_count=tree.get_managed_device_count()
        )
        return cls(
            tree, system_info=system_info, license_info=license_info, metadata=metadata
        )

    @classmethod
    def from_xml(cls, xml_source, **kwargs):
        """Instantiates XMLConfig from XML.

        Args:
            xml_source: a file name/path, file object, or file-like object.
        """
        tree = etree.parse(xml_source, cls.parser)
        return cls(tree, **kwargs)
