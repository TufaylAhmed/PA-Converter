# -*- coding: utf-8 -*-
import logging
import weakref
from abc import ABCMeta
from typing import List

from dataclasses import dataclass
from lxml import etree

from ..utils.common import common_key

from .model_set import ModelSet
from .mixins import LocationMixin, TemplateMixin, ModelMixin


LOG = logging.getLogger(__name__)


@dataclass
class BaseModel(ModelMixin, metaclass=ABCMeta):
    """Parent object to provide common attributes and methods.

    You cannot initialize BaseModel on its own. This should be used
    as the parent class for all other models. Keep in mind that all
    subclasses also need to have the @dataclass decorator for their
    class definition.

    Attributes:
        model_manager: Weak reference to ModelManager.
    """

    model_manager: weakref.ReferenceType

    model_set = ModelSet

    def __init_subclass__(cls):
        """Enforce xpath attribute in subclasses."""
        if not hasattr(cls, "xpath"):
            raise NotImplementedError(f"{cls.__name__} has no attribute 'xpath'")

    @classmethod
    def build_model_key(cls):
        """Get default model key."""
        return common_key(cls)

    def json(self):
        """Get dictionary that excludes private attributes."""
        return {
            key: val for key, val in self.__dict__.items() if not key.startswith("_")
        }

    @property
    def objects(self):
        """Returns a ModelManager object similar to Django's object model_manager."""
        model_manager = self.model_manager()
        if isinstance(self, TemplateMixin):
            template_stack = model_manager.get("template_stack").find(
                name=self.template_name
            )
            if template_stack is not None:
                return template_stack
        return model_manager

    @classmethod
    def from_el(cls, el: etree._Element, model_manager):
        """Initialize model instance from etree element.

        The default implementation looks at all dataclass fields and
        dynamically runs the static methods related to each of them before
        creating the class instance. Keep in mind that these static methods
        should have `_get_` as a prefix.

        If the BaseModel's from_el routine is overwritten, bear in
        mind that the model_manager will need to created on top
        of local attributes.
        """
        attrs = {"model_manager": weakref.ref(model_manager)}
        fields = set(cls.__dataclass_fields__.keys()) - {"model_manager"}
        for field in fields:
            prefix = "_get_"
            method = getattr(cls, prefix + field)
            attrs[field] = method(el, model_manager=model_manager)
        return cls(**attrs)

    @classmethod
    def parse(cls, model_manager) -> ModelSet:
        """Creates a list of instantiated objects for the target class."""
        model_set = cls.model_set()
        if cls.xpath is not None:
            for el in model_manager.tree.xpatheval(cls.xpath):
                try:
                    model = cls.from_el(el, model_manager)
                    model_set.add(model)
                except Exception as e:
                    LOG.exception(
                        f"Encountered {e.__class__.__name__} while parsing {cls.__name__}"
                    )
        return model_set

    @classmethod
    def build_index(cls) -> List[str]:
        """Build class index.

        Programmatically generates the index lookup to aid clients
        with model set lookups.

        This was implemented as a class method so that you do not
        need a model instance in order to reverse engineer a signature
        for looking up a model from the analyzer side of things.
        """
        if "name" not in cls.__dataclass_fields__:
            raise AttributeError(f"{cls.__name__} has no attribute 'name'")
        index = []
        if issubclass(cls, TemplateMixin):
            index.append("template_name")
        if issubclass(cls, LocationMixin):
            index.append("location")
        index.append("name")
        return index
