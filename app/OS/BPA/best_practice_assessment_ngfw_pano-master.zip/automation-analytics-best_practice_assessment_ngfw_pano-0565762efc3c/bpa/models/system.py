import re
from typing import Dict, List

import pendulum
from dateutil import parser
from pendulum.parsing.exceptions import ParserError

from .constants import TIMEZONES
from .mixins import MaskMixin


class SystemInfo(dict, MaskMixin):
    """System information.

    There are many attributes related to system information,
    but this docstring will list out some that one may need
    to interact with on a need-to-know basis.

    Attributes:
        default-gateway: Default gateway IP.
        ip-address: IP address of device.
        ipv6-link-local-address: IPv6 address for local link.
        mac-address: MAC address.
        netmask: Network masking of IP address.
        serial: Serial number.
        vm-cpuid: VM CPU identifier.
        vm-mac_base: VM MAC base.
        vm-uuid: VM unique identifier.
    """

    mask_attrs = {
        "default-gateway": ["ipv4"],
        "ip-address": ["ipv4"],
        "ipv6-address": ["ipv6"],
        "ipv6-default-gateway": ["ipv6"],
        "ipv6-link-local-address": ["ipv6"],
        "mac-address": [],
        "netmask": ["ipv4"],
        "serial": [],
        "vm-cpuid": [],
        "vm-mac-base": [],
        "vm-uuid": [],
        "ha-peer-serial": [],
    }

    def copy(self):
        old = super().copy()
        new = {}
        for ok, ov in old.items():
            if self.maskable(ok):
                new[ok] = self.maskv(ok, ov)
            else:
                new[ok] = ov
        return new

    def get_content_deltas(self, system_time: pendulum.DateTime) -> Dict[str, int]:
        """Returns the time delta in seconds between the system time and content update releases."""

        def convert(date_string: str) -> pendulum.DateTime:
            # Strip off timezone if present
            # These values are not standard (e.g. PST), so we will use tz from the system time instead
            if re.search(r" [A-Z]{3}$", date_string):
                date_string = date_string[:-4]
            try:
                return pendulum.parse(release_date).set(tz=system_time.tz)
            except ParserError:
                return pendulum.instance(parser.parse(release_date, tzinfos=TIMEZONES))

        deltas = {}
        for target in ["app-release-date", "av-release-date", "wildfire-release-date"]:
            release_date = self.get(target)
            if release_date is not None and release_date != "unknown":
                # Enforce that the release date timezone matches that of the system time
                release_date = convert(release_date)
                deltas[target] = system_time.diff(release_date).in_seconds()
        return deltas

    @property
    def all_serial_numbers(self) -> List[str]:
        """Returns a list of serial numbers of the current device and its peers"""

        all_serials = [self.get(key) for key in {"serial", "ha-peer-serial"}]

        # Removing None or empty values
        valid_serials = list(filter(lambda x: x not in [None, ""], all_serials))
        return valid_serials
