# -*- coding: utf-8 -*-
from lxml import etree
from typing import List
from dataclasses import dataclass

from ..base_model import BaseModel
from ..sub_model import SubModel
from ..constants import NONE
from ..mixins import LocationMixin, TemplateMixin
from ..utils.parsing import parse_exists


@dataclass
class AuthClient(SubModel):
    """GP Gateway / Portal > Authentication Client configuration."""

    name: str
    auth_profile: str

    @classmethod
    def parse_entry(cls, el: etree._Element, model_manager, feature_type):
        """Return a list of AuthClient objects"""
        # XPATH is different for GP Portal and GP Gateway
        if feature_type == "portal":
            xpath = "portal-config/client-auth/entry"
        else:
            xpath = "client-auth/entry"
        return [
            cls(name=e.get("name"), auth_profile=e.findtext("authentication-profile"))
            for e in el.findall(xpath)
        ]


@dataclass
class GlobalProtectPortalAgentConfig(SubModel):
    name: str
    save_user_credentials: str
    two_factor_authentication: List[str]
    internal_host_detection_enabled: bool
    continue_with_invalid_portal_server_cert: bool
    enforce_gp_connection_for_network_access: bool
    collect_hip_data_enabled: bool
    external_gateway_ips: List[str]
    disable_timeout: int

    @classmethod
    def parse_entry(cls, el: etree._Element, model_manager):
        save_user_credentials_dict = {
            "0": "No",
            "1": "Yes",
            "2": "Save Username Only",
            "3": "Only with User Fingerprint",
        }
        name = el.get("name")
        save_user_credentials = save_user_credentials_dict[
            el.findtext("save-user-credentials", "0")
        ]
        two_factor_authentication = [
            two_factor.tag
            for two_factor in el.getchildren()
            if two_factor.tag.endswith("-2fa") and two_factor.text != "no"
        ]
        internal_host_detection_enabled = el.find("internal-host-detection") is not None

        continue_with_invalid_portal_server_cert = bool(
            el.xpath(
                'gp-app-config/config/entry[@name="can-continue-if-portal-cert-invalid"]'
                '/value/member[text()="yes"]'
            )
        )

        enforce_gp_connection_for_network_access = bool(
            el.xpath(
                'gp-app-config/config/entry[@name="enforce-globalprotect"]'
                '/value/member[text()="yes"]'
            )
        )

        collect_hip_data_enabled = parse_exists(
            el, "hip-collection/collect-hip-data/text()"
        )

        if model_manager.tree.version < 8.0:
            external_gateway_ips = el.xpath("gateways/external/list/entry/@name")
        else:
            external_gateway_ips = el.xpath(
                "gateways/external/list/entry/ip/*[self::ipv4 or self::ipv6]/text()"
            )

        disable_timeout = int(el.findtext("agent-ui/agent-user-override-timeout", 0))

        return cls(
            name,
            save_user_credentials,
            two_factor_authentication,
            internal_host_detection_enabled,
            continue_with_invalid_portal_server_cert,
            enforce_gp_connection_for_network_access,
            collect_hip_data_enabled,
            external_gateway_ips,
            disable_timeout,
        )


@dataclass
class GlobalProtectPortalModel(BaseModel, LocationMixin, TemplateMixin):
    xpath = "//global-protect/global-protect-portal/entry"

    name: str
    satellite_trusted_root_ca: List[str]
    agent_trusted_root_ca: List[str]
    ssl_tls_service_profile: str
    certificate_profile: str
    satellites_configured: bool
    satellite_ocsp_responder: str
    auth_clients: List[AuthClient]
    agent_configs: List[GlobalProtectPortalAgentConfig]

    @staticmethod
    def _get_name(el: etree._Element, model_manager):
        return el.get("name")

    @staticmethod
    def _get_satellite_trusted_root_ca(el: etree._Element, model_manager):
        return el.xpath("satellite-config/root-ca/member/text()")

    @staticmethod
    def _get_agent_trusted_root_ca(el: etree._Element, model_manager):
        return el.xpath("client-config/root-ca/entry/@name")

    @staticmethod
    def _get_ssl_tls_service_profile(el: etree._Element, model_manager):
        service_profile = el.findtext("portal-config/ssl-tls-service-profile", NONE)
        if service_profile == "-":
            service_profile = NONE
        return service_profile

    @staticmethod
    def _get_certificate_profile(el: etree._Element, model_manager):
        return el.findtext("portal-config/certificate-profile", NONE)

    @staticmethod
    def _get_satellites_configured(el: etree._Element, model_manager):
        return el.find("satellite-config/configs/entry") is not None

    @staticmethod
    def _get_satellite_ocsp_responder(el: etree._Element, model_manager):
        return el.findtext(
            "satellite-config/client-certificate/local/ocsp-responder", NONE
        )

    @staticmethod
    def _get_auth_clients(el: etree._Element, model_manager):
        return AuthClient.parse_entry(el, model_manager, "portal")

    @staticmethod
    def _get_agent_configs(el: etree._Element, model_manager):
        agent_configs_lst = []
        for agent_config in el.findall("client-config/configs/entry"):
            agent_configs_lst.append(
                GlobalProtectPortalAgentConfig.parse_entry(agent_config, model_manager)
            )
        return agent_configs_lst


@dataclass
class GlobalProtectGatewayAgentConfig(SubModel):
    name: str
    access_routes: List[str]
    no_direct_access_to_local_network: bool

    @classmethod
    def parse_entry(cls, el: etree._Element, model_manager):
        name = el.get("name")
        access_routes = el.xpath("split-tunneling/access-route/member/text()")
        no_direct_access_to_local_network = (
            el.findtext("no-direct-access-to-local-network", "no") == "yes"
        )
        return cls(name, access_routes, no_direct_access_to_local_network)


@dataclass
class GlobalProtectGatewayModel(BaseModel, LocationMixin, TemplateMixin):
    xpath = "//global-protect/global-protect-gateway/entry"

    name: str
    tunnel_mode_enabled: bool
    certificate_profile: str
    ssl_tls_service_profile: str
    auth_clients: List[AuthClient]
    agent_configs: List[GlobalProtectGatewayAgentConfig]

    @staticmethod
    def _get_name(el: etree._Element, model_manager):
        return el.get("name")

    @staticmethod
    def _get_tunnel_mode_enabled(el: etree._Element, model_manager):
        return el.findtext("tunnel-mode", "no") == "yes"

    @staticmethod
    def _get_certificate_profile(el: etree._Element, model_manager):
        return el.findtext("certificate-profile", NONE)

    @staticmethod
    def _get_ssl_tls_service_profile(el: etree._Element, model_manager):
        profile_name = el.findtext("ssl-tls-service-profile", NONE)
        if profile_name == "-":
            profile_name = NONE
        return profile_name

    @staticmethod
    def _get_agent_configs(el: etree._Element, model_manager):
        agent_configs_lst = []
        for agent_config_entry in el.findall("remote-user-tunnel-configs/entry"):
            agent_configs_lst.append(
                GlobalProtectGatewayAgentConfig.parse_entry(
                    agent_config_entry, model_manager
                )
            )
        return agent_configs_lst

    @staticmethod
    def _get_auth_clients(el: etree._Element, model_manager):
        return AuthClient.parse_entry(el, model_manager, "gateway")


@dataclass
class GlobalProtectSiteToSiteTunnelSettingsModel(BaseModel, TemplateMixin):
    xpath = "//config/devices/entry/network/tunnel/global-protect-site-to-site/entry"

    name: str
    tunnel_monitoring_enabled: bool
    replay_attack_detection_enabled: bool
    ipsec_crypto_profile: str

    @staticmethod
    def _get_name(el: etree._Element, model_manager):
        return el.get("name")

    @staticmethod
    def _get_tunnel_monitoring_enabled(el: etree._Element, model_manager):
        return "no" not in el.xpath("client/tunnel-monitor/enable/text()")

    @staticmethod
    def _get_replay_attack_detection_enabled(el: etree._Element, model_manager):
        return "no" not in el.xpath("client/anti-replay/text()")

    @staticmethod
    def _get_ipsec_crypto_profile(el: etree._Element, model_manager):
        return el.findtext("client/ipsec-crypto-profile")
