# -*- coding: utf-8 -*-
# https://jira-hq.paloaltonetworks.local/browse/CST-36
from lxml import etree
from typing import List
from dataclasses import dataclass

from ..base_model import BaseModel
from ..constants import NONE
from ..mixins import TemplateMixin


@dataclass
class IpSecCryptoProfileModel(BaseModel, TemplateMixin):
    xpath = (
        "//config/devices/entry/network/ike/crypto-profiles/ipsec-crypto-profiles/entry"
    )

    name: str
    protocol: str
    encryption_algorithms: List[str]
    authentication_algorithms: List[str]

    @staticmethod
    def _get_name(el: etree._Element, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_protocol(el: etree._Element, model_manager) -> str:
        try:
            return el.xpath("esp|ah")[0].tag
        except BaseException:
            return NONE

    @staticmethod
    def _get_encryption_algorithms(el: etree._Element, model_manager) -> List[str]:
        return el.xpath(
            '%s/encryption/member[text() != "null"]/text()'
            % IpSecCryptoProfileModel._get_protocol(el, model_manager)
        )

    @staticmethod
    def _get_authentication_algorithms(el: etree._Element, model_manager) -> List[str]:
        return el.xpath(
            '%s/authentication/member[text() != "none"]/text()'
            % IpSecCryptoProfileModel._get_protocol(el, model_manager)
        )
