# -*- coding: utf-8 -*-
from lxml import etree
from typing import Optional, Union
from dataclasses import dataclass

from ..base_model import BaseModel
from ..mixins import TemplateMixin, LocationMixin
from bpa.models.default_value import DefaultValue
from bpa.models.utils.parsing import parse_match


@dataclass
class ZoneModel(BaseModel, TemplateMixin, LocationMixin):
    xpath = "//vsys/entry/zone/entry[not(ancestor::readonly)]"

    name: str
    user_id_enabled: Union[bool, DefaultValue]
    using_acl_include_list: Union[bool, DefaultValue]
    zone_protection_profile: Optional[str]
    packet_buffer_protection_enabled: Union[bool, DefaultValue, None]

    @staticmethod
    def _get_name(el: etree._Element, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_user_id_enabled(
        el: etree._Element, model_manager
    ) -> Union[bool, DefaultValue]:
        return parse_match(el, "enable-user-identification", "yes", False)

    @staticmethod
    def _get_using_acl_include_list(
        el: etree._Element, model_manager
    ) -> Union[bool, DefaultValue]:
        return DefaultValue(False) if el.find("user-acl/include-list") is None else True

    @staticmethod
    def _get_zone_protection_profile(
        el: etree._Element, model_manager
    ) -> Optional[str]:
        return el.findtext("network/zone-protection-profile")

    @staticmethod
    def _get_packet_buffer_protection_enabled(
        el: etree._Element, model_manager
    ) -> Union[bool, DefaultValue, None]:
        if model_manager.tree.version >= 8:
            return parse_match(
                el, "network/enable-packet-buffer-protection", "yes", False
            )
