# -*- coding: utf-8 -*-
from typing import List

from lxml import etree
from dataclasses import dataclass

from ..base_model import BaseModel
from ..sub_model import SubModel
from ..mixins import TemplateMixin


@dataclass
class TcpDrop(SubModel):
    mismatched_overlapping_tcp_segment: bool
    tcp_syn_with_data: bool
    tcp_synack_with_data: bool
    strip_tcp_timestamp: bool

    @classmethod
    def parse_entry(cls, el: etree._Element):
        mismatched_overlapping_tcp_segment = (
            el.findtext("discard-overlapping-tcp-segment-mismatch", "no") == "yes"
        )
        tcp_syn_with_data = el.findtext("discard-tcp-syn-with-data", "yes") == "yes"
        tcp_synack_with_data = (
            el.findtext("discard-tcp-synack-with-data", "yes") == "yes"
        )
        strip_tcp_timestamp = el.findtext("remove-tcp-timestamp", "no") == "yes"
        return cls(
            mismatched_overlapping_tcp_segment,
            tcp_syn_with_data,
            tcp_synack_with_data,
            strip_tcp_timestamp,
        )


@dataclass
class PacketBasedAttackProtection(SubModel):
    """Packet Based Attack Protection settings within a Zone Protection Profile."""

    ip_option_drop_malformed: bool
    tcp_drop: TcpDrop

    @classmethod
    def parse_entry(cls, el: etree._Element):
        ip_option_drop_malformed = (
            el.findtext("discard-malformed-option", "no") == "yes"
        )
        tcp_drop = TcpDrop.parse_entry(el)
        return cls(ip_option_drop_malformed, tcp_drop)


@dataclass
class FloodProtectionFeature(SubModel):
    enabled: bool
    alert: int
    activate: int
    maximum: int


@dataclass
class FloodProtection(SubModel):
    tcp_syn: FloodProtectionFeature
    icmp: FloodProtectionFeature
    icmp_v6: FloodProtectionFeature
    other_ip: FloodProtectionFeature
    udp: FloodProtectionFeature

    defaults = {"alarm-rate": 10000, "activate-rate": 10000, "maximal-rate": 40000}

    @classmethod
    def parse_entry(cls, el: etree._Element):
        feature_lst = []
        for feature in ("tcp-syn", "icmp", "icmpv6", "other-ip", "udp"):
            feature_settings = []
            feature_settings.append(
                el.findtext("flood/%s/enable" % feature, "no")
                == "yes"  # enable setting
            )
            for setting, default in cls.defaults.items():
                try:
                    val = int(el.xpath("flood/%s/*/%s/text()" % (feature, setting))[0])
                except BaseException:
                    val = default
                finally:
                    feature_settings.append(val)
            feature_lst.append(FloodProtectionFeature(*feature_settings))

        return cls(*feature_lst)


@dataclass
class ReconnaissanceProtection(SubModel):
    tcp_port_scan_enabled: bool
    host_sweep_enabled: bool
    udp_port_scan_enabled: bool
    source_ipv4_exclusions: List[str]
    source_ipv6_exclusions: List[str]

    ports = {"tcp": "8001", "host": "8002", "udp": "8003"}

    @classmethod
    def get_flag_ports(cls):
        result = {}
        for field in cls.__dataclass_fields__:
            field_short = field.split("_")[0]
            if field_short in cls.ports:
                result[field] = cls.ports[field_short]
        return result

    @property
    def flags(self):
        return {attr: getattr(self, attr) for attr in self.get_flag_ports().keys()}


@dataclass
class ZoneProtectionProfileModel(BaseModel, TemplateMixin):
    xpath = "//network/profiles/zone-protection-profile/entry"

    name: str
    packet_based_attack_protection: PacketBasedAttackProtection
    flood_protection: FloodProtection
    reconnaissance_protection: ReconnaissanceProtection

    @staticmethod
    def _get_name(el: etree._Element, model_manager):
        return el.get("name")

    @staticmethod
    def _get_packet_based_attack_protection(el: etree._Element, model_manager):
        return PacketBasedAttackProtection.parse_entry(el)

    @staticmethod
    def _get_flood_protection(el: etree._Element, model_manager):
        return FloodProtection.parse_entry(el)

    @staticmethod
    def _get_reconnaissance_protection(el: etree._Element, model_manager):
        attrs = {}

        flag_ports = ReconnaissanceProtection.get_flag_ports()
        for flag, port in flag_ports.items():
            attrs[flag] = el.find(f'scan/entry[@name="{port}"]') is not None

        attrs["source_ipv4_exclusions"] = el.xpath("scan-white-list/entry/ipv4/text()")
        attrs["source_ipv6_exclusions"] = el.xpath("scan-white-list/entry/ipv6/text()")
        return ReconnaissanceProtection(**attrs)
