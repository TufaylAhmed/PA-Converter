# -*- coding: utf-8 -*-
from lxml import etree
from typing import Optional
from dataclasses import dataclass

from ..base_model import BaseModel
from ..default_value import DefaultValue
from ..mixins import TemplateMixin
from ..utils.parsing import parse_text, parse_match, parse_int


@dataclass
class GreTunnelModel(BaseModel, TemplateMixin):
    """NOTE: GRE Tunnels were added in PAN-OS 9.0"""

    xpath = "//network/tunnel/gre/entry"

    name: str
    source_interface: Optional[str] = DefaultValue(None)
    peer_ip: Optional[str] = DefaultValue(None)
    tunnel_interface: Optional[str] = DefaultValue(None)
    keep_alive_interval: Optional[int] = DefaultValue(None)
    keep_alive_retry: Optional[int] = DefaultValue(None)
    keep_alive_hold_timer: Optional[int] = DefaultValue(None)
    keep_alive_enable: bool = DefaultValue(False)

    mask_attrs = {"peer_ip": ["ipv4", "ipv6"]}

    @staticmethod
    def _get_name(el: etree._Element, model_manager):
        return el.get("name")

    @staticmethod
    def _get_source_interface(el: etree._Element, model_manager):
        return parse_text(el, "local-address/interface")

    @staticmethod
    def _get_peer_ip(el: etree._Element, model_manager):
        return parse_text(el, "peer-address/ip")

    @staticmethod
    def _get_tunnel_interface(el: etree._Element, model_manager):
        return parse_text(el, "tunnel-interface")

    @staticmethod
    def _get_keep_alive_interval(el: etree._Element, model_manager):
        return parse_int(el, "keep-alive/interval", 10)

    @staticmethod
    def _get_keep_alive_retry(el: etree._Element, model_manager):
        return parse_int(el, "keep-alive/retry", 3)

    @staticmethod
    def _get_keep_alive_hold_timer(el: etree._Element, model_manager):
        return parse_int(el, "keep-alive/hold-timer", 5)

    @staticmethod
    def _get_keep_alive_enable(el: etree._Element, model_manager):
        return parse_match(el, "keep-alive/enable", "yes", False)
