from lxml import etree
from typing import Set
from dataclasses import dataclass

from ..base_model import BaseModel
from ..mixins import TemplateMixin


@dataclass
class InterfaceManagementProfileModel(BaseModel, TemplateMixin):
    xpath = "//network/profiles/interface-management-profile/entry"

    name: str
    protocols: Set[str]

    @staticmethod
    def _get_name(el: etree._Element, model_manager):
        return el.get("name")

    @staticmethod
    def _get_protocols(el: etree._Element, model_manager):
        return {p.tag for p in el.xpath("*") if p.text == "yes"}
