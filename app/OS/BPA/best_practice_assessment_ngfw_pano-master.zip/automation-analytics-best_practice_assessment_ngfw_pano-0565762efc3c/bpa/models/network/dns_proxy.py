# -*- coding: utf-8 -*-
from lxml import etree
from typing import List
from dataclasses import dataclass

from ..base_model import BaseModel
from ..sub_model import SubModel
from ..mixins import TemplateMixin
from ..utils.parsing import parse_exists


@dataclass
class DnsProxyRule(SubModel):
    name: str
    cacheable: bool

    @classmethod
    def parse_entry(cls, el: etree._Element):
        name = el.get("name")
        cacheable = parse_exists(el, "cacheable/text()")
        return cls(name, cacheable)


@dataclass
class DnsProxyModel(BaseModel, TemplateMixin):
    xpath = "//dns-proxy/entry"

    name: str
    enabled: bool
    cache: bool
    interfaces: bool
    rules: List[DnsProxyRule]

    @staticmethod
    def _get_name(el: etree._Element, model_manager) -> str:
        return el.get("name")

    @staticmethod
    def _get_enabled(el: etree._Element, model_manager) -> bool:
        enabled = el.find("enabled")
        if enabled is None or enabled.text == "yes":
            return True
        else:
            return False

    @staticmethod
    def _get_cache(el: etree._Element, model_manager) -> bool:
        return parse_exists(el, "cache/enabled/text()")

    @staticmethod
    def _get_interfaces(el: etree._Element, model_manager) -> bool:
        return el.find("interface") is not None

    @staticmethod
    def _get_rules(el: etree._Element, model_manager):
        return [
            DnsProxyRule.parse_entry(rule)
            for rule in el.findall("domain-servers/entry")
        ]
