import logging
from typing import Any, List, Set, Union, Dict
from copy import deepcopy

from bpa.models.constants import NONE, NONE_LOWER
from bpa.models.default_value import DefaultValue
from bpa.models.mixins import ModelMixin

LOG = logging.getLogger(__name__)


def _can_combine(val) -> bool:
    if hasattr(val, "name"):
        return True
    elif isinstance(val, dict):
        return "name" in val
    else:
        LOG.debug(f"No logic for handling val of type {type(val)}")
        return False


def _get(val):
    if hasattr(val, "name"):
        return val.name
    elif isinstance(val, dict):
        return val["name"]
    else:
        raise ValueError(f"No logic for handling val of type {type(val)}")


def get_composite_list(l1: List, l2: List) -> List:
    """Get composite list.

    Args:
        l1: List instance with higher priority.
        l2: List instance with lower priority.
    """
    lsum = l1 + l2
    if lsum and all(_can_combine(val) for val in lsum):
        result = {}
        for val in lsum:
            key = _get(val)
            if key not in result:
                result[key] = val
        return list(result.values())
    else:
        return l2


def get_composite_set(s1: Set, s2: Set) -> Set:
    return s1.union(s2)


def value_unset(val: Any) -> bool:
    """Check whether value is unset.

    Args:
        val: Any type of Python object.

    Returns:
        True or False.
    """
    return (
        val is None
        or val == NONE
        or val == NONE_LOWER
        or isinstance(val, DefaultValue)
        or (type(val) is str and val.startswith("$"))
    )


def get_composite_dict(v1: Dict, v2: Dict) -> Dict:
    """

    Args:
        v1: dictionary with high priority
        v2: dictionary with low priority

    Returns:
        dictionary after merging data
    """
    if v1 is None:
        return v2
    if v2 is None:
        return v1
    result = {**v1}
    for k, v in v2.items():
        if k not in result:
            result[k] = v2[k]
        elif isinstance(v, dict):
            result[k] = get_composite_dict(result[k], v)
        elif isinstance(v, list):
            result[k] = get_composite_list(result[k], v)
        # I put this condition because on one scenario, when customers have clicked on sync_to_peer from template_stack it was not overwriting
        # data of that particular property in DynamicUpdatesModel.
        elif isinstance(v, ModelMixin):
            result[k] = get_composite_dataclass(result[k], v)
        elif (isinstance(v, DefaultValue) and v.value is None) or (not result[k]):
            result[k] = v
    return result


def get_composite_dataclass(d1: ModelMixin, d2: ModelMixin) -> Union[ModelMixin, None]:
    """Get composite model.

    NOTE: We pop template_vars outside of the __dict__ during
    template stack resolution phase so as to by-pass the default
    validation that the dataclass does against dataclass_fields
    while its prebuilt constructor is running.

    NOTE: We only store breadcrumbs for template variables, NOT
    template stack variables as they are not useful when we
    resolve template/stack variables.

    Args:
        d1: ModelMixin instance with higher priority.
        d2: ModelMixin instance with lower priority.

    Returns:
        Compiled ModelMixin or NoneType if d1 and d2 are empty.
    """
    if d1 is None:
        # TODO will keep track if deepcopy needed here.
        return deepcopy(d2)
    elif d2 is None:
        return deepcopy(d1)
    # NOTE: Avoid modifying existing state
    d1_copy = deepcopy(d1.__dict__)
    d2_copy = deepcopy(d2.__dict__)

    d1_meta = d1_copy.pop("template_vars")
    d2_meta = d2_copy.pop("template_vars")

    params = d2_copy

    for f1, v1 in d1_copy.items():
        if value_unset(v1):
            continue

        if f1 not in params:
            params[f1] = v1
            continue

        v2 = params[f1]
        if value_unset(v2):
            params[f1] = v1
            continue

        if type(v2) is list:
            params[f1] = get_composite_list(v1, v2)
        elif type(v2) is set:
            params[f1] = get_composite_set(v1, v2)
        elif hasattr(v1, "__dataclass_fields__"):
            params[f1] = get_composite_dataclass(v1, v2)
        elif (type(v1) is dict) and (type(v2) is dict):
            params[f1] = get_composite_dict(v1, v2)
        else:
            params[f1] = v1

    # NOTE: Implicitly invokes another __post_init__
    new_model = type(d1)(**params)

    # NOTE: No need to store the template stack vars
    final_meta = {"fields": {}, "vars": {}}
    final_meta["fields"] = {**d2_meta["fields"], **d1_meta["fields"]}
    final_meta["vars"] = {**d2_meta["vars"], **d1_meta["vars"]}
    new_model.template_vars = final_meta

    return new_model


def combine_models(models: List) -> Union[ModelMixin, None]:
    """Combine models into a single model.

    NOTE: Assume that models argument is non-empty.

    Args:
        models: Collection of BaseModel instances sorted by
        priority from highest to lowest.

    Returns:
        Single BaseModel instance.

    Raises:
        IndexError if models list is empty.
    """
    if len(models) == 0:
        return None
    if len(models) == 1:
        return deepcopy(models[0])
    middle = len(models) // 2
    hi_model = combine_models(models[:middle])
    lo_model = combine_models(models[middle:])
    return get_composite_dataclass(hi_model, lo_model)
