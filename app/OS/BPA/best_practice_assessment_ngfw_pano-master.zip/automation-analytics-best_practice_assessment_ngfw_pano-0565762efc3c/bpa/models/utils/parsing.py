from typing import Any, List, Dict, Union

from dataclasses import dataclass

from bpa.models.default_value import DefaultValue


def _resolve_default(default: Any) -> Union[DefaultValue, None]:
    if default is None:
        return None
    return DefaultValue(default)


def _resolve_xpath(xpath: str) -> str:
    text = "/text()"
    if not xpath.endswith(text):
        return xpath + text
    return xpath


def parse_match(
    el, xpath: str, truthy: str = "yes", default: Any = None
) -> Union[bool, DefaultValue, None]:
    """Parse exact match against truthy value."""
    text = el.findtext(xpath)
    if text is None:
        return _resolve_default(default)
    return text == truthy


def parse_not_match(
    el, xpath: str, truthy: str = "yes", default: Any = None
) -> Union[bool, DefaultValue, None]:
    """Parse non-exact match against truthy value."""
    text = el.findtext(xpath)
    if text is None:
        return _resolve_default(default)
    return text != truthy


def parse_exists(
    el, xpath: str, truthy: str = "yes", default: Any = False
) -> Union[bool, DefaultValue, None]:
    """Parse existence of truthy value."""
    result = el.xpath(_resolve_xpath(xpath))
    if len(result) == 0:
        return _resolve_default(default)
    return truthy in result


def parse_int(el, xpath: str, default: Any = None) -> Union[int, DefaultValue, None]:
    """Parse integer value."""
    text = el.findtext(xpath)
    if text is None:
        return _resolve_default(default)
    return int(text)


def parse_list(el, xpath: str, default: Any = None) -> Union[List, DefaultValue, None]:
    """Parse list values."""
    result = el.xpath(xpath)
    if len(result) == 0:
        return _resolve_default(default)
    return result


def parse_text(el, xpath: str, default: Any = None) -> Union[str, DefaultValue, None]:
    """Parse text content."""
    text = el.findtext(xpath)
    if text is None:
        return _resolve_default(default)
    return text


def parse_tag(
    el, xpath: str, override: str = "", default: Any = None
) -> Union[str, DefaultValue, None]:
    """Parse tag name."""
    node = el.find(xpath)
    if node is None or node.tag == override:
        return _resolve_default(default)
    return node.tag


def parse_rule_type(el, rule_name: str) -> str:
    """Parse rule type."""
    if rule_name == "intrazone-default":
        return "intrazone"
    elif rule_name == "interzone-default":
        return "interzone"
    else:
        return el.findtext("rule-type", "universal")


@dataclass
class ParseVariableMixin:
    """Parsing logic for template variables.

    NOTE: Applies to TemplateModel and TemplateStackModel.
    Instead of modifying the code twice in each model, it
    would be better to keep the same code in one spot.
    """

    variables: Dict[str, str]

    @staticmethod
    def _get_variables(el, model_manager) -> Dict[str, str]:
        matches = el.xpath("variable/entry")
        result = {}
        for match in matches:
            key = match.get("name")
            val = match.findtext("type/*")
            if val == "None":
                val = None
            result[key] = val
        return result
