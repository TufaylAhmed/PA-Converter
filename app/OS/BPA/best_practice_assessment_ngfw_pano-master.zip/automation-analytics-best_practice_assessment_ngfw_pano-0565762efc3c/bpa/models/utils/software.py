import logging
from typing import Dict, Optional, Tuple
from datetime import date

import pendulum


LOG = logging.getLogger(__name__)


EOL = {
    "1.3": "11/20/2008",
    "2.0": "05/20/2009",
    "2.1": "01/5/2012",
    "3.0": "12/17/2010",
    "3.1": "06/30/2013",
    "4.0": "12/31/2014",
    "4.1": "04/30/2015",
    "5.0": "11/13/2016",
    "5.1": "05/9/2017",
    "6.0": "03/19/2017",
    "6.1": "10/25/2018",
    "7.0": "12/4/2017",
    "7.1": "03/29/2020",
    "8.0": "10/31/2019",
    "8.1": "03/1/2022",
    "9.0": "02/6/2021",
    "9.1": "12/13/2023",
}


def is_eol_version(version: float, system_time: pendulum.DateTime) -> Tuple[bool, str]:
    """Helper to determine whether the current PAN-OS version has reached End-of-Life"""
    try:
        eol_str = EOL[str(version)]
    except KeyError:
        LOG.error(f"Unknown version: {version}")
        return False, "Unknown"
    eol_date = pendulum.parse(eol_str, strict=False)
    return ((system_time > eol_date), eol_str)


def get_release_date_info(
    version: str, release_dates: Dict
) -> Optional[Tuple[date, int]]:
    today = date.today()
    try:
        release_date = release_dates[version]
    except KeyError:
        LOG.error(f"Unknown release date for version {version}")
        return
    days_since_release = (today - release_date).days
    return (release_date, days_since_release)
