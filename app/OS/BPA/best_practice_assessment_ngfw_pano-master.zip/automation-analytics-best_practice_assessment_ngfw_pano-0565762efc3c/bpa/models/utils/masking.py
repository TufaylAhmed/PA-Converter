import re
import math
from functools import wraps
from typing import Any, Callable

import lxml

from bpa.models.constants import MASK, NONE, NONE_LOWER


def mask_single_multi(f: Callable) -> Callable:
    @wraps(f)
    def wrapper(entry: Any) -> Any:
        if entry is None or entry == NONE or entry == NONE_LOWER:
            return None
        elif type(entry) is str:
            return f(entry)
        elif isinstance(entry, lxml.etree._ElementUnicodeResult):
            return f(str(entry))
        elif type(entry) is list:
            return [f(i) for i in entry]
        elif type(entry) is set:
            return {f(i) for i in entry}
        elif type(entry) is dict:
            return {k: f(v) for k, v in entry.items()}
        else:
            raise ValueError(f"Expected str/Iterable[str], got: {type(entry)}")

    return wrapper


def mask_unknown(f: Callable) -> Callable:
    @wraps(f)
    def wrapper(entry: str) -> str:
        if entry.lower() == "unknown" or entry.lower() == "any":
            return entry
        else:
            return f(entry)

    return wrapper


@mask_single_multi
@mask_unknown
def mask_ipv4(content: str) -> str:
    """Mask IPv4 addresses.

    Masks the first and last octets and leaves the rest of the
    IPv4 address intact.

    Args:
        content: Any valid IPv4 address.

    Returns:
        Masked IPv4 address.

    Raises:
        AttributeError if invalid string content gets passed in.
    """
    p = re.compile(r"(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})")
    m = p.match(content)
    return ".".join([MASK, m.group(2), m.group(3), MASK])


@mask_single_multi
@mask_unknown
def mask_general(content: str) -> str:
    """Mask general string content.

    Starts with masking 40% of the characters, and increases
    the masking portion in a step-wise fashion as the content
    gets bigger in size.

    Args:
        content: Any string content.

    Returns:
        Masked string content.
    """
    clen = len(content)
    if clen < 3:
        return content
    base_pct = 40 + (math.floor(clen) // 10 * 5)
    base_offset = clen * base_pct // 100
    return MASK + content[base_offset:]


def is_masked(content: str) -> bool:
    """
    This will check if the given content is already masked

    Args:
        content: Any string content to be tested

    Returns:
        True if content is masked else False

    Raises:
        AttributeError: If content is not a string
    """
    return content.startswith(MASK)
