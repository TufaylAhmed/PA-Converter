from typing import Optional, Tuple

from lxml import etree


def find_ancestor_value(
    el: etree._Element, target_tags, value_tags=frozenset()
) -> Optional[str]:
    """Iterates through element ancestors to find a specific value.

    Args:
        el: lxml Element.
        target_tags: list of parent tags for returning the name of the PRIOR element.
        value_tags: list of parent tags for returning the tag of the CURRENT element.

    Returns:
        String of desired ancestor value or None
    """
    previous = el
    for parent in etree.AncestorsIterator(el):
        if parent.tag in target_tags:
            return previous.get("name")
        elif parent.tag in value_tags:
            return parent.tag
        else:
            previous = parent


def build_signature_with_model(model) -> Tuple:
    """Build signature from model instance.

    Returns:
        Tuple of full signature.

    Args:
        model: BaseModel instance.
    """
    index = model.build_index()
    return build_signature_with_kwargs(
        model.__class__, **{k: getattr(model, k) for k in index}
    )


def build_partial_signature_with_model(model, excludes) -> Tuple:
    """Build partial signature from model instance.

    Args:
        model: BaseModel instance.
        excludes: Set of index fields to exclude.

    Returns:
        Tuple of partial signature.
    """
    index = []
    for field in model.build_index():
        if field not in excludes:
            index.append(field)
    data = model.to_dict()
    return tuple(data[attr] for attr in index)


def build_signature_with_kwargs(kls, **kwargs):
    """Build model signature from keyword arguments.

    This signature is critical for doing fast lookups on
    a ModelSet. Without it, one would have to loop through
    the whole ModelSet for an item match.

    Args:
        kls: Class definition.

    Returns:
        Tuple of the build signature.

    Raises:
        KeyError if attr does not exist in kwargs.
    """
    index = kls.build_index()
    return tuple(kwargs[attr] for attr in index)
