class ImmutableCache:
    """Cache that can only be filled once.

    Provides a subset of the usual dictionary methods to give the illusion
    that the inner dictionary cannot be overwritten. The goal is NOT to
    implement all dictionary items but just enough to support model set
    workflows.

    Attributes:
        cache: Raw dictionary.
    """

    def __init__(self):
        self.cache = {}

    def __bool__(self):
        return bool(self.cache)

    def __len__(self):
        return len(self.cache)

    def __getitem__(self, key):
        return self.cache[key]

    def __contains__(self, key):
        return key in self.cache

    def __iter__(self):
        return iter(self.cache)

    def fill(self, other):
        """Fill with contents of another dictionary."""
        if len(self.cache) > 0:
            return
        self.cache = other.copy()

    @staticmethod
    def get_cache(model_manager, name):
        return model_manager.get(name).group_by("location")

    def fill_name(self, model_manager, name):
        """Fill cache with single name."""
        self.fill(self.get_cache(model_manager, name))

    def fill_names(self, model_manager, names):
        """Fill cache with multiple names."""
        self.fill({name: self.get_cache(model_manager, name) for name in names})
