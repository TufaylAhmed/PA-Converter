import logging
from typing import List, Optional
from ..base_model import BaseModel

LOG = logging.getLogger(__name__)

"""Singular methods"""


def get_object_from_ancestors(
    model_manager, location, model_set, **signature_params
) -> Optional[BaseModel]:
    """Get single object from ancestors.

    Args:
        model_manager: ModelManager instance.
        location: String representation of location.
        model_set: Single model set to retrieve object from.
        signature_params: Dictionary of key-value pairs passed to build_signature.

    Returns:
        Desired object from the model set. Otherwise, return None.
    """
    mapping = model_manager.tree.ancestors
    for node in mapping.get(location, []):
        signature_params["location"] = node
        model = model_set.find(**signature_params)
        if model is not None:
            LOG.debug(f"Model found in model set at {signature_params}")
            return model


"""Plural methods"""


def get_objects_from_ancestors(
    model_manager, location, model_set, **signature_params
) -> List[BaseModel]:
    """Get multiple objects from ancestors.

    Uses ModelSet builtin findall to get the necessary models.

    Args:
        model_manager: ModelManager instance.
        location: String representation of location.
        model_set: Single model set to retrieve object from.
        signature_params: Dictionary of key-value pairs passed to build_signature.

    Returns:
        List of desired objects from the model set.
    """
    results = []
    mapping = model_manager.tree.ancestors
    for node in mapping.get(location, []):
        signature_params["location"] = node
        models_found = model_set.findall(**signature_params)
        if len(models_found) > 0:
            LOG.debug(f"Models found in model set at {signature_params}")
        results += models_found
    return results


def get_objects_from_descendants(
    model_manager, location, model_set, **signature_params
) -> List[BaseModel]:
    """Get multiple objects from descendants.

    Uses ModelSet builtin findall to get the necessary models.

    Args:
        model_manager: ModelManager instance.
        location: String representation of location.
        model_set: Single model set to retrieve object from.
        signature_params: Dictionary of key-value pairs passed to build_signature.

    Returns:
        List of desired objects from the model set.
    """
    results = []
    mapping = model_manager.tree.descendants
    for node in mapping.get(location, []):
        signature_params["location"] = node
        models_found = model_set.findall(**signature_params)
        if len(models_found) > 0:
            LOG.debug(f"Models found in model set at {signature_params}")
        results += models_found
    return results


def get_objects_from_mapping(keys, model_set_map) -> List[BaseModel]:
    """Get multiple objects from listing.

    Args:
        keys: List of key tuples.
        model_set_map: Mapping from tuple key to list of models.

    Returns:
        List of objects.

    Raises:
        KeyError if key does not exist.
    """
    result = []
    for key in keys:
        models = model_set_map[key]
        result.extend(models)
    return result


def arrange_by_rulebase(keys, rules_lst, is_panorama=False):
    """

    Args:
        keys: ancestors of a location(list of tuple) ex if location was Artigarvan then keys can be [('predefined',), ('shared',), ('lakeland',), ('Artigarvan',)]
        rules_lst: default dict with key as tuple and 4 keys pre-rulebase, post-rulebase, rulebase, default-security-rules. values are list of securityrulemodel
        . ex (lakeland,) :{'pre-rulebase':[SecurityRulemodel, SecurityRuleModel,...],'post-rulebase':[SecurityRuleModel,.....]}
        is_panorama: boolean value to check if it's panorama or not

    Returns:

    """
    # Need to store data in ordered dict to put them into proper order.
    # for ex Artigarvan = [('Artigarvan',), ('Lakeland',), ('shared',), ('predefined',)] this is the right path
    # for post rulebase but since I have reversed the ancestors on line #751 I need to reverse it again to
    # maintain order from UI(Panorama). Make sense?

    if is_panorama:
        return helper_func_to_arrange_by_rulebase(
            keys, rules_lst, ["pre-rulebase", "post-rulebase"]
        )
    else:
        return helper_func_to_arrange_by_rulebase(
            keys, rules_lst, ["rulebase", "default-security-rules"]
        )


def helper_func_to_arrange_by_rulebase(keys, rules_lst, rulebase_values):
    """

    Args:
        keys: ancestors of a location(list of tuple) ex if location was Artigarvan then keys can be [('predefined',), ('shared',), ('lakeland',), ('Artigarvan',)]
        rules_lst: default dict with key as tuple and 4 keys pre-rulebase, post-rulebase, rulebase, default-security-rules. values are list of securityrulemodel
        . ex (lakeland,) :{'pre-rulebase':[SecurityRulemodel, SecurityRuleModel,...],'post-rulebase':[SecurityRuleModel,.....]}
        rulebase_values: to differentiate between panorama and NGFW. For PANORAMA = ['pre-rulebase', 'post-rulebase'] and NGFW = ['rulebase', 'default-security-rules']

    Returns:
        ordered list of securityrulemodel

    """
    temp_storage = []
    res = []
    for key in keys:
        res.extend(rules_lst[key][rulebase_values[0]])
        temp_storage = rules_lst[key][rulebase_values[1]] + temp_storage

    res.extend(temp_storage)
    return res


def get_cached_from_ancestors(
    model_manager, location, model_set_map
) -> List[BaseModel]:
    """Get multiple objects from mapping.

    Uses ModelSet builtin findall to get the necessary models.

    Args:
        model_manager: ModelManager instance.
        location: String representation of location.
        model_set_map: Mapping from location tuple to list of models.

    Returns:
        List of desired objects from the model set.
    """
    results = []
    mapping = model_manager.tree.ancestors
    for node in mapping.get(location, []):
        try:
            results += model_set_map[(node,)]
            LOG.debug(f"Models found in model set at {node}")
        except KeyError:
            continue
    return results


def find_valid_descendants(profiles, descendants, result, **kwargs) -> List:
    """

    NOTE - made specially for decryption_profile. but can be used for other tasks. VALID means no overwritten descendants
    will come.

    Args:
        profiles: profiles is list of all profiles you need to use for searching(filtering)
        descendants: Node(see tree.py) of descendants needed
        result: list in which we store final result.
        **kwargs: Dictionary of key-value pairs passed to filter.

    Returns:
        list of string containing final result
    """
    for child in descendants.children:
        kwargs["location"] = child.val
        #  here to check if profile has been overwritten in child.
        #  checking this condition because once we know it's overwritten we can go and check siblings of that node.
        #  for ex dg-texas = [dg-dfw,dg-houston]. Here if we have overwritten profile in dg-dfw we don't need to check
        #  it's child but need to check dg-houston.
        if profiles.findall(**kwargs):
            continue
        else:
            result.append(child.val)
        # if not overwritten then and then see child of particular profile. Otherwise no need
        if child.children:
            find_valid_descendants(profiles, child, result)
    return result
