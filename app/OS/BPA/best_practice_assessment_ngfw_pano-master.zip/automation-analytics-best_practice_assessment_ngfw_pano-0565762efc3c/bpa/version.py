# NOTE: Modify each time the version is bumped
VERSION = (3, 33, 0)

__version__ = ".".join(map(str, VERSION))
