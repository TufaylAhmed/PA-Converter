from collections import OrderedDict
from typing import Dict, Tuple, Union

from bpa.components.constant import AdoptionMetrics
from bpa.publishers.formats.html.adapters.bpa import BestPracticeAssessment
from bpa.utils.common import flatten_json
from dataclasses import dataclass


@dataclass
class HeatMapHistory:

    historical_data: OrderedDict
    is_panorama = None
    latest_heatmap_json: Dict = None
    latest_tsf_generation_date: str = None

    def _reorder_history(self) -> None:
        """
        This will sort historical data and store it back.
        Returns:

        """
        self.historical_data = OrderedDict(sorted(self.historical_data.items()))

    def set_is_panorama(self, is_panorama: bool):
        """This will set if the current device is a panorama device or not

        """
        self.is_panorama = is_panorama

    def add_heatmap(
        self,
        tsf_generation_date: str,
        pan_os_version: str,
        heatmap_data: Dict,
        serial_number: str,
        managed_device_count: int = None,
    ) -> None:
        """
        This will added the new heatmap to the existing history and re-sort it according to the tsf_generation_date

        Args:
            managed_device_count:
            tsf_generation_date:
            pan_os_version:
            heatmap_data:
            serial_number:

        Returns:

        """
        self.latest_tsf_generation_date = tsf_generation_date
        self.latest_heatmap_json = {
            "data": heatmap_data,
            "panos_version": pan_os_version,
            "serial_number": serial_number,
        }
        if managed_device_count is not None:
            self.latest_heatmap_json[AdoptionMetrics.MANAGED_FIREWALL_COUNT_SLUG] = int(
                managed_device_count
            )
        self.historical_data[self.latest_tsf_generation_date] = self.latest_heatmap_json
        self._reorder_history()

    def get_previous_heatmap(self, tsf_generation_date: str) -> Union[Dict, None]:
        """
        Retrieve data of previous report.

        Args:
            tsf_generation_date: The report in the history before this date will be returned.

        Returns:

        """
        keys = list(self.historical_data.keys())
        prior_index = keys.index(tsf_generation_date) - 1
        if prior_index >= 0:
            return self.historical_data[keys[prior_index]]


@dataclass
class BPAHistory:
    """
    This will help build a summary of the BPA
    """

    sorted_historical_data: OrderedDict
    current_tsf_generation_date: str = None
    latest_bpa_flattened_json: dict = None

    def __post_init__(self):
        """
        Flatten all the historical_data values

        Returns:
        """

        for key, val in self.sorted_historical_data.items():
            self.sorted_historical_data[key] = flatten_json(val)

    def _reorder_history(self) -> None:
        """
        This will sort historical data and store it back.
        Returns:

        """
        self.sorted_historical_data = OrderedDict(
            sorted(self.sorted_historical_data.items())
        )

    def add_assessment(
        self, tsf_generation_date: str, latest_bpa: BestPracticeAssessment
    ) -> Tuple[Dict, Dict[str, Dict]]:
        """
        This will add current BPA's flattened json to the history and will re-sort history

        Args:
            tsf_generation_date: This is the tech support file generation date.
                It will also act as the key in the historical data

            latest_bpa: It will add the json of the object and add it as a value in the historical data

        Returns:
            Ordered Dict of the updated historical data

        """
        self.current_tsf_generation_date = tsf_generation_date
        self.latest_bpa_flattened_json = flatten_json(latest_bpa.json())
        self.sorted_historical_data[
            tsf_generation_date
        ] = self.latest_bpa_flattened_json
        self._reorder_history()
        return self.latest_bpa_flattened_json, self.sorted_historical_data

    def get_previous_assessment(
        self, current_tsf_generation_date: str
    ) -> Union[Dict, None]:
        """
        This will search for the current_tsf_generation_date as key in the sorted historical data
        and then return the flattened bpa json at the index just before.

        Args:
            current_tsf_generation_date: The assessment recorded before this in the will be given.

        Returns:
            Dict of the flattened bpa json
        """

        keys = list(self.sorted_historical_data.keys())
        prior_index = keys.index(current_tsf_generation_date) - 1
        if prior_index >= 0:
            return self.sorted_historical_data[keys[prior_index]]
