from __future__ import annotations
import logging
import itertools
from collections import defaultdict
from typing import List, Dict, Union, Optional, DefaultDict

import pandas as pd

from bpa.components.constant import AdoptionMetrics
from bpa.components.data_models import HeatMapHistory, BPAHistory

from bpa.components.helper import panos_major_version
from bpa.publishers.schemas.documentation import Documentation

from bpa.publishers.formats.html.adapters.bpa import BestPracticeAssessment
from bpa.publishers.utils.common import divide
from bpa.models.utils.masking import mask_general, is_masked

LOG = logging.getLogger(__name__)


class AdoptionAnalysis:
    METRIC_CALCULATED_KEY = "metric_calculated"  # Can be Percentage or Count
    CHANGE_KEY = "change"
    NO_CHANGE_VAL = "No change"

    def __init__(self, analysis_data: Union[List[Dict], pd.DataFrame]):
        self.analysis_data = analysis_data
        self.calculated_adoption_metrics = {}
        self.calculated_count_metrics = {}
        self.calculated_change_metrics = {}

        self.adoption_metrics = AdoptionMetrics()
        # Dict of sums of each
        self.aggregate_analysis_data = (
            pd.DataFrame(self.analysis_data)
            .select_dtypes(include="number")
            .sum()
            .to_dict()
        )

    @property
    def calculated_metrics(self) -> Dict:
        """
        This will return a combined dict of the calculated adoption
        and calculated count metrics

        Returns:
            A dict of agg measures
        """
        return {**self.calculated_adoption_metrics, **self.calculated_count_metrics}

    def calculate_adoption_percentage(
        self,
        version: Union[str, int, float, None] = None,
        include_metrics: Optional[List] = None,
        exclude_metrics: Optional[List] = None,
        key_prefix: str = "",
        key_suffix: str = "",
        pct_non_numeric_values_allowed: bool = False,
    ) -> Dict:
        """Aggregates recordset by summing specified measures.

            Args:
                version: Optional device PAN-OS version
                include_metrics: Any metrics that need to be specifically added
                exclude_metrics: Any metrics that need to be ignored specifically
                key_prefix: Any string to be added to the start of the key in the dict eg a % symbol
                key_suffix: Any string to be added to the end of the key in the dict eg a % symbol
                pct_non_numeric_values_allowed: Will allow string values in pct field. Typically in trending data to show PAN-OS < 8.0


            Returns:
                The instance variable calculated_count_metrics which is a dictionary of aggregated measures
                Format: <metric (as key)> : <aggregate (as value)>
            """
        self.calculated_adoption_metrics = {}

        # Get all the possible adoption metrics
        metrics = self.adoption_metrics.get_adoption_metrics()

        if type(include_metrics) == list:
            metrics.extend(include_metrics)

        # credential_theft_enabled will be missing for older history data and devices not running PAN-OS 8.0+
        # version will be missing for industry average data
        if version is not None and panos_major_version(version) < 8:
            if exclude_metrics is None:
                exclude_metrics = list()
            exclude_metrics.append(self.adoption_metrics.CREDENTIAL_THEFT_ADOPTION)
            exclude_metrics.append(
                self.adoption_metrics.CREDENTIAL_THEFT_ADOPTION_STRICT
            )

            # Adding value for Credential Theft Adoption metric
            if pct_non_numeric_values_allowed:
                self.calculated_adoption_metrics[
                    f"{key_prefix}{self.adoption_metrics.CREDENTIAL_THEFT_ADOPTION}{key_suffix}"
                ] = "PAN-OS < 8.0"

        # If there are any metrics to be excluded then remove them.
        if exclude_metrics:
            metrics = list(set(metrics) - set(exclude_metrics))

        # Now go over the final metrics and calculate the percentage of adoption
        for metric in metrics:
            numerator, denominator = self.adoption_metrics.metric_definitions[metric]
            try:
                self.calculated_adoption_metrics[
                    f"{key_prefix}{metric}{key_suffix}"
                ] = round(
                    float(
                        (
                            self.aggregate_analysis_data[numerator]
                            / self.aggregate_analysis_data[denominator]
                        )
                        * 100
                    ),
                    1,
                )

            except (ZeroDivisionError, KeyError):
                self.calculated_adoption_metrics[
                    f"{key_prefix}{metric}{key_suffix}"
                ] = ("N/A" if pct_non_numeric_values_allowed else 0)

        return self.calculated_adoption_metrics

    def calculate_count_total(self) -> Dict:
        """
        This retrieves the pre calculate count metrics from the aggregate_analysis_data

        Returns:
            The instance variable calculated_count_metrics which is a dict of results
            Format: <metric (as key)> : <aggregate (as value)>
        """
        metrics = self.adoption_metrics.get_count_metrics()
        for metric in metrics:
            try:
                val_key = self.adoption_metrics.metric_definitions[metric][0]
                self.calculated_count_metrics[metric] = self.aggregate_analysis_data[
                    val_key
                ]
            except KeyError:
                self.calculated_count_metrics[metric] = 0

        return self.calculated_count_metrics

    @classmethod
    def _calculate_change(cls, current_pct: float, prior_pct: float) -> str:
        """
        Calculates point change between two percentages.

        """
        delta = round(current_pct - prior_pct)
        if delta == 0:
            return cls.NO_CHANGE_VAL
        label = "pt" if abs(delta) == 1 else "pts"
        prefix = "+" if delta > 0 else ""
        return f"{prefix}{delta} {label}"

    @classmethod
    def calculate_adoption_change(
        cls,
        current_data_analysis: AdoptionAnalysis,
        prior_data_analysis: Optional[AdoptionAnalysis],
    ) -> Dict:
        """
        This compares the percentages of adoption between two analysis
        and populates calculated_change_metrics of the current_data_analysis.
        If prior_data_analysis is None then the change value is 'No Change'

        Args:
            current_data_analysis: Instance of AdoptionAnalysis created using
                the current Heatmap's data and populated with the results of
                self.calculate_adoption_percentage or self.calculate_count_total
            prior_data_analysis: None or Instance of AdoptionAnalysis created using
                the current Heatmap's data and populated with the results of
                self.calculate_adoption_percentage or self.calculate_count_total

        Returns:
            Dictionary of <metric (as key)>: < x pts/ No Change (as val)>

        """
        # If there is no prior analysis then there is no change
        if prior_data_analysis is None:
            for each_metric in current_data_analysis.calculated_metrics:
                current_data_analysis.calculated_change_metrics[
                    each_metric
                ] = cls.NO_CHANGE_VAL
        else:
            current_calc_metric = current_data_analysis.calculated_metrics
            prior_calc_metric = prior_data_analysis.calculated_metrics
            for each_metric in current_calc_metric:
                try:
                    current_data_analysis.calculated_change_metrics[
                        each_metric
                    ] = cls._calculate_change(
                        current_pct=current_calc_metric[each_metric],
                        prior_pct=prior_calc_metric[each_metric],
                    )
                except (KeyError, TypeError):
                    current_data_analysis.calculated_change_metrics[
                        each_metric
                    ] = cls.NO_CHANGE_VAL

        return current_data_analysis.calculated_change_metrics


class BPAChecksPassFail:
    PASS = "pass"
    FAIL = "fail"

    def __init__(self, check_results: defaultdict):
        """

        Args:
            check_results: A defaultdict where keys are checks IDs found in the BPA JSON data
            and values are dictionaries of pass / fail counts.
        """
        self.result = check_results

    @classmethod
    def get_counts(cls, bpat_flattened_json: Dict) -> BPAChecksPassFail:
        """Count all passing and failing checks.

        Args:
            bpat_flattened_json: Flattened BPA JSON data

        Returns:
            A defaultdict where keys are checks IDs found in the BPA JSON data
            and values are dictionaries of pass / fail counts.
        """
        checks = defaultdict(lambda: defaultdict(int))
        for records in bpat_flattened_json.values():
            for record in records:
                for check in record["bp_check"]:
                    if check["result"] in [cls.PASS, cls.FAIL]:
                        checks[check["id"]][check["result"]] += 1
        return cls(checks)


class HeatMapTrend:
    @classmethod
    def generate(cls, heatmap_history: HeatMapHistory) -> List[Dict]:
        """
        For each of the assessments in the history this will calculate percentage of adoption
        based on the pass/fail and the total count

        Args:
            heatmap_history:

        Returns:
            A list of dictionaries representing the adoption percentage.
        """
        trend = []
        for tsf_date, record in heatmap_history.historical_data.items():
            adoption_analysis = AdoptionAnalysis(analysis_data=record["data"])
            adoption_analysis.calculate_adoption_percentage(
                version=panos_major_version(record["panos_version"]),
                include_metrics=adoption_analysis.adoption_metrics.get_bp_mode_metrics(),
                key_suffix=" %",
                pct_non_numeric_values_allowed=True,
            )
            adoption_analysis.calculate_count_total()

            # Combination of the results of the adoption metrics and count metrics
            complete_analysis = dict(
                **adoption_analysis.calculated_count_metrics,
                **adoption_analysis.calculated_adoption_metrics,
            )

            # Adding tsf generation date to the analysis
            complete_analysis["tsf_generated_date"] = tsf_date

            # Adding serial number to the analysis
            _serial = record["serial_number"]

            # is masked test is need otherwise serial number is shortening
            # if masked again due to the 40% logic of the algorithm
            complete_analysis["Serial"] = (
                mask_general(_serial) if not is_masked(_serial) else _serial
            )

            # Adding managed device count
            complete_analysis[
                adoption_analysis.adoption_metrics.MANAGED_FIREWALL_COUNT
            ] = (
                record.get(
                    adoption_analysis.adoption_metrics.MANAGED_FIREWALL_COUNT_SLUG
                )
                or "N/A"
            )

            # Adding complete analysis to the trend
            trend.append(complete_analysis)
        return trend


class BPAChecksDocsMapping:
    columns_with_list_as_value = [
        "Functionality / Capability",
        "Class",
        "Control Category",
        "CSCv6 Controls",
        "CSCv7 Controls",
    ]

    readable_column_names = {
        "doc_id": "ID",
        "rationale": "Rationale",
        "title": "Title",
        "top_nav": "Top Nav",
        "left_nav": "Left Nav",
        "capability_label": "Functionality / Capability",
        "class_label": "Class",
        "control_category": "Control Category",
        "cscv6_control": "CSCv6 Controls",
        "cscv7_control": "CSCv7 Controls",
    }

    def __init__(
        self,
        mapped_records: pd.DataFrame,
        xls_used: bool = False,
        xls_df: Optional[pd.DataFrame] = None,
    ):
        """

        Args:
            mapped_records:
        """
        self.records: pd.DataFrame = mapped_records
        self.xls_used: bool = xls_used
        self.xls_df: Optional[pd.DataFrame] = xls_df

    @classmethod
    def map_checks_to_docs(
        cls,
        current_pass_fail_checks: BPAChecksPassFail,
        previous_pass_fail_checks: Union[BPAChecksPassFail, Dict],
        bpa_docs: List[Documentation],
    ) -> Union[BPAChecksDocsMapping, None]:
        """Maps the pass fail results of the the BP checks and maps it against the BPA docs

        Returns:
            an instance of BPAChecksDocsMapping
        """
        current_pass_fail_checks = current_pass_fail_checks.result

        current_records = [
            {
                "ID": key,
                "current_pass": val[BPAChecksPassFail.PASS],
                "current_fail": val[BPAChecksPassFail.FAIL],
                "previous_pass": previous_pass_fail_checks.result[key][
                    BPAChecksPassFail.PASS
                ]
                if (
                    previous_pass_fail_checks
                    and previous_pass_fail_checks.result.get(key)
                )
                else None,
                "previous_fail": previous_pass_fail_checks.result[key][
                    BPAChecksPassFail.FAIL
                ]
                if (
                    previous_pass_fail_checks
                    and previous_pass_fail_checks.result.get(key)
                )
                else None,
            }
            for key, val in current_pass_fail_checks.items()
        ]

        if bpa_docs:
            # Then process only from DB Records
            docs_df = pd.DataFrame(
                [d.as_dict for d in bpa_docs], columns=cls.readable_column_names.keys()
            ).rename(columns=cls.readable_column_names)
            mapped_records = pd.merge(
                docs_df, pd.DataFrame(current_records), how="left", on="ID"
            )
            return cls(mapped_records=mapped_records)
        else:
            LOG.debug(f"No Documentation found.")
            return

    def format_data_util(self) -> Dict:
        """
        This will:
            1. converts columns with list as values to a string comma separated values
            2. Add 'N/A' in blank fields

        Args:
            mapped_df: Dataframe got from bpa.components.aggregate.BPAMappings.map_checks_to_docs

        Returns:
            Formatted Data Frame as dict
        """
        # Create Mapping Record
        formatted_records = self.records.copy()

        if self.xls_used:
            return formatted_records.to_dict(orient="records")
        else:
            for column in self.columns_with_list_as_value:
                formatted_records[column] = (
                    formatted_records[column].dropna().apply(", ".join)
                )
            formatted_records = formatted_records.replace(to_replace="", value="N/A")
            return formatted_records.to_dict(orient="records")

    def extract_summarization_data(self) -> Dict:
        """
        This will return a dictionary containing the data to create a BPA summary

        Returns:

        """
        # Creating the collector
        collector = dict()

        if self.xls_used:
            collector_df = self.xls_df.copy()
            collector_df.set_index("ID", inplace=True)

            for col in ["Functionality / Capability", "Class", "Control Category"]:
                collector[col] = (
                    collector_df[col].dropna().str.strip().str.split(", ").to_dict()
                )

            # NOTE: Include checks with no CSC entries
            csc_column = collector_df["CSCv7 Controls"].astype(str).to_dict()
            csc_collector = collector["CSC Controls"] = {}
            for k, v in csc_column.items():
                if v == "nan":
                    csc_collector[k] = []
                else:
                    csc_collector[k] = [int(float(n)) for n in v.split(", ")]
        else:
            collector_df = self.records.copy()
            collector_df.set_index("ID", inplace=True)
            collector = dict()
            for col in ["Functionality / Capability", "Class", "Control Category"]:
                collector[col] = collector_df[col].to_dict()

            # NOTE: Include checks with no CSC entries
            csc_column = collector_df["CSCv7 Controls"].apply(",".join).to_dict()
            csc_collector = collector["CSC Controls"] = dict()
            for k, v in csc_column.items():
                if v in ["", "NA", "nan"]:
                    csc_collector[k] = []
                else:
                    csc_collector[k] = [int(float(n)) for n in v.split(",")]

        return collector


class BPASummary:
    def __init__(self, data: DefaultDict):
        self.data = data

    @classmethod
    def from_mappings(
        cls, pass_fail_checks: BPAChecksPassFail, summarization_data: Dict
    ) -> BPASummary:
        """

        Args:
            pass_fail_checks: Instance of BPAChecksPassFail
            mappings: Result of bpa.components.aggregate.BPAMappings.map_checks_to_docs

        Returns:
            An instance of bpa.components.data_models.BPASummary
        """
        checks = pass_fail_checks.result
        collector = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
        for category, id_lookup in summarization_data.items():
            mapping_counts = defaultdict(lambda: defaultdict(int))
            for bpa_id, mappings in id_lookup.items():
                passing = checks[bpa_id]["pass"]
                total = checks[bpa_id]["pass"] + checks[bpa_id]["fail"]
                for mapping in mappings:
                    mapping_counts[mapping]["passing"] += passing
                    mapping_counts[mapping]["total"] += total
            for mapping, counts in mapping_counts.items():
                collector[category][mapping] = {**counts}
                collector[category][mapping]["percent"] = round(
                    divide(counts["passing"], counts["total"]) * 100
                )
        return cls(collector)


class BPChecksDescription:
    """
    This is primarily used to give a description of the all the
    best practice checks for every best practice attribute

    """

    def _get_check_ids(self, bpat, attrib):
        """Looks up all check IDs associated with a given attribute.

        Args:
            bpat: BestPracticeAssessment object instance
            attrib: BestPracticeAssessment check attribute

        Returns:
            A tuple where the first item is the attribute check name and the
            second item is a list of check IDs. "device" and "template" attribute
            name prefixes are stripped from the attribute name since the documentation
            for the checks themselves are the same.
        """
        if attrib == "security_rules":
            try:
                ids = {
                    check.check_id
                    for check in bpat.bp_manager().get("security_rule")[0].checks
                }
            except IndexError:
                ids = set()
        else:
            ids = set(
                itertools.chain.from_iterable(
                    [
                        [check.get("id", -1) for check in record["bp_check"]]
                        for record in getattr(bpat, attrib)
                    ]
                )
            )

        return (
            "_".join(x for x in attrib.split("_") if x not in ["device", "template"]),
            ids,
        )

    def get(self, bpat: BestPracticeAssessment) -> Dict:
        """
        This will give a dict with bpat.result_atts as keys
        and every value is a list of docs matching the bp_check ids under that attribute.

        Args:
            bpat: BestPracticeAssessment object instance

        Returns:
            Dictionary object.
        """

        # Create a map of all the attributes in the assessment and their corresponding bp_check ids
        documentation_dict = defaultdict(set)
        for attrib in bpat.result_attrs:
            key, ids = self._get_check_ids(bpat, attrib)
            if ids:
                documentation_dict[key].update(ids)

        # Now using the collected ids find the corresponding Docs and create and updated mapping.
        docs = bpat.bp_manager().model_manager().documentation
        if not docs:
            return {}
        collector = dict()
        for key, ids in documentation_dict.items():
            collector[key] = [d.as_dict for d in docs if d.as_dict["doc_id"] in ids]

        return collector


class BPAChange:
    def __init__(self, bpa_summary: BPASummary):
        self.bpa_summary = bpa_summary

    def compare_change(self, compare_against: Union[BPASummary, None]) -> BPASummary:
        """
        This will calculate the change between the new assessment and prior assessment.
        It will then mutate bpa_summary to add the calculated value

        Args:
            bpa_summary: Instance of current Assessment's summary
            prior_bpa_summary: Instance of prior

        Returns:

        """
        _bpa_summary = self.bpa_summary.data
        _prior_bpa_summary = compare_against
        _prior_bpa_summary = _prior_bpa_summary.data if _prior_bpa_summary else None
        for category, mappings in _bpa_summary.items():
            for mapping, vals in mappings.items():
                if _prior_bpa_summary is None:
                    _bpa_summary[category][mapping]["change"] = "No change"
                else:
                    try:
                        change = (
                            _bpa_summary[category][mapping]["percent"]
                            - _prior_bpa_summary[category][mapping]["percent"]
                        )
                        if change > 0:
                            change_text = f"+{change}"
                        elif change == 0:
                            change_text = "No change"
                        else:
                            change_text = str(change)
                        abs_change = abs(change)
                        if abs_change != 0:
                            if abs_change == 1:
                                change_text = f"{change_text} pt"
                            else:
                                change_text = f"{change_text} pts"
                        _bpa_summary[category][mapping]["change"] = change_text
                    except KeyError:
                        _bpa_summary[category][mapping]["change"] = "No change"
        return self.bpa_summary


class BPATrend:
    TSF_GENERATED_DATE = "tsf_generated_date"

    def _calculate_passing(self, record: Dict, include_keys: List) -> Dict:
        """Calculates passing percentages by top nav categories.

        Args:
            record: dictionary of aggregated total and passing checks per category
            include_keys: list of keys to include in returned passing percentages dictionary

        Returns:
            A dictionary of passing percentages by category
        """
        passing = dict()
        for category in {
            key.split("_")[0] for key in record.keys() if key not in include_keys
        }:
            passing[category] = round(
                divide(
                    record["{}_pass".format(category)],
                    record["{}_total".format(category)],
                )
                * 100,
                2,
            )

        passing.update({key: record[key] for key in include_keys})

        return passing

    def _aggregate_measures(
        self, records: Dict, include_dict: Dict = None, sep: str = "."
    ) -> DefaultDict:
        """For the top nav items aggregate total and passing counts from Best Practice Assessment JSON.

        Args:
            records: flattened Best Practice Assessment JSON data
            include_dict: dictionary to add to aggregated counts dictionary
            sep: nested JSON key separator

        Returns:
            A dictionary of aggregated total and passing checks per
            category (i.e. policies, objects, etc.)
        """
        totals = defaultdict(int)
        warning_results = {"pass", "fail"}
        for nav, items in records.items():
            top_nav = nav.split(sep)[0]
            totals[top_nav + "_pass"] += 0
            totals[top_nav + "_total"] += 0
            for record in items:
                for check in record["bp_check"]:
                    if check["result"] in warning_results:
                        totals[top_nav + "_total"] += 1
                    if check["result"] == "pass":
                        totals[top_nav + "_pass"] += 1

        if include_dict is not None:
            totals.update(include_dict)

        return totals

    def create_trend(self, bpa_history: BPAHistory, panorama: bool) -> List:
        """Creates trending pass % metrics by top nav category.

        Args:
            tsf_generated_date: string representing the TSF generated datetime of current data.
            serial_number: string representing the device serial number.
            current_data: optional dictionary of the current data in flattened JSON structure

        Returns:
            A list of trend dictionary records
        """
        CATEGORIES = ["policies", "objects", "device", "network", "panorama"]
        if not panorama:
            CATEGORIES = CATEGORIES[:-1]
        trend = []
        for tsf_date, data in bpa_history.sorted_historical_data.items():
            agg_data = self._aggregate_measures(
                data, include_dict={self.TSF_GENERATED_DATE: tsf_date}
            )
            not_configured = [
                cat for cat in CATEGORIES if agg_data[f"{cat}_total"] == 0
            ]
            passing_pcts = self._calculate_passing(
                record=agg_data, include_keys=[self.TSF_GENERATED_DATE]
            )
            for nc in not_configured:
                passing_pcts[nc] = "Not Configured"
            trend.append(passing_pcts)
        return trend
