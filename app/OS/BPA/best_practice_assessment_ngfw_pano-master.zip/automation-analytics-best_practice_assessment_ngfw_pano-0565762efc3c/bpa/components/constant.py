"""
This file has all the static variables used across components
"""
from typing import List, Callable


def format_metrics(func: Callable) -> Callable:
    """This decorator will add prefix/suffix around the metrics returned by a given function if specified

    Args:
        prefix
    """

    def inner(*args, prefix: str = "", suffix: str = "", **kwargs):
        _metrics = func(*args, **kwargs)
        if prefix or suffix:
            return [f"{prefix}{_metric}{suffix}" for _metric in _metrics]
        return _metrics

    return inner


class AdoptionMetrics:

    TOTAL_RULE_COUNT = "Total Rule Count"
    TOTAL_RULE_COUNT_SLUG = "total_rule_count"
    ALLOW_RULE_COUNT = "Allow Rule Count"
    ALLOW_RULE_COUNT_SLUG = "allow_rule_count"
    DENY_RULE_COUNT = "Deny Rule Count"
    DENY_RULE_COUNT_SLUG = "deny_rule_count"
    WILD_FIRE_ADOPTION = "WildFire Adoption"
    WILD_FIRE_SLUG = "wildfire_enabled"
    WILD_FIRE_ADOPTION_STRICT = "WildFire Adoption Strict"
    WILD_FIRE_STRICT_SLUG = "wildfire_enabled_strict"
    ZONE_PROTECTION_PROFILE_ADOPTION = "Zone Protection Profile Adoption"
    ZONE_PROTECTION_PROFILE_SLUG = "zone_protection_profile_enabled"
    LOG_FORWARDING_ADOPTION = "Log Forwarding Adoption"
    LOG_FORWARDING_SLUG = "log_forwarding_enabled"
    LOGGING_ADOPTION = "Logging Adoption"
    LOGGING_SLUG = "log_end"
    SERVICE_PORT_ADOPTION = "Service / Port Adoption"
    SERVICE_PORT_SLUG = "service_port_configured"
    APP_ID_ADOPTION = "App ID Adoption"
    APP_ID_SLUG = "app_id_enabled"
    USER_ID_ADOPTION = "User ID Adoption"
    USER_ID_SLUG = "user_id_enabled"
    DATA_FILTERING_ADOPTION = "Data-Filtering Adoption"
    DATA_FILTERING_SLUG = "data_filtering_enabled"
    FILE_BLOCKING_ADOPTION = "File-Blocking Adoption"
    FILE_BLOCKING_SLUG = "file_blocking_enabled"
    FILE_BLOCKING_ADOPTION_STRICT = "File-Blocking Adoption Strict"
    FILE_BLOCKING_STRICT_SLUG = "file_blocking_enabled_strict"
    CREDENTIAL_THEFT_ADOPTION = "Credential Theft Adoption"
    CREDENTIAL_THEFT_SLUG = "credential_theft_enabled"
    CREDENTIAL_THEFT_ADOPTION_STRICT = "Credential Theft Adoption Strict"
    CREDENTIAL_THEFT_STRICT_SLUG = "credential_theft_enabled_strict"
    URL_FILTERING_ADOPTION = "URL-Filtering Adoption"
    URL_FILTERING_SLUG = "url_filtering_enabled"
    URL_FILTERING_ADOPTION_STRICT = "URL-Filtering Adoption Strict"
    URL_FILTERING_STRICT_SLUG = "url_filtering_enabled_strict"
    VULNERABILITY_PROTECTION_ADOPTION = "Vulnerability Protection Adoption"
    VULNERABILITY_PROTECTION_SLUG = "vulnerability_enabled"
    VULNERABILITY_PROTECTION_ADOPTION_STRICT = (
        "Vulnerability Protection Adoption Strict"
    )
    VULNERABILITY_PROTECTION_STRICT_SLUG = "vulnerability_enabled_strict"
    ANTI_VIRUS_ADOPTION = "Anti-Virus Adoption"
    ANTI_VIRUS_SLUG = "antivirus_enabled"
    ANTI_VIRUS_ADOPTION_STRICT = "Anti-Virus Adoption Strict"
    ANTI_VIRUS_STRICT_SLUG = "antivirus_enabled_strict"
    DNS_SINKHOLE_ADOPTION = "DNS Sinkhole Adoption"
    DNS_SINKHOLE_SLUG = "dns_sinkhole_enabled"
    DNS_SINKHOLE_ADOPTION_STRICT = "DNS Sinkhole Adoption Strict"
    DNS_SINKHOLE_STRICT_SLUG = "dns_sinkhole_enabled_strict"
    ANTI_SPYWARE_ADOPTION = "Anti-Spyware Adoption"
    ANTI_SPYWARE_SLUG = "antispyware_enabled"
    ANTI_SPYWARE_ADOPTION_STRICT = "Anti-Spyware Adoption Strict"
    ANTI_SPYWARE_STRICT_SLUG = "antispyware_enabled_strict"
    MANAGED_FIREWALL_COUNT = "Managed Firewall Count"
    MANAGED_FIREWALL_COUNT_SLUG = "managed_device_count"

    def __init__(self):
        self.metric_definitions = {
            self.ALLOW_RULE_COUNT: (self.ALLOW_RULE_COUNT_SLUG,),
            self.TOTAL_RULE_COUNT: (self.TOTAL_RULE_COUNT_SLUG,),
            self.DENY_RULE_COUNT: (self.DENY_RULE_COUNT_SLUG,),
            self.WILD_FIRE_ADOPTION: (self.WILD_FIRE_SLUG, self.ALLOW_RULE_COUNT_SLUG),
            self.WILD_FIRE_ADOPTION_STRICT: (
                self.WILD_FIRE_STRICT_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.ANTI_SPYWARE_ADOPTION: (
                self.ANTI_SPYWARE_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.ANTI_SPYWARE_ADOPTION_STRICT: (
                self.ANTI_SPYWARE_STRICT_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.ANTI_VIRUS_ADOPTION: (
                self.ANTI_VIRUS_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.ANTI_VIRUS_ADOPTION_STRICT: (
                self.ANTI_VIRUS_STRICT_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.VULNERABILITY_PROTECTION_ADOPTION: (
                self.VULNERABILITY_PROTECTION_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.VULNERABILITY_PROTECTION_ADOPTION_STRICT: (
                self.VULNERABILITY_PROTECTION_STRICT_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.FILE_BLOCKING_ADOPTION: (
                self.FILE_BLOCKING_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.FILE_BLOCKING_ADOPTION_STRICT: (
                self.FILE_BLOCKING_STRICT_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.DATA_FILTERING_ADOPTION: (
                self.DATA_FILTERING_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.URL_FILTERING_ADOPTION: (
                self.URL_FILTERING_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.URL_FILTERING_ADOPTION_STRICT: (
                self.URL_FILTERING_STRICT_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.CREDENTIAL_THEFT_ADOPTION: (
                self.CREDENTIAL_THEFT_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.CREDENTIAL_THEFT_ADOPTION_STRICT: (
                self.CREDENTIAL_THEFT_STRICT_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.DNS_SINKHOLE_ADOPTION: (
                self.DNS_SINKHOLE_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.DNS_SINKHOLE_ADOPTION_STRICT: (
                self.DNS_SINKHOLE_STRICT_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.APP_ID_ADOPTION: (self.APP_ID_SLUG, self.ALLOW_RULE_COUNT_SLUG),
            self.USER_ID_ADOPTION: (self.USER_ID_SLUG, self.ALLOW_RULE_COUNT_SLUG),
            self.LOGGING_ADOPTION: (self.LOGGING_SLUG, self.TOTAL_RULE_COUNT_SLUG),
            self.SERVICE_PORT_ADOPTION: (
                self.SERVICE_PORT_SLUG,
                self.ALLOW_RULE_COUNT_SLUG,
            ),
            self.LOG_FORWARDING_ADOPTION: (
                self.LOG_FORWARDING_SLUG,
                self.TOTAL_RULE_COUNT_SLUG,
            ),
            self.ZONE_PROTECTION_PROFILE_ADOPTION: (
                self.ZONE_PROTECTION_PROFILE_SLUG,
                self.TOTAL_RULE_COUNT_SLUG,
            ),
        }

    @classmethod
    @format_metrics
    def get_adoption_metrics(cls) -> List:
        """
        This is a list of metrics that are used to calculate percentage of adoption and also
        Returns:

        """
        _metrics = [
            cls.WILD_FIRE_ADOPTION,
            cls.ANTI_SPYWARE_ADOPTION,
            cls.DNS_SINKHOLE_ADOPTION,
            cls.ANTI_VIRUS_ADOPTION,
            cls.VULNERABILITY_PROTECTION_ADOPTION,
            cls.URL_FILTERING_ADOPTION,
            cls.CREDENTIAL_THEFT_ADOPTION,
            cls.FILE_BLOCKING_ADOPTION,
            cls.DATA_FILTERING_ADOPTION,
            cls.USER_ID_ADOPTION,
            cls.APP_ID_ADOPTION,
            cls.SERVICE_PORT_ADOPTION,
            cls.LOGGING_ADOPTION,
            cls.LOG_FORWARDING_ADOPTION,
            cls.ZONE_PROTECTION_PROFILE_ADOPTION,
        ]
        return _metrics

    @classmethod
    def get_count_metrics(cls) -> List:
        """
        This is a list of a the metrics that return a sum/count

        Returns:

        """
        return [cls.TOTAL_RULE_COUNT, cls.ALLOW_RULE_COUNT, cls.DENY_RULE_COUNT]

    @classmethod
    def get_panorama_specific_metrics(cls, is_panorama: bool) -> List:
        """
        This returns a list of metrics that are very specific to a panorama device

        Returns:

        """
        if is_panorama:
            return cls.get_panorama_specific_count_metrics()
        return list()

    @classmethod
    def get_panorama_specific_count_metrics(cls) -> List:
        """
        This returns a list of metrics that are very specific to a panorama device

        Returns:

        """
        return [cls.MANAGED_FIREWALL_COUNT]

    @classmethod
    def get_bp_ignores_metrics(cls) -> List:
        """

        Returns: A list of metrics that the BP Check ignores as there is no industry best practice for these

        """
        return [
            cls.DATA_FILTERING_ADOPTION,
            cls.USER_ID_ADOPTION,
            cls.APP_ID_ADOPTION,
            cls.SERVICE_PORT_ADOPTION,
            cls.LOGGING_ADOPTION,
            cls.LOG_FORWARDING_ADOPTION,
            cls.ZONE_PROTECTION_PROFILE_ADOPTION,
        ]

    @classmethod
    def get_industry_ignores_metrics(cls) -> List:
        """

        Returns: A list of metrics that the industry ignores as there is no industry best practice for these

        """
        return [
            cls.USER_ID_ADOPTION,
            cls.APP_ID_ADOPTION,
            cls.SERVICE_PORT_ADOPTION,
            cls.LOGGING_ADOPTION,
            cls.LOG_FORWARDING_ADOPTION,
            cls.ZONE_PROTECTION_PROFILE_ADOPTION,
        ]

    @classmethod
    @format_metrics
    def get_bp_mode_metrics(cls, only_strict: bool = False) -> List:
        """
        Keyword Args:
            only_strict: (Bool) Set to true if you only want metrics used by BP Mode else it will
                return a list of all metrics but just indicating the ones used by the BP Mode as Strict

        Returns:
            A list of metrics

        """

        _strict_metrics = [
            cls.WILD_FIRE_ADOPTION_STRICT,
            cls.ANTI_SPYWARE_ADOPTION_STRICT,
            cls.DNS_SINKHOLE_ADOPTION_STRICT,
            cls.ANTI_VIRUS_ADOPTION_STRICT,
            cls.VULNERABILITY_PROTECTION_ADOPTION_STRICT,
            cls.URL_FILTERING_ADOPTION_STRICT,
            cls.CREDENTIAL_THEFT_ADOPTION_STRICT,
            cls.FILE_BLOCKING_ADOPTION_STRICT,
        ]

        if only_strict:
            return _strict_metrics
        return _strict_metrics + cls.get_bp_ignores_metrics()
