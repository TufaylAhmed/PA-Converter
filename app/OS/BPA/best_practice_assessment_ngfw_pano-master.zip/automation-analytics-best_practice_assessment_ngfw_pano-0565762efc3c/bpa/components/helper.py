"""
This file contains helper functions used across components
"""
from typing import Union


def panos_major_version(panos_version: Union[str, int, float]) -> int:
    """Get the major version from a PAN-OS version string.

    Handles bad data corner cases where panos_version is None or an empty string.
    """
    try:
        return int(str(panos_version)[0])
    except (IndexError, TypeError, ValueError):
        return 0
