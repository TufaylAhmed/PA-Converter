from __future__ import annotations
import logging
import os
import sqlalchemy

from typing import Tuple, List
from collections import OrderedDict

from bpa.components.data_models import BPAHistory, HeatMapHistory

LOG = logging.getLogger(__name__)


class HeatMapBPAHistoricalData:
    @classmethod
    def get(
        # cls, serial_number: str, limit: int = 9
        cls,
        serial_numbers: List[str],
        limit: int = 9,
    ) -> Tuple[HeatMapHistory, BPAHistory]:
        """Queries database for BPA and heatmap history for a given serial number.

        If the same TSF is used multiple times, select the
        latest report generated (id) per TSF Generated Date.
        """
        heatmap_history, bpa_history = OrderedDict(), OrderedDict()

        try:
            user = os.environ["CS_SITE_PG_USER_RO"]
            pw = os.environ["CS_SITE_PG_PW_RO"]
            host = os.environ["CS_SITE_PG_HOST"]
            port = os.getenv("CS_SITE_PG_PORT", 5432)
            database_name = os.environ["CS_SITE_PG_DATABASE"]
        except KeyError:
            return (
                HeatMapHistory(historical_data=heatmap_history),
                BPAHistory(sorted_historical_data=bpa_history),
            )

        # engine = sqlalchemy.create_engine(
        #     f"postgresql://{user}:{pw}@cs-data-us-02.paloaltonetworks.local:5432/customer_success_site"
        # )
        css_db_url = f"postgresql://{user}:{pw}@{host}:{port}/{database_name}"
        engine = sqlalchemy.create_engine(css_db_url)

        # https://www.postgresql.org/docs/current/static/sql-select.html#SQL-DISTINCT
        query = f"""
            SELECT a.tsf_date, a.panos_version, a.managed_device_count, a.serial_number, b.history_type, b.data FROM (
                SELECT DISTINCT ON (1)
                info->>'Tech Support File Generated Date' as tsf_date, id, COALESCE(info->>'sw-version', info->>'sw_version') as panos_version,
                metadata->>'managed_device_count' as managed_device_count, serial_number
                FROM public.tools_device
                WHERE serial_number IN ('{"','".join(serial_numbers)}')
                ORDER BY tsf_date DESC, id DESC
                LIMIT {limit}
            ) a
            INNER JOIN public.tools_history b ON a.id = b.device_id
            """
        try:
            with engine.connect() as con:
                rs = con.execute(query)
                for row in rs:
                    if row["history_type"] == "bpat":
                        bpa_history[row["tsf_date"]] = row["data"]
                    else:
                        heatmap_history[row["tsf_date"]] = dict(row)
        except sqlalchemy.exc.OperationalError as e:
            LOG.warning(f"Database error: {repr(e)}")

        if (
            os.getenv("DJANGO_SETTINGS_MODULE", "") == "solo.settings.prod"
            or os.getenv("SOLO_USER") is not None
        ):
            LOG.info("Getting data from solo API")
            user = os.getenv("SOLO_USER") or os.getenv("POSTGRES_USER")
            pw = os.getenv("SOLO_PASSWORD") or os.getenv("POSTGRES_PASSWORD")
            host = os.environ["POSTGRES_HOST"]
            port = os.getenv("POSTGRES_PORT", 5432)
            database_name = os.environ["POSTGRES_DB"]

            # engine = sqlalchemy.create_engine(
            #     f"postgresql://{user}:{pw}@sjcccxpvl04p.paloaltonetworks.local:5432/postgres"
            # )
            solo_db_url = f"postgresql://{user}:{pw}@{host}:{port}/{database_name}"

            engine = sqlalchemy.create_engine(solo_db_url)
            query = f"""
            SELECT DISTINCT ON (1)
            tsf_generated_date as tsf_date, system_info->>'sw-version' as panos_version, adoption_data as data,
            bpa_data, metadata->>'managed_device_count' as managed_device_count, serial_number
            FROM public.api_device
            WHERE serial_number IN ('{"','".join(serial_numbers)}')
            AND date_generated is not null
            AND archived is False
            ORDER BY tsf_date DESC, id DESC
            LIMIT {limit}
            """
            try:
                with engine.connect() as con:
                    rs = con.execute(query)
                    for row in rs:
                        tsf_date = row["tsf_date"].strftime("%Y-%m-%d %H:%M:%S")
                        bpa_history[tsf_date] = row["bpa_data"]
                        heatmap_history[tsf_date] = dict(row)
            except sqlalchemy.exc.OperationalError as e:
                LOG.warning(f"Database error: {repr(e)}")

        offset = limit * -1
        heatmap_history_offsetted = OrderedDict(
            sorted(heatmap_history.items())[offset:]
        )
        bpa_history_offsetted = OrderedDict(sorted(bpa_history.items())[offset:])

        return (
            HeatMapHistory(heatmap_history_offsetted),
            BPAHistory(bpa_history_offsetted),
        )
