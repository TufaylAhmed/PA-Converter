# -*- coding: utf-8 -*-
import datetime
import logging
from typing import Dict, Optional, List

import pendulum
from lxml import etree

from bpa.publishers.schemas.documentation import Documentation


from .models.industry import IndustryInfo

from .models.rule_usage import RuleUsageInfo
from .models.tsf import TechSupportFile
from .models import query
from .models.manager import ModelManager
from .models.license import LicenseInfo
from .models.system import SystemInfo
from .analyzers.adoption.manager import AdoptionAnalyzerManager
from .analyzers.best_practices.manager import BestPracticesAnalyzerManager
from .publishers.manager import PublisherManager

LOG = logging.getLogger(__name__)


class Controller:
    """Controller component.

    It is the single interface that developers will use the most
    when it comes to the BPA and adoption reports. It handles
    orchestration of the following activities:

    - Collecting data
    - Analyzing data
    - Publishing data

    Attributes:
        tree: A lxml.etree._ElementTree representing the device XML config.
        xpatheval: XPath evaluator.
        version: Version of the codebase.
        urldb: Location of URL database.
        panorama: Boolean flag for Panorama/firewall.
        ancestors: Ancestors of each node in the XML.
        descendants: Descendants of each node in the XML.
        dgs_with_devices: Device groups with devices.
        collector: Feature collector for analysis.
        parser: XML parser from lxml.
    """

    parser = etree.XMLParser(recover=True, huge_tree=True)

    def __init__(self):
        LOG.debug(f"{self.__class__.__name__} initializing")
        self._bpa = None
        self._heatmap = None
        self._metadata = None
        self.model_manager = ModelManager()
        self.bp_manager = BestPracticesAnalyzerManager(self.model_manager)
        self.adoption_manager = AdoptionAnalyzerManager(self.bp_manager)
        self.publisher_manager = PublisherManager(self.adoption_manager)

    @property
    def bpa(self):
        """Evaluate BPA results dynamically."""
        if self._bpa is not None:
            return self._bpa
        else:
            raise NotImplementedError("Not implemented yet")

    @property
    def heatmap(self):
        """Evaluate Adoption results dynamically."""
        if self._heatmap is not None:
            return self._heatmap
        else:
            raise NotImplementedError("Not implemented yet")

    @property
    def metadata(self) -> Dict:
        if self._metadata is None:
            self._metadata = self.model_manager.metadata
        return self._metadata

    @property
    def serial_number(self) -> str:
        """Retrieve the serial number if available."""
        try:
            return self.model_manager.system_info.get("serial", "")
        except AttributeError:
            return ""

    def parse_tsf_generated_date(self, fmt=None):
        """Parse TSF generated date.

        Args:
            format: String with desired formatting options.

        Returns:
            TSF generated date.
        """
        tsf_generated_date = datetime.datetime.strptime(
            self.system_info["Tech Support File Generated Date"], "%Y-%m-%d %H:%M:%S"
        )
        if fmt is not None:
            return tsf_generated_date.strftime(fmt)
        else:
            return tsf_generated_date

    def register_industry_info(self, industry_info: IndustryInfo):
        """This is a helper function to register the industry info that has been externally fetched
        (ideally at the Django level) and make it available in the library at the model manager level"""

        self.model_manager.register_industry_info(industry_info=industry_info)

    @classmethod
    def from_tsf(cls, *args, **kwargs):
        """Instantiate XMLConfig from a Tech Support File.

        Args:
            args: List of arguments.
            kwargs: Dictionary of keyword arguments.

        Returns:
            Controller instance.
        """

        docs = kwargs.pop("documentation", [])
        release_dates = kwargs.pop("release_dates", {})
        tsf = TechSupportFile.read_tsf(*args, **kwargs)
        controller = cls()

        controller.model_manager.register_tsf(tsf, release_dates)
        controller.model_manager.register_documentation_info(docs)
        return controller

    @classmethod
    def from_xml(
        cls,
        xml_source,
        documentation: List[Documentation] = None,
        system_info: Optional[Dict] = None,
        license_info: Optional[LicenseInfo] = None,
        system_time: Optional[pendulum.DateTime] = None,
        rule_usage_info: Optional[RuleUsageInfo] = None,
        release_dates: Optional[Dict] = None,
    ):
        """Instantiate XMLConfig from XML.

        Args:
            documentation: list of Documentation for excel and html publisher.
            xml_source: a file name/path, file object, or file-like object.
            system_info: System information.
            license_info: License information.
            rule_usage_info: Rule usage information.
            release_dates: Release date information.

        Returns:
            Controller instance.
        """
        tree = etree.parse(xml_source, cls.parser)
        controller = cls()
        license_info = license_info or LicenseInfo()
        system_info = SystemInfo() if system_info is None else SystemInfo(system_info)
        system_time = pendulum.now() if system_time is None else system_time
        rule_usage_info = (
            RuleUsageInfo() if rule_usage_info is None else rule_usage_info
        )
        release_dates = release_dates if release_dates is not None else {}
        controller.model_manager.register_core(
            tree, system_info, license_info, system_time, rule_usage_info, release_dates
        )
        if documentation is None:
            documentation = []
        controller.model_manager.register_documentation_info(
            documentation=documentation
        )
        return controller

    @staticmethod
    def parse_zones(xml: etree._ElementTree):
        """Parse zones from security policies.

        Args:
            xml: A config file as an ElementTree object

        Returns:
            A set of tuples. The first item in each tuple is the zone and
            the second item is the device group/vsys.
        """
        zones = query.get_rules_zones(xml)
        zone_collector = set()

        for zone in zones:
            location_element = next(iter(query.get_location(zone)))
            location = location_element.get("name", "shared")
            zone_collector.add((zone.text.rstrip(), location))

        return zone_collector
